// @bun
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getProtoOf = Object.getPrototypeOf;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __toESM = (mod, isNodeMode, target) => {
  target = mod != null ? __create(__getProtoOf(mod)) : {};
  const to = isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target;
  for (let key of __getOwnPropNames(mod))
    if (!__hasOwnProp.call(to, key))
      __defProp(to, key, {
        get: () => mod[key],
        enumerable: true
      });
  return to;
};
var __commonJS = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: (newValue) => all[name] = () => newValue
    });
};

// node_modules/commander/lib/error.js
var require_error = __commonJS((exports) => {
  class CommanderError extends Error {
    constructor(exitCode, code, message) {
      super(message);
      Error.captureStackTrace(this, this.constructor);
      this.name = this.constructor.name;
      this.code = code;
      this.exitCode = exitCode;
      this.nestedError = undefined;
    }
  }

  class InvalidArgumentError extends CommanderError {
    constructor(message) {
      super(1, "commander.invalidArgument", message);
      Error.captureStackTrace(this, this.constructor);
      this.name = this.constructor.name;
    }
  }
  exports.CommanderError = CommanderError;
  exports.InvalidArgumentError = InvalidArgumentError;
});

// node_modules/commander/lib/argument.js
var require_argument = __commonJS((exports) => {
  var humanReadableArgName = function(arg) {
    const nameOutput = arg.name() + (arg.variadic === true ? "..." : "");
    return arg.required ? "<" + nameOutput + ">" : "[" + nameOutput + "]";
  };
  var { InvalidArgumentError } = require_error();

  class Argument {
    constructor(name, description) {
      this.description = description || "";
      this.variadic = false;
      this.parseArg = undefined;
      this.defaultValue = undefined;
      this.defaultValueDescription = undefined;
      this.argChoices = undefined;
      switch (name[0]) {
        case "<":
          this.required = true;
          this._name = name.slice(1, -1);
          break;
        case "[":
          this.required = false;
          this._name = name.slice(1, -1);
          break;
        default:
          this.required = true;
          this._name = name;
          break;
      }
      if (this._name.length > 3 && this._name.slice(-3) === "...") {
        this.variadic = true;
        this._name = this._name.slice(0, -3);
      }
    }
    name() {
      return this._name;
    }
    _concatValue(value, previous) {
      if (previous === this.defaultValue || !Array.isArray(previous)) {
        return [value];
      }
      return previous.concat(value);
    }
    default(value, description) {
      this.defaultValue = value;
      this.defaultValueDescription = description;
      return this;
    }
    argParser(fn) {
      this.parseArg = fn;
      return this;
    }
    choices(values) {
      this.argChoices = values.slice();
      this.parseArg = (arg, previous) => {
        if (!this.argChoices.includes(arg)) {
          throw new InvalidArgumentError(`Allowed choices are ${this.argChoices.join(", ")}.`);
        }
        if (this.variadic) {
          return this._concatValue(arg, previous);
        }
        return arg;
      };
      return this;
    }
    argRequired() {
      this.required = true;
      return this;
    }
    argOptional() {
      this.required = false;
      return this;
    }
  }
  exports.Argument = Argument;
  exports.humanReadableArgName = humanReadableArgName;
});

// node_modules/commander/lib/help.js
var require_help = __commonJS((exports) => {
  var { humanReadableArgName } = require_argument();

  class Help {
    constructor() {
      this.helpWidth = undefined;
      this.sortSubcommands = false;
      this.sortOptions = false;
      this.showGlobalOptions = false;
    }
    visibleCommands(cmd) {
      const visibleCommands = cmd.commands.filter((cmd2) => !cmd2._hidden);
      const helpCommand = cmd._getHelpCommand();
      if (helpCommand && !helpCommand._hidden) {
        visibleCommands.push(helpCommand);
      }
      if (this.sortSubcommands) {
        visibleCommands.sort((a, b) => {
          return a.name().localeCompare(b.name());
        });
      }
      return visibleCommands;
    }
    compareOptions(a, b) {
      const getSortKey = (option) => {
        return option.short ? option.short.replace(/^-/, "") : option.long.replace(/^--/, "");
      };
      return getSortKey(a).localeCompare(getSortKey(b));
    }
    visibleOptions(cmd) {
      const visibleOptions = cmd.options.filter((option) => !option.hidden);
      const helpOption = cmd._getHelpOption();
      if (helpOption && !helpOption.hidden) {
        const removeShort = helpOption.short && cmd._findOption(helpOption.short);
        const removeLong = helpOption.long && cmd._findOption(helpOption.long);
        if (!removeShort && !removeLong) {
          visibleOptions.push(helpOption);
        } else if (helpOption.long && !removeLong) {
          visibleOptions.push(cmd.createOption(helpOption.long, helpOption.description));
        } else if (helpOption.short && !removeShort) {
          visibleOptions.push(cmd.createOption(helpOption.short, helpOption.description));
        }
      }
      if (this.sortOptions) {
        visibleOptions.sort(this.compareOptions);
      }
      return visibleOptions;
    }
    visibleGlobalOptions(cmd) {
      if (!this.showGlobalOptions)
        return [];
      const globalOptions = [];
      for (let ancestorCmd = cmd.parent;ancestorCmd; ancestorCmd = ancestorCmd.parent) {
        const visibleOptions = ancestorCmd.options.filter((option) => !option.hidden);
        globalOptions.push(...visibleOptions);
      }
      if (this.sortOptions) {
        globalOptions.sort(this.compareOptions);
      }
      return globalOptions;
    }
    visibleArguments(cmd) {
      if (cmd._argsDescription) {
        cmd.registeredArguments.forEach((argument) => {
          argument.description = argument.description || cmd._argsDescription[argument.name()] || "";
        });
      }
      if (cmd.registeredArguments.find((argument) => argument.description)) {
        return cmd.registeredArguments;
      }
      return [];
    }
    subcommandTerm(cmd) {
      const args = cmd.registeredArguments.map((arg) => humanReadableArgName(arg)).join(" ");
      return cmd._name + (cmd._aliases[0] ? "|" + cmd._aliases[0] : "") + (cmd.options.length ? " [options]" : "") + (args ? " " + args : "");
    }
    optionTerm(option) {
      return option.flags;
    }
    argumentTerm(argument) {
      return argument.name();
    }
    longestSubcommandTermLength(cmd, helper) {
      return helper.visibleCommands(cmd).reduce((max, command) => {
        return Math.max(max, helper.subcommandTerm(command).length);
      }, 0);
    }
    longestOptionTermLength(cmd, helper) {
      return helper.visibleOptions(cmd).reduce((max, option) => {
        return Math.max(max, helper.optionTerm(option).length);
      }, 0);
    }
    longestGlobalOptionTermLength(cmd, helper) {
      return helper.visibleGlobalOptions(cmd).reduce((max, option) => {
        return Math.max(max, helper.optionTerm(option).length);
      }, 0);
    }
    longestArgumentTermLength(cmd, helper) {
      return helper.visibleArguments(cmd).reduce((max, argument) => {
        return Math.max(max, helper.argumentTerm(argument).length);
      }, 0);
    }
    commandUsage(cmd) {
      let cmdName = cmd._name;
      if (cmd._aliases[0]) {
        cmdName = cmdName + "|" + cmd._aliases[0];
      }
      let ancestorCmdNames = "";
      for (let ancestorCmd = cmd.parent;ancestorCmd; ancestorCmd = ancestorCmd.parent) {
        ancestorCmdNames = ancestorCmd.name() + " " + ancestorCmdNames;
      }
      return ancestorCmdNames + cmdName + " " + cmd.usage();
    }
    commandDescription(cmd) {
      return cmd.description();
    }
    subcommandDescription(cmd) {
      return cmd.summary() || cmd.description();
    }
    optionDescription(option) {
      const extraInfo = [];
      if (option.argChoices) {
        extraInfo.push(`choices: ${option.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`);
      }
      if (option.defaultValue !== undefined) {
        const showDefault = option.required || option.optional || option.isBoolean() && typeof option.defaultValue === "boolean";
        if (showDefault) {
          extraInfo.push(`default: ${option.defaultValueDescription || JSON.stringify(option.defaultValue)}`);
        }
      }
      if (option.presetArg !== undefined && option.optional) {
        extraInfo.push(`preset: ${JSON.stringify(option.presetArg)}`);
      }
      if (option.envVar !== undefined) {
        extraInfo.push(`env: ${option.envVar}`);
      }
      if (extraInfo.length > 0) {
        return `${option.description} (${extraInfo.join(", ")})`;
      }
      return option.description;
    }
    argumentDescription(argument) {
      const extraInfo = [];
      if (argument.argChoices) {
        extraInfo.push(`choices: ${argument.argChoices.map((choice) => JSON.stringify(choice)).join(", ")}`);
      }
      if (argument.defaultValue !== undefined) {
        extraInfo.push(`default: ${argument.defaultValueDescription || JSON.stringify(argument.defaultValue)}`);
      }
      if (extraInfo.length > 0) {
        const extraDescripton = `(${extraInfo.join(", ")})`;
        if (argument.description) {
          return `${argument.description} ${extraDescripton}`;
        }
        return extraDescripton;
      }
      return argument.description;
    }
    formatHelp(cmd, helper) {
      const termWidth = helper.padWidth(cmd, helper);
      const helpWidth = helper.helpWidth || 80;
      const itemIndentWidth = 2;
      const itemSeparatorWidth = 2;
      function formatItem(term, description) {
        if (description) {
          const fullText = `${term.padEnd(termWidth + itemSeparatorWidth)}${description}`;
          return helper.wrap(fullText, helpWidth - itemIndentWidth, termWidth + itemSeparatorWidth);
        }
        return term;
      }
      function formatList(textArray) {
        return textArray.join("\n").replace(/^/gm, " ".repeat(itemIndentWidth));
      }
      let output = [`Usage: ${helper.commandUsage(cmd)}`, ""];
      const commandDescription = helper.commandDescription(cmd);
      if (commandDescription.length > 0) {
        output = output.concat([
          helper.wrap(commandDescription, helpWidth, 0),
          ""
        ]);
      }
      const argumentList = helper.visibleArguments(cmd).map((argument) => {
        return formatItem(helper.argumentTerm(argument), helper.argumentDescription(argument));
      });
      if (argumentList.length > 0) {
        output = output.concat(["Arguments:", formatList(argumentList), ""]);
      }
      const optionList = helper.visibleOptions(cmd).map((option) => {
        return formatItem(helper.optionTerm(option), helper.optionDescription(option));
      });
      if (optionList.length > 0) {
        output = output.concat(["Options:", formatList(optionList), ""]);
      }
      if (this.showGlobalOptions) {
        const globalOptionList = helper.visibleGlobalOptions(cmd).map((option) => {
          return formatItem(helper.optionTerm(option), helper.optionDescription(option));
        });
        if (globalOptionList.length > 0) {
          output = output.concat([
            "Global Options:",
            formatList(globalOptionList),
            ""
          ]);
        }
      }
      const commandList = helper.visibleCommands(cmd).map((cmd2) => {
        return formatItem(helper.subcommandTerm(cmd2), helper.subcommandDescription(cmd2));
      });
      if (commandList.length > 0) {
        output = output.concat(["Commands:", formatList(commandList), ""]);
      }
      return output.join("\n");
    }
    padWidth(cmd, helper) {
      return Math.max(helper.longestOptionTermLength(cmd, helper), helper.longestGlobalOptionTermLength(cmd, helper), helper.longestSubcommandTermLength(cmd, helper), helper.longestArgumentTermLength(cmd, helper));
    }
    wrap(str, width, indent, minColumnWidth = 40) {
      const indents = " \\f\\t\\v\xA0\u1680\u2000-\u200A\u202F\u205F\u3000\uFEFF";
      const manualIndent = new RegExp(`[\\n][${indents}]+`);
      if (str.match(manualIndent))
        return str;
      const columnWidth = width - indent;
      if (columnWidth < minColumnWidth)
        return str;
      const leadingStr = str.slice(0, indent);
      const columnText = str.slice(indent).replace("\r\n", "\n");
      const indentString = " ".repeat(indent);
      const zeroWidthSpace = "\u200B";
      const breaks = `\\s${zeroWidthSpace}`;
      const regex = new RegExp(`\n|.{1,${columnWidth - 1}}([${breaks}]|\$)|[^${breaks}]+?([${breaks}]|\$)`, "g");
      const lines = columnText.match(regex) || [];
      return leadingStr + lines.map((line, i) => {
        if (line === "\n")
          return "";
        return (i > 0 ? indentString : "") + line.trimEnd();
      }).join("\n");
    }
  }
  exports.Help = Help;
});

// node_modules/commander/lib/option.js
var require_option = __commonJS((exports) => {
  var camelcase = function(str) {
    return str.split("-").reduce((str2, word) => {
      return str2 + word[0].toUpperCase() + word.slice(1);
    });
  };
  var splitOptionFlags = function(flags) {
    let shortFlag;
    let longFlag;
    const flagParts = flags.split(/[ |,]+/);
    if (flagParts.length > 1 && !/^[[<]/.test(flagParts[1]))
      shortFlag = flagParts.shift();
    longFlag = flagParts.shift();
    if (!shortFlag && /^-[^-]$/.test(longFlag)) {
      shortFlag = longFlag;
      longFlag = undefined;
    }
    return { shortFlag, longFlag };
  };
  var { InvalidArgumentError } = require_error();

  class Option {
    constructor(flags, description) {
      this.flags = flags;
      this.description = description || "";
      this.required = flags.includes("<");
      this.optional = flags.includes("[");
      this.variadic = /\w\.\.\.[>\]]$/.test(flags);
      this.mandatory = false;
      const optionFlags = splitOptionFlags(flags);
      this.short = optionFlags.shortFlag;
      this.long = optionFlags.longFlag;
      this.negate = false;
      if (this.long) {
        this.negate = this.long.startsWith("--no-");
      }
      this.defaultValue = undefined;
      this.defaultValueDescription = undefined;
      this.presetArg = undefined;
      this.envVar = undefined;
      this.parseArg = undefined;
      this.hidden = false;
      this.argChoices = undefined;
      this.conflictsWith = [];
      this.implied = undefined;
    }
    default(value, description) {
      this.defaultValue = value;
      this.defaultValueDescription = description;
      return this;
    }
    preset(arg) {
      this.presetArg = arg;
      return this;
    }
    conflicts(names) {
      this.conflictsWith = this.conflictsWith.concat(names);
      return this;
    }
    implies(impliedOptionValues) {
      let newImplied = impliedOptionValues;
      if (typeof impliedOptionValues === "string") {
        newImplied = { [impliedOptionValues]: true };
      }
      this.implied = Object.assign(this.implied || {}, newImplied);
      return this;
    }
    env(name) {
      this.envVar = name;
      return this;
    }
    argParser(fn) {
      this.parseArg = fn;
      return this;
    }
    makeOptionMandatory(mandatory = true) {
      this.mandatory = !!mandatory;
      return this;
    }
    hideHelp(hide = true) {
      this.hidden = !!hide;
      return this;
    }
    _concatValue(value, previous) {
      if (previous === this.defaultValue || !Array.isArray(previous)) {
        return [value];
      }
      return previous.concat(value);
    }
    choices(values) {
      this.argChoices = values.slice();
      this.parseArg = (arg, previous) => {
        if (!this.argChoices.includes(arg)) {
          throw new InvalidArgumentError(`Allowed choices are ${this.argChoices.join(", ")}.`);
        }
        if (this.variadic) {
          return this._concatValue(arg, previous);
        }
        return arg;
      };
      return this;
    }
    name() {
      if (this.long) {
        return this.long.replace(/^--/, "");
      }
      return this.short.replace(/^-/, "");
    }
    attributeName() {
      return camelcase(this.name().replace(/^no-/, ""));
    }
    is(arg) {
      return this.short === arg || this.long === arg;
    }
    isBoolean() {
      return !this.required && !this.optional && !this.negate;
    }
  }

  class DualOptions {
    constructor(options) {
      this.positiveOptions = new Map;
      this.negativeOptions = new Map;
      this.dualOptions = new Set;
      options.forEach((option) => {
        if (option.negate) {
          this.negativeOptions.set(option.attributeName(), option);
        } else {
          this.positiveOptions.set(option.attributeName(), option);
        }
      });
      this.negativeOptions.forEach((value, key) => {
        if (this.positiveOptions.has(key)) {
          this.dualOptions.add(key);
        }
      });
    }
    valueFromOption(value, option) {
      const optionKey = option.attributeName();
      if (!this.dualOptions.has(optionKey))
        return true;
      const preset = this.negativeOptions.get(optionKey).presetArg;
      const negativeValue = preset !== undefined ? preset : false;
      return option.negate === (negativeValue === value);
    }
  }
  exports.Option = Option;
  exports.DualOptions = DualOptions;
});

// node_modules/commander/lib/suggestSimilar.js
var require_suggestSimilar = __commonJS((exports) => {
  var editDistance = function(a, b) {
    if (Math.abs(a.length - b.length) > maxDistance)
      return Math.max(a.length, b.length);
    const d = [];
    for (let i = 0;i <= a.length; i++) {
      d[i] = [i];
    }
    for (let j = 0;j <= b.length; j++) {
      d[0][j] = j;
    }
    for (let j = 1;j <= b.length; j++) {
      for (let i = 1;i <= a.length; i++) {
        let cost = 1;
        if (a[i - 1] === b[j - 1]) {
          cost = 0;
        } else {
          cost = 1;
        }
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost);
        if (i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1]) {
          d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
        }
      }
    }
    return d[a.length][b.length];
  };
  var suggestSimilar = function(word, candidates) {
    if (!candidates || candidates.length === 0)
      return "";
    candidates = Array.from(new Set(candidates));
    const searchingOptions = word.startsWith("--");
    if (searchingOptions) {
      word = word.slice(2);
      candidates = candidates.map((candidate) => candidate.slice(2));
    }
    let similar = [];
    let bestDistance = maxDistance;
    const minSimilarity = 0.4;
    candidates.forEach((candidate) => {
      if (candidate.length <= 1)
        return;
      const distance = editDistance(word, candidate);
      const length = Math.max(word.length, candidate.length);
      const similarity = (length - distance) / length;
      if (similarity > minSimilarity) {
        if (distance < bestDistance) {
          bestDistance = distance;
          similar = [candidate];
        } else if (distance === bestDistance) {
          similar.push(candidate);
        }
      }
    });
    similar.sort((a, b) => a.localeCompare(b));
    if (searchingOptions) {
      similar = similar.map((candidate) => `--${candidate}`);
    }
    if (similar.length > 1) {
      return `\n(Did you mean one of ${similar.join(", ")}?)`;
    }
    if (similar.length === 1) {
      return `\n(Did you mean ${similar[0]}?)`;
    }
    return "";
  };
  var maxDistance = 3;
  exports.suggestSimilar = suggestSimilar;
});

// node_modules/commander/lib/command.js
var require_command = __commonJS((exports) => {
  var incrementNodeInspectorPort = function(args) {
    return args.map((arg) => {
      if (!arg.startsWith("--inspect")) {
        return arg;
      }
      let debugOption;
      let debugHost = "127.0.0.1";
      let debugPort = "9229";
      let match;
      if ((match = arg.match(/^(--inspect(-brk)?)$/)) !== null) {
        debugOption = match[1];
      } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+)$/)) !== null) {
        debugOption = match[1];
        if (/^\d+$/.test(match[3])) {
          debugPort = match[3];
        } else {
          debugHost = match[3];
        }
      } else if ((match = arg.match(/^(--inspect(-brk|-port)?)=([^:]+):(\d+)$/)) !== null) {
        debugOption = match[1];
        debugHost = match[3];
        debugPort = match[4];
      }
      if (debugOption && debugPort !== "0") {
        return `${debugOption}=${debugHost}:${parseInt(debugPort) + 1}`;
      }
      return arg;
    });
  };
  var EventEmitter = import.meta.require("events").EventEmitter;
  var childProcess = import.meta.require("child_process");
  var path = import.meta.require("path");
  var fs = import.meta.require("fs");
  var process2 = import.meta.require("process");
  var { Argument, humanReadableArgName } = require_argument();
  var { CommanderError } = require_error();
  var { Help } = require_help();
  var { Option, DualOptions } = require_option();
  var { suggestSimilar } = require_suggestSimilar();

  class Command extends EventEmitter {
    constructor(name) {
      super();
      this.commands = [];
      this.options = [];
      this.parent = null;
      this._allowUnknownOption = false;
      this._allowExcessArguments = true;
      this.registeredArguments = [];
      this._args = this.registeredArguments;
      this.args = [];
      this.rawArgs = [];
      this.processedArgs = [];
      this._scriptPath = null;
      this._name = name || "";
      this._optionValues = {};
      this._optionValueSources = {};
      this._storeOptionsAsProperties = false;
      this._actionHandler = null;
      this._executableHandler = false;
      this._executableFile = null;
      this._executableDir = null;
      this._defaultCommandName = null;
      this._exitCallback = null;
      this._aliases = [];
      this._combineFlagAndOptionalValue = true;
      this._description = "";
      this._summary = "";
      this._argsDescription = undefined;
      this._enablePositionalOptions = false;
      this._passThroughOptions = false;
      this._lifeCycleHooks = {};
      this._showHelpAfterError = false;
      this._showSuggestionAfterError = true;
      this._outputConfiguration = {
        writeOut: (str) => process2.stdout.write(str),
        writeErr: (str) => process2.stderr.write(str),
        getOutHelpWidth: () => process2.stdout.isTTY ? process2.stdout.columns : undefined,
        getErrHelpWidth: () => process2.stderr.isTTY ? process2.stderr.columns : undefined,
        outputError: (str, write) => write(str)
      };
      this._hidden = false;
      this._helpOption = undefined;
      this._addImplicitHelpCommand = undefined;
      this._helpCommand = undefined;
      this._helpConfiguration = {};
    }
    copyInheritedSettings(sourceCommand) {
      this._outputConfiguration = sourceCommand._outputConfiguration;
      this._helpOption = sourceCommand._helpOption;
      this._helpCommand = sourceCommand._helpCommand;
      this._helpConfiguration = sourceCommand._helpConfiguration;
      this._exitCallback = sourceCommand._exitCallback;
      this._storeOptionsAsProperties = sourceCommand._storeOptionsAsProperties;
      this._combineFlagAndOptionalValue = sourceCommand._combineFlagAndOptionalValue;
      this._allowExcessArguments = sourceCommand._allowExcessArguments;
      this._enablePositionalOptions = sourceCommand._enablePositionalOptions;
      this._showHelpAfterError = sourceCommand._showHelpAfterError;
      this._showSuggestionAfterError = sourceCommand._showSuggestionAfterError;
      return this;
    }
    _getCommandAndAncestors() {
      const result = [];
      for (let command = this;command; command = command.parent) {
        result.push(command);
      }
      return result;
    }
    command(nameAndArgs, actionOptsOrExecDesc, execOpts) {
      let desc = actionOptsOrExecDesc;
      let opts = execOpts;
      if (typeof desc === "object" && desc !== null) {
        opts = desc;
        desc = null;
      }
      opts = opts || {};
      const [, name, args] = nameAndArgs.match(/([^ ]+) *(.*)/);
      const cmd = this.createCommand(name);
      if (desc) {
        cmd.description(desc);
        cmd._executableHandler = true;
      }
      if (opts.isDefault)
        this._defaultCommandName = cmd._name;
      cmd._hidden = !!(opts.noHelp || opts.hidden);
      cmd._executableFile = opts.executableFile || null;
      if (args)
        cmd.arguments(args);
      this._registerCommand(cmd);
      cmd.parent = this;
      cmd.copyInheritedSettings(this);
      if (desc)
        return this;
      return cmd;
    }
    createCommand(name) {
      return new Command(name);
    }
    createHelp() {
      return Object.assign(new Help, this.configureHelp());
    }
    configureHelp(configuration) {
      if (configuration === undefined)
        return this._helpConfiguration;
      this._helpConfiguration = configuration;
      return this;
    }
    configureOutput(configuration) {
      if (configuration === undefined)
        return this._outputConfiguration;
      Object.assign(this._outputConfiguration, configuration);
      return this;
    }
    showHelpAfterError(displayHelp = true) {
      if (typeof displayHelp !== "string")
        displayHelp = !!displayHelp;
      this._showHelpAfterError = displayHelp;
      return this;
    }
    showSuggestionAfterError(displaySuggestion = true) {
      this._showSuggestionAfterError = !!displaySuggestion;
      return this;
    }
    addCommand(cmd, opts) {
      if (!cmd._name) {
        throw new Error(`Command passed to .addCommand() must have a name
- specify the name in Command constructor or using .name()`);
      }
      opts = opts || {};
      if (opts.isDefault)
        this._defaultCommandName = cmd._name;
      if (opts.noHelp || opts.hidden)
        cmd._hidden = true;
      this._registerCommand(cmd);
      cmd.parent = this;
      cmd._checkForBrokenPassThrough();
      return this;
    }
    createArgument(name, description) {
      return new Argument(name, description);
    }
    argument(name, description, fn, defaultValue) {
      const argument = this.createArgument(name, description);
      if (typeof fn === "function") {
        argument.default(defaultValue).argParser(fn);
      } else {
        argument.default(fn);
      }
      this.addArgument(argument);
      return this;
    }
    arguments(names) {
      names.trim().split(/ +/).forEach((detail) => {
        this.argument(detail);
      });
      return this;
    }
    addArgument(argument) {
      const previousArgument = this.registeredArguments.slice(-1)[0];
      if (previousArgument && previousArgument.variadic) {
        throw new Error(`only the last argument can be variadic '${previousArgument.name()}'`);
      }
      if (argument.required && argument.defaultValue !== undefined && argument.parseArg === undefined) {
        throw new Error(`a default value for a required argument is never used: '${argument.name()}'`);
      }
      this.registeredArguments.push(argument);
      return this;
    }
    helpCommand(enableOrNameAndArgs, description) {
      if (typeof enableOrNameAndArgs === "boolean") {
        this._addImplicitHelpCommand = enableOrNameAndArgs;
        return this;
      }
      enableOrNameAndArgs = enableOrNameAndArgs ?? "help [command]";
      const [, helpName, helpArgs] = enableOrNameAndArgs.match(/([^ ]+) *(.*)/);
      const helpDescription = description ?? "display help for command";
      const helpCommand = this.createCommand(helpName);
      helpCommand.helpOption(false);
      if (helpArgs)
        helpCommand.arguments(helpArgs);
      if (helpDescription)
        helpCommand.description(helpDescription);
      this._addImplicitHelpCommand = true;
      this._helpCommand = helpCommand;
      return this;
    }
    addHelpCommand(helpCommand, deprecatedDescription) {
      if (typeof helpCommand !== "object") {
        this.helpCommand(helpCommand, deprecatedDescription);
        return this;
      }
      this._addImplicitHelpCommand = true;
      this._helpCommand = helpCommand;
      return this;
    }
    _getHelpCommand() {
      const hasImplicitHelpCommand = this._addImplicitHelpCommand ?? (this.commands.length && !this._actionHandler && !this._findCommand("help"));
      if (hasImplicitHelpCommand) {
        if (this._helpCommand === undefined) {
          this.helpCommand(undefined, undefined);
        }
        return this._helpCommand;
      }
      return null;
    }
    hook(event, listener) {
      const allowedValues = ["preSubcommand", "preAction", "postAction"];
      if (!allowedValues.includes(event)) {
        throw new Error(`Unexpected value for event passed to hook : '${event}'.
Expecting one of '${allowedValues.join("', '")}'`);
      }
      if (this._lifeCycleHooks[event]) {
        this._lifeCycleHooks[event].push(listener);
      } else {
        this._lifeCycleHooks[event] = [listener];
      }
      return this;
    }
    exitOverride(fn) {
      if (fn) {
        this._exitCallback = fn;
      } else {
        this._exitCallback = (err) => {
          if (err.code !== "commander.executeSubCommandAsync") {
            throw err;
          } else {
          }
        };
      }
      return this;
    }
    _exit(exitCode, code, message) {
      if (this._exitCallback) {
        this._exitCallback(new CommanderError(exitCode, code, message));
      }
      process2.exit(exitCode);
    }
    action(fn) {
      const listener = (args) => {
        const expectedArgsCount = this.registeredArguments.length;
        const actionArgs = args.slice(0, expectedArgsCount);
        if (this._storeOptionsAsProperties) {
          actionArgs[expectedArgsCount] = this;
        } else {
          actionArgs[expectedArgsCount] = this.opts();
        }
        actionArgs.push(this);
        return fn.apply(this, actionArgs);
      };
      this._actionHandler = listener;
      return this;
    }
    createOption(flags, description) {
      return new Option(flags, description);
    }
    _callParseArg(target, value, previous, invalidArgumentMessage) {
      try {
        return target.parseArg(value, previous);
      } catch (err) {
        if (err.code === "commander.invalidArgument") {
          const message = `${invalidArgumentMessage} ${err.message}`;
          this.error(message, { exitCode: err.exitCode, code: err.code });
        }
        throw err;
      }
    }
    _registerOption(option) {
      const matchingOption = option.short && this._findOption(option.short) || option.long && this._findOption(option.long);
      if (matchingOption) {
        const matchingFlag = option.long && this._findOption(option.long) ? option.long : option.short;
        throw new Error(`Cannot add option '${option.flags}'${this._name && ` to command '${this._name}'`} due to conflicting flag '${matchingFlag}'
-  already used by option '${matchingOption.flags}'`);
      }
      this.options.push(option);
    }
    _registerCommand(command) {
      const knownBy = (cmd) => {
        return [cmd.name()].concat(cmd.aliases());
      };
      const alreadyUsed = knownBy(command).find((name) => this._findCommand(name));
      if (alreadyUsed) {
        const existingCmd = knownBy(this._findCommand(alreadyUsed)).join("|");
        const newCmd = knownBy(command).join("|");
        throw new Error(`cannot add command '${newCmd}' as already have command '${existingCmd}'`);
      }
      this.commands.push(command);
    }
    addOption(option) {
      this._registerOption(option);
      const oname = option.name();
      const name = option.attributeName();
      if (option.negate) {
        const positiveLongFlag = option.long.replace(/^--no-/, "--");
        if (!this._findOption(positiveLongFlag)) {
          this.setOptionValueWithSource(name, option.defaultValue === undefined ? true : option.defaultValue, "default");
        }
      } else if (option.defaultValue !== undefined) {
        this.setOptionValueWithSource(name, option.defaultValue, "default");
      }
      const handleOptionValue = (val, invalidValueMessage, valueSource) => {
        if (val == null && option.presetArg !== undefined) {
          val = option.presetArg;
        }
        const oldValue = this.getOptionValue(name);
        if (val !== null && option.parseArg) {
          val = this._callParseArg(option, val, oldValue, invalidValueMessage);
        } else if (val !== null && option.variadic) {
          val = option._concatValue(val, oldValue);
        }
        if (val == null) {
          if (option.negate) {
            val = false;
          } else if (option.isBoolean() || option.optional) {
            val = true;
          } else {
            val = "";
          }
        }
        this.setOptionValueWithSource(name, val, valueSource);
      };
      this.on("option:" + oname, (val) => {
        const invalidValueMessage = `error: option '${option.flags}' argument '${val}' is invalid.`;
        handleOptionValue(val, invalidValueMessage, "cli");
      });
      if (option.envVar) {
        this.on("optionEnv:" + oname, (val) => {
          const invalidValueMessage = `error: option '${option.flags}' value '${val}' from env '${option.envVar}' is invalid.`;
          handleOptionValue(val, invalidValueMessage, "env");
        });
      }
      return this;
    }
    _optionEx(config, flags, description, fn, defaultValue) {
      if (typeof flags === "object" && flags instanceof Option) {
        throw new Error("To add an Option object use addOption() instead of option() or requiredOption()");
      }
      const option = this.createOption(flags, description);
      option.makeOptionMandatory(!!config.mandatory);
      if (typeof fn === "function") {
        option.default(defaultValue).argParser(fn);
      } else if (fn instanceof RegExp) {
        const regex = fn;
        fn = (val, def) => {
          const m = regex.exec(val);
          return m ? m[0] : def;
        };
        option.default(defaultValue).argParser(fn);
      } else {
        option.default(fn);
      }
      return this.addOption(option);
    }
    option(flags, description, parseArg, defaultValue) {
      return this._optionEx({}, flags, description, parseArg, defaultValue);
    }
    requiredOption(flags, description, parseArg, defaultValue) {
      return this._optionEx({ mandatory: true }, flags, description, parseArg, defaultValue);
    }
    combineFlagAndOptionalValue(combine = true) {
      this._combineFlagAndOptionalValue = !!combine;
      return this;
    }
    allowUnknownOption(allowUnknown = true) {
      this._allowUnknownOption = !!allowUnknown;
      return this;
    }
    allowExcessArguments(allowExcess = true) {
      this._allowExcessArguments = !!allowExcess;
      return this;
    }
    enablePositionalOptions(positional = true) {
      this._enablePositionalOptions = !!positional;
      return this;
    }
    passThroughOptions(passThrough = true) {
      this._passThroughOptions = !!passThrough;
      this._checkForBrokenPassThrough();
      return this;
    }
    _checkForBrokenPassThrough() {
      if (this.parent && this._passThroughOptions && !this.parent._enablePositionalOptions) {
        throw new Error(`passThroughOptions cannot be used for '${this._name}' without turning on enablePositionalOptions for parent command(s)`);
      }
    }
    storeOptionsAsProperties(storeAsProperties = true) {
      if (this.options.length) {
        throw new Error("call .storeOptionsAsProperties() before adding options");
      }
      if (Object.keys(this._optionValues).length) {
        throw new Error("call .storeOptionsAsProperties() before setting option values");
      }
      this._storeOptionsAsProperties = !!storeAsProperties;
      return this;
    }
    getOptionValue(key) {
      if (this._storeOptionsAsProperties) {
        return this[key];
      }
      return this._optionValues[key];
    }
    setOptionValue(key, value) {
      return this.setOptionValueWithSource(key, value, undefined);
    }
    setOptionValueWithSource(key, value, source) {
      if (this._storeOptionsAsProperties) {
        this[key] = value;
      } else {
        this._optionValues[key] = value;
      }
      this._optionValueSources[key] = source;
      return this;
    }
    getOptionValueSource(key) {
      return this._optionValueSources[key];
    }
    getOptionValueSourceWithGlobals(key) {
      let source;
      this._getCommandAndAncestors().forEach((cmd) => {
        if (cmd.getOptionValueSource(key) !== undefined) {
          source = cmd.getOptionValueSource(key);
        }
      });
      return source;
    }
    _prepareUserArgs(argv, parseOptions) {
      if (argv !== undefined && !Array.isArray(argv)) {
        throw new Error("first parameter to parse must be array or undefined");
      }
      parseOptions = parseOptions || {};
      if (argv === undefined && parseOptions.from === undefined) {
        if (process2.versions?.electron) {
          parseOptions.from = "electron";
        }
        const execArgv = process2.execArgv ?? [];
        if (execArgv.includes("-e") || execArgv.includes("--eval") || execArgv.includes("-p") || execArgv.includes("--print")) {
          parseOptions.from = "eval";
        }
      }
      if (argv === undefined) {
        argv = process2.argv;
      }
      this.rawArgs = argv.slice();
      let userArgs;
      switch (parseOptions.from) {
        case undefined:
        case "node":
          this._scriptPath = argv[1];
          userArgs = argv.slice(2);
          break;
        case "electron":
          if (process2.defaultApp) {
            this._scriptPath = argv[1];
            userArgs = argv.slice(2);
          } else {
            userArgs = argv.slice(1);
          }
          break;
        case "user":
          userArgs = argv.slice(0);
          break;
        case "eval":
          userArgs = argv.slice(1);
          break;
        default:
          throw new Error(`unexpected parse option { from: '${parseOptions.from}' }`);
      }
      if (!this._name && this._scriptPath)
        this.nameFromFilename(this._scriptPath);
      this._name = this._name || "program";
      return userArgs;
    }
    parse(argv, parseOptions) {
      const userArgs = this._prepareUserArgs(argv, parseOptions);
      this._parseCommand([], userArgs);
      return this;
    }
    async parseAsync(argv, parseOptions) {
      const userArgs = this._prepareUserArgs(argv, parseOptions);
      await this._parseCommand([], userArgs);
      return this;
    }
    _executeSubCommand(subcommand, args) {
      args = args.slice();
      let launchWithNode = false;
      const sourceExt = [".js", ".ts", ".tsx", ".mjs", ".cjs"];
      function findFile(baseDir, baseName) {
        const localBin = path.resolve(baseDir, baseName);
        if (fs.existsSync(localBin))
          return localBin;
        if (sourceExt.includes(path.extname(baseName)))
          return;
        const foundExt = sourceExt.find((ext) => fs.existsSync(`${localBin}${ext}`));
        if (foundExt)
          return `${localBin}${foundExt}`;
        return;
      }
      this._checkForMissingMandatoryOptions();
      this._checkForConflictingOptions();
      let executableFile = subcommand._executableFile || `${this._name}-${subcommand._name}`;
      let executableDir = this._executableDir || "";
      if (this._scriptPath) {
        let resolvedScriptPath;
        try {
          resolvedScriptPath = fs.realpathSync(this._scriptPath);
        } catch (err) {
          resolvedScriptPath = this._scriptPath;
        }
        executableDir = path.resolve(path.dirname(resolvedScriptPath), executableDir);
      }
      if (executableDir) {
        let localFile = findFile(executableDir, executableFile);
        if (!localFile && !subcommand._executableFile && this._scriptPath) {
          const legacyName = path.basename(this._scriptPath, path.extname(this._scriptPath));
          if (legacyName !== this._name) {
            localFile = findFile(executableDir, `${legacyName}-${subcommand._name}`);
          }
        }
        executableFile = localFile || executableFile;
      }
      launchWithNode = sourceExt.includes(path.extname(executableFile));
      let proc;
      if (process2.platform !== "win32") {
        if (launchWithNode) {
          args.unshift(executableFile);
          args = incrementNodeInspectorPort(process2.execArgv).concat(args);
          proc = childProcess.spawn(process2.argv[0], args, { stdio: "inherit" });
        } else {
          proc = childProcess.spawn(executableFile, args, { stdio: "inherit" });
        }
      } else {
        args.unshift(executableFile);
        args = incrementNodeInspectorPort(process2.execArgv).concat(args);
        proc = childProcess.spawn(process2.execPath, args, { stdio: "inherit" });
      }
      if (!proc.killed) {
        const signals = ["SIGUSR1", "SIGUSR2", "SIGTERM", "SIGINT", "SIGHUP"];
        signals.forEach((signal) => {
          process2.on(signal, () => {
            if (proc.killed === false && proc.exitCode === null) {
              proc.kill(signal);
            }
          });
        });
      }
      const exitCallback = this._exitCallback;
      proc.on("close", (code) => {
        code = code ?? 1;
        if (!exitCallback) {
          process2.exit(code);
        } else {
          exitCallback(new CommanderError(code, "commander.executeSubCommandAsync", "(close)"));
        }
      });
      proc.on("error", (err) => {
        if (err.code === "ENOENT") {
          const executableDirMessage = executableDir ? `searched for local subcommand relative to directory '${executableDir}'` : "no directory for search for local subcommand, use .executableDir() to supply a custom directory";
          const executableMissing = `'${executableFile}' does not exist
 - if '${subcommand._name}' is not meant to be an executable command, remove description parameter from '.command()' and use '.description()' instead
 - if the default executable name is not suitable, use the executableFile option to supply a custom name or path
 - ${executableDirMessage}`;
          throw new Error(executableMissing);
        } else if (err.code === "EACCES") {
          throw new Error(`'${executableFile}' not executable`);
        }
        if (!exitCallback) {
          process2.exit(1);
        } else {
          const wrappedError = new CommanderError(1, "commander.executeSubCommandAsync", "(error)");
          wrappedError.nestedError = err;
          exitCallback(wrappedError);
        }
      });
      this.runningCommand = proc;
    }
    _dispatchSubcommand(commandName, operands, unknown) {
      const subCommand = this._findCommand(commandName);
      if (!subCommand)
        this.help({ error: true });
      let promiseChain;
      promiseChain = this._chainOrCallSubCommandHook(promiseChain, subCommand, "preSubcommand");
      promiseChain = this._chainOrCall(promiseChain, () => {
        if (subCommand._executableHandler) {
          this._executeSubCommand(subCommand, operands.concat(unknown));
        } else {
          return subCommand._parseCommand(operands, unknown);
        }
      });
      return promiseChain;
    }
    _dispatchHelpCommand(subcommandName) {
      if (!subcommandName) {
        this.help();
      }
      const subCommand = this._findCommand(subcommandName);
      if (subCommand && !subCommand._executableHandler) {
        subCommand.help();
      }
      return this._dispatchSubcommand(subcommandName, [], [this._getHelpOption()?.long ?? this._getHelpOption()?.short ?? "--help"]);
    }
    _checkNumberOfArguments() {
      this.registeredArguments.forEach((arg, i) => {
        if (arg.required && this.args[i] == null) {
          this.missingArgument(arg.name());
        }
      });
      if (this.registeredArguments.length > 0 && this.registeredArguments[this.registeredArguments.length - 1].variadic) {
        return;
      }
      if (this.args.length > this.registeredArguments.length) {
        this._excessArguments(this.args);
      }
    }
    _processArguments() {
      const myParseArg = (argument, value, previous) => {
        let parsedValue = value;
        if (value !== null && argument.parseArg) {
          const invalidValueMessage = `error: command-argument value '${value}' is invalid for argument '${argument.name()}'.`;
          parsedValue = this._callParseArg(argument, value, previous, invalidValueMessage);
        }
        return parsedValue;
      };
      this._checkNumberOfArguments();
      const processedArgs = [];
      this.registeredArguments.forEach((declaredArg, index) => {
        let value = declaredArg.defaultValue;
        if (declaredArg.variadic) {
          if (index < this.args.length) {
            value = this.args.slice(index);
            if (declaredArg.parseArg) {
              value = value.reduce((processed, v) => {
                return myParseArg(declaredArg, v, processed);
              }, declaredArg.defaultValue);
            }
          } else if (value === undefined) {
            value = [];
          }
        } else if (index < this.args.length) {
          value = this.args[index];
          if (declaredArg.parseArg) {
            value = myParseArg(declaredArg, value, declaredArg.defaultValue);
          }
        }
        processedArgs[index] = value;
      });
      this.processedArgs = processedArgs;
    }
    _chainOrCall(promise, fn) {
      if (promise && promise.then && typeof promise.then === "function") {
        return promise.then(() => fn());
      }
      return fn();
    }
    _chainOrCallHooks(promise, event) {
      let result = promise;
      const hooks = [];
      this._getCommandAndAncestors().reverse().filter((cmd) => cmd._lifeCycleHooks[event] !== undefined).forEach((hookedCommand) => {
        hookedCommand._lifeCycleHooks[event].forEach((callback) => {
          hooks.push({ hookedCommand, callback });
        });
      });
      if (event === "postAction") {
        hooks.reverse();
      }
      hooks.forEach((hookDetail) => {
        result = this._chainOrCall(result, () => {
          return hookDetail.callback(hookDetail.hookedCommand, this);
        });
      });
      return result;
    }
    _chainOrCallSubCommandHook(promise, subCommand, event) {
      let result = promise;
      if (this._lifeCycleHooks[event] !== undefined) {
        this._lifeCycleHooks[event].forEach((hook) => {
          result = this._chainOrCall(result, () => {
            return hook(this, subCommand);
          });
        });
      }
      return result;
    }
    _parseCommand(operands, unknown) {
      const parsed = this.parseOptions(unknown);
      this._parseOptionsEnv();
      this._parseOptionsImplied();
      operands = operands.concat(parsed.operands);
      unknown = parsed.unknown;
      this.args = operands.concat(unknown);
      if (operands && this._findCommand(operands[0])) {
        return this._dispatchSubcommand(operands[0], operands.slice(1), unknown);
      }
      if (this._getHelpCommand() && operands[0] === this._getHelpCommand().name()) {
        return this._dispatchHelpCommand(operands[1]);
      }
      if (this._defaultCommandName) {
        this._outputHelpIfRequested(unknown);
        return this._dispatchSubcommand(this._defaultCommandName, operands, unknown);
      }
      if (this.commands.length && this.args.length === 0 && !this._actionHandler && !this._defaultCommandName) {
        this.help({ error: true });
      }
      this._outputHelpIfRequested(parsed.unknown);
      this._checkForMissingMandatoryOptions();
      this._checkForConflictingOptions();
      const checkForUnknownOptions = () => {
        if (parsed.unknown.length > 0) {
          this.unknownOption(parsed.unknown[0]);
        }
      };
      const commandEvent = `command:${this.name()}`;
      if (this._actionHandler) {
        checkForUnknownOptions();
        this._processArguments();
        let promiseChain;
        promiseChain = this._chainOrCallHooks(promiseChain, "preAction");
        promiseChain = this._chainOrCall(promiseChain, () => this._actionHandler(this.processedArgs));
        if (this.parent) {
          promiseChain = this._chainOrCall(promiseChain, () => {
            this.parent.emit(commandEvent, operands, unknown);
          });
        }
        promiseChain = this._chainOrCallHooks(promiseChain, "postAction");
        return promiseChain;
      }
      if (this.parent && this.parent.listenerCount(commandEvent)) {
        checkForUnknownOptions();
        this._processArguments();
        this.parent.emit(commandEvent, operands, unknown);
      } else if (operands.length) {
        if (this._findCommand("*")) {
          return this._dispatchSubcommand("*", operands, unknown);
        }
        if (this.listenerCount("command:*")) {
          this.emit("command:*", operands, unknown);
        } else if (this.commands.length) {
          this.unknownCommand();
        } else {
          checkForUnknownOptions();
          this._processArguments();
        }
      } else if (this.commands.length) {
        checkForUnknownOptions();
        this.help({ error: true });
      } else {
        checkForUnknownOptions();
        this._processArguments();
      }
    }
    _findCommand(name) {
      if (!name)
        return;
      return this.commands.find((cmd) => cmd._name === name || cmd._aliases.includes(name));
    }
    _findOption(arg) {
      return this.options.find((option) => option.is(arg));
    }
    _checkForMissingMandatoryOptions() {
      this._getCommandAndAncestors().forEach((cmd) => {
        cmd.options.forEach((anOption) => {
          if (anOption.mandatory && cmd.getOptionValue(anOption.attributeName()) === undefined) {
            cmd.missingMandatoryOptionValue(anOption);
          }
        });
      });
    }
    _checkForConflictingLocalOptions() {
      const definedNonDefaultOptions = this.options.filter((option) => {
        const optionKey = option.attributeName();
        if (this.getOptionValue(optionKey) === undefined) {
          return false;
        }
        return this.getOptionValueSource(optionKey) !== "default";
      });
      const optionsWithConflicting = definedNonDefaultOptions.filter((option) => option.conflictsWith.length > 0);
      optionsWithConflicting.forEach((option) => {
        const conflictingAndDefined = definedNonDefaultOptions.find((defined) => option.conflictsWith.includes(defined.attributeName()));
        if (conflictingAndDefined) {
          this._conflictingOption(option, conflictingAndDefined);
        }
      });
    }
    _checkForConflictingOptions() {
      this._getCommandAndAncestors().forEach((cmd) => {
        cmd._checkForConflictingLocalOptions();
      });
    }
    parseOptions(argv) {
      const operands = [];
      const unknown = [];
      let dest = operands;
      const args = argv.slice();
      function maybeOption(arg) {
        return arg.length > 1 && arg[0] === "-";
      }
      let activeVariadicOption = null;
      while (args.length) {
        const arg = args.shift();
        if (arg === "--") {
          if (dest === unknown)
            dest.push(arg);
          dest.push(...args);
          break;
        }
        if (activeVariadicOption && !maybeOption(arg)) {
          this.emit(`option:${activeVariadicOption.name()}`, arg);
          continue;
        }
        activeVariadicOption = null;
        if (maybeOption(arg)) {
          const option = this._findOption(arg);
          if (option) {
            if (option.required) {
              const value = args.shift();
              if (value === undefined)
                this.optionMissingArgument(option);
              this.emit(`option:${option.name()}`, value);
            } else if (option.optional) {
              let value = null;
              if (args.length > 0 && !maybeOption(args[0])) {
                value = args.shift();
              }
              this.emit(`option:${option.name()}`, value);
            } else {
              this.emit(`option:${option.name()}`);
            }
            activeVariadicOption = option.variadic ? option : null;
            continue;
          }
        }
        if (arg.length > 2 && arg[0] === "-" && arg[1] !== "-") {
          const option = this._findOption(`-${arg[1]}`);
          if (option) {
            if (option.required || option.optional && this._combineFlagAndOptionalValue) {
              this.emit(`option:${option.name()}`, arg.slice(2));
            } else {
              this.emit(`option:${option.name()}`);
              args.unshift(`-${arg.slice(2)}`);
            }
            continue;
          }
        }
        if (/^--[^=]+=/.test(arg)) {
          const index = arg.indexOf("=");
          const option = this._findOption(arg.slice(0, index));
          if (option && (option.required || option.optional)) {
            this.emit(`option:${option.name()}`, arg.slice(index + 1));
            continue;
          }
        }
        if (maybeOption(arg)) {
          dest = unknown;
        }
        if ((this._enablePositionalOptions || this._passThroughOptions) && operands.length === 0 && unknown.length === 0) {
          if (this._findCommand(arg)) {
            operands.push(arg);
            if (args.length > 0)
              unknown.push(...args);
            break;
          } else if (this._getHelpCommand() && arg === this._getHelpCommand().name()) {
            operands.push(arg);
            if (args.length > 0)
              operands.push(...args);
            break;
          } else if (this._defaultCommandName) {
            unknown.push(arg);
            if (args.length > 0)
              unknown.push(...args);
            break;
          }
        }
        if (this._passThroughOptions) {
          dest.push(arg);
          if (args.length > 0)
            dest.push(...args);
          break;
        }
        dest.push(arg);
      }
      return { operands, unknown };
    }
    opts() {
      if (this._storeOptionsAsProperties) {
        const result = {};
        const len = this.options.length;
        for (let i = 0;i < len; i++) {
          const key = this.options[i].attributeName();
          result[key] = key === this._versionOptionName ? this._version : this[key];
        }
        return result;
      }
      return this._optionValues;
    }
    optsWithGlobals() {
      return this._getCommandAndAncestors().reduce((combinedOptions, cmd) => Object.assign(combinedOptions, cmd.opts()), {});
    }
    error(message, errorOptions) {
      this._outputConfiguration.outputError(`${message}\n`, this._outputConfiguration.writeErr);
      if (typeof this._showHelpAfterError === "string") {
        this._outputConfiguration.writeErr(`${this._showHelpAfterError}\n`);
      } else if (this._showHelpAfterError) {
        this._outputConfiguration.writeErr("\n");
        this.outputHelp({ error: true });
      }
      const config = errorOptions || {};
      const exitCode = config.exitCode || 1;
      const code = config.code || "commander.error";
      this._exit(exitCode, code, message);
    }
    _parseOptionsEnv() {
      this.options.forEach((option) => {
        if (option.envVar && option.envVar in process2.env) {
          const optionKey = option.attributeName();
          if (this.getOptionValue(optionKey) === undefined || ["default", "config", "env"].includes(this.getOptionValueSource(optionKey))) {
            if (option.required || option.optional) {
              this.emit(`optionEnv:${option.name()}`, process2.env[option.envVar]);
            } else {
              this.emit(`optionEnv:${option.name()}`);
            }
          }
        }
      });
    }
    _parseOptionsImplied() {
      const dualHelper = new DualOptions(this.options);
      const hasCustomOptionValue = (optionKey) => {
        return this.getOptionValue(optionKey) !== undefined && !["default", "implied"].includes(this.getOptionValueSource(optionKey));
      };
      this.options.filter((option) => option.implied !== undefined && hasCustomOptionValue(option.attributeName()) && dualHelper.valueFromOption(this.getOptionValue(option.attributeName()), option)).forEach((option) => {
        Object.keys(option.implied).filter((impliedKey) => !hasCustomOptionValue(impliedKey)).forEach((impliedKey) => {
          this.setOptionValueWithSource(impliedKey, option.implied[impliedKey], "implied");
        });
      });
    }
    missingArgument(name) {
      const message = `error: missing required argument '${name}'`;
      this.error(message, { code: "commander.missingArgument" });
    }
    optionMissingArgument(option) {
      const message = `error: option '${option.flags}' argument missing`;
      this.error(message, { code: "commander.optionMissingArgument" });
    }
    missingMandatoryOptionValue(option) {
      const message = `error: required option '${option.flags}' not specified`;
      this.error(message, { code: "commander.missingMandatoryOptionValue" });
    }
    _conflictingOption(option, conflictingOption) {
      const findBestOptionFromValue = (option2) => {
        const optionKey = option2.attributeName();
        const optionValue = this.getOptionValue(optionKey);
        const negativeOption = this.options.find((target) => target.negate && optionKey === target.attributeName());
        const positiveOption = this.options.find((target) => !target.negate && optionKey === target.attributeName());
        if (negativeOption && (negativeOption.presetArg === undefined && optionValue === false || negativeOption.presetArg !== undefined && optionValue === negativeOption.presetArg)) {
          return negativeOption;
        }
        return positiveOption || option2;
      };
      const getErrorMessage = (option2) => {
        const bestOption = findBestOptionFromValue(option2);
        const optionKey = bestOption.attributeName();
        const source = this.getOptionValueSource(optionKey);
        if (source === "env") {
          return `environment variable '${bestOption.envVar}'`;
        }
        return `option '${bestOption.flags}'`;
      };
      const message = `error: ${getErrorMessage(option)} cannot be used with ${getErrorMessage(conflictingOption)}`;
      this.error(message, { code: "commander.conflictingOption" });
    }
    unknownOption(flag) {
      if (this._allowUnknownOption)
        return;
      let suggestion = "";
      if (flag.startsWith("--") && this._showSuggestionAfterError) {
        let candidateFlags = [];
        let command = this;
        do {
          const moreFlags = command.createHelp().visibleOptions(command).filter((option) => option.long).map((option) => option.long);
          candidateFlags = candidateFlags.concat(moreFlags);
          command = command.parent;
        } while (command && !command._enablePositionalOptions);
        suggestion = suggestSimilar(flag, candidateFlags);
      }
      const message = `error: unknown option '${flag}'${suggestion}`;
      this.error(message, { code: "commander.unknownOption" });
    }
    _excessArguments(receivedArgs) {
      if (this._allowExcessArguments)
        return;
      const expected = this.registeredArguments.length;
      const s = expected === 1 ? "" : "s";
      const forSubcommand = this.parent ? ` for '${this.name()}'` : "";
      const message = `error: too many arguments${forSubcommand}. Expected ${expected} argument${s} but got ${receivedArgs.length}.`;
      this.error(message, { code: "commander.excessArguments" });
    }
    unknownCommand() {
      const unknownName = this.args[0];
      let suggestion = "";
      if (this._showSuggestionAfterError) {
        const candidateNames = [];
        this.createHelp().visibleCommands(this).forEach((command) => {
          candidateNames.push(command.name());
          if (command.alias())
            candidateNames.push(command.alias());
        });
        suggestion = suggestSimilar(unknownName, candidateNames);
      }
      const message = `error: unknown command '${unknownName}'${suggestion}`;
      this.error(message, { code: "commander.unknownCommand" });
    }
    version(str, flags, description) {
      if (str === undefined)
        return this._version;
      this._version = str;
      flags = flags || "-V, --version";
      description = description || "output the version number";
      const versionOption = this.createOption(flags, description);
      this._versionOptionName = versionOption.attributeName();
      this._registerOption(versionOption);
      this.on("option:" + versionOption.name(), () => {
        this._outputConfiguration.writeOut(`${str}\n`);
        this._exit(0, "commander.version", str);
      });
      return this;
    }
    description(str, argsDescription) {
      if (str === undefined && argsDescription === undefined)
        return this._description;
      this._description = str;
      if (argsDescription) {
        this._argsDescription = argsDescription;
      }
      return this;
    }
    summary(str) {
      if (str === undefined)
        return this._summary;
      this._summary = str;
      return this;
    }
    alias(alias) {
      if (alias === undefined)
        return this._aliases[0];
      let command = this;
      if (this.commands.length !== 0 && this.commands[this.commands.length - 1]._executableHandler) {
        command = this.commands[this.commands.length - 1];
      }
      if (alias === command._name)
        throw new Error("Command alias can't be the same as its name");
      const matchingCommand = this.parent?._findCommand(alias);
      if (matchingCommand) {
        const existingCmd = [matchingCommand.name()].concat(matchingCommand.aliases()).join("|");
        throw new Error(`cannot add alias '${alias}' to command '${this.name()}' as already have command '${existingCmd}'`);
      }
      command._aliases.push(alias);
      return this;
    }
    aliases(aliases) {
      if (aliases === undefined)
        return this._aliases;
      aliases.forEach((alias) => this.alias(alias));
      return this;
    }
    usage(str) {
      if (str === undefined) {
        if (this._usage)
          return this._usage;
        const args = this.registeredArguments.map((arg) => {
          return humanReadableArgName(arg);
        });
        return [].concat(this.options.length || this._helpOption !== null ? "[options]" : [], this.commands.length ? "[command]" : [], this.registeredArguments.length ? args : []).join(" ");
      }
      this._usage = str;
      return this;
    }
    name(str) {
      if (str === undefined)
        return this._name;
      this._name = str;
      return this;
    }
    nameFromFilename(filename) {
      this._name = path.basename(filename, path.extname(filename));
      return this;
    }
    executableDir(path2) {
      if (path2 === undefined)
        return this._executableDir;
      this._executableDir = path2;
      return this;
    }
    helpInformation(contextOptions) {
      const helper = this.createHelp();
      if (helper.helpWidth === undefined) {
        helper.helpWidth = contextOptions && contextOptions.error ? this._outputConfiguration.getErrHelpWidth() : this._outputConfiguration.getOutHelpWidth();
      }
      return helper.formatHelp(this, helper);
    }
    _getHelpContext(contextOptions) {
      contextOptions = contextOptions || {};
      const context = { error: !!contextOptions.error };
      let write;
      if (context.error) {
        write = (arg) => this._outputConfiguration.writeErr(arg);
      } else {
        write = (arg) => this._outputConfiguration.writeOut(arg);
      }
      context.write = contextOptions.write || write;
      context.command = this;
      return context;
    }
    outputHelp(contextOptions) {
      let deprecatedCallback;
      if (typeof contextOptions === "function") {
        deprecatedCallback = contextOptions;
        contextOptions = undefined;
      }
      const context = this._getHelpContext(contextOptions);
      this._getCommandAndAncestors().reverse().forEach((command) => command.emit("beforeAllHelp", context));
      this.emit("beforeHelp", context);
      let helpInformation = this.helpInformation(context);
      if (deprecatedCallback) {
        helpInformation = deprecatedCallback(helpInformation);
        if (typeof helpInformation !== "string" && !Buffer.isBuffer(helpInformation)) {
          throw new Error("outputHelp callback must return a string or a Buffer");
        }
      }
      context.write(helpInformation);
      if (this._getHelpOption()?.long) {
        this.emit(this._getHelpOption().long);
      }
      this.emit("afterHelp", context);
      this._getCommandAndAncestors().forEach((command) => command.emit("afterAllHelp", context));
    }
    helpOption(flags, description) {
      if (typeof flags === "boolean") {
        if (flags) {
          this._helpOption = this._helpOption ?? undefined;
        } else {
          this._helpOption = null;
        }
        return this;
      }
      flags = flags ?? "-h, --help";
      description = description ?? "display help for command";
      this._helpOption = this.createOption(flags, description);
      return this;
    }
    _getHelpOption() {
      if (this._helpOption === undefined) {
        this.helpOption(undefined, undefined);
      }
      return this._helpOption;
    }
    addHelpOption(option) {
      this._helpOption = option;
      return this;
    }
    help(contextOptions) {
      this.outputHelp(contextOptions);
      let exitCode = process2.exitCode || 0;
      if (exitCode === 0 && contextOptions && typeof contextOptions !== "function" && contextOptions.error) {
        exitCode = 1;
      }
      this._exit(exitCode, "commander.help", "(outputHelp)");
    }
    addHelpText(position, text) {
      const allowedValues = ["beforeAll", "before", "after", "afterAll"];
      if (!allowedValues.includes(position)) {
        throw new Error(`Unexpected value for position to addHelpText.
Expecting one of '${allowedValues.join("', '")}'`);
      }
      const helpEvent = `${position}Help`;
      this.on(helpEvent, (context) => {
        let helpStr;
        if (typeof text === "function") {
          helpStr = text({ error: context.error, command: context.command });
        } else {
          helpStr = text;
        }
        if (helpStr) {
          context.write(`${helpStr}\n`);
        }
      });
      return this;
    }
    _outputHelpIfRequested(args) {
      const helpOption = this._getHelpOption();
      const helpRequested = helpOption && args.find((arg) => helpOption.is(arg));
      if (helpRequested) {
        this.outputHelp();
        this._exit(0, "commander.helpDisplayed", "(outputHelp)");
      }
    }
  }
  exports.Command = Command;
});

// node_modules/commander/index.js
var require_commander = __commonJS((exports) => {
  var { Argument } = require_argument();
  var { Command } = require_command();
  var { CommanderError, InvalidArgumentError } = require_error();
  var { Help } = require_help();
  var { Option } = require_option();
  exports.program = new Command;
  exports.createCommand = (name) => new Command(name);
  exports.createOption = (flags, description) => new Option(flags, description);
  exports.createArgument = (name, description) => new Argument(name, description);
  exports.Command = Command;
  exports.Option = Option;
  exports.Argument = Argument;
  exports.Help = Help;
  exports.CommanderError = CommanderError;
  exports.InvalidArgumentError = InvalidArgumentError;
  exports.InvalidOptionArgumentError = InvalidArgumentError;
});

// node_modules/uuid/dist/max.js
var require_max = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _default = exports.default = "ffffffff-ffff-ffff-ffff-ffffffffffff";
});

// node_modules/uuid/dist/nil.js
var require_nil = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _default = exports.default = "00000000-0000-0000-0000-000000000000";
});

// node_modules/uuid/dist/regex.js
var require_regex = __commonJS((exports) => {
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _default = exports.default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/i;
});

// node_modules/uuid/dist/validate.js
var require_validate = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var validate = function(uuid) {
    return typeof uuid === "string" && _regex.default.test(uuid);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _regex = _interopRequireDefault(require_regex());
  var _default = exports.default = validate;
});

// node_modules/uuid/dist/parse.js
var require_parse = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var parse = function(uuid) {
    if (!(0, _validate.default)(uuid)) {
      throw TypeError("Invalid UUID");
    }
    let v;
    const arr = new Uint8Array(16);
    arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
    arr[1] = v >>> 16 & 255;
    arr[2] = v >>> 8 & 255;
    arr[3] = v & 255;
    arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
    arr[5] = v & 255;
    arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
    arr[7] = v & 255;
    arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
    arr[9] = v & 255;
    arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255;
    arr[11] = v / 4294967296 & 255;
    arr[12] = v >>> 24 & 255;
    arr[13] = v >>> 16 & 255;
    arr[14] = v >>> 8 & 255;
    arr[15] = v & 255;
    return arr;
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _validate = _interopRequireDefault(require_validate());
  var _default = exports.default = parse;
});

// node_modules/uuid/dist/stringify.js
var require_stringify = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var unsafeStringify = function(arr, offset = 0) {
    return (byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]]).toLowerCase();
  };
  var stringify = function(arr, offset = 0) {
    const uuid = unsafeStringify(arr, offset);
    if (!(0, _validate.default)(uuid)) {
      throw TypeError("Stringified UUID is invalid");
    }
    return uuid;
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  exports.unsafeStringify = unsafeStringify;
  var _validate = _interopRequireDefault(require_validate());
  var byteToHex = [];
  for (let i = 0;i < 256; ++i) {
    byteToHex.push((i + 256).toString(16).slice(1));
  }
  var _default = exports.default = stringify;
});

// node_modules/uuid/dist/rng.js
var require_rng = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var rng = function() {
    if (poolPtr > rnds8Pool.length - 16) {
      _nodeCrypto.default.randomFillSync(rnds8Pool);
      poolPtr = 0;
    }
    return rnds8Pool.slice(poolPtr, poolPtr += 16);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = rng;
  var _nodeCrypto = _interopRequireDefault(import.meta.require("crypto"));
  var rnds8Pool = new Uint8Array(256);
  var poolPtr = rnds8Pool.length;
});

// node_modules/uuid/dist/v1.js
var require_v1 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var v1 = function(options, buf, offset) {
    let i = buf && offset || 0;
    const b = buf || new Array(16);
    options = options || {};
    let node = options.node;
    let clockseq = options.clockseq;
    if (!options._v6) {
      if (!node) {
        node = _nodeId;
      }
      if (clockseq == null) {
        clockseq = _clockseq;
      }
    }
    if (node == null || clockseq == null) {
      const seedBytes = options.random || (options.rng || _rng.default)();
      if (node == null) {
        node = [seedBytes[0], seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
        if (!_nodeId && !options._v6) {
          node[0] |= 1;
          _nodeId = node;
        }
      }
      if (clockseq == null) {
        clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 16383;
        if (_clockseq === undefined && !options._v6) {
          _clockseq = clockseq;
        }
      }
    }
    let msecs = options.msecs !== undefined ? options.msecs : Date.now();
    let nsecs = options.nsecs !== undefined ? options.nsecs : _lastNSecs + 1;
    const dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 1e4;
    if (dt < 0 && options.clockseq === undefined) {
      clockseq = clockseq + 1 & 16383;
    }
    if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === undefined) {
      nsecs = 0;
    }
    if (nsecs >= 1e4) {
      throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
    }
    _lastMSecs = msecs;
    _lastNSecs = nsecs;
    _clockseq = clockseq;
    msecs += 12219292800000;
    const tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
    b[i++] = tl >>> 24 & 255;
    b[i++] = tl >>> 16 & 255;
    b[i++] = tl >>> 8 & 255;
    b[i++] = tl & 255;
    const tmh = msecs / 4294967296 * 1e4 & 268435455;
    b[i++] = tmh >>> 8 & 255;
    b[i++] = tmh & 255;
    b[i++] = tmh >>> 24 & 15 | 16;
    b[i++] = tmh >>> 16 & 255;
    b[i++] = clockseq >>> 8 | 128;
    b[i++] = clockseq & 255;
    for (let n = 0;n < 6; ++n) {
      b[i + n] = node[n];
    }
    return buf || (0, _stringify.unsafeStringify)(b);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _rng = _interopRequireDefault(require_rng());
  var _stringify = require_stringify();
  var _nodeId;
  var _clockseq;
  var _lastMSecs = 0;
  var _lastNSecs = 0;
  var _default = exports.default = v1;
});

// node_modules/uuid/dist/v1ToV6.js
var require_v1ToV6 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var v1ToV6 = function(uuid) {
    const v1Bytes = typeof uuid === "string" ? (0, _parse.default)(uuid) : uuid;
    const v6Bytes = _v1ToV6(v1Bytes);
    return typeof uuid === "string" ? (0, _stringify.unsafeStringify)(v6Bytes) : v6Bytes;
  };
  var _v1ToV6 = function(v1Bytes, randomize = false) {
    return Uint8Array.of((v1Bytes[6] & 15) << 4 | v1Bytes[7] >> 4 & 15, (v1Bytes[7] & 15) << 4 | (v1Bytes[4] & 240) >> 4, (v1Bytes[4] & 15) << 4 | (v1Bytes[5] & 240) >> 4, (v1Bytes[5] & 15) << 4 | (v1Bytes[0] & 240) >> 4, (v1Bytes[0] & 15) << 4 | (v1Bytes[1] & 240) >> 4, (v1Bytes[1] & 15) << 4 | (v1Bytes[2] & 240) >> 4, 96 | v1Bytes[2] & 15, v1Bytes[3], v1Bytes[8], v1Bytes[9], v1Bytes[10], v1Bytes[11], v1Bytes[12], v1Bytes[13], v1Bytes[14], v1Bytes[15]);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = v1ToV6;
  var _parse = _interopRequireDefault(require_parse());
  var _stringify = require_stringify();
});

// node_modules/uuid/dist/v35.js
var require_v35 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var stringToBytes = function(str) {
    str = unescape(encodeURIComponent(str));
    const bytes = [];
    for (let i = 0;i < str.length; ++i) {
      bytes.push(str.charCodeAt(i));
    }
    return bytes;
  };
  var v35 = function(name, version3, hashfunc) {
    function generateUUID(value, namespace, buf, offset) {
      var _namespace;
      if (typeof value === "string") {
        value = stringToBytes(value);
      }
      if (typeof namespace === "string") {
        namespace = (0, _parse.default)(namespace);
      }
      if (((_namespace = namespace) === null || _namespace === undefined ? undefined : _namespace.length) !== 16) {
        throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
      }
      let bytes = new Uint8Array(16 + value.length);
      bytes.set(namespace);
      bytes.set(value, namespace.length);
      bytes = hashfunc(bytes);
      bytes[6] = bytes[6] & 15 | version3;
      bytes[8] = bytes[8] & 63 | 128;
      if (buf) {
        offset = offset || 0;
        for (let i = 0;i < 16; ++i) {
          buf[offset + i] = bytes[i];
        }
        return buf;
      }
      return (0, _stringify.unsafeStringify)(bytes);
    }
    try {
      generateUUID.name = name;
    } catch (err) {
    }
    generateUUID.DNS = DNS;
    generateUUID.URL = URL2;
    return generateUUID;
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.URL = exports.DNS = undefined;
  exports.default = v35;
  var _stringify = require_stringify();
  var _parse = _interopRequireDefault(require_parse());
  var DNS = exports.DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
  var URL2 = exports.URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
});

// node_modules/uuid/dist/md5.js
var require_md5 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var md5 = function(bytes) {
    if (Array.isArray(bytes)) {
      bytes = Buffer.from(bytes);
    } else if (typeof bytes === "string") {
      bytes = Buffer.from(bytes, "utf8");
    }
    return _nodeCrypto.default.createHash("md5").update(bytes).digest();
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _nodeCrypto = _interopRequireDefault(import.meta.require("crypto"));
  var _default = exports.default = md5;
});

// node_modules/uuid/dist/v3.js
var require_v3 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _v = _interopRequireDefault(require_v35());
  var _md = _interopRequireDefault(require_md5());
  var v3 = (0, _v.default)("v3", 48, _md.default);
  var _default = exports.default = v3;
});

// node_modules/uuid/dist/native.js
var require_native = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _nodeCrypto = _interopRequireDefault(import.meta.require("crypto"));
  var _default = exports.default = {
    randomUUID: _nodeCrypto.default.randomUUID
  };
});

// node_modules/uuid/dist/v4.js
var require_v4 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var v4 = function(options, buf, offset) {
    if (_native.default.randomUUID && !buf && !options) {
      return _native.default.randomUUID();
    }
    options = options || {};
    const rnds = options.random || (options.rng || _rng.default)();
    rnds[6] = rnds[6] & 15 | 64;
    rnds[8] = rnds[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (let i = 0;i < 16; ++i) {
        buf[offset + i] = rnds[i];
      }
      return buf;
    }
    return (0, _stringify.unsafeStringify)(rnds);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _native = _interopRequireDefault(require_native());
  var _rng = _interopRequireDefault(require_rng());
  var _stringify = require_stringify();
  var _default = exports.default = v4;
});

// node_modules/uuid/dist/sha1.js
var require_sha1 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var sha1 = function(bytes) {
    if (Array.isArray(bytes)) {
      bytes = Buffer.from(bytes);
    } else if (typeof bytes === "string") {
      bytes = Buffer.from(bytes, "utf8");
    }
    return _nodeCrypto.default.createHash("sha1").update(bytes).digest();
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _nodeCrypto = _interopRequireDefault(import.meta.require("crypto"));
  var _default = exports.default = sha1;
});

// node_modules/uuid/dist/v5.js
var require_v5 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _v = _interopRequireDefault(require_v35());
  var _sha = _interopRequireDefault(require_sha1());
  var v5 = (0, _v.default)("v5", 80, _sha.default);
  var _default = exports.default = v5;
});

// node_modules/uuid/dist/v6.js
var require_v6 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var v6 = function(options = {}, buf, offset = 0) {
    let bytes = (0, _v.default)({
      ...options,
      _v6: true
    }, new Uint8Array(16));
    bytes = (0, _v1ToV.default)(bytes);
    if (buf) {
      for (let i = 0;i < 16; i++) {
        buf[offset + i] = bytes[i];
      }
      return buf;
    }
    return (0, _stringify.unsafeStringify)(bytes);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = v6;
  var _stringify = require_stringify();
  var _v = _interopRequireDefault(require_v1());
  var _v1ToV = _interopRequireDefault(require_v1ToV6());
});

// node_modules/uuid/dist/v6ToV1.js
var require_v6ToV1 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var v6ToV1 = function(uuid) {
    const v6Bytes = typeof uuid === "string" ? (0, _parse.default)(uuid) : uuid;
    const v1Bytes = _v6ToV1(v6Bytes);
    return typeof uuid === "string" ? (0, _stringify.unsafeStringify)(v1Bytes) : v1Bytes;
  };
  var _v6ToV1 = function(v6Bytes) {
    return Uint8Array.of((v6Bytes[3] & 15) << 4 | v6Bytes[4] >> 4 & 15, (v6Bytes[4] & 15) << 4 | (v6Bytes[5] & 240) >> 4, (v6Bytes[5] & 15) << 4 | v6Bytes[6] & 15, v6Bytes[7], (v6Bytes[1] & 15) << 4 | (v6Bytes[2] & 240) >> 4, (v6Bytes[2] & 15) << 4 | (v6Bytes[3] & 240) >> 4, 16 | (v6Bytes[0] & 240) >> 4, (v6Bytes[0] & 15) << 4 | (v6Bytes[1] & 240) >> 4, v6Bytes[8], v6Bytes[9], v6Bytes[10], v6Bytes[11], v6Bytes[12], v6Bytes[13], v6Bytes[14], v6Bytes[15]);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = v6ToV1;
  var _parse = _interopRequireDefault(require_parse());
  var _stringify = require_stringify();
});

// node_modules/uuid/dist/v7.js
var require_v7 = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var v7 = function(options, buf, offset) {
    options = options || {};
    let i = buf && offset || 0;
    const b = buf || new Uint8Array(16);
    const rnds = options.random || (options.rng || _rng.default)();
    const msecs = options.msecs !== undefined ? options.msecs : Date.now();
    let seq = options.seq !== undefined ? options.seq : null;
    let seqHigh = _seqHigh;
    let seqLow = _seqLow;
    if (msecs > _msecs && options.msecs === undefined) {
      _msecs = msecs;
      if (seq !== null) {
        seqHigh = null;
        seqLow = null;
      }
    }
    if (seq !== null) {
      if (seq > 2147483647) {
        seq = 2147483647;
      }
      seqHigh = seq >>> 19 & 4095;
      seqLow = seq & 524287;
    }
    if (seqHigh === null || seqLow === null) {
      seqHigh = rnds[6] & 127;
      seqHigh = seqHigh << 8 | rnds[7];
      seqLow = rnds[8] & 63;
      seqLow = seqLow << 8 | rnds[9];
      seqLow = seqLow << 5 | rnds[10] >>> 3;
    }
    if (msecs + 1e4 > _msecs && seq === null) {
      if (++seqLow > 524287) {
        seqLow = 0;
        if (++seqHigh > 4095) {
          seqHigh = 0;
          _msecs++;
        }
      }
    } else {
      _msecs = msecs;
    }
    _seqHigh = seqHigh;
    _seqLow = seqLow;
    b[i++] = _msecs / 1099511627776 & 255;
    b[i++] = _msecs / 4294967296 & 255;
    b[i++] = _msecs / 16777216 & 255;
    b[i++] = _msecs / 65536 & 255;
    b[i++] = _msecs / 256 & 255;
    b[i++] = _msecs & 255;
    b[i++] = seqHigh >>> 4 & 15 | 112;
    b[i++] = seqHigh & 255;
    b[i++] = seqLow >>> 13 & 63 | 128;
    b[i++] = seqLow >>> 5 & 255;
    b[i++] = seqLow << 3 & 255 | rnds[10] & 7;
    b[i++] = rnds[11];
    b[i++] = rnds[12];
    b[i++] = rnds[13];
    b[i++] = rnds[14];
    b[i++] = rnds[15];
    return buf || (0, _stringify.unsafeStringify)(b);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _rng = _interopRequireDefault(require_rng());
  var _stringify = require_stringify();
  var _seqLow = null;
  var _seqHigh = null;
  var _msecs = 0;
  var _default = exports.default = v7;
});

// node_modules/uuid/dist/version.js
var require_version = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  var version3 = function(uuid) {
    if (!(0, _validate.default)(uuid)) {
      throw TypeError("Invalid UUID");
    }
    return parseInt(uuid.slice(14, 15), 16);
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = undefined;
  var _validate = _interopRequireDefault(require_validate());
  var _default = exports.default = version3;
});

// node_modules/uuid/dist/index.js
var require_dist = __commonJS((exports) => {
  var _interopRequireDefault = function(e) {
    return e && e.__esModule ? e : { default: e };
  };
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  Object.defineProperty(exports, "MAX", {
    enumerable: true,
    get: function() {
      return _max.default;
    }
  });
  Object.defineProperty(exports, "NIL", {
    enumerable: true,
    get: function() {
      return _nil.default;
    }
  });
  Object.defineProperty(exports, "parse", {
    enumerable: true,
    get: function() {
      return _parse.default;
    }
  });
  Object.defineProperty(exports, "stringify", {
    enumerable: true,
    get: function() {
      return _stringify.default;
    }
  });
  Object.defineProperty(exports, "v1", {
    enumerable: true,
    get: function() {
      return _v.default;
    }
  });
  Object.defineProperty(exports, "v1ToV6", {
    enumerable: true,
    get: function() {
      return _v1ToV.default;
    }
  });
  Object.defineProperty(exports, "v3", {
    enumerable: true,
    get: function() {
      return _v2.default;
    }
  });
  Object.defineProperty(exports, "v4", {
    enumerable: true,
    get: function() {
      return _v3.default;
    }
  });
  Object.defineProperty(exports, "v5", {
    enumerable: true,
    get: function() {
      return _v4.default;
    }
  });
  Object.defineProperty(exports, "v6", {
    enumerable: true,
    get: function() {
      return _v5.default;
    }
  });
  Object.defineProperty(exports, "v6ToV1", {
    enumerable: true,
    get: function() {
      return _v6ToV.default;
    }
  });
  Object.defineProperty(exports, "v7", {
    enumerable: true,
    get: function() {
      return _v6.default;
    }
  });
  Object.defineProperty(exports, "validate", {
    enumerable: true,
    get: function() {
      return _validate.default;
    }
  });
  Object.defineProperty(exports, "version", {
    enumerable: true,
    get: function() {
      return _version.default;
    }
  });
  var _max = _interopRequireDefault(require_max());
  var _nil = _interopRequireDefault(require_nil());
  var _parse = _interopRequireDefault(require_parse());
  var _stringify = _interopRequireDefault(require_stringify());
  var _v = _interopRequireDefault(require_v1());
  var _v1ToV = _interopRequireDefault(require_v1ToV6());
  var _v2 = _interopRequireDefault(require_v3());
  var _v3 = _interopRequireDefault(require_v4());
  var _v4 = _interopRequireDefault(require_v5());
  var _v5 = _interopRequireDefault(require_v6());
  var _v6ToV = _interopRequireDefault(require_v6ToV1());
  var _v6 = _interopRequireDefault(require_v7());
  var _validate = _interopRequireDefault(require_validate());
  var _version = _interopRequireDefault(require_version());
});

// node_modules/nodemailer/lib/fetch/cookies.js
var require_cookies = __commonJS((exports, module) => {
  var urllib = import.meta.require("url");
  var SESSION_TIMEOUT = 1800;

  class Cookies {
    constructor(options) {
      this.options = options || {};
      this.cookies = [];
    }
    set(cookieStr, url) {
      let urlparts = urllib.parse(url || "");
      let cookie = this.parse(cookieStr);
      let domain;
      if (cookie.domain) {
        domain = cookie.domain.replace(/^\./, "");
        if (urlparts.hostname.length < domain.length || ("." + urlparts.hostname).substr(-domain.length + 1) !== "." + domain) {
          cookie.domain = urlparts.hostname;
        }
      } else {
        cookie.domain = urlparts.hostname;
      }
      if (!cookie.path) {
        cookie.path = this.getPath(urlparts.pathname);
      }
      if (!cookie.expires) {
        cookie.expires = new Date(Date.now() + (Number(this.options.sessionTimeout || SESSION_TIMEOUT) || SESSION_TIMEOUT) * 1000);
      }
      return this.add(cookie);
    }
    get(url) {
      return this.list(url).map((cookie) => cookie.name + "=" + cookie.value).join("; ");
    }
    list(url) {
      let result = [];
      let i;
      let cookie;
      for (i = this.cookies.length - 1;i >= 0; i--) {
        cookie = this.cookies[i];
        if (this.isExpired(cookie)) {
          this.cookies.splice(i, i);
          continue;
        }
        if (this.match(cookie, url)) {
          result.unshift(cookie);
        }
      }
      return result;
    }
    parse(cookieStr) {
      let cookie = {};
      (cookieStr || "").toString().split(";").forEach((cookiePart) => {
        let valueParts = cookiePart.split("=");
        let key = valueParts.shift().trim().toLowerCase();
        let value = valueParts.join("=").trim();
        let domain;
        if (!key) {
          return;
        }
        switch (key) {
          case "expires":
            value = new Date(value);
            if (value.toString() !== "Invalid Date") {
              cookie.expires = value;
            }
            break;
          case "path":
            cookie.path = value;
            break;
          case "domain":
            domain = value.toLowerCase();
            if (domain.length && domain.charAt(0) !== ".") {
              domain = "." + domain;
            }
            cookie.domain = domain;
            break;
          case "max-age":
            cookie.expires = new Date(Date.now() + (Number(value) || 0) * 1000);
            break;
          case "secure":
            cookie.secure = true;
            break;
          case "httponly":
            cookie.httponly = true;
            break;
          default:
            if (!cookie.name) {
              cookie.name = key;
              cookie.value = value;
            }
        }
      });
      return cookie;
    }
    match(cookie, url) {
      let urlparts = urllib.parse(url || "");
      if (urlparts.hostname !== cookie.domain && (cookie.domain.charAt(0) !== "." || ("." + urlparts.hostname).substr(-cookie.domain.length) !== cookie.domain)) {
        return false;
      }
      let path2 = this.getPath(urlparts.pathname);
      if (path2.substr(0, cookie.path.length) !== cookie.path) {
        return false;
      }
      if (cookie.secure && urlparts.protocol !== "https:") {
        return false;
      }
      return true;
    }
    add(cookie) {
      let i;
      let len;
      if (!cookie || !cookie.name) {
        return false;
      }
      for (i = 0, len = this.cookies.length;i < len; i++) {
        if (this.compare(this.cookies[i], cookie)) {
          if (this.isExpired(cookie)) {
            this.cookies.splice(i, 1);
            return false;
          }
          this.cookies[i] = cookie;
          return true;
        }
      }
      if (!this.isExpired(cookie)) {
        this.cookies.push(cookie);
      }
      return true;
    }
    compare(a, b) {
      return a.name === b.name && a.path === b.path && a.domain === b.domain && a.secure === b.secure && a.httponly === a.httponly;
    }
    isExpired(cookie) {
      return cookie.expires && cookie.expires < new Date || !cookie.value;
    }
    getPath(pathname) {
      let path2 = (pathname || "/").split("/");
      path2.pop();
      path2 = path2.join("/").trim();
      if (path2.charAt(0) !== "/") {
        path2 = "/" + path2;
      }
      if (path2.substr(-1) !== "/") {
        path2 += "/";
      }
      return path2;
    }
  }
  module.exports = Cookies;
});

// node_modules/nodemailer/package.json
var require_package = __commonJS((exports, module) => {
  module.exports = {
    name: "nodemailer",
    version: "6.9.14",
    description: "Easy as cake e-mail sending from your Node.js applications",
    main: "lib/nodemailer.js",
    scripts: {
      test: "node --test --test-concurrency=1 test/**/*.test.js test/**/*-test.js",
      "test:coverage": "c8 node --test --test-concurrency=1 test/**/*.test.js test/**/*-test.js",
      lint: "eslint .",
      update: "rm -rf node_modules/ package-lock.json && ncu -u && npm install"
    },
    repository: {
      type: "git",
      url: "https://github.com/nodemailer/nodemailer.git"
    },
    keywords: [
      "Nodemailer"
    ],
    author: "Andris Reinman",
    license: "MIT-0",
    bugs: {
      url: "https://github.com/nodemailer/nodemailer/issues"
    },
    homepage: "https://nodemailer.com/",
    devDependencies: {
      "@aws-sdk/client-ses": "3.600.0",
      bunyan: "1.8.15",
      c8: "10.1.2",
      eslint: "8.57.0",
      "eslint-config-nodemailer": "1.2.0",
      "eslint-config-prettier": "9.1.0",
      libbase64: "1.3.0",
      libmime: "5.3.5",
      libqp: "2.1.0",
      "nodemailer-ntlm-auth": "1.0.4",
      proxy: "1.0.2",
      "proxy-test-server": "1.0.0",
      "smtp-server": "3.13.4"
    },
    engines: {
      node: ">=6.0.0"
    }
  };
});

// node_modules/nodemailer/lib/fetch/index.js
var require_fetch = __commonJS((exports, module) => {
  var nmfetch = function(url, options) {
    options = options || {};
    options.fetchRes = options.fetchRes || new PassThrough;
    options.cookies = options.cookies || new Cookies;
    options.redirects = options.redirects || 0;
    options.maxRedirects = isNaN(options.maxRedirects) ? MAX_REDIRECTS : options.maxRedirects;
    if (options.cookie) {
      [].concat(options.cookie || []).forEach((cookie) => {
        options.cookies.set(cookie, url);
      });
      options.cookie = false;
    }
    let fetchRes = options.fetchRes;
    let parsed = urllib.parse(url);
    let method = (options.method || "").toString().trim().toUpperCase() || "GET";
    let finished = false;
    let cookies;
    let body;
    let handler = parsed.protocol === "https:" ? https : http;
    let headers = {
      "accept-encoding": "gzip,deflate",
      "user-agent": "nodemailer/" + packageData.version
    };
    Object.keys(options.headers || {}).forEach((key) => {
      headers[key.toLowerCase().trim()] = options.headers[key];
    });
    if (options.userAgent) {
      headers["user-agent"] = options.userAgent;
    }
    if (parsed.auth) {
      headers.Authorization = "Basic " + Buffer.from(parsed.auth).toString("base64");
    }
    if (cookies = options.cookies.get(url)) {
      headers.cookie = cookies;
    }
    if (options.body) {
      if (options.contentType !== false) {
        headers["Content-Type"] = options.contentType || "application/x-www-form-urlencoded";
      }
      if (typeof options.body.pipe === "function") {
        headers["Transfer-Encoding"] = "chunked";
        body = options.body;
        body.on("error", (err) => {
          if (finished) {
            return;
          }
          finished = true;
          err.type = "FETCH";
          err.sourceUrl = url;
          fetchRes.emit("error", err);
        });
      } else {
        if (options.body instanceof Buffer) {
          body = options.body;
        } else if (typeof options.body === "object") {
          try {
            body = Buffer.from(Object.keys(options.body).map((key) => {
              let value = options.body[key].toString().trim();
              return encodeURIComponent(key) + "=" + encodeURIComponent(value);
            }).join("&"));
          } catch (E) {
            if (finished) {
              return;
            }
            finished = true;
            E.type = "FETCH";
            E.sourceUrl = url;
            fetchRes.emit("error", E);
            return;
          }
        } else {
          body = Buffer.from(options.body.toString().trim());
        }
        headers["Content-Type"] = options.contentType || "application/x-www-form-urlencoded";
        headers["Content-Length"] = body.length;
      }
      method = (options.method || "").toString().trim().toUpperCase() || "POST";
    }
    let req;
    let reqOptions = {
      method,
      host: parsed.hostname,
      path: parsed.path,
      port: parsed.port ? parsed.port : parsed.protocol === "https:" ? 443 : 80,
      headers,
      rejectUnauthorized: false,
      agent: false
    };
    if (options.tls) {
      Object.keys(options.tls).forEach((key) => {
        reqOptions[key] = options.tls[key];
      });
    }
    if (parsed.protocol === "https:" && parsed.hostname && parsed.hostname !== reqOptions.host && !net.isIP(parsed.hostname) && !reqOptions.servername) {
      reqOptions.servername = parsed.hostname;
    }
    try {
      req = handler.request(reqOptions);
    } catch (E) {
      finished = true;
      setImmediate(() => {
        E.type = "FETCH";
        E.sourceUrl = url;
        fetchRes.emit("error", E);
      });
      return fetchRes;
    }
    if (options.timeout) {
      req.setTimeout(options.timeout, () => {
        if (finished) {
          return;
        }
        finished = true;
        req.abort();
        let err = new Error("Request Timeout");
        err.type = "FETCH";
        err.sourceUrl = url;
        fetchRes.emit("error", err);
      });
    }
    req.on("error", (err) => {
      if (finished) {
        return;
      }
      finished = true;
      err.type = "FETCH";
      err.sourceUrl = url;
      fetchRes.emit("error", err);
    });
    req.on("response", (res) => {
      let inflate;
      if (finished) {
        return;
      }
      switch (res.headers["content-encoding"]) {
        case "gzip":
        case "deflate":
          inflate = zlib.createUnzip();
          break;
      }
      if (res.headers["set-cookie"]) {
        [].concat(res.headers["set-cookie"] || []).forEach((cookie) => {
          options.cookies.set(cookie, url);
        });
      }
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location) {
        options.redirects++;
        if (options.redirects > options.maxRedirects) {
          finished = true;
          let err = new Error("Maximum redirect count exceeded");
          err.type = "FETCH";
          err.sourceUrl = url;
          fetchRes.emit("error", err);
          req.abort();
          return;
        }
        options.method = "GET";
        options.body = false;
        return nmfetch(urllib.resolve(url, res.headers.location), options);
      }
      fetchRes.statusCode = res.statusCode;
      fetchRes.headers = res.headers;
      if (res.statusCode >= 300 && !options.allowErrorResponse) {
        finished = true;
        let err = new Error("Invalid status code " + res.statusCode);
        err.type = "FETCH";
        err.sourceUrl = url;
        fetchRes.emit("error", err);
        req.abort();
        return;
      }
      res.on("error", (err) => {
        if (finished) {
          return;
        }
        finished = true;
        err.type = "FETCH";
        err.sourceUrl = url;
        fetchRes.emit("error", err);
        req.abort();
      });
      if (inflate) {
        res.pipe(inflate).pipe(fetchRes);
        inflate.on("error", (err) => {
          if (finished) {
            return;
          }
          finished = true;
          err.type = "FETCH";
          err.sourceUrl = url;
          fetchRes.emit("error", err);
          req.abort();
        });
      } else {
        res.pipe(fetchRes);
      }
    });
    setImmediate(() => {
      if (body) {
        try {
          if (typeof body.pipe === "function") {
            return body.pipe(req);
          } else {
            req.write(body);
          }
        } catch (err) {
          finished = true;
          err.type = "FETCH";
          err.sourceUrl = url;
          fetchRes.emit("error", err);
          return;
        }
      }
      req.end();
    });
    return fetchRes;
  };
  var http = import.meta.require("http");
  var https = import.meta.require("https");
  var urllib = import.meta.require("url");
  var zlib = import.meta.require("zlib");
  var PassThrough = import.meta.require("stream").PassThrough;
  var Cookies = require_cookies();
  var packageData = require_package();
  var net = import.meta.require("net");
  var MAX_REDIRECTS = 5;
  module.exports = function(url, options) {
    return nmfetch(url, options);
  };
  module.exports.Cookies = Cookies;
});

// node_modules/nodemailer/lib/shared/index.js
var require_shared = __commonJS((exports, module) => {
  var resolveStream = function(stream, callback) {
    let responded = false;
    let chunks = [];
    let chunklen = 0;
    stream.on("error", (err) => {
      if (responded) {
        return;
      }
      responded = true;
      callback(err);
    });
    stream.on("readable", () => {
      let chunk;
      while ((chunk = stream.read()) !== null) {
        chunks.push(chunk);
        chunklen += chunk.length;
      }
    });
    stream.on("end", () => {
      if (responded) {
        return;
      }
      responded = true;
      let value;
      try {
        value = Buffer.concat(chunks, chunklen);
      } catch (E) {
        return callback(E);
      }
      callback(null, value);
    });
  };
  var createDefaultLogger = function(levels) {
    let levelMaxLen = 0;
    let levelNames = new Map;
    levels.forEach((level) => {
      if (level.length > levelMaxLen) {
        levelMaxLen = level.length;
      }
    });
    levels.forEach((level) => {
      let levelName = level.toUpperCase();
      if (levelName.length < levelMaxLen) {
        levelName += " ".repeat(levelMaxLen - levelName.length);
      }
      levelNames.set(level, levelName);
    });
    let print = (level, entry, message, ...args) => {
      let prefix = "";
      if (entry) {
        if (entry.tnx === "server") {
          prefix = "S: ";
        } else if (entry.tnx === "client") {
          prefix = "C: ";
        }
        if (entry.sid) {
          prefix = "[" + entry.sid + "] " + prefix;
        }
        if (entry.cid) {
          prefix = "[#" + entry.cid + "] " + prefix;
        }
      }
      message = util.format(message, ...args);
      message.split(/\r?\n/).forEach((line) => {
        console.log("[%s] %s %s", new Date().toISOString().substr(0, 19).replace(/T/, " "), levelNames.get(level), prefix + line);
      });
    };
    let logger3 = {};
    levels.forEach((level) => {
      logger3[level] = print.bind(null, level);
    });
    return logger3;
  };
  var urllib = import.meta.require("url");
  var util = import.meta.require("util");
  var fs2 = import.meta.require("fs");
  var nmfetch = require_fetch();
  var dns = import.meta.require("dns");
  var net = import.meta.require("net");
  var os = import.meta.require("os");
  var DNS_TTL = 5 * 60 * 1000;
  var networkInterfaces;
  try {
    networkInterfaces = os.networkInterfaces();
  } catch (err) {
  }
  exports.networkInterfaces = networkInterfaces;
  var isFamilySupported = (family, allowInternal) => {
    let networkInterfaces2 = exports.networkInterfaces;
    if (!networkInterfaces2) {
      return true;
    }
    const familySupported = Object.keys(networkInterfaces2).map((key) => networkInterfaces2[key]).reduce((acc, val) => acc.concat(val), []).filter((i) => !i.internal || allowInternal).filter((i) => i.family === "IPv" + family || i.family === family).length > 0;
    return familySupported;
  };
  var resolver = (family, hostname, options, callback) => {
    options = options || {};
    const familySupported = isFamilySupported(family, options.allowInternalNetworkInterfaces);
    if (!familySupported) {
      return callback(null, []);
    }
    const resolver2 = dns.Resolver ? new dns.Resolver(options) : dns;
    resolver2["resolve" + family](hostname, (err, addresses) => {
      if (err) {
        switch (err.code) {
          case dns.NODATA:
          case dns.NOTFOUND:
          case dns.NOTIMP:
          case dns.SERVFAIL:
          case dns.CONNREFUSED:
          case dns.REFUSED:
          case "EAI_AGAIN":
            return callback(null, []);
        }
        return callback(err);
      }
      return callback(null, Array.isArray(addresses) ? addresses : [].concat(addresses || []));
    });
  };
  var dnsCache = exports.dnsCache = new Map;
  var formatDNSValue = (value, extra) => {
    if (!value) {
      return Object.assign({}, extra || {});
    }
    return Object.assign({
      servername: value.servername,
      host: !value.addresses || !value.addresses.length ? null : value.addresses.length === 1 ? value.addresses[0] : value.addresses[Math.floor(Math.random() * value.addresses.length)]
    }, extra || {});
  };
  exports.resolveHostname = (options, callback) => {
    options = options || {};
    if (!options.host && options.servername) {
      options.host = options.servername;
    }
    if (!options.host || net.isIP(options.host)) {
      let value = {
        addresses: [options.host],
        servername: options.servername || false
      };
      return callback(null, formatDNSValue(value, {
        cached: false
      }));
    }
    let cached;
    if (dnsCache.has(options.host)) {
      cached = dnsCache.get(options.host);
      if (!cached.expires || cached.expires >= Date.now()) {
        return callback(null, formatDNSValue(cached.value, {
          cached: true
        }));
      }
    }
    resolver(4, options.host, options, (err, addresses) => {
      if (err) {
        if (cached) {
          return callback(null, formatDNSValue(cached.value, {
            cached: true,
            error: err
          }));
        }
        return callback(err);
      }
      if (addresses && addresses.length) {
        let value = {
          addresses,
          servername: options.servername || options.host
        };
        dnsCache.set(options.host, {
          value,
          expires: Date.now() + (options.dnsTtl || DNS_TTL)
        });
        return callback(null, formatDNSValue(value, {
          cached: false
        }));
      }
      resolver(6, options.host, options, (err2, addresses2) => {
        if (err2) {
          if (cached) {
            return callback(null, formatDNSValue(cached.value, {
              cached: true,
              error: err2
            }));
          }
          return callback(err2);
        }
        if (addresses2 && addresses2.length) {
          let value = {
            addresses: addresses2,
            servername: options.servername || options.host
          };
          dnsCache.set(options.host, {
            value,
            expires: Date.now() + (options.dnsTtl || DNS_TTL)
          });
          return callback(null, formatDNSValue(value, {
            cached: false
          }));
        }
        try {
          dns.lookup(options.host, { all: true }, (err3, addresses3) => {
            if (err3) {
              if (cached) {
                return callback(null, formatDNSValue(cached.value, {
                  cached: true,
                  error: err3
                }));
              }
              return callback(err3);
            }
            let address = addresses3 ? addresses3.filter((addr) => isFamilySupported(addr.family)).map((addr) => addr.address).shift() : false;
            if (addresses3 && addresses3.length && !address) {
              console.warn(`Failed to resolve IPv${addresses3[0].family} addresses with current network`);
            }
            if (!address && cached) {
              return callback(null, formatDNSValue(cached.value, {
                cached: true
              }));
            }
            let value = {
              addresses: address ? [address] : [options.host],
              servername: options.servername || options.host
            };
            dnsCache.set(options.host, {
              value,
              expires: Date.now() + (options.dnsTtl || DNS_TTL)
            });
            return callback(null, formatDNSValue(value, {
              cached: false
            }));
          });
        } catch (err3) {
          if (cached) {
            return callback(null, formatDNSValue(cached.value, {
              cached: true,
              error: err3
            }));
          }
          return callback(err3);
        }
      });
    });
  };
  exports.parseConnectionUrl = (str) => {
    str = str || "";
    let options = {};
    [urllib.parse(str, true)].forEach((url) => {
      let auth;
      switch (url.protocol) {
        case "smtp:":
          options.secure = false;
          break;
        case "smtps:":
          options.secure = true;
          break;
        case "direct:":
          options.direct = true;
          break;
      }
      if (!isNaN(url.port) && Number(url.port)) {
        options.port = Number(url.port);
      }
      if (url.hostname) {
        options.host = url.hostname;
      }
      if (url.auth) {
        auth = url.auth.split(":");
        if (!options.auth) {
          options.auth = {};
        }
        options.auth.user = auth.shift();
        options.auth.pass = auth.join(":");
      }
      Object.keys(url.query || {}).forEach((key) => {
        let obj = options;
        let lKey = key;
        let value = url.query[key];
        if (!isNaN(value)) {
          value = Number(value);
        }
        switch (value) {
          case "true":
            value = true;
            break;
          case "false":
            value = false;
            break;
        }
        if (key.indexOf("tls.") === 0) {
          lKey = key.substr(4);
          if (!options.tls) {
            options.tls = {};
          }
          obj = options.tls;
        } else if (key.indexOf(".") >= 0) {
          return;
        }
        if (!(lKey in obj)) {
          obj[lKey] = value;
        }
      });
    });
    return options;
  };
  exports._logFunc = (logger3, level, defaults, data, message, ...args) => {
    let entry = {};
    Object.keys(defaults || {}).forEach((key) => {
      if (key !== "level") {
        entry[key] = defaults[key];
      }
    });
    Object.keys(data || {}).forEach((key) => {
      if (key !== "level") {
        entry[key] = data[key];
      }
    });
    logger3[level](entry, message, ...args);
  };
  exports.getLogger = (options, defaults) => {
    options = options || {};
    let response = {};
    let levels = ["trace", "debug", "info", "warn", "error", "fatal"];
    if (!options.logger) {
      levels.forEach((level) => {
        response[level] = () => false;
      });
      return response;
    }
    let logger3 = options.logger;
    if (options.logger === true) {
      logger3 = createDefaultLogger(levels);
    }
    levels.forEach((level) => {
      response[level] = (data, message, ...args) => {
        exports._logFunc(logger3, level, defaults, data, message, ...args);
      };
    });
    return response;
  };
  exports.callbackPromise = (resolve, reject) => function() {
    let args = Array.from(arguments);
    let err = args.shift();
    if (err) {
      reject(err);
    } else {
      resolve(...args);
    }
  };
  exports.parseDataURI = (uri) => {
    let input = uri;
    let commaPos = input.indexOf(",");
    if (!commaPos) {
      return uri;
    }
    let data = input.substring(commaPos + 1);
    let metaStr = input.substring("data:".length, commaPos);
    let encoding;
    let metaEntries = metaStr.split(";");
    let lastMetaEntry = metaEntries.length > 1 ? metaEntries[metaEntries.length - 1] : false;
    if (lastMetaEntry && lastMetaEntry.indexOf("=") < 0) {
      encoding = lastMetaEntry.toLowerCase();
      metaEntries.pop();
    }
    let contentType = metaEntries.shift() || "application/octet-stream";
    let params = {};
    for (let entry of metaEntries) {
      let sep = entry.indexOf("=");
      if (sep >= 0) {
        let key = entry.substring(0, sep);
        let value = entry.substring(sep + 1);
        params[key] = value;
      }
    }
    switch (encoding) {
      case "base64":
        data = Buffer.from(data, "base64");
        break;
      case "utf8":
        data = Buffer.from(data);
        break;
      default:
        try {
          data = Buffer.from(decodeURIComponent(data));
        } catch (err) {
          data = Buffer.from(data);
        }
        data = Buffer.from(data);
    }
    return { data, encoding, contentType, params };
  };
  exports.resolveContent = (data, key, callback) => {
    let promise;
    if (!callback) {
      promise = new Promise((resolve, reject) => {
        callback = exports.callbackPromise(resolve, reject);
      });
    }
    let content = data && data[key] && data[key].content || data[key];
    let contentStream;
    let encoding = (typeof data[key] === "object" && data[key].encoding || "utf8").toString().toLowerCase().replace(/[-_\s]/g, "");
    if (!content) {
      return callback(null, content);
    }
    if (typeof content === "object") {
      if (typeof content.pipe === "function") {
        return resolveStream(content, (err, value) => {
          if (err) {
            return callback(err);
          }
          if (data[key].content) {
            data[key].content = value;
          } else {
            data[key] = value;
          }
          callback(null, value);
        });
      } else if (/^https?:\/\//i.test(content.path || content.href)) {
        contentStream = nmfetch(content.path || content.href);
        return resolveStream(contentStream, callback);
      } else if (/^data:/i.test(content.path || content.href)) {
        let parsedDataUri = exports.parseDataURI(content.path || content.href);
        if (!parsedDataUri || !parsedDataUri.data) {
          return callback(null, Buffer.from(0));
        }
        return callback(null, parsedDataUri.data);
      } else if (content.path) {
        return resolveStream(fs2.createReadStream(content.path), callback);
      }
    }
    if (typeof data[key].content === "string" && !["utf8", "usascii", "ascii"].includes(encoding)) {
      content = Buffer.from(data[key].content, encoding);
    }
    setImmediate(() => callback(null, content));
    return promise;
  };
  exports.assign = function() {
    let args = Array.from(arguments);
    let target = args.shift() || {};
    args.forEach((source) => {
      Object.keys(source || {}).forEach((key) => {
        if (["tls", "auth"].includes(key) && source[key] && typeof source[key] === "object") {
          if (!target[key]) {
            target[key] = {};
          }
          Object.keys(source[key]).forEach((subKey) => {
            target[key][subKey] = source[key][subKey];
          });
        } else {
          target[key] = source[key];
        }
      });
    });
    return target;
  };
  exports.encodeXText = (str) => {
    if (!/[^\x21-\x2A\x2C-\x3C\x3E-\x7E]/.test(str)) {
      return str;
    }
    let buf = Buffer.from(str);
    let result = "";
    for (let i = 0, len = buf.length;i < len; i++) {
      let c = buf[i];
      if (c < 33 || c > 126 || c === 43 || c === 61) {
        result += "+" + (c < 16 ? "0" : "") + c.toString(16).toUpperCase();
      } else {
        result += String.fromCharCode(c);
      }
    }
    return result;
  };
});

// node_modules/nodemailer/lib/mime-funcs/mime-types.js
var require_mime_types = __commonJS((exports, module) => {
  var path2 = import.meta.require("path");
  var defaultMimeType = "application/octet-stream";
  var defaultExtension = "bin";
  var mimeTypes = new Map([
    ["application/acad", "dwg"],
    ["application/applixware", "aw"],
    ["application/arj", "arj"],
    ["application/atom+xml", "xml"],
    ["application/atomcat+xml", "atomcat"],
    ["application/atomsvc+xml", "atomsvc"],
    ["application/base64", ["mm", "mme"]],
    ["application/binhex", "hqx"],
    ["application/binhex4", "hqx"],
    ["application/book", ["book", "boo"]],
    ["application/ccxml+xml,", "ccxml"],
    ["application/cdf", "cdf"],
    ["application/cdmi-capability", "cdmia"],
    ["application/cdmi-container", "cdmic"],
    ["application/cdmi-domain", "cdmid"],
    ["application/cdmi-object", "cdmio"],
    ["application/cdmi-queue", "cdmiq"],
    ["application/clariscad", "ccad"],
    ["application/commonground", "dp"],
    ["application/cu-seeme", "cu"],
    ["application/davmount+xml", "davmount"],
    ["application/drafting", "drw"],
    ["application/dsptype", "tsp"],
    ["application/dssc+der", "dssc"],
    ["application/dssc+xml", "xdssc"],
    ["application/dxf", "dxf"],
    ["application/ecmascript", ["js", "es"]],
    ["application/emma+xml", "emma"],
    ["application/envoy", "evy"],
    ["application/epub+zip", "epub"],
    ["application/excel", ["xls", "xl", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw"]],
    ["application/exi", "exi"],
    ["application/font-tdpfr", "pfr"],
    ["application/fractals", "fif"],
    ["application/freeloader", "frl"],
    ["application/futuresplash", "spl"],
    ["application/gnutar", "tgz"],
    ["application/groupwise", "vew"],
    ["application/hlp", "hlp"],
    ["application/hta", "hta"],
    ["application/hyperstudio", "stk"],
    ["application/i-deas", "unv"],
    ["application/iges", ["iges", "igs"]],
    ["application/inf", "inf"],
    ["application/internet-property-stream", "acx"],
    ["application/ipfix", "ipfix"],
    ["application/java", "class"],
    ["application/java-archive", "jar"],
    ["application/java-byte-code", "class"],
    ["application/java-serialized-object", "ser"],
    ["application/java-vm", "class"],
    ["application/javascript", "js"],
    ["application/json", "json"],
    ["application/lha", "lha"],
    ["application/lzx", "lzx"],
    ["application/mac-binary", "bin"],
    ["application/mac-binhex", "hqx"],
    ["application/mac-binhex40", "hqx"],
    ["application/mac-compactpro", "cpt"],
    ["application/macbinary", "bin"],
    ["application/mads+xml", "mads"],
    ["application/marc", "mrc"],
    ["application/marcxml+xml", "mrcx"],
    ["application/mathematica", "ma"],
    ["application/mathml+xml", "mathml"],
    ["application/mbedlet", "mbd"],
    ["application/mbox", "mbox"],
    ["application/mcad", "mcd"],
    ["application/mediaservercontrol+xml", "mscml"],
    ["application/metalink4+xml", "meta4"],
    ["application/mets+xml", "mets"],
    ["application/mime", "aps"],
    ["application/mods+xml", "mods"],
    ["application/mp21", "m21"],
    ["application/mp4", "mp4"],
    ["application/mspowerpoint", ["ppt", "pot", "pps", "ppz"]],
    ["application/msword", ["doc", "dot", "w6w", "wiz", "word"]],
    ["application/mswrite", "wri"],
    ["application/mxf", "mxf"],
    ["application/netmc", "mcp"],
    ["application/octet-stream", ["*"]],
    ["application/oda", "oda"],
    ["application/oebps-package+xml", "opf"],
    ["application/ogg", "ogx"],
    ["application/olescript", "axs"],
    ["application/onenote", "onetoc"],
    ["application/patch-ops-error+xml", "xer"],
    ["application/pdf", "pdf"],
    ["application/pgp-encrypted", "asc"],
    ["application/pgp-signature", "pgp"],
    ["application/pics-rules", "prf"],
    ["application/pkcs-12", "p12"],
    ["application/pkcs-crl", "crl"],
    ["application/pkcs10", "p10"],
    ["application/pkcs7-mime", ["p7c", "p7m"]],
    ["application/pkcs7-signature", "p7s"],
    ["application/pkcs8", "p8"],
    ["application/pkix-attr-cert", "ac"],
    ["application/pkix-cert", ["cer", "crt"]],
    ["application/pkix-crl", "crl"],
    ["application/pkix-pkipath", "pkipath"],
    ["application/pkixcmp", "pki"],
    ["application/plain", "text"],
    ["application/pls+xml", "pls"],
    ["application/postscript", ["ps", "ai", "eps"]],
    ["application/powerpoint", "ppt"],
    ["application/pro_eng", ["part", "prt"]],
    ["application/prs.cww", "cww"],
    ["application/pskc+xml", "pskcxml"],
    ["application/rdf+xml", "rdf"],
    ["application/reginfo+xml", "rif"],
    ["application/relax-ng-compact-syntax", "rnc"],
    ["application/resource-lists+xml", "rl"],
    ["application/resource-lists-diff+xml", "rld"],
    ["application/ringing-tones", "rng"],
    ["application/rls-services+xml", "rs"],
    ["application/rsd+xml", "rsd"],
    ["application/rss+xml", "xml"],
    ["application/rtf", ["rtf", "rtx"]],
    ["application/sbml+xml", "sbml"],
    ["application/scvp-cv-request", "scq"],
    ["application/scvp-cv-response", "scs"],
    ["application/scvp-vp-request", "spq"],
    ["application/scvp-vp-response", "spp"],
    ["application/sdp", "sdp"],
    ["application/sea", "sea"],
    ["application/set", "set"],
    ["application/set-payment-initiation", "setpay"],
    ["application/set-registration-initiation", "setreg"],
    ["application/shf+xml", "shf"],
    ["application/sla", "stl"],
    ["application/smil", ["smi", "smil"]],
    ["application/smil+xml", "smi"],
    ["application/solids", "sol"],
    ["application/sounder", "sdr"],
    ["application/sparql-query", "rq"],
    ["application/sparql-results+xml", "srx"],
    ["application/srgs", "gram"],
    ["application/srgs+xml", "grxml"],
    ["application/sru+xml", "sru"],
    ["application/ssml+xml", "ssml"],
    ["application/step", ["step", "stp"]],
    ["application/streamingmedia", "ssm"],
    ["application/tei+xml", "tei"],
    ["application/thraud+xml", "tfi"],
    ["application/timestamped-data", "tsd"],
    ["application/toolbook", "tbk"],
    ["application/vda", "vda"],
    ["application/vnd.3gpp.pic-bw-large", "plb"],
    ["application/vnd.3gpp.pic-bw-small", "psb"],
    ["application/vnd.3gpp.pic-bw-var", "pvb"],
    ["application/vnd.3gpp2.tcap", "tcap"],
    ["application/vnd.3m.post-it-notes", "pwn"],
    ["application/vnd.accpac.simply.aso", "aso"],
    ["application/vnd.accpac.simply.imp", "imp"],
    ["application/vnd.acucobol", "acu"],
    ["application/vnd.acucorp", "atc"],
    ["application/vnd.adobe.air-application-installer-package+zip", "air"],
    ["application/vnd.adobe.fxp", "fxp"],
    ["application/vnd.adobe.xdp+xml", "xdp"],
    ["application/vnd.adobe.xfdf", "xfdf"],
    ["application/vnd.ahead.space", "ahead"],
    ["application/vnd.airzip.filesecure.azf", "azf"],
    ["application/vnd.airzip.filesecure.azs", "azs"],
    ["application/vnd.amazon.ebook", "azw"],
    ["application/vnd.americandynamics.acc", "acc"],
    ["application/vnd.amiga.ami", "ami"],
    ["application/vnd.android.package-archive", "apk"],
    ["application/vnd.anser-web-certificate-issue-initiation", "cii"],
    ["application/vnd.anser-web-funds-transfer-initiation", "fti"],
    ["application/vnd.antix.game-component", "atx"],
    ["application/vnd.apple.installer+xml", "mpkg"],
    ["application/vnd.apple.mpegurl", "m3u8"],
    ["application/vnd.aristanetworks.swi", "swi"],
    ["application/vnd.audiograph", "aep"],
    ["application/vnd.blueice.multipass", "mpm"],
    ["application/vnd.bmi", "bmi"],
    ["application/vnd.businessobjects", "rep"],
    ["application/vnd.chemdraw+xml", "cdxml"],
    ["application/vnd.chipnuts.karaoke-mmd", "mmd"],
    ["application/vnd.cinderella", "cdy"],
    ["application/vnd.claymore", "cla"],
    ["application/vnd.cloanto.rp9", "rp9"],
    ["application/vnd.clonk.c4group", "c4g"],
    ["application/vnd.cluetrust.cartomobile-config", "c11amc"],
    ["application/vnd.cluetrust.cartomobile-config-pkg", "c11amz"],
    ["application/vnd.commonspace", "csp"],
    ["application/vnd.contact.cmsg", "cdbcmsg"],
    ["application/vnd.cosmocaller", "cmc"],
    ["application/vnd.crick.clicker", "clkx"],
    ["application/vnd.crick.clicker.keyboard", "clkk"],
    ["application/vnd.crick.clicker.palette", "clkp"],
    ["application/vnd.crick.clicker.template", "clkt"],
    ["application/vnd.crick.clicker.wordbank", "clkw"],
    ["application/vnd.criticaltools.wbs+xml", "wbs"],
    ["application/vnd.ctc-posml", "pml"],
    ["application/vnd.cups-ppd", "ppd"],
    ["application/vnd.curl.car", "car"],
    ["application/vnd.curl.pcurl", "pcurl"],
    ["application/vnd.data-vision.rdz", "rdz"],
    ["application/vnd.denovo.fcselayout-link", "fe_launch"],
    ["application/vnd.dna", "dna"],
    ["application/vnd.dolby.mlp", "mlp"],
    ["application/vnd.dpgraph", "dpg"],
    ["application/vnd.dreamfactory", "dfac"],
    ["application/vnd.dvb.ait", "ait"],
    ["application/vnd.dvb.service", "svc"],
    ["application/vnd.dynageo", "geo"],
    ["application/vnd.ecowin.chart", "mag"],
    ["application/vnd.enliven", "nml"],
    ["application/vnd.epson.esf", "esf"],
    ["application/vnd.epson.msf", "msf"],
    ["application/vnd.epson.quickanime", "qam"],
    ["application/vnd.epson.salt", "slt"],
    ["application/vnd.epson.ssf", "ssf"],
    ["application/vnd.eszigno3+xml", "es3"],
    ["application/vnd.ezpix-album", "ez2"],
    ["application/vnd.ezpix-package", "ez3"],
    ["application/vnd.fdf", "fdf"],
    ["application/vnd.fdsn.seed", "seed"],
    ["application/vnd.flographit", "gph"],
    ["application/vnd.fluxtime.clip", "ftc"],
    ["application/vnd.framemaker", "fm"],
    ["application/vnd.frogans.fnc", "fnc"],
    ["application/vnd.frogans.ltf", "ltf"],
    ["application/vnd.fsc.weblaunch", "fsc"],
    ["application/vnd.fujitsu.oasys", "oas"],
    ["application/vnd.fujitsu.oasys2", "oa2"],
    ["application/vnd.fujitsu.oasys3", "oa3"],
    ["application/vnd.fujitsu.oasysgp", "fg5"],
    ["application/vnd.fujitsu.oasysprs", "bh2"],
    ["application/vnd.fujixerox.ddd", "ddd"],
    ["application/vnd.fujixerox.docuworks", "xdw"],
    ["application/vnd.fujixerox.docuworks.binder", "xbd"],
    ["application/vnd.fuzzysheet", "fzs"],
    ["application/vnd.genomatix.tuxedo", "txd"],
    ["application/vnd.geogebra.file", "ggb"],
    ["application/vnd.geogebra.tool", "ggt"],
    ["application/vnd.geometry-explorer", "gex"],
    ["application/vnd.geonext", "gxt"],
    ["application/vnd.geoplan", "g2w"],
    ["application/vnd.geospace", "g3w"],
    ["application/vnd.gmx", "gmx"],
    ["application/vnd.google-earth.kml+xml", "kml"],
    ["application/vnd.google-earth.kmz", "kmz"],
    ["application/vnd.grafeq", "gqf"],
    ["application/vnd.groove-account", "gac"],
    ["application/vnd.groove-help", "ghf"],
    ["application/vnd.groove-identity-message", "gim"],
    ["application/vnd.groove-injector", "grv"],
    ["application/vnd.groove-tool-message", "gtm"],
    ["application/vnd.groove-tool-template", "tpl"],
    ["application/vnd.groove-vcard", "vcg"],
    ["application/vnd.hal+xml", "hal"],
    ["application/vnd.handheld-entertainment+xml", "zmm"],
    ["application/vnd.hbci", "hbci"],
    ["application/vnd.hhe.lesson-player", "les"],
    ["application/vnd.hp-hpgl", ["hgl", "hpg", "hpgl"]],
    ["application/vnd.hp-hpid", "hpid"],
    ["application/vnd.hp-hps", "hps"],
    ["application/vnd.hp-jlyt", "jlt"],
    ["application/vnd.hp-pcl", "pcl"],
    ["application/vnd.hp-pclxl", "pclxl"],
    ["application/vnd.hydrostatix.sof-data", "sfd-hdstx"],
    ["application/vnd.hzn-3d-crossword", "x3d"],
    ["application/vnd.ibm.minipay", "mpy"],
    ["application/vnd.ibm.modcap", "afp"],
    ["application/vnd.ibm.rights-management", "irm"],
    ["application/vnd.ibm.secure-container", "sc"],
    ["application/vnd.iccprofile", "icc"],
    ["application/vnd.igloader", "igl"],
    ["application/vnd.immervision-ivp", "ivp"],
    ["application/vnd.immervision-ivu", "ivu"],
    ["application/vnd.insors.igm", "igm"],
    ["application/vnd.intercon.formnet", "xpw"],
    ["application/vnd.intergeo", "i2g"],
    ["application/vnd.intu.qbo", "qbo"],
    ["application/vnd.intu.qfx", "qfx"],
    ["application/vnd.ipunplugged.rcprofile", "rcprofile"],
    ["application/vnd.irepository.package+xml", "irp"],
    ["application/vnd.is-xpr", "xpr"],
    ["application/vnd.isac.fcs", "fcs"],
    ["application/vnd.jam", "jam"],
    ["application/vnd.jcp.javame.midlet-rms", "rms"],
    ["application/vnd.jisp", "jisp"],
    ["application/vnd.joost.joda-archive", "joda"],
    ["application/vnd.kahootz", "ktz"],
    ["application/vnd.kde.karbon", "karbon"],
    ["application/vnd.kde.kchart", "chrt"],
    ["application/vnd.kde.kformula", "kfo"],
    ["application/vnd.kde.kivio", "flw"],
    ["application/vnd.kde.kontour", "kon"],
    ["application/vnd.kde.kpresenter", "kpr"],
    ["application/vnd.kde.kspread", "ksp"],
    ["application/vnd.kde.kword", "kwd"],
    ["application/vnd.kenameaapp", "htke"],
    ["application/vnd.kidspiration", "kia"],
    ["application/vnd.kinar", "kne"],
    ["application/vnd.koan", "skp"],
    ["application/vnd.kodak-descriptor", "sse"],
    ["application/vnd.las.las+xml", "lasxml"],
    ["application/vnd.llamagraphics.life-balance.desktop", "lbd"],
    ["application/vnd.llamagraphics.life-balance.exchange+xml", "lbe"],
    ["application/vnd.lotus-1-2-3", "123"],
    ["application/vnd.lotus-approach", "apr"],
    ["application/vnd.lotus-freelance", "pre"],
    ["application/vnd.lotus-notes", "nsf"],
    ["application/vnd.lotus-organizer", "org"],
    ["application/vnd.lotus-screencam", "scm"],
    ["application/vnd.lotus-wordpro", "lwp"],
    ["application/vnd.macports.portpkg", "portpkg"],
    ["application/vnd.mcd", "mcd"],
    ["application/vnd.medcalcdata", "mc1"],
    ["application/vnd.mediastation.cdkey", "cdkey"],
    ["application/vnd.mfer", "mwf"],
    ["application/vnd.mfmp", "mfm"],
    ["application/vnd.micrografx.flo", "flo"],
    ["application/vnd.micrografx.igx", "igx"],
    ["application/vnd.mif", "mif"],
    ["application/vnd.mobius.daf", "daf"],
    ["application/vnd.mobius.dis", "dis"],
    ["application/vnd.mobius.mbk", "mbk"],
    ["application/vnd.mobius.mqy", "mqy"],
    ["application/vnd.mobius.msl", "msl"],
    ["application/vnd.mobius.plc", "plc"],
    ["application/vnd.mobius.txf", "txf"],
    ["application/vnd.mophun.application", "mpn"],
    ["application/vnd.mophun.certificate", "mpc"],
    ["application/vnd.mozilla.xul+xml", "xul"],
    ["application/vnd.ms-artgalry", "cil"],
    ["application/vnd.ms-cab-compressed", "cab"],
    ["application/vnd.ms-excel", ["xls", "xla", "xlc", "xlm", "xlt", "xlw", "xlb", "xll"]],
    ["application/vnd.ms-excel.addin.macroenabled.12", "xlam"],
    ["application/vnd.ms-excel.sheet.binary.macroenabled.12", "xlsb"],
    ["application/vnd.ms-excel.sheet.macroenabled.12", "xlsm"],
    ["application/vnd.ms-excel.template.macroenabled.12", "xltm"],
    ["application/vnd.ms-fontobject", "eot"],
    ["application/vnd.ms-htmlhelp", "chm"],
    ["application/vnd.ms-ims", "ims"],
    ["application/vnd.ms-lrm", "lrm"],
    ["application/vnd.ms-officetheme", "thmx"],
    ["application/vnd.ms-outlook", "msg"],
    ["application/vnd.ms-pki.certstore", "sst"],
    ["application/vnd.ms-pki.pko", "pko"],
    ["application/vnd.ms-pki.seccat", "cat"],
    ["application/vnd.ms-pki.stl", "stl"],
    ["application/vnd.ms-pkicertstore", "sst"],
    ["application/vnd.ms-pkiseccat", "cat"],
    ["application/vnd.ms-pkistl", "stl"],
    ["application/vnd.ms-powerpoint", ["ppt", "pot", "pps", "ppa", "pwz"]],
    ["application/vnd.ms-powerpoint.addin.macroenabled.12", "ppam"],
    ["application/vnd.ms-powerpoint.presentation.macroenabled.12", "pptm"],
    ["application/vnd.ms-powerpoint.slide.macroenabled.12", "sldm"],
    ["application/vnd.ms-powerpoint.slideshow.macroenabled.12", "ppsm"],
    ["application/vnd.ms-powerpoint.template.macroenabled.12", "potm"],
    ["application/vnd.ms-project", "mpp"],
    ["application/vnd.ms-word.document.macroenabled.12", "docm"],
    ["application/vnd.ms-word.template.macroenabled.12", "dotm"],
    ["application/vnd.ms-works", ["wks", "wcm", "wdb", "wps"]],
    ["application/vnd.ms-wpl", "wpl"],
    ["application/vnd.ms-xpsdocument", "xps"],
    ["application/vnd.mseq", "mseq"],
    ["application/vnd.musician", "mus"],
    ["application/vnd.muvee.style", "msty"],
    ["application/vnd.neurolanguage.nlu", "nlu"],
    ["application/vnd.noblenet-directory", "nnd"],
    ["application/vnd.noblenet-sealer", "nns"],
    ["application/vnd.noblenet-web", "nnw"],
    ["application/vnd.nokia.configuration-message", "ncm"],
    ["application/vnd.nokia.n-gage.data", "ngdat"],
    ["application/vnd.nokia.n-gage.symbian.install", "n-gage"],
    ["application/vnd.nokia.radio-preset", "rpst"],
    ["application/vnd.nokia.radio-presets", "rpss"],
    ["application/vnd.nokia.ringing-tone", "rng"],
    ["application/vnd.novadigm.edm", "edm"],
    ["application/vnd.novadigm.edx", "edx"],
    ["application/vnd.novadigm.ext", "ext"],
    ["application/vnd.oasis.opendocument.chart", "odc"],
    ["application/vnd.oasis.opendocument.chart-template", "otc"],
    ["application/vnd.oasis.opendocument.database", "odb"],
    ["application/vnd.oasis.opendocument.formula", "odf"],
    ["application/vnd.oasis.opendocument.formula-template", "odft"],
    ["application/vnd.oasis.opendocument.graphics", "odg"],
    ["application/vnd.oasis.opendocument.graphics-template", "otg"],
    ["application/vnd.oasis.opendocument.image", "odi"],
    ["application/vnd.oasis.opendocument.image-template", "oti"],
    ["application/vnd.oasis.opendocument.presentation", "odp"],
    ["application/vnd.oasis.opendocument.presentation-template", "otp"],
    ["application/vnd.oasis.opendocument.spreadsheet", "ods"],
    ["application/vnd.oasis.opendocument.spreadsheet-template", "ots"],
    ["application/vnd.oasis.opendocument.text", "odt"],
    ["application/vnd.oasis.opendocument.text-master", "odm"],
    ["application/vnd.oasis.opendocument.text-template", "ott"],
    ["application/vnd.oasis.opendocument.text-web", "oth"],
    ["application/vnd.olpc-sugar", "xo"],
    ["application/vnd.oma.dd2+xml", "dd2"],
    ["application/vnd.openofficeorg.extension", "oxt"],
    ["application/vnd.openxmlformats-officedocument.presentationml.presentation", "pptx"],
    ["application/vnd.openxmlformats-officedocument.presentationml.slide", "sldx"],
    ["application/vnd.openxmlformats-officedocument.presentationml.slideshow", "ppsx"],
    ["application/vnd.openxmlformats-officedocument.presentationml.template", "potx"],
    ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"],
    ["application/vnd.openxmlformats-officedocument.spreadsheetml.template", "xltx"],
    ["application/vnd.openxmlformats-officedocument.wordprocessingml.document", "docx"],
    ["application/vnd.openxmlformats-officedocument.wordprocessingml.template", "dotx"],
    ["application/vnd.osgeo.mapguide.package", "mgp"],
    ["application/vnd.osgi.dp", "dp"],
    ["application/vnd.palm", "pdb"],
    ["application/vnd.pawaafile", "paw"],
    ["application/vnd.pg.format", "str"],
    ["application/vnd.pg.osasli", "ei6"],
    ["application/vnd.picsel", "efif"],
    ["application/vnd.pmi.widget", "wg"],
    ["application/vnd.pocketlearn", "plf"],
    ["application/vnd.powerbuilder6", "pbd"],
    ["application/vnd.previewsystems.box", "box"],
    ["application/vnd.proteus.magazine", "mgz"],
    ["application/vnd.publishare-delta-tree", "qps"],
    ["application/vnd.pvi.ptid1", "ptid"],
    ["application/vnd.quark.quarkxpress", "qxd"],
    ["application/vnd.realvnc.bed", "bed"],
    ["application/vnd.recordare.musicxml", "mxl"],
    ["application/vnd.recordare.musicxml+xml", "musicxml"],
    ["application/vnd.rig.cryptonote", "cryptonote"],
    ["application/vnd.rim.cod", "cod"],
    ["application/vnd.rn-realmedia", "rm"],
    ["application/vnd.rn-realplayer", "rnx"],
    ["application/vnd.route66.link66+xml", "link66"],
    ["application/vnd.sailingtracker.track", "st"],
    ["application/vnd.seemail", "see"],
    ["application/vnd.sema", "sema"],
    ["application/vnd.semd", "semd"],
    ["application/vnd.semf", "semf"],
    ["application/vnd.shana.informed.formdata", "ifm"],
    ["application/vnd.shana.informed.formtemplate", "itp"],
    ["application/vnd.shana.informed.interchange", "iif"],
    ["application/vnd.shana.informed.package", "ipk"],
    ["application/vnd.simtech-mindmapper", "twd"],
    ["application/vnd.smaf", "mmf"],
    ["application/vnd.smart.teacher", "teacher"],
    ["application/vnd.solent.sdkm+xml", "sdkm"],
    ["application/vnd.spotfire.dxp", "dxp"],
    ["application/vnd.spotfire.sfs", "sfs"],
    ["application/vnd.stardivision.calc", "sdc"],
    ["application/vnd.stardivision.draw", "sda"],
    ["application/vnd.stardivision.impress", "sdd"],
    ["application/vnd.stardivision.math", "smf"],
    ["application/vnd.stardivision.writer", "sdw"],
    ["application/vnd.stardivision.writer-global", "sgl"],
    ["application/vnd.stepmania.stepchart", "sm"],
    ["application/vnd.sun.xml.calc", "sxc"],
    ["application/vnd.sun.xml.calc.template", "stc"],
    ["application/vnd.sun.xml.draw", "sxd"],
    ["application/vnd.sun.xml.draw.template", "std"],
    ["application/vnd.sun.xml.impress", "sxi"],
    ["application/vnd.sun.xml.impress.template", "sti"],
    ["application/vnd.sun.xml.math", "sxm"],
    ["application/vnd.sun.xml.writer", "sxw"],
    ["application/vnd.sun.xml.writer.global", "sxg"],
    ["application/vnd.sun.xml.writer.template", "stw"],
    ["application/vnd.sus-calendar", "sus"],
    ["application/vnd.svd", "svd"],
    ["application/vnd.symbian.install", "sis"],
    ["application/vnd.syncml+xml", "xsm"],
    ["application/vnd.syncml.dm+wbxml", "bdm"],
    ["application/vnd.syncml.dm+xml", "xdm"],
    ["application/vnd.tao.intent-module-archive", "tao"],
    ["application/vnd.tmobile-livetv", "tmo"],
    ["application/vnd.trid.tpt", "tpt"],
    ["application/vnd.triscape.mxs", "mxs"],
    ["application/vnd.trueapp", "tra"],
    ["application/vnd.ufdl", "ufd"],
    ["application/vnd.uiq.theme", "utz"],
    ["application/vnd.umajin", "umj"],
    ["application/vnd.unity", "unityweb"],
    ["application/vnd.uoml+xml", "uoml"],
    ["application/vnd.vcx", "vcx"],
    ["application/vnd.visio", "vsd"],
    ["application/vnd.visionary", "vis"],
    ["application/vnd.vsf", "vsf"],
    ["application/vnd.wap.wbxml", "wbxml"],
    ["application/vnd.wap.wmlc", "wmlc"],
    ["application/vnd.wap.wmlscriptc", "wmlsc"],
    ["application/vnd.webturbo", "wtb"],
    ["application/vnd.wolfram.player", "nbp"],
    ["application/vnd.wordperfect", "wpd"],
    ["application/vnd.wqd", "wqd"],
    ["application/vnd.wt.stf", "stf"],
    ["application/vnd.xara", ["web", "xar"]],
    ["application/vnd.xfdl", "xfdl"],
    ["application/vnd.yamaha.hv-dic", "hvd"],
    ["application/vnd.yamaha.hv-script", "hvs"],
    ["application/vnd.yamaha.hv-voice", "hvp"],
    ["application/vnd.yamaha.openscoreformat", "osf"],
    ["application/vnd.yamaha.openscoreformat.osfpvg+xml", "osfpvg"],
    ["application/vnd.yamaha.smaf-audio", "saf"],
    ["application/vnd.yamaha.smaf-phrase", "spf"],
    ["application/vnd.yellowriver-custom-menu", "cmp"],
    ["application/vnd.zul", "zir"],
    ["application/vnd.zzazz.deck+xml", "zaz"],
    ["application/vocaltec-media-desc", "vmd"],
    ["application/vocaltec-media-file", "vmf"],
    ["application/voicexml+xml", "vxml"],
    ["application/widget", "wgt"],
    ["application/winhlp", "hlp"],
    ["application/wordperfect", ["wp", "wp5", "wp6", "wpd"]],
    ["application/wordperfect6.0", ["w60", "wp5"]],
    ["application/wordperfect6.1", "w61"],
    ["application/wsdl+xml", "wsdl"],
    ["application/wspolicy+xml", "wspolicy"],
    ["application/x-123", "wk1"],
    ["application/x-7z-compressed", "7z"],
    ["application/x-abiword", "abw"],
    ["application/x-ace-compressed", "ace"],
    ["application/x-aim", "aim"],
    ["application/x-authorware-bin", "aab"],
    ["application/x-authorware-map", "aam"],
    ["application/x-authorware-seg", "aas"],
    ["application/x-bcpio", "bcpio"],
    ["application/x-binary", "bin"],
    ["application/x-binhex40", "hqx"],
    ["application/x-bittorrent", "torrent"],
    ["application/x-bsh", ["bsh", "sh", "shar"]],
    ["application/x-bytecode.elisp", "elc"],
    ["application/x-bytecode.python", "pyc"],
    ["application/x-bzip", "bz"],
    ["application/x-bzip2", ["boz", "bz2"]],
    ["application/x-cdf", "cdf"],
    ["application/x-cdlink", "vcd"],
    ["application/x-chat", ["cha", "chat"]],
    ["application/x-chess-pgn", "pgn"],
    ["application/x-cmu-raster", "ras"],
    ["application/x-cocoa", "cco"],
    ["application/x-compactpro", "cpt"],
    ["application/x-compress", "z"],
    ["application/x-compressed", ["tgz", "gz", "z", "zip"]],
    ["application/x-conference", "nsc"],
    ["application/x-cpio", "cpio"],
    ["application/x-cpt", "cpt"],
    ["application/x-csh", "csh"],
    ["application/x-debian-package", "deb"],
    ["application/x-deepv", "deepv"],
    ["application/x-director", ["dir", "dcr", "dxr"]],
    ["application/x-doom", "wad"],
    ["application/x-dtbncx+xml", "ncx"],
    ["application/x-dtbook+xml", "dtb"],
    ["application/x-dtbresource+xml", "res"],
    ["application/x-dvi", "dvi"],
    ["application/x-elc", "elc"],
    ["application/x-envoy", ["env", "evy"]],
    ["application/x-esrehber", "es"],
    ["application/x-excel", ["xls", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw"]],
    ["application/x-font-bdf", "bdf"],
    ["application/x-font-ghostscript", "gsf"],
    ["application/x-font-linux-psf", "psf"],
    ["application/x-font-otf", "otf"],
    ["application/x-font-pcf", "pcf"],
    ["application/x-font-snf", "snf"],
    ["application/x-font-ttf", "ttf"],
    ["application/x-font-type1", "pfa"],
    ["application/x-font-woff", "woff"],
    ["application/x-frame", "mif"],
    ["application/x-freelance", "pre"],
    ["application/x-futuresplash", "spl"],
    ["application/x-gnumeric", "gnumeric"],
    ["application/x-gsp", "gsp"],
    ["application/x-gss", "gss"],
    ["application/x-gtar", "gtar"],
    ["application/x-gzip", ["gz", "gzip"]],
    ["application/x-hdf", "hdf"],
    ["application/x-helpfile", ["help", "hlp"]],
    ["application/x-httpd-imap", "imap"],
    ["application/x-ima", "ima"],
    ["application/x-internet-signup", ["ins", "isp"]],
    ["application/x-internett-signup", "ins"],
    ["application/x-inventor", "iv"],
    ["application/x-ip2", "ip"],
    ["application/x-iphone", "iii"],
    ["application/x-java-class", "class"],
    ["application/x-java-commerce", "jcm"],
    ["application/x-java-jnlp-file", "jnlp"],
    ["application/x-javascript", "js"],
    ["application/x-koan", ["skd", "skm", "skp", "skt"]],
    ["application/x-ksh", "ksh"],
    ["application/x-latex", ["latex", "ltx"]],
    ["application/x-lha", "lha"],
    ["application/x-lisp", "lsp"],
    ["application/x-livescreen", "ivy"],
    ["application/x-lotus", "wq1"],
    ["application/x-lotusscreencam", "scm"],
    ["application/x-lzh", "lzh"],
    ["application/x-lzx", "lzx"],
    ["application/x-mac-binhex40", "hqx"],
    ["application/x-macbinary", "bin"],
    ["application/x-magic-cap-package-1.0", "mc$"],
    ["application/x-mathcad", "mcd"],
    ["application/x-meme", "mm"],
    ["application/x-midi", ["mid", "midi"]],
    ["application/x-mif", "mif"],
    ["application/x-mix-transfer", "nix"],
    ["application/x-mobipocket-ebook", "prc"],
    ["application/x-mplayer2", "asx"],
    ["application/x-ms-application", "application"],
    ["application/x-ms-wmd", "wmd"],
    ["application/x-ms-wmz", "wmz"],
    ["application/x-ms-xbap", "xbap"],
    ["application/x-msaccess", "mdb"],
    ["application/x-msbinder", "obd"],
    ["application/x-mscardfile", "crd"],
    ["application/x-msclip", "clp"],
    ["application/x-msdownload", ["exe", "dll"]],
    ["application/x-msexcel", ["xls", "xla", "xlw"]],
    ["application/x-msmediaview", ["mvb", "m13", "m14"]],
    ["application/x-msmetafile", "wmf"],
    ["application/x-msmoney", "mny"],
    ["application/x-mspowerpoint", "ppt"],
    ["application/x-mspublisher", "pub"],
    ["application/x-msschedule", "scd"],
    ["application/x-msterminal", "trm"],
    ["application/x-mswrite", "wri"],
    ["application/x-navi-animation", "ani"],
    ["application/x-navidoc", "nvd"],
    ["application/x-navimap", "map"],
    ["application/x-navistyle", "stl"],
    ["application/x-netcdf", ["cdf", "nc"]],
    ["application/x-newton-compatible-pkg", "pkg"],
    ["application/x-nokia-9000-communicator-add-on-software", "aos"],
    ["application/x-omc", "omc"],
    ["application/x-omcdatamaker", "omcd"],
    ["application/x-omcregerator", "omcr"],
    ["application/x-pagemaker", ["pm4", "pm5"]],
    ["application/x-pcl", "pcl"],
    ["application/x-perfmon", ["pma", "pmc", "pml", "pmr", "pmw"]],
    ["application/x-pixclscript", "plx"],
    ["application/x-pkcs10", "p10"],
    ["application/x-pkcs12", ["p12", "pfx"]],
    ["application/x-pkcs7-certificates", ["p7b", "spc"]],
    ["application/x-pkcs7-certreqresp", "p7r"],
    ["application/x-pkcs7-mime", ["p7m", "p7c"]],
    ["application/x-pkcs7-signature", ["p7s", "p7a"]],
    ["application/x-pointplus", "css"],
    ["application/x-portable-anymap", "pnm"],
    ["application/x-project", ["mpc", "mpt", "mpv", "mpx"]],
    ["application/x-qpro", "wb1"],
    ["application/x-rar-compressed", "rar"],
    ["application/x-rtf", "rtf"],
    ["application/x-sdp", "sdp"],
    ["application/x-sea", "sea"],
    ["application/x-seelogo", "sl"],
    ["application/x-sh", "sh"],
    ["application/x-shar", ["shar", "sh"]],
    ["application/x-shockwave-flash", "swf"],
    ["application/x-silverlight-app", "xap"],
    ["application/x-sit", "sit"],
    ["application/x-sprite", ["spr", "sprite"]],
    ["application/x-stuffit", "sit"],
    ["application/x-stuffitx", "sitx"],
    ["application/x-sv4cpio", "sv4cpio"],
    ["application/x-sv4crc", "sv4crc"],
    ["application/x-tar", "tar"],
    ["application/x-tbook", ["sbk", "tbk"]],
    ["application/x-tcl", "tcl"],
    ["application/x-tex", "tex"],
    ["application/x-tex-tfm", "tfm"],
    ["application/x-texinfo", ["texi", "texinfo"]],
    ["application/x-troff", ["roff", "t", "tr"]],
    ["application/x-troff-man", "man"],
    ["application/x-troff-me", "me"],
    ["application/x-troff-ms", "ms"],
    ["application/x-troff-msvideo", "avi"],
    ["application/x-ustar", "ustar"],
    ["application/x-visio", ["vsd", "vst", "vsw"]],
    ["application/x-vnd.audioexplosion.mzz", "mzz"],
    ["application/x-vnd.ls-xpix", "xpix"],
    ["application/x-vrml", "vrml"],
    ["application/x-wais-source", ["src", "wsrc"]],
    ["application/x-winhelp", "hlp"],
    ["application/x-wintalk", "wtk"],
    ["application/x-world", ["wrl", "svr"]],
    ["application/x-wpwin", "wpd"],
    ["application/x-wri", "wri"],
    ["application/x-x509-ca-cert", ["cer", "crt", "der"]],
    ["application/x-x509-user-cert", "crt"],
    ["application/x-xfig", "fig"],
    ["application/x-xpinstall", "xpi"],
    ["application/x-zip-compressed", "zip"],
    ["application/xcap-diff+xml", "xdf"],
    ["application/xenc+xml", "xenc"],
    ["application/xhtml+xml", "xhtml"],
    ["application/xml", "xml"],
    ["application/xml-dtd", "dtd"],
    ["application/xop+xml", "xop"],
    ["application/xslt+xml", "xslt"],
    ["application/xspf+xml", "xspf"],
    ["application/xv+xml", "mxml"],
    ["application/yang", "yang"],
    ["application/yin+xml", "yin"],
    ["application/ynd.ms-pkipko", "pko"],
    ["application/zip", "zip"],
    ["audio/adpcm", "adp"],
    ["audio/aiff", ["aiff", "aif", "aifc"]],
    ["audio/basic", ["snd", "au"]],
    ["audio/it", "it"],
    ["audio/make", ["funk", "my", "pfunk"]],
    ["audio/make.my.funk", "pfunk"],
    ["audio/mid", ["mid", "rmi"]],
    ["audio/midi", ["midi", "kar", "mid"]],
    ["audio/mod", "mod"],
    ["audio/mp4", "mp4a"],
    ["audio/mpeg", ["mpga", "mp3", "m2a", "mp2", "mpa", "mpg"]],
    ["audio/mpeg3", "mp3"],
    ["audio/nspaudio", ["la", "lma"]],
    ["audio/ogg", "oga"],
    ["audio/s3m", "s3m"],
    ["audio/tsp-audio", "tsi"],
    ["audio/tsplayer", "tsp"],
    ["audio/vnd.dece.audio", "uva"],
    ["audio/vnd.digital-winds", "eol"],
    ["audio/vnd.dra", "dra"],
    ["audio/vnd.dts", "dts"],
    ["audio/vnd.dts.hd", "dtshd"],
    ["audio/vnd.lucent.voice", "lvp"],
    ["audio/vnd.ms-playready.media.pya", "pya"],
    ["audio/vnd.nuera.ecelp4800", "ecelp4800"],
    ["audio/vnd.nuera.ecelp7470", "ecelp7470"],
    ["audio/vnd.nuera.ecelp9600", "ecelp9600"],
    ["audio/vnd.qcelp", "qcp"],
    ["audio/vnd.rip", "rip"],
    ["audio/voc", "voc"],
    ["audio/voxware", "vox"],
    ["audio/wav", "wav"],
    ["audio/webm", "weba"],
    ["audio/x-aac", "aac"],
    ["audio/x-adpcm", "snd"],
    ["audio/x-aiff", ["aiff", "aif", "aifc"]],
    ["audio/x-au", "au"],
    ["audio/x-gsm", ["gsd", "gsm"]],
    ["audio/x-jam", "jam"],
    ["audio/x-liveaudio", "lam"],
    ["audio/x-mid", ["mid", "midi"]],
    ["audio/x-midi", ["midi", "mid"]],
    ["audio/x-mod", "mod"],
    ["audio/x-mpeg", "mp2"],
    ["audio/x-mpeg-3", "mp3"],
    ["audio/x-mpegurl", "m3u"],
    ["audio/x-mpequrl", "m3u"],
    ["audio/x-ms-wax", "wax"],
    ["audio/x-ms-wma", "wma"],
    ["audio/x-nspaudio", ["la", "lma"]],
    ["audio/x-pn-realaudio", ["ra", "ram", "rm", "rmm", "rmp"]],
    ["audio/x-pn-realaudio-plugin", ["ra", "rmp", "rpm"]],
    ["audio/x-psid", "sid"],
    ["audio/x-realaudio", "ra"],
    ["audio/x-twinvq", "vqf"],
    ["audio/x-twinvq-plugin", ["vqe", "vql"]],
    ["audio/x-vnd.audioexplosion.mjuicemediafile", "mjf"],
    ["audio/x-voc", "voc"],
    ["audio/x-wav", "wav"],
    ["audio/xm", "xm"],
    ["chemical/x-cdx", "cdx"],
    ["chemical/x-cif", "cif"],
    ["chemical/x-cmdf", "cmdf"],
    ["chemical/x-cml", "cml"],
    ["chemical/x-csml", "csml"],
    ["chemical/x-pdb", ["pdb", "xyz"]],
    ["chemical/x-xyz", "xyz"],
    ["drawing/x-dwf", "dwf"],
    ["i-world/i-vrml", "ivr"],
    ["image/bmp", ["bmp", "bm"]],
    ["image/cgm", "cgm"],
    ["image/cis-cod", "cod"],
    ["image/cmu-raster", ["ras", "rast"]],
    ["image/fif", "fif"],
    ["image/florian", ["flo", "turbot"]],
    ["image/g3fax", "g3"],
    ["image/gif", "gif"],
    ["image/ief", ["ief", "iefs"]],
    ["image/jpeg", ["jpeg", "jpe", "jpg", "jfif", "jfif-tbnl"]],
    ["image/jutvision", "jut"],
    ["image/ktx", "ktx"],
    ["image/naplps", ["nap", "naplps"]],
    ["image/pict", ["pic", "pict"]],
    ["image/pipeg", "jfif"],
    ["image/pjpeg", ["jfif", "jpe", "jpeg", "jpg"]],
    ["image/png", ["png", "x-png"]],
    ["image/prs.btif", "btif"],
    ["image/svg+xml", "svg"],
    ["image/tiff", ["tif", "tiff"]],
    ["image/vasa", "mcf"],
    ["image/vnd.adobe.photoshop", "psd"],
    ["image/vnd.dece.graphic", "uvi"],
    ["image/vnd.djvu", "djvu"],
    ["image/vnd.dvb.subtitle", "sub"],
    ["image/vnd.dwg", ["dwg", "dxf", "svf"]],
    ["image/vnd.dxf", "dxf"],
    ["image/vnd.fastbidsheet", "fbs"],
    ["image/vnd.fpx", "fpx"],
    ["image/vnd.fst", "fst"],
    ["image/vnd.fujixerox.edmics-mmr", "mmr"],
    ["image/vnd.fujixerox.edmics-rlc", "rlc"],
    ["image/vnd.ms-modi", "mdi"],
    ["image/vnd.net-fpx", ["fpx", "npx"]],
    ["image/vnd.rn-realflash", "rf"],
    ["image/vnd.rn-realpix", "rp"],
    ["image/vnd.wap.wbmp", "wbmp"],
    ["image/vnd.xiff", "xif"],
    ["image/webp", "webp"],
    ["image/x-cmu-raster", "ras"],
    ["image/x-cmx", "cmx"],
    ["image/x-dwg", ["dwg", "dxf", "svf"]],
    ["image/x-freehand", "fh"],
    ["image/x-icon", "ico"],
    ["image/x-jg", "art"],
    ["image/x-jps", "jps"],
    ["image/x-niff", ["niff", "nif"]],
    ["image/x-pcx", "pcx"],
    ["image/x-pict", ["pct", "pic"]],
    ["image/x-portable-anymap", "pnm"],
    ["image/x-portable-bitmap", "pbm"],
    ["image/x-portable-graymap", "pgm"],
    ["image/x-portable-greymap", "pgm"],
    ["image/x-portable-pixmap", "ppm"],
    ["image/x-quicktime", ["qif", "qti", "qtif"]],
    ["image/x-rgb", "rgb"],
    ["image/x-tiff", ["tif", "tiff"]],
    ["image/x-windows-bmp", "bmp"],
    ["image/x-xbitmap", "xbm"],
    ["image/x-xbm", "xbm"],
    ["image/x-xpixmap", ["xpm", "pm"]],
    ["image/x-xwd", "xwd"],
    ["image/x-xwindowdump", "xwd"],
    ["image/xbm", "xbm"],
    ["image/xpm", "xpm"],
    ["message/rfc822", ["eml", "mht", "mhtml", "nws", "mime"]],
    ["model/iges", ["iges", "igs"]],
    ["model/mesh", "msh"],
    ["model/vnd.collada+xml", "dae"],
    ["model/vnd.dwf", "dwf"],
    ["model/vnd.gdl", "gdl"],
    ["model/vnd.gtw", "gtw"],
    ["model/vnd.mts", "mts"],
    ["model/vnd.vtu", "vtu"],
    ["model/vrml", ["vrml", "wrl", "wrz"]],
    ["model/x-pov", "pov"],
    ["multipart/x-gzip", "gzip"],
    ["multipart/x-ustar", "ustar"],
    ["multipart/x-zip", "zip"],
    ["music/crescendo", ["mid", "midi"]],
    ["music/x-karaoke", "kar"],
    ["paleovu/x-pv", "pvu"],
    ["text/asp", "asp"],
    ["text/calendar", "ics"],
    ["text/css", "css"],
    ["text/csv", "csv"],
    ["text/ecmascript", "js"],
    ["text/h323", "323"],
    ["text/html", ["html", "htm", "stm", "acgi", "htmls", "htx", "shtml"]],
    ["text/iuls", "uls"],
    ["text/javascript", "js"],
    ["text/mcf", "mcf"],
    ["text/n3", "n3"],
    ["text/pascal", "pas"],
    [
      "text/plain",
      [
        "txt",
        "bas",
        "c",
        "h",
        "c++",
        "cc",
        "com",
        "conf",
        "cxx",
        "def",
        "f",
        "f90",
        "for",
        "g",
        "hh",
        "idc",
        "jav",
        "java",
        "list",
        "log",
        "lst",
        "m",
        "mar",
        "pl",
        "sdml",
        "text"
      ]
    ],
    ["text/plain-bas", "par"],
    ["text/prs.lines.tag", "dsc"],
    ["text/richtext", ["rtx", "rt", "rtf"]],
    ["text/scriplet", "wsc"],
    ["text/scriptlet", "sct"],
    ["text/sgml", ["sgm", "sgml"]],
    ["text/tab-separated-values", "tsv"],
    ["text/troff", "t"],
    ["text/turtle", "ttl"],
    ["text/uri-list", ["uni", "unis", "uri", "uris"]],
    ["text/vnd.abc", "abc"],
    ["text/vnd.curl", "curl"],
    ["text/vnd.curl.dcurl", "dcurl"],
    ["text/vnd.curl.mcurl", "mcurl"],
    ["text/vnd.curl.scurl", "scurl"],
    ["text/vnd.fly", "fly"],
    ["text/vnd.fmi.flexstor", "flx"],
    ["text/vnd.graphviz", "gv"],
    ["text/vnd.in3d.3dml", "3dml"],
    ["text/vnd.in3d.spot", "spot"],
    ["text/vnd.rn-realtext", "rt"],
    ["text/vnd.sun.j2me.app-descriptor", "jad"],
    ["text/vnd.wap.wml", "wml"],
    ["text/vnd.wap.wmlscript", "wmls"],
    ["text/webviewhtml", "htt"],
    ["text/x-asm", ["asm", "s"]],
    ["text/x-audiosoft-intra", "aip"],
    ["text/x-c", ["c", "cc", "cpp"]],
    ["text/x-component", "htc"],
    ["text/x-fortran", ["for", "f", "f77", "f90"]],
    ["text/x-h", ["h", "hh"]],
    ["text/x-java-source", ["java", "jav"]],
    ["text/x-java-source,java", "java"],
    ["text/x-la-asf", "lsx"],
    ["text/x-m", "m"],
    ["text/x-pascal", "p"],
    ["text/x-script", "hlb"],
    ["text/x-script.csh", "csh"],
    ["text/x-script.elisp", "el"],
    ["text/x-script.guile", "scm"],
    ["text/x-script.ksh", "ksh"],
    ["text/x-script.lisp", "lsp"],
    ["text/x-script.perl", "pl"],
    ["text/x-script.perl-module", "pm"],
    ["text/x-script.phyton", "py"],
    ["text/x-script.rexx", "rexx"],
    ["text/x-script.scheme", "scm"],
    ["text/x-script.sh", "sh"],
    ["text/x-script.tcl", "tcl"],
    ["text/x-script.tcsh", "tcsh"],
    ["text/x-script.zsh", "zsh"],
    ["text/x-server-parsed-html", ["shtml", "ssi"]],
    ["text/x-setext", "etx"],
    ["text/x-sgml", ["sgm", "sgml"]],
    ["text/x-speech", ["spc", "talk"]],
    ["text/x-uil", "uil"],
    ["text/x-uuencode", ["uu", "uue"]],
    ["text/x-vcalendar", "vcs"],
    ["text/x-vcard", "vcf"],
    ["text/xml", "xml"],
    ["video/3gpp", "3gp"],
    ["video/3gpp2", "3g2"],
    ["video/animaflex", "afl"],
    ["video/avi", "avi"],
    ["video/avs-video", "avs"],
    ["video/dl", "dl"],
    ["video/fli", "fli"],
    ["video/gl", "gl"],
    ["video/h261", "h261"],
    ["video/h263", "h263"],
    ["video/h264", "h264"],
    ["video/jpeg", "jpgv"],
    ["video/jpm", "jpm"],
    ["video/mj2", "mj2"],
    ["video/mp4", "mp4"],
    ["video/mpeg", ["mpeg", "mp2", "mpa", "mpe", "mpg", "mpv2", "m1v", "m2v", "mp3"]],
    ["video/msvideo", "avi"],
    ["video/ogg", "ogv"],
    ["video/quicktime", ["mov", "qt", "moov"]],
    ["video/vdo", "vdo"],
    ["video/vivo", ["viv", "vivo"]],
    ["video/vnd.dece.hd", "uvh"],
    ["video/vnd.dece.mobile", "uvm"],
    ["video/vnd.dece.pd", "uvp"],
    ["video/vnd.dece.sd", "uvs"],
    ["video/vnd.dece.video", "uvv"],
    ["video/vnd.fvt", "fvt"],
    ["video/vnd.mpegurl", "mxu"],
    ["video/vnd.ms-playready.media.pyv", "pyv"],
    ["video/vnd.rn-realvideo", "rv"],
    ["video/vnd.uvvu.mp4", "uvu"],
    ["video/vnd.vivo", ["viv", "vivo"]],
    ["video/vosaic", "vos"],
    ["video/webm", "webm"],
    ["video/x-amt-demorun", "xdr"],
    ["video/x-amt-showrun", "xsr"],
    ["video/x-atomic3d-feature", "fmf"],
    ["video/x-dl", "dl"],
    ["video/x-dv", ["dif", "dv"]],
    ["video/x-f4v", "f4v"],
    ["video/x-fli", "fli"],
    ["video/x-flv", "flv"],
    ["video/x-gl", "gl"],
    ["video/x-isvideo", "isu"],
    ["video/x-la-asf", ["lsf", "lsx"]],
    ["video/x-m4v", "m4v"],
    ["video/x-motion-jpeg", "mjpg"],
    ["video/x-mpeg", ["mp3", "mp2"]],
    ["video/x-mpeq2a", "mp2"],
    ["video/x-ms-asf", ["asf", "asr", "asx"]],
    ["video/x-ms-asf-plugin", "asx"],
    ["video/x-ms-wm", "wm"],
    ["video/x-ms-wmv", "wmv"],
    ["video/x-ms-wmx", "wmx"],
    ["video/x-ms-wvx", "wvx"],
    ["video/x-msvideo", "avi"],
    ["video/x-qtc", "qtc"],
    ["video/x-scm", "scm"],
    ["video/x-sgi-movie", ["movie", "mv"]],
    ["windows/metafile", "wmf"],
    ["www/mime", "mime"],
    ["x-conference/x-cooltalk", "ice"],
    ["x-music/x-midi", ["mid", "midi"]],
    ["x-world/x-3dmf", ["3dm", "3dmf", "qd3", "qd3d"]],
    ["x-world/x-svr", "svr"],
    ["x-world/x-vrml", ["flr", "vrml", "wrl", "wrz", "xaf", "xof"]],
    ["x-world/x-vrt", "vrt"],
    ["xgl/drawing", "xgz"],
    ["xgl/movie", "xmz"]
  ]);
  var extensions = new Map([
    ["123", "application/vnd.lotus-1-2-3"],
    ["323", "text/h323"],
    ["*", "application/octet-stream"],
    ["3dm", "x-world/x-3dmf"],
    ["3dmf", "x-world/x-3dmf"],
    ["3dml", "text/vnd.in3d.3dml"],
    ["3g2", "video/3gpp2"],
    ["3gp", "video/3gpp"],
    ["7z", "application/x-7z-compressed"],
    ["a", "application/octet-stream"],
    ["aab", "application/x-authorware-bin"],
    ["aac", "audio/x-aac"],
    ["aam", "application/x-authorware-map"],
    ["aas", "application/x-authorware-seg"],
    ["abc", "text/vnd.abc"],
    ["abw", "application/x-abiword"],
    ["ac", "application/pkix-attr-cert"],
    ["acc", "application/vnd.americandynamics.acc"],
    ["ace", "application/x-ace-compressed"],
    ["acgi", "text/html"],
    ["acu", "application/vnd.acucobol"],
    ["acx", "application/internet-property-stream"],
    ["adp", "audio/adpcm"],
    ["aep", "application/vnd.audiograph"],
    ["afl", "video/animaflex"],
    ["afp", "application/vnd.ibm.modcap"],
    ["ahead", "application/vnd.ahead.space"],
    ["ai", "application/postscript"],
    ["aif", ["audio/aiff", "audio/x-aiff"]],
    ["aifc", ["audio/aiff", "audio/x-aiff"]],
    ["aiff", ["audio/aiff", "audio/x-aiff"]],
    ["aim", "application/x-aim"],
    ["aip", "text/x-audiosoft-intra"],
    ["air", "application/vnd.adobe.air-application-installer-package+zip"],
    ["ait", "application/vnd.dvb.ait"],
    ["ami", "application/vnd.amiga.ami"],
    ["ani", "application/x-navi-animation"],
    ["aos", "application/x-nokia-9000-communicator-add-on-software"],
    ["apk", "application/vnd.android.package-archive"],
    ["application", "application/x-ms-application"],
    ["apr", "application/vnd.lotus-approach"],
    ["aps", "application/mime"],
    ["arc", "application/octet-stream"],
    ["arj", ["application/arj", "application/octet-stream"]],
    ["art", "image/x-jg"],
    ["asf", "video/x-ms-asf"],
    ["asm", "text/x-asm"],
    ["aso", "application/vnd.accpac.simply.aso"],
    ["asp", "text/asp"],
    ["asr", "video/x-ms-asf"],
    ["asx", ["video/x-ms-asf", "application/x-mplayer2", "video/x-ms-asf-plugin"]],
    ["atc", "application/vnd.acucorp"],
    ["atomcat", "application/atomcat+xml"],
    ["atomsvc", "application/atomsvc+xml"],
    ["atx", "application/vnd.antix.game-component"],
    ["au", ["audio/basic", "audio/x-au"]],
    ["avi", ["video/avi", "video/msvideo", "application/x-troff-msvideo", "video/x-msvideo"]],
    ["avs", "video/avs-video"],
    ["aw", "application/applixware"],
    ["axs", "application/olescript"],
    ["azf", "application/vnd.airzip.filesecure.azf"],
    ["azs", "application/vnd.airzip.filesecure.azs"],
    ["azw", "application/vnd.amazon.ebook"],
    ["bas", "text/plain"],
    ["bcpio", "application/x-bcpio"],
    ["bdf", "application/x-font-bdf"],
    ["bdm", "application/vnd.syncml.dm+wbxml"],
    ["bed", "application/vnd.realvnc.bed"],
    ["bh2", "application/vnd.fujitsu.oasysprs"],
    ["bin", ["application/octet-stream", "application/mac-binary", "application/macbinary", "application/x-macbinary", "application/x-binary"]],
    ["bm", "image/bmp"],
    ["bmi", "application/vnd.bmi"],
    ["bmp", ["image/bmp", "image/x-windows-bmp"]],
    ["boo", "application/book"],
    ["book", "application/book"],
    ["box", "application/vnd.previewsystems.box"],
    ["boz", "application/x-bzip2"],
    ["bsh", "application/x-bsh"],
    ["btif", "image/prs.btif"],
    ["bz", "application/x-bzip"],
    ["bz2", "application/x-bzip2"],
    ["c", ["text/plain", "text/x-c"]],
    ["c++", "text/plain"],
    ["c11amc", "application/vnd.cluetrust.cartomobile-config"],
    ["c11amz", "application/vnd.cluetrust.cartomobile-config-pkg"],
    ["c4g", "application/vnd.clonk.c4group"],
    ["cab", "application/vnd.ms-cab-compressed"],
    ["car", "application/vnd.curl.car"],
    ["cat", ["application/vnd.ms-pkiseccat", "application/vnd.ms-pki.seccat"]],
    ["cc", ["text/plain", "text/x-c"]],
    ["ccad", "application/clariscad"],
    ["cco", "application/x-cocoa"],
    ["ccxml", "application/ccxml+xml,"],
    ["cdbcmsg", "application/vnd.contact.cmsg"],
    ["cdf", ["application/cdf", "application/x-cdf", "application/x-netcdf"]],
    ["cdkey", "application/vnd.mediastation.cdkey"],
    ["cdmia", "application/cdmi-capability"],
    ["cdmic", "application/cdmi-container"],
    ["cdmid", "application/cdmi-domain"],
    ["cdmio", "application/cdmi-object"],
    ["cdmiq", "application/cdmi-queue"],
    ["cdx", "chemical/x-cdx"],
    ["cdxml", "application/vnd.chemdraw+xml"],
    ["cdy", "application/vnd.cinderella"],
    ["cer", ["application/pkix-cert", "application/x-x509-ca-cert"]],
    ["cgm", "image/cgm"],
    ["cha", "application/x-chat"],
    ["chat", "application/x-chat"],
    ["chm", "application/vnd.ms-htmlhelp"],
    ["chrt", "application/vnd.kde.kchart"],
    ["cif", "chemical/x-cif"],
    ["cii", "application/vnd.anser-web-certificate-issue-initiation"],
    ["cil", "application/vnd.ms-artgalry"],
    ["cla", "application/vnd.claymore"],
    ["class", ["application/octet-stream", "application/java", "application/java-byte-code", "application/java-vm", "application/x-java-class"]],
    ["clkk", "application/vnd.crick.clicker.keyboard"],
    ["clkp", "application/vnd.crick.clicker.palette"],
    ["clkt", "application/vnd.crick.clicker.template"],
    ["clkw", "application/vnd.crick.clicker.wordbank"],
    ["clkx", "application/vnd.crick.clicker"],
    ["clp", "application/x-msclip"],
    ["cmc", "application/vnd.cosmocaller"],
    ["cmdf", "chemical/x-cmdf"],
    ["cml", "chemical/x-cml"],
    ["cmp", "application/vnd.yellowriver-custom-menu"],
    ["cmx", "image/x-cmx"],
    ["cod", ["image/cis-cod", "application/vnd.rim.cod"]],
    ["com", ["application/octet-stream", "text/plain"]],
    ["conf", "text/plain"],
    ["cpio", "application/x-cpio"],
    ["cpp", "text/x-c"],
    ["cpt", ["application/mac-compactpro", "application/x-compactpro", "application/x-cpt"]],
    ["crd", "application/x-mscardfile"],
    ["crl", ["application/pkix-crl", "application/pkcs-crl"]],
    ["crt", ["application/pkix-cert", "application/x-x509-user-cert", "application/x-x509-ca-cert"]],
    ["cryptonote", "application/vnd.rig.cryptonote"],
    ["csh", ["text/x-script.csh", "application/x-csh"]],
    ["csml", "chemical/x-csml"],
    ["csp", "application/vnd.commonspace"],
    ["css", ["text/css", "application/x-pointplus"]],
    ["csv", "text/csv"],
    ["cu", "application/cu-seeme"],
    ["curl", "text/vnd.curl"],
    ["cww", "application/prs.cww"],
    ["cxx", "text/plain"],
    ["dae", "model/vnd.collada+xml"],
    ["daf", "application/vnd.mobius.daf"],
    ["davmount", "application/davmount+xml"],
    ["dcr", "application/x-director"],
    ["dcurl", "text/vnd.curl.dcurl"],
    ["dd2", "application/vnd.oma.dd2+xml"],
    ["ddd", "application/vnd.fujixerox.ddd"],
    ["deb", "application/x-debian-package"],
    ["deepv", "application/x-deepv"],
    ["def", "text/plain"],
    ["der", "application/x-x509-ca-cert"],
    ["dfac", "application/vnd.dreamfactory"],
    ["dif", "video/x-dv"],
    ["dir", "application/x-director"],
    ["dis", "application/vnd.mobius.dis"],
    ["djvu", "image/vnd.djvu"],
    ["dl", ["video/dl", "video/x-dl"]],
    ["dll", "application/x-msdownload"],
    ["dms", "application/octet-stream"],
    ["dna", "application/vnd.dna"],
    ["doc", "application/msword"],
    ["docm", "application/vnd.ms-word.document.macroenabled.12"],
    ["docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"],
    ["dot", "application/msword"],
    ["dotm", "application/vnd.ms-word.template.macroenabled.12"],
    ["dotx", "application/vnd.openxmlformats-officedocument.wordprocessingml.template"],
    ["dp", ["application/commonground", "application/vnd.osgi.dp"]],
    ["dpg", "application/vnd.dpgraph"],
    ["dra", "audio/vnd.dra"],
    ["drw", "application/drafting"],
    ["dsc", "text/prs.lines.tag"],
    ["dssc", "application/dssc+der"],
    ["dtb", "application/x-dtbook+xml"],
    ["dtd", "application/xml-dtd"],
    ["dts", "audio/vnd.dts"],
    ["dtshd", "audio/vnd.dts.hd"],
    ["dump", "application/octet-stream"],
    ["dv", "video/x-dv"],
    ["dvi", "application/x-dvi"],
    ["dwf", ["model/vnd.dwf", "drawing/x-dwf"]],
    ["dwg", ["application/acad", "image/vnd.dwg", "image/x-dwg"]],
    ["dxf", ["application/dxf", "image/vnd.dwg", "image/vnd.dxf", "image/x-dwg"]],
    ["dxp", "application/vnd.spotfire.dxp"],
    ["dxr", "application/x-director"],
    ["ecelp4800", "audio/vnd.nuera.ecelp4800"],
    ["ecelp7470", "audio/vnd.nuera.ecelp7470"],
    ["ecelp9600", "audio/vnd.nuera.ecelp9600"],
    ["edm", "application/vnd.novadigm.edm"],
    ["edx", "application/vnd.novadigm.edx"],
    ["efif", "application/vnd.picsel"],
    ["ei6", "application/vnd.pg.osasli"],
    ["el", "text/x-script.elisp"],
    ["elc", ["application/x-elc", "application/x-bytecode.elisp"]],
    ["eml", "message/rfc822"],
    ["emma", "application/emma+xml"],
    ["env", "application/x-envoy"],
    ["eol", "audio/vnd.digital-winds"],
    ["eot", "application/vnd.ms-fontobject"],
    ["eps", "application/postscript"],
    ["epub", "application/epub+zip"],
    ["es", ["application/ecmascript", "application/x-esrehber"]],
    ["es3", "application/vnd.eszigno3+xml"],
    ["esf", "application/vnd.epson.esf"],
    ["etx", "text/x-setext"],
    ["evy", ["application/envoy", "application/x-envoy"]],
    ["exe", ["application/octet-stream", "application/x-msdownload"]],
    ["exi", "application/exi"],
    ["ext", "application/vnd.novadigm.ext"],
    ["ez2", "application/vnd.ezpix-album"],
    ["ez3", "application/vnd.ezpix-package"],
    ["f", ["text/plain", "text/x-fortran"]],
    ["f4v", "video/x-f4v"],
    ["f77", "text/x-fortran"],
    ["f90", ["text/plain", "text/x-fortran"]],
    ["fbs", "image/vnd.fastbidsheet"],
    ["fcs", "application/vnd.isac.fcs"],
    ["fdf", "application/vnd.fdf"],
    ["fe_launch", "application/vnd.denovo.fcselayout-link"],
    ["fg5", "application/vnd.fujitsu.oasysgp"],
    ["fh", "image/x-freehand"],
    ["fif", ["application/fractals", "image/fif"]],
    ["fig", "application/x-xfig"],
    ["fli", ["video/fli", "video/x-fli"]],
    ["flo", ["image/florian", "application/vnd.micrografx.flo"]],
    ["flr", "x-world/x-vrml"],
    ["flv", "video/x-flv"],
    ["flw", "application/vnd.kde.kivio"],
    ["flx", "text/vnd.fmi.flexstor"],
    ["fly", "text/vnd.fly"],
    ["fm", "application/vnd.framemaker"],
    ["fmf", "video/x-atomic3d-feature"],
    ["fnc", "application/vnd.frogans.fnc"],
    ["for", ["text/plain", "text/x-fortran"]],
    ["fpx", ["image/vnd.fpx", "image/vnd.net-fpx"]],
    ["frl", "application/freeloader"],
    ["fsc", "application/vnd.fsc.weblaunch"],
    ["fst", "image/vnd.fst"],
    ["ftc", "application/vnd.fluxtime.clip"],
    ["fti", "application/vnd.anser-web-funds-transfer-initiation"],
    ["funk", "audio/make"],
    ["fvt", "video/vnd.fvt"],
    ["fxp", "application/vnd.adobe.fxp"],
    ["fzs", "application/vnd.fuzzysheet"],
    ["g", "text/plain"],
    ["g2w", "application/vnd.geoplan"],
    ["g3", "image/g3fax"],
    ["g3w", "application/vnd.geospace"],
    ["gac", "application/vnd.groove-account"],
    ["gdl", "model/vnd.gdl"],
    ["geo", "application/vnd.dynageo"],
    ["gex", "application/vnd.geometry-explorer"],
    ["ggb", "application/vnd.geogebra.file"],
    ["ggt", "application/vnd.geogebra.tool"],
    ["ghf", "application/vnd.groove-help"],
    ["gif", "image/gif"],
    ["gim", "application/vnd.groove-identity-message"],
    ["gl", ["video/gl", "video/x-gl"]],
    ["gmx", "application/vnd.gmx"],
    ["gnumeric", "application/x-gnumeric"],
    ["gph", "application/vnd.flographit"],
    ["gqf", "application/vnd.grafeq"],
    ["gram", "application/srgs"],
    ["grv", "application/vnd.groove-injector"],
    ["grxml", "application/srgs+xml"],
    ["gsd", "audio/x-gsm"],
    ["gsf", "application/x-font-ghostscript"],
    ["gsm", "audio/x-gsm"],
    ["gsp", "application/x-gsp"],
    ["gss", "application/x-gss"],
    ["gtar", "application/x-gtar"],
    ["gtm", "application/vnd.groove-tool-message"],
    ["gtw", "model/vnd.gtw"],
    ["gv", "text/vnd.graphviz"],
    ["gxt", "application/vnd.geonext"],
    ["gz", ["application/x-gzip", "application/x-compressed"]],
    ["gzip", ["multipart/x-gzip", "application/x-gzip"]],
    ["h", ["text/plain", "text/x-h"]],
    ["h261", "video/h261"],
    ["h263", "video/h263"],
    ["h264", "video/h264"],
    ["hal", "application/vnd.hal+xml"],
    ["hbci", "application/vnd.hbci"],
    ["hdf", "application/x-hdf"],
    ["help", "application/x-helpfile"],
    ["hgl", "application/vnd.hp-hpgl"],
    ["hh", ["text/plain", "text/x-h"]],
    ["hlb", "text/x-script"],
    ["hlp", ["application/winhlp", "application/hlp", "application/x-helpfile", "application/x-winhelp"]],
    ["hpg", "application/vnd.hp-hpgl"],
    ["hpgl", "application/vnd.hp-hpgl"],
    ["hpid", "application/vnd.hp-hpid"],
    ["hps", "application/vnd.hp-hps"],
    [
      "hqx",
      [
        "application/mac-binhex40",
        "application/binhex",
        "application/binhex4",
        "application/mac-binhex",
        "application/x-binhex40",
        "application/x-mac-binhex40"
      ]
    ],
    ["hta", "application/hta"],
    ["htc", "text/x-component"],
    ["htke", "application/vnd.kenameaapp"],
    ["htm", "text/html"],
    ["html", "text/html"],
    ["htmls", "text/html"],
    ["htt", "text/webviewhtml"],
    ["htx", "text/html"],
    ["hvd", "application/vnd.yamaha.hv-dic"],
    ["hvp", "application/vnd.yamaha.hv-voice"],
    ["hvs", "application/vnd.yamaha.hv-script"],
    ["i2g", "application/vnd.intergeo"],
    ["icc", "application/vnd.iccprofile"],
    ["ice", "x-conference/x-cooltalk"],
    ["ico", "image/x-icon"],
    ["ics", "text/calendar"],
    ["idc", "text/plain"],
    ["ief", "image/ief"],
    ["iefs", "image/ief"],
    ["ifm", "application/vnd.shana.informed.formdata"],
    ["iges", ["application/iges", "model/iges"]],
    ["igl", "application/vnd.igloader"],
    ["igm", "application/vnd.insors.igm"],
    ["igs", ["application/iges", "model/iges"]],
    ["igx", "application/vnd.micrografx.igx"],
    ["iif", "application/vnd.shana.informed.interchange"],
    ["iii", "application/x-iphone"],
    ["ima", "application/x-ima"],
    ["imap", "application/x-httpd-imap"],
    ["imp", "application/vnd.accpac.simply.imp"],
    ["ims", "application/vnd.ms-ims"],
    ["inf", "application/inf"],
    ["ins", ["application/x-internet-signup", "application/x-internett-signup"]],
    ["ip", "application/x-ip2"],
    ["ipfix", "application/ipfix"],
    ["ipk", "application/vnd.shana.informed.package"],
    ["irm", "application/vnd.ibm.rights-management"],
    ["irp", "application/vnd.irepository.package+xml"],
    ["isp", "application/x-internet-signup"],
    ["isu", "video/x-isvideo"],
    ["it", "audio/it"],
    ["itp", "application/vnd.shana.informed.formtemplate"],
    ["iv", "application/x-inventor"],
    ["ivp", "application/vnd.immervision-ivp"],
    ["ivr", "i-world/i-vrml"],
    ["ivu", "application/vnd.immervision-ivu"],
    ["ivy", "application/x-livescreen"],
    ["jad", "text/vnd.sun.j2me.app-descriptor"],
    ["jam", ["application/vnd.jam", "audio/x-jam"]],
    ["jar", "application/java-archive"],
    ["jav", ["text/plain", "text/x-java-source"]],
    ["java", ["text/plain", "text/x-java-source,java", "text/x-java-source"]],
    ["jcm", "application/x-java-commerce"],
    ["jfif", ["image/pipeg", "image/jpeg", "image/pjpeg"]],
    ["jfif-tbnl", "image/jpeg"],
    ["jisp", "application/vnd.jisp"],
    ["jlt", "application/vnd.hp-jlyt"],
    ["jnlp", "application/x-java-jnlp-file"],
    ["joda", "application/vnd.joost.joda-archive"],
    ["jpe", ["image/jpeg", "image/pjpeg"]],
    ["jpeg", ["image/jpeg", "image/pjpeg"]],
    ["jpg", ["image/jpeg", "image/pjpeg"]],
    ["jpgv", "video/jpeg"],
    ["jpm", "video/jpm"],
    ["jps", "image/x-jps"],
    ["js", ["application/javascript", "application/ecmascript", "text/javascript", "text/ecmascript", "application/x-javascript"]],
    ["json", "application/json"],
    ["jut", "image/jutvision"],
    ["kar", ["audio/midi", "music/x-karaoke"]],
    ["karbon", "application/vnd.kde.karbon"],
    ["kfo", "application/vnd.kde.kformula"],
    ["kia", "application/vnd.kidspiration"],
    ["kml", "application/vnd.google-earth.kml+xml"],
    ["kmz", "application/vnd.google-earth.kmz"],
    ["kne", "application/vnd.kinar"],
    ["kon", "application/vnd.kde.kontour"],
    ["kpr", "application/vnd.kde.kpresenter"],
    ["ksh", ["application/x-ksh", "text/x-script.ksh"]],
    ["ksp", "application/vnd.kde.kspread"],
    ["ktx", "image/ktx"],
    ["ktz", "application/vnd.kahootz"],
    ["kwd", "application/vnd.kde.kword"],
    ["la", ["audio/nspaudio", "audio/x-nspaudio"]],
    ["lam", "audio/x-liveaudio"],
    ["lasxml", "application/vnd.las.las+xml"],
    ["latex", "application/x-latex"],
    ["lbd", "application/vnd.llamagraphics.life-balance.desktop"],
    ["lbe", "application/vnd.llamagraphics.life-balance.exchange+xml"],
    ["les", "application/vnd.hhe.lesson-player"],
    ["lha", ["application/octet-stream", "application/lha", "application/x-lha"]],
    ["lhx", "application/octet-stream"],
    ["link66", "application/vnd.route66.link66+xml"],
    ["list", "text/plain"],
    ["lma", ["audio/nspaudio", "audio/x-nspaudio"]],
    ["log", "text/plain"],
    ["lrm", "application/vnd.ms-lrm"],
    ["lsf", "video/x-la-asf"],
    ["lsp", ["application/x-lisp", "text/x-script.lisp"]],
    ["lst", "text/plain"],
    ["lsx", ["video/x-la-asf", "text/x-la-asf"]],
    ["ltf", "application/vnd.frogans.ltf"],
    ["ltx", "application/x-latex"],
    ["lvp", "audio/vnd.lucent.voice"],
    ["lwp", "application/vnd.lotus-wordpro"],
    ["lzh", ["application/octet-stream", "application/x-lzh"]],
    ["lzx", ["application/lzx", "application/octet-stream", "application/x-lzx"]],
    ["m", ["text/plain", "text/x-m"]],
    ["m13", "application/x-msmediaview"],
    ["m14", "application/x-msmediaview"],
    ["m1v", "video/mpeg"],
    ["m21", "application/mp21"],
    ["m2a", "audio/mpeg"],
    ["m2v", "video/mpeg"],
    ["m3u", ["audio/x-mpegurl", "audio/x-mpequrl"]],
    ["m3u8", "application/vnd.apple.mpegurl"],
    ["m4v", "video/x-m4v"],
    ["ma", "application/mathematica"],
    ["mads", "application/mads+xml"],
    ["mag", "application/vnd.ecowin.chart"],
    ["man", "application/x-troff-man"],
    ["map", "application/x-navimap"],
    ["mar", "text/plain"],
    ["mathml", "application/mathml+xml"],
    ["mbd", "application/mbedlet"],
    ["mbk", "application/vnd.mobius.mbk"],
    ["mbox", "application/mbox"],
    ["mc$", "application/x-magic-cap-package-1.0"],
    ["mc1", "application/vnd.medcalcdata"],
    ["mcd", ["application/mcad", "application/vnd.mcd", "application/x-mathcad"]],
    ["mcf", ["image/vasa", "text/mcf"]],
    ["mcp", "application/netmc"],
    ["mcurl", "text/vnd.curl.mcurl"],
    ["mdb", "application/x-msaccess"],
    ["mdi", "image/vnd.ms-modi"],
    ["me", "application/x-troff-me"],
    ["meta4", "application/metalink4+xml"],
    ["mets", "application/mets+xml"],
    ["mfm", "application/vnd.mfmp"],
    ["mgp", "application/vnd.osgeo.mapguide.package"],
    ["mgz", "application/vnd.proteus.magazine"],
    ["mht", "message/rfc822"],
    ["mhtml", "message/rfc822"],
    ["mid", ["audio/mid", "audio/midi", "music/crescendo", "x-music/x-midi", "audio/x-midi", "application/x-midi", "audio/x-mid"]],
    ["midi", ["audio/midi", "music/crescendo", "x-music/x-midi", "audio/x-midi", "application/x-midi", "audio/x-mid"]],
    ["mif", ["application/vnd.mif", "application/x-mif", "application/x-frame"]],
    ["mime", ["message/rfc822", "www/mime"]],
    ["mj2", "video/mj2"],
    ["mjf", "audio/x-vnd.audioexplosion.mjuicemediafile"],
    ["mjpg", "video/x-motion-jpeg"],
    ["mlp", "application/vnd.dolby.mlp"],
    ["mm", ["application/base64", "application/x-meme"]],
    ["mmd", "application/vnd.chipnuts.karaoke-mmd"],
    ["mme", "application/base64"],
    ["mmf", "application/vnd.smaf"],
    ["mmr", "image/vnd.fujixerox.edmics-mmr"],
    ["mny", "application/x-msmoney"],
    ["mod", ["audio/mod", "audio/x-mod"]],
    ["mods", "application/mods+xml"],
    ["moov", "video/quicktime"],
    ["mov", "video/quicktime"],
    ["movie", "video/x-sgi-movie"],
    ["mp2", ["video/mpeg", "audio/mpeg", "video/x-mpeg", "audio/x-mpeg", "video/x-mpeq2a"]],
    ["mp3", ["audio/mpeg", "audio/mpeg3", "video/mpeg", "audio/x-mpeg-3", "video/x-mpeg"]],
    ["mp4", ["video/mp4", "application/mp4"]],
    ["mp4a", "audio/mp4"],
    ["mpa", ["video/mpeg", "audio/mpeg"]],
    ["mpc", ["application/vnd.mophun.certificate", "application/x-project"]],
    ["mpe", "video/mpeg"],
    ["mpeg", "video/mpeg"],
    ["mpg", ["video/mpeg", "audio/mpeg"]],
    ["mpga", "audio/mpeg"],
    ["mpkg", "application/vnd.apple.installer+xml"],
    ["mpm", "application/vnd.blueice.multipass"],
    ["mpn", "application/vnd.mophun.application"],
    ["mpp", "application/vnd.ms-project"],
    ["mpt", "application/x-project"],
    ["mpv", "application/x-project"],
    ["mpv2", "video/mpeg"],
    ["mpx", "application/x-project"],
    ["mpy", "application/vnd.ibm.minipay"],
    ["mqy", "application/vnd.mobius.mqy"],
    ["mrc", "application/marc"],
    ["mrcx", "application/marcxml+xml"],
    ["ms", "application/x-troff-ms"],
    ["mscml", "application/mediaservercontrol+xml"],
    ["mseq", "application/vnd.mseq"],
    ["msf", "application/vnd.epson.msf"],
    ["msg", "application/vnd.ms-outlook"],
    ["msh", "model/mesh"],
    ["msl", "application/vnd.mobius.msl"],
    ["msty", "application/vnd.muvee.style"],
    ["mts", "model/vnd.mts"],
    ["mus", "application/vnd.musician"],
    ["musicxml", "application/vnd.recordare.musicxml+xml"],
    ["mv", "video/x-sgi-movie"],
    ["mvb", "application/x-msmediaview"],
    ["mwf", "application/vnd.mfer"],
    ["mxf", "application/mxf"],
    ["mxl", "application/vnd.recordare.musicxml"],
    ["mxml", "application/xv+xml"],
    ["mxs", "application/vnd.triscape.mxs"],
    ["mxu", "video/vnd.mpegurl"],
    ["my", "audio/make"],
    ["mzz", "application/x-vnd.audioexplosion.mzz"],
    ["n-gage", "application/vnd.nokia.n-gage.symbian.install"],
    ["n3", "text/n3"],
    ["nap", "image/naplps"],
    ["naplps", "image/naplps"],
    ["nbp", "application/vnd.wolfram.player"],
    ["nc", "application/x-netcdf"],
    ["ncm", "application/vnd.nokia.configuration-message"],
    ["ncx", "application/x-dtbncx+xml"],
    ["ngdat", "application/vnd.nokia.n-gage.data"],
    ["nif", "image/x-niff"],
    ["niff", "image/x-niff"],
    ["nix", "application/x-mix-transfer"],
    ["nlu", "application/vnd.neurolanguage.nlu"],
    ["nml", "application/vnd.enliven"],
    ["nnd", "application/vnd.noblenet-directory"],
    ["nns", "application/vnd.noblenet-sealer"],
    ["nnw", "application/vnd.noblenet-web"],
    ["npx", "image/vnd.net-fpx"],
    ["nsc", "application/x-conference"],
    ["nsf", "application/vnd.lotus-notes"],
    ["nvd", "application/x-navidoc"],
    ["nws", "message/rfc822"],
    ["o", "application/octet-stream"],
    ["oa2", "application/vnd.fujitsu.oasys2"],
    ["oa3", "application/vnd.fujitsu.oasys3"],
    ["oas", "application/vnd.fujitsu.oasys"],
    ["obd", "application/x-msbinder"],
    ["oda", "application/oda"],
    ["odb", "application/vnd.oasis.opendocument.database"],
    ["odc", "application/vnd.oasis.opendocument.chart"],
    ["odf", "application/vnd.oasis.opendocument.formula"],
    ["odft", "application/vnd.oasis.opendocument.formula-template"],
    ["odg", "application/vnd.oasis.opendocument.graphics"],
    ["odi", "application/vnd.oasis.opendocument.image"],
    ["odm", "application/vnd.oasis.opendocument.text-master"],
    ["odp", "application/vnd.oasis.opendocument.presentation"],
    ["ods", "application/vnd.oasis.opendocument.spreadsheet"],
    ["odt", "application/vnd.oasis.opendocument.text"],
    ["oga", "audio/ogg"],
    ["ogv", "video/ogg"],
    ["ogx", "application/ogg"],
    ["omc", "application/x-omc"],
    ["omcd", "application/x-omcdatamaker"],
    ["omcr", "application/x-omcregerator"],
    ["onetoc", "application/onenote"],
    ["opf", "application/oebps-package+xml"],
    ["org", "application/vnd.lotus-organizer"],
    ["osf", "application/vnd.yamaha.openscoreformat"],
    ["osfpvg", "application/vnd.yamaha.openscoreformat.osfpvg+xml"],
    ["otc", "application/vnd.oasis.opendocument.chart-template"],
    ["otf", "application/x-font-otf"],
    ["otg", "application/vnd.oasis.opendocument.graphics-template"],
    ["oth", "application/vnd.oasis.opendocument.text-web"],
    ["oti", "application/vnd.oasis.opendocument.image-template"],
    ["otp", "application/vnd.oasis.opendocument.presentation-template"],
    ["ots", "application/vnd.oasis.opendocument.spreadsheet-template"],
    ["ott", "application/vnd.oasis.opendocument.text-template"],
    ["oxt", "application/vnd.openofficeorg.extension"],
    ["p", "text/x-pascal"],
    ["p10", ["application/pkcs10", "application/x-pkcs10"]],
    ["p12", ["application/pkcs-12", "application/x-pkcs12"]],
    ["p7a", "application/x-pkcs7-signature"],
    ["p7b", "application/x-pkcs7-certificates"],
    ["p7c", ["application/pkcs7-mime", "application/x-pkcs7-mime"]],
    ["p7m", ["application/pkcs7-mime", "application/x-pkcs7-mime"]],
    ["p7r", "application/x-pkcs7-certreqresp"],
    ["p7s", ["application/pkcs7-signature", "application/x-pkcs7-signature"]],
    ["p8", "application/pkcs8"],
    ["par", "text/plain-bas"],
    ["part", "application/pro_eng"],
    ["pas", "text/pascal"],
    ["paw", "application/vnd.pawaafile"],
    ["pbd", "application/vnd.powerbuilder6"],
    ["pbm", "image/x-portable-bitmap"],
    ["pcf", "application/x-font-pcf"],
    ["pcl", ["application/vnd.hp-pcl", "application/x-pcl"]],
    ["pclxl", "application/vnd.hp-pclxl"],
    ["pct", "image/x-pict"],
    ["pcurl", "application/vnd.curl.pcurl"],
    ["pcx", "image/x-pcx"],
    ["pdb", ["application/vnd.palm", "chemical/x-pdb"]],
    ["pdf", "application/pdf"],
    ["pfa", "application/x-font-type1"],
    ["pfr", "application/font-tdpfr"],
    ["pfunk", ["audio/make", "audio/make.my.funk"]],
    ["pfx", "application/x-pkcs12"],
    ["pgm", ["image/x-portable-graymap", "image/x-portable-greymap"]],
    ["pgn", "application/x-chess-pgn"],
    ["pgp", "application/pgp-signature"],
    ["pic", ["image/pict", "image/x-pict"]],
    ["pict", "image/pict"],
    ["pkg", "application/x-newton-compatible-pkg"],
    ["pki", "application/pkixcmp"],
    ["pkipath", "application/pkix-pkipath"],
    ["pko", ["application/ynd.ms-pkipko", "application/vnd.ms-pki.pko"]],
    ["pl", ["text/plain", "text/x-script.perl"]],
    ["plb", "application/vnd.3gpp.pic-bw-large"],
    ["plc", "application/vnd.mobius.plc"],
    ["plf", "application/vnd.pocketlearn"],
    ["pls", "application/pls+xml"],
    ["plx", "application/x-pixclscript"],
    ["pm", ["text/x-script.perl-module", "image/x-xpixmap"]],
    ["pm4", "application/x-pagemaker"],
    ["pm5", "application/x-pagemaker"],
    ["pma", "application/x-perfmon"],
    ["pmc", "application/x-perfmon"],
    ["pml", ["application/vnd.ctc-posml", "application/x-perfmon"]],
    ["pmr", "application/x-perfmon"],
    ["pmw", "application/x-perfmon"],
    ["png", "image/png"],
    ["pnm", ["application/x-portable-anymap", "image/x-portable-anymap"]],
    ["portpkg", "application/vnd.macports.portpkg"],
    ["pot", ["application/vnd.ms-powerpoint", "application/mspowerpoint"]],
    ["potm", "application/vnd.ms-powerpoint.template.macroenabled.12"],
    ["potx", "application/vnd.openxmlformats-officedocument.presentationml.template"],
    ["pov", "model/x-pov"],
    ["ppa", "application/vnd.ms-powerpoint"],
    ["ppam", "application/vnd.ms-powerpoint.addin.macroenabled.12"],
    ["ppd", "application/vnd.cups-ppd"],
    ["ppm", "image/x-portable-pixmap"],
    ["pps", ["application/vnd.ms-powerpoint", "application/mspowerpoint"]],
    ["ppsm", "application/vnd.ms-powerpoint.slideshow.macroenabled.12"],
    ["ppsx", "application/vnd.openxmlformats-officedocument.presentationml.slideshow"],
    ["ppt", ["application/vnd.ms-powerpoint", "application/mspowerpoint", "application/powerpoint", "application/x-mspowerpoint"]],
    ["pptm", "application/vnd.ms-powerpoint.presentation.macroenabled.12"],
    ["pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation"],
    ["ppz", "application/mspowerpoint"],
    ["prc", "application/x-mobipocket-ebook"],
    ["pre", ["application/vnd.lotus-freelance", "application/x-freelance"]],
    ["prf", "application/pics-rules"],
    ["prt", "application/pro_eng"],
    ["ps", "application/postscript"],
    ["psb", "application/vnd.3gpp.pic-bw-small"],
    ["psd", ["application/octet-stream", "image/vnd.adobe.photoshop"]],
    ["psf", "application/x-font-linux-psf"],
    ["pskcxml", "application/pskc+xml"],
    ["ptid", "application/vnd.pvi.ptid1"],
    ["pub", "application/x-mspublisher"],
    ["pvb", "application/vnd.3gpp.pic-bw-var"],
    ["pvu", "paleovu/x-pv"],
    ["pwn", "application/vnd.3m.post-it-notes"],
    ["pwz", "application/vnd.ms-powerpoint"],
    ["py", "text/x-script.phyton"],
    ["pya", "audio/vnd.ms-playready.media.pya"],
    ["pyc", "application/x-bytecode.python"],
    ["pyv", "video/vnd.ms-playready.media.pyv"],
    ["qam", "application/vnd.epson.quickanime"],
    ["qbo", "application/vnd.intu.qbo"],
    ["qcp", "audio/vnd.qcelp"],
    ["qd3", "x-world/x-3dmf"],
    ["qd3d", "x-world/x-3dmf"],
    ["qfx", "application/vnd.intu.qfx"],
    ["qif", "image/x-quicktime"],
    ["qps", "application/vnd.publishare-delta-tree"],
    ["qt", "video/quicktime"],
    ["qtc", "video/x-qtc"],
    ["qti", "image/x-quicktime"],
    ["qtif", "image/x-quicktime"],
    ["qxd", "application/vnd.quark.quarkxpress"],
    ["ra", ["audio/x-realaudio", "audio/x-pn-realaudio", "audio/x-pn-realaudio-plugin"]],
    ["ram", "audio/x-pn-realaudio"],
    ["rar", "application/x-rar-compressed"],
    ["ras", ["image/cmu-raster", "application/x-cmu-raster", "image/x-cmu-raster"]],
    ["rast", "image/cmu-raster"],
    ["rcprofile", "application/vnd.ipunplugged.rcprofile"],
    ["rdf", "application/rdf+xml"],
    ["rdz", "application/vnd.data-vision.rdz"],
    ["rep", "application/vnd.businessobjects"],
    ["res", "application/x-dtbresource+xml"],
    ["rexx", "text/x-script.rexx"],
    ["rf", "image/vnd.rn-realflash"],
    ["rgb", "image/x-rgb"],
    ["rif", "application/reginfo+xml"],
    ["rip", "audio/vnd.rip"],
    ["rl", "application/resource-lists+xml"],
    ["rlc", "image/vnd.fujixerox.edmics-rlc"],
    ["rld", "application/resource-lists-diff+xml"],
    ["rm", ["application/vnd.rn-realmedia", "audio/x-pn-realaudio"]],
    ["rmi", "audio/mid"],
    ["rmm", "audio/x-pn-realaudio"],
    ["rmp", ["audio/x-pn-realaudio-plugin", "audio/x-pn-realaudio"]],
    ["rms", "application/vnd.jcp.javame.midlet-rms"],
    ["rnc", "application/relax-ng-compact-syntax"],
    ["rng", ["application/ringing-tones", "application/vnd.nokia.ringing-tone"]],
    ["rnx", "application/vnd.rn-realplayer"],
    ["roff", "application/x-troff"],
    ["rp", "image/vnd.rn-realpix"],
    ["rp9", "application/vnd.cloanto.rp9"],
    ["rpm", "audio/x-pn-realaudio-plugin"],
    ["rpss", "application/vnd.nokia.radio-presets"],
    ["rpst", "application/vnd.nokia.radio-preset"],
    ["rq", "application/sparql-query"],
    ["rs", "application/rls-services+xml"],
    ["rsd", "application/rsd+xml"],
    ["rt", ["text/richtext", "text/vnd.rn-realtext"]],
    ["rtf", ["application/rtf", "text/richtext", "application/x-rtf"]],
    ["rtx", ["text/richtext", "application/rtf"]],
    ["rv", "video/vnd.rn-realvideo"],
    ["s", "text/x-asm"],
    ["s3m", "audio/s3m"],
    ["saf", "application/vnd.yamaha.smaf-audio"],
    ["saveme", "application/octet-stream"],
    ["sbk", "application/x-tbook"],
    ["sbml", "application/sbml+xml"],
    ["sc", "application/vnd.ibm.secure-container"],
    ["scd", "application/x-msschedule"],
    ["scm", ["application/vnd.lotus-screencam", "video/x-scm", "text/x-script.guile", "application/x-lotusscreencam", "text/x-script.scheme"]],
    ["scq", "application/scvp-cv-request"],
    ["scs", "application/scvp-cv-response"],
    ["sct", "text/scriptlet"],
    ["scurl", "text/vnd.curl.scurl"],
    ["sda", "application/vnd.stardivision.draw"],
    ["sdc", "application/vnd.stardivision.calc"],
    ["sdd", "application/vnd.stardivision.impress"],
    ["sdkm", "application/vnd.solent.sdkm+xml"],
    ["sdml", "text/plain"],
    ["sdp", ["application/sdp", "application/x-sdp"]],
    ["sdr", "application/sounder"],
    ["sdw", "application/vnd.stardivision.writer"],
    ["sea", ["application/sea", "application/x-sea"]],
    ["see", "application/vnd.seemail"],
    ["seed", "application/vnd.fdsn.seed"],
    ["sema", "application/vnd.sema"],
    ["semd", "application/vnd.semd"],
    ["semf", "application/vnd.semf"],
    ["ser", "application/java-serialized-object"],
    ["set", "application/set"],
    ["setpay", "application/set-payment-initiation"],
    ["setreg", "application/set-registration-initiation"],
    ["sfd-hdstx", "application/vnd.hydrostatix.sof-data"],
    ["sfs", "application/vnd.spotfire.sfs"],
    ["sgl", "application/vnd.stardivision.writer-global"],
    ["sgm", ["text/sgml", "text/x-sgml"]],
    ["sgml", ["text/sgml", "text/x-sgml"]],
    ["sh", ["application/x-shar", "application/x-bsh", "application/x-sh", "text/x-script.sh"]],
    ["shar", ["application/x-bsh", "application/x-shar"]],
    ["shf", "application/shf+xml"],
    ["shtml", ["text/html", "text/x-server-parsed-html"]],
    ["sid", "audio/x-psid"],
    ["sis", "application/vnd.symbian.install"],
    ["sit", ["application/x-stuffit", "application/x-sit"]],
    ["sitx", "application/x-stuffitx"],
    ["skd", "application/x-koan"],
    ["skm", "application/x-koan"],
    ["skp", ["application/vnd.koan", "application/x-koan"]],
    ["skt", "application/x-koan"],
    ["sl", "application/x-seelogo"],
    ["sldm", "application/vnd.ms-powerpoint.slide.macroenabled.12"],
    ["sldx", "application/vnd.openxmlformats-officedocument.presentationml.slide"],
    ["slt", "application/vnd.epson.salt"],
    ["sm", "application/vnd.stepmania.stepchart"],
    ["smf", "application/vnd.stardivision.math"],
    ["smi", ["application/smil", "application/smil+xml"]],
    ["smil", "application/smil"],
    ["snd", ["audio/basic", "audio/x-adpcm"]],
    ["snf", "application/x-font-snf"],
    ["sol", "application/solids"],
    ["spc", ["text/x-speech", "application/x-pkcs7-certificates"]],
    ["spf", "application/vnd.yamaha.smaf-phrase"],
    ["spl", ["application/futuresplash", "application/x-futuresplash"]],
    ["spot", "text/vnd.in3d.spot"],
    ["spp", "application/scvp-vp-response"],
    ["spq", "application/scvp-vp-request"],
    ["spr", "application/x-sprite"],
    ["sprite", "application/x-sprite"],
    ["src", "application/x-wais-source"],
    ["sru", "application/sru+xml"],
    ["srx", "application/sparql-results+xml"],
    ["sse", "application/vnd.kodak-descriptor"],
    ["ssf", "application/vnd.epson.ssf"],
    ["ssi", "text/x-server-parsed-html"],
    ["ssm", "application/streamingmedia"],
    ["ssml", "application/ssml+xml"],
    ["sst", ["application/vnd.ms-pkicertstore", "application/vnd.ms-pki.certstore"]],
    ["st", "application/vnd.sailingtracker.track"],
    ["stc", "application/vnd.sun.xml.calc.template"],
    ["std", "application/vnd.sun.xml.draw.template"],
    ["step", "application/step"],
    ["stf", "application/vnd.wt.stf"],
    ["sti", "application/vnd.sun.xml.impress.template"],
    ["stk", "application/hyperstudio"],
    ["stl", ["application/vnd.ms-pkistl", "application/sla", "application/vnd.ms-pki.stl", "application/x-navistyle"]],
    ["stm", "text/html"],
    ["stp", "application/step"],
    ["str", "application/vnd.pg.format"],
    ["stw", "application/vnd.sun.xml.writer.template"],
    ["sub", "image/vnd.dvb.subtitle"],
    ["sus", "application/vnd.sus-calendar"],
    ["sv4cpio", "application/x-sv4cpio"],
    ["sv4crc", "application/x-sv4crc"],
    ["svc", "application/vnd.dvb.service"],
    ["svd", "application/vnd.svd"],
    ["svf", ["image/vnd.dwg", "image/x-dwg"]],
    ["svg", "image/svg+xml"],
    ["svr", ["x-world/x-svr", "application/x-world"]],
    ["swf", "application/x-shockwave-flash"],
    ["swi", "application/vnd.aristanetworks.swi"],
    ["sxc", "application/vnd.sun.xml.calc"],
    ["sxd", "application/vnd.sun.xml.draw"],
    ["sxg", "application/vnd.sun.xml.writer.global"],
    ["sxi", "application/vnd.sun.xml.impress"],
    ["sxm", "application/vnd.sun.xml.math"],
    ["sxw", "application/vnd.sun.xml.writer"],
    ["t", ["text/troff", "application/x-troff"]],
    ["talk", "text/x-speech"],
    ["tao", "application/vnd.tao.intent-module-archive"],
    ["tar", "application/x-tar"],
    ["tbk", ["application/toolbook", "application/x-tbook"]],
    ["tcap", "application/vnd.3gpp2.tcap"],
    ["tcl", ["text/x-script.tcl", "application/x-tcl"]],
    ["tcsh", "text/x-script.tcsh"],
    ["teacher", "application/vnd.smart.teacher"],
    ["tei", "application/tei+xml"],
    ["tex", "application/x-tex"],
    ["texi", "application/x-texinfo"],
    ["texinfo", "application/x-texinfo"],
    ["text", ["application/plain", "text/plain"]],
    ["tfi", "application/thraud+xml"],
    ["tfm", "application/x-tex-tfm"],
    ["tgz", ["application/gnutar", "application/x-compressed"]],
    ["thmx", "application/vnd.ms-officetheme"],
    ["tif", ["image/tiff", "image/x-tiff"]],
    ["tiff", ["image/tiff", "image/x-tiff"]],
    ["tmo", "application/vnd.tmobile-livetv"],
    ["torrent", "application/x-bittorrent"],
    ["tpl", "application/vnd.groove-tool-template"],
    ["tpt", "application/vnd.trid.tpt"],
    ["tr", "application/x-troff"],
    ["tra", "application/vnd.trueapp"],
    ["trm", "application/x-msterminal"],
    ["tsd", "application/timestamped-data"],
    ["tsi", "audio/tsp-audio"],
    ["tsp", ["application/dsptype", "audio/tsplayer"]],
    ["tsv", "text/tab-separated-values"],
    ["ttf", "application/x-font-ttf"],
    ["ttl", "text/turtle"],
    ["turbot", "image/florian"],
    ["twd", "application/vnd.simtech-mindmapper"],
    ["txd", "application/vnd.genomatix.tuxedo"],
    ["txf", "application/vnd.mobius.txf"],
    ["txt", "text/plain"],
    ["ufd", "application/vnd.ufdl"],
    ["uil", "text/x-uil"],
    ["uls", "text/iuls"],
    ["umj", "application/vnd.umajin"],
    ["uni", "text/uri-list"],
    ["unis", "text/uri-list"],
    ["unityweb", "application/vnd.unity"],
    ["unv", "application/i-deas"],
    ["uoml", "application/vnd.uoml+xml"],
    ["uri", "text/uri-list"],
    ["uris", "text/uri-list"],
    ["ustar", ["application/x-ustar", "multipart/x-ustar"]],
    ["utz", "application/vnd.uiq.theme"],
    ["uu", ["application/octet-stream", "text/x-uuencode"]],
    ["uue", "text/x-uuencode"],
    ["uva", "audio/vnd.dece.audio"],
    ["uvh", "video/vnd.dece.hd"],
    ["uvi", "image/vnd.dece.graphic"],
    ["uvm", "video/vnd.dece.mobile"],
    ["uvp", "video/vnd.dece.pd"],
    ["uvs", "video/vnd.dece.sd"],
    ["uvu", "video/vnd.uvvu.mp4"],
    ["uvv", "video/vnd.dece.video"],
    ["vcd", "application/x-cdlink"],
    ["vcf", "text/x-vcard"],
    ["vcg", "application/vnd.groove-vcard"],
    ["vcs", "text/x-vcalendar"],
    ["vcx", "application/vnd.vcx"],
    ["vda", "application/vda"],
    ["vdo", "video/vdo"],
    ["vew", "application/groupwise"],
    ["vis", "application/vnd.visionary"],
    ["viv", ["video/vivo", "video/vnd.vivo"]],
    ["vivo", ["video/vivo", "video/vnd.vivo"]],
    ["vmd", "application/vocaltec-media-desc"],
    ["vmf", "application/vocaltec-media-file"],
    ["voc", ["audio/voc", "audio/x-voc"]],
    ["vos", "video/vosaic"],
    ["vox", "audio/voxware"],
    ["vqe", "audio/x-twinvq-plugin"],
    ["vqf", "audio/x-twinvq"],
    ["vql", "audio/x-twinvq-plugin"],
    ["vrml", ["model/vrml", "x-world/x-vrml", "application/x-vrml"]],
    ["vrt", "x-world/x-vrt"],
    ["vsd", ["application/vnd.visio", "application/x-visio"]],
    ["vsf", "application/vnd.vsf"],
    ["vst", "application/x-visio"],
    ["vsw", "application/x-visio"],
    ["vtu", "model/vnd.vtu"],
    ["vxml", "application/voicexml+xml"],
    ["w60", "application/wordperfect6.0"],
    ["w61", "application/wordperfect6.1"],
    ["w6w", "application/msword"],
    ["wad", "application/x-doom"],
    ["wav", ["audio/wav", "audio/x-wav"]],
    ["wax", "audio/x-ms-wax"],
    ["wb1", "application/x-qpro"],
    ["wbmp", "image/vnd.wap.wbmp"],
    ["wbs", "application/vnd.criticaltools.wbs+xml"],
    ["wbxml", "application/vnd.wap.wbxml"],
    ["wcm", "application/vnd.ms-works"],
    ["wdb", "application/vnd.ms-works"],
    ["web", "application/vnd.xara"],
    ["weba", "audio/webm"],
    ["webm", "video/webm"],
    ["webp", "image/webp"],
    ["wg", "application/vnd.pmi.widget"],
    ["wgt", "application/widget"],
    ["wiz", "application/msword"],
    ["wk1", "application/x-123"],
    ["wks", "application/vnd.ms-works"],
    ["wm", "video/x-ms-wm"],
    ["wma", "audio/x-ms-wma"],
    ["wmd", "application/x-ms-wmd"],
    ["wmf", ["windows/metafile", "application/x-msmetafile"]],
    ["wml", "text/vnd.wap.wml"],
    ["wmlc", "application/vnd.wap.wmlc"],
    ["wmls", "text/vnd.wap.wmlscript"],
    ["wmlsc", "application/vnd.wap.wmlscriptc"],
    ["wmv", "video/x-ms-wmv"],
    ["wmx", "video/x-ms-wmx"],
    ["wmz", "application/x-ms-wmz"],
    ["woff", "application/x-font-woff"],
    ["word", "application/msword"],
    ["wp", "application/wordperfect"],
    ["wp5", ["application/wordperfect", "application/wordperfect6.0"]],
    ["wp6", "application/wordperfect"],
    ["wpd", ["application/wordperfect", "application/vnd.wordperfect", "application/x-wpwin"]],
    ["wpl", "application/vnd.ms-wpl"],
    ["wps", "application/vnd.ms-works"],
    ["wq1", "application/x-lotus"],
    ["wqd", "application/vnd.wqd"],
    ["wri", ["application/mswrite", "application/x-wri", "application/x-mswrite"]],
    ["wrl", ["model/vrml", "x-world/x-vrml", "application/x-world"]],
    ["wrz", ["model/vrml", "x-world/x-vrml"]],
    ["wsc", "text/scriplet"],
    ["wsdl", "application/wsdl+xml"],
    ["wspolicy", "application/wspolicy+xml"],
    ["wsrc", "application/x-wais-source"],
    ["wtb", "application/vnd.webturbo"],
    ["wtk", "application/x-wintalk"],
    ["wvx", "video/x-ms-wvx"],
    ["x-png", "image/png"],
    ["x3d", "application/vnd.hzn-3d-crossword"],
    ["xaf", "x-world/x-vrml"],
    ["xap", "application/x-silverlight-app"],
    ["xar", "application/vnd.xara"],
    ["xbap", "application/x-ms-xbap"],
    ["xbd", "application/vnd.fujixerox.docuworks.binder"],
    ["xbm", ["image/xbm", "image/x-xbm", "image/x-xbitmap"]],
    ["xdf", "application/xcap-diff+xml"],
    ["xdm", "application/vnd.syncml.dm+xml"],
    ["xdp", "application/vnd.adobe.xdp+xml"],
    ["xdr", "video/x-amt-demorun"],
    ["xdssc", "application/dssc+xml"],
    ["xdw", "application/vnd.fujixerox.docuworks"],
    ["xenc", "application/xenc+xml"],
    ["xer", "application/patch-ops-error+xml"],
    ["xfdf", "application/vnd.adobe.xfdf"],
    ["xfdl", "application/vnd.xfdl"],
    ["xgz", "xgl/drawing"],
    ["xhtml", "application/xhtml+xml"],
    ["xif", "image/vnd.xiff"],
    ["xl", "application/excel"],
    ["xla", ["application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel"]],
    ["xlam", "application/vnd.ms-excel.addin.macroenabled.12"],
    ["xlb", ["application/excel", "application/vnd.ms-excel", "application/x-excel"]],
    ["xlc", ["application/vnd.ms-excel", "application/excel", "application/x-excel"]],
    ["xld", ["application/excel", "application/x-excel"]],
    ["xlk", ["application/excel", "application/x-excel"]],
    ["xll", ["application/excel", "application/vnd.ms-excel", "application/x-excel"]],
    ["xlm", ["application/vnd.ms-excel", "application/excel", "application/x-excel"]],
    ["xls", ["application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel"]],
    ["xlsb", "application/vnd.ms-excel.sheet.binary.macroenabled.12"],
    ["xlsm", "application/vnd.ms-excel.sheet.macroenabled.12"],
    ["xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"],
    ["xlt", ["application/vnd.ms-excel", "application/excel", "application/x-excel"]],
    ["xltm", "application/vnd.ms-excel.template.macroenabled.12"],
    ["xltx", "application/vnd.openxmlformats-officedocument.spreadsheetml.template"],
    ["xlv", ["application/excel", "application/x-excel"]],
    ["xlw", ["application/vnd.ms-excel", "application/excel", "application/x-msexcel", "application/x-excel"]],
    ["xm", "audio/xm"],
    ["xml", ["application/xml", "text/xml", "application/atom+xml", "application/rss+xml"]],
    ["xmz", "xgl/movie"],
    ["xo", "application/vnd.olpc-sugar"],
    ["xof", "x-world/x-vrml"],
    ["xop", "application/xop+xml"],
    ["xpi", "application/x-xpinstall"],
    ["xpix", "application/x-vnd.ls-xpix"],
    ["xpm", ["image/xpm", "image/x-xpixmap"]],
    ["xpr", "application/vnd.is-xpr"],
    ["xps", "application/vnd.ms-xpsdocument"],
    ["xpw", "application/vnd.intercon.formnet"],
    ["xslt", "application/xslt+xml"],
    ["xsm", "application/vnd.syncml+xml"],
    ["xspf", "application/xspf+xml"],
    ["xsr", "video/x-amt-showrun"],
    ["xul", "application/vnd.mozilla.xul+xml"],
    ["xwd", ["image/x-xwd", "image/x-xwindowdump"]],
    ["xyz", ["chemical/x-xyz", "chemical/x-pdb"]],
    ["yang", "application/yang"],
    ["yin", "application/yin+xml"],
    ["z", ["application/x-compressed", "application/x-compress"]],
    ["zaz", "application/vnd.zzazz.deck+xml"],
    ["zip", ["application/zip", "multipart/x-zip", "application/x-zip-compressed", "application/x-compressed"]],
    ["zir", "application/vnd.zul"],
    ["zmm", "application/vnd.handheld-entertainment+xml"],
    ["zoo", "application/octet-stream"],
    ["zsh", "text/x-script.zsh"]
  ]);
  module.exports = {
    detectMimeType(filename) {
      if (!filename) {
        return defaultMimeType;
      }
      let parsed = path2.parse(filename);
      let extension = (parsed.ext.substr(1) || parsed.name || "").split("?").shift().trim().toLowerCase();
      let value = defaultMimeType;
      if (extensions.has(extension)) {
        value = extensions.get(extension);
      }
      if (Array.isArray(value)) {
        return value[0];
      }
      return value;
    },
    detectExtension(mimeType) {
      if (!mimeType) {
        return defaultExtension;
      }
      let parts = (mimeType || "").toLowerCase().trim().split("/");
      let rootType = parts.shift().trim();
      let subType = parts.join("/").trim();
      if (mimeTypes.has(rootType + "/" + subType)) {
        let value = mimeTypes.get(rootType + "/" + subType);
        if (Array.isArray(value)) {
          return value[0];
        }
        return value;
      }
      switch (rootType) {
        case "text":
          return "txt";
        default:
          return "bin";
      }
    }
  };
});

// node_modules/nodemailer/lib/punycode/index.js
var require_punycode = __commonJS((exports, module) => {
  var error = function(type) {
    throw new RangeError(errors3[type]);
  };
  var map = function(array, callback) {
    const result = [];
    let length = array.length;
    while (length--) {
      result[length] = callback(array[length]);
    }
    return result;
  };
  var mapDomain = function(domain, callback) {
    const parts = domain.split("@");
    let result = "";
    if (parts.length > 1) {
      result = parts[0] + "@";
      domain = parts[1];
    }
    domain = domain.replace(regexSeparators, ".");
    const labels = domain.split(".");
    const encoded = map(labels, callback).join(".");
    return result + encoded;
  };
  var ucs2decode = function(string) {
    const output = [];
    let counter = 0;
    const length = string.length;
    while (counter < length) {
      const value = string.charCodeAt(counter++);
      if (value >= 55296 && value <= 56319 && counter < length) {
        const extra = string.charCodeAt(counter++);
        if ((extra & 64512) == 56320) {
          output.push(((value & 1023) << 10) + (extra & 1023) + 65536);
        } else {
          output.push(value);
          counter--;
        }
      } else {
        output.push(value);
      }
    }
    return output;
  };
  var maxInt = 2147483647;
  var base = 36;
  var tMin = 1;
  var tMax = 26;
  var skew = 38;
  var damp = 700;
  var initialBias = 72;
  var initialN = 128;
  var delimiter = "-";
  var regexPunycode = /^xn--/;
  var regexNonASCII = /[^\0-\x7F]/;
  var regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g;
  var errors3 = {
    overflow: "Overflow: input needs wider integers to process",
    "not-basic": "Illegal input >= 0x80 (not a basic code point)",
    "invalid-input": "Invalid input"
  };
  var baseMinusTMin = base - tMin;
  var floor = Math.floor;
  var stringFromCharCode = String.fromCharCode;
  var ucs2encode = (codePoints) => String.fromCodePoint(...codePoints);
  var basicToDigit = function(codePoint) {
    if (codePoint >= 48 && codePoint < 58) {
      return 26 + (codePoint - 48);
    }
    if (codePoint >= 65 && codePoint < 91) {
      return codePoint - 65;
    }
    if (codePoint >= 97 && codePoint < 123) {
      return codePoint - 97;
    }
    return base;
  };
  var digitToBasic = function(digit, flag) {
    return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
  };
  var adapt = function(delta, numPoints, firstTime) {
    let k = 0;
    delta = firstTime ? floor(delta / damp) : delta >> 1;
    delta += floor(delta / numPoints);
    for (;delta > baseMinusTMin * tMax >> 1; k += base) {
      delta = floor(delta / baseMinusTMin);
    }
    return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
  };
  var decode = function(input) {
    const output = [];
    const inputLength = input.length;
    let i = 0;
    let n = initialN;
    let bias = initialBias;
    let basic = input.lastIndexOf(delimiter);
    if (basic < 0) {
      basic = 0;
    }
    for (let j = 0;j < basic; ++j) {
      if (input.charCodeAt(j) >= 128) {
        error("not-basic");
      }
      output.push(input.charCodeAt(j));
    }
    for (let index = basic > 0 ? basic + 1 : 0;index < inputLength; ) {
      const oldi = i;
      for (let w = 1, k = base;; k += base) {
        if (index >= inputLength) {
          error("invalid-input");
        }
        const digit = basicToDigit(input.charCodeAt(index++));
        if (digit >= base) {
          error("invalid-input");
        }
        if (digit > floor((maxInt - i) / w)) {
          error("overflow");
        }
        i += digit * w;
        const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
        if (digit < t) {
          break;
        }
        const baseMinusT = base - t;
        if (w > floor(maxInt / baseMinusT)) {
          error("overflow");
        }
        w *= baseMinusT;
      }
      const out = output.length + 1;
      bias = adapt(i - oldi, out, oldi == 0);
      if (floor(i / out) > maxInt - n) {
        error("overflow");
      }
      n += floor(i / out);
      i %= out;
      output.splice(i++, 0, n);
    }
    return String.fromCodePoint(...output);
  };
  var encode = function(input) {
    const output = [];
    input = ucs2decode(input);
    const inputLength = input.length;
    let n = initialN;
    let delta = 0;
    let bias = initialBias;
    for (const currentValue of input) {
      if (currentValue < 128) {
        output.push(stringFromCharCode(currentValue));
      }
    }
    const basicLength = output.length;
    let handledCPCount = basicLength;
    if (basicLength) {
      output.push(delimiter);
    }
    while (handledCPCount < inputLength) {
      let m = maxInt;
      for (const currentValue of input) {
        if (currentValue >= n && currentValue < m) {
          m = currentValue;
        }
      }
      const handledCPCountPlusOne = handledCPCount + 1;
      if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
        error("overflow");
      }
      delta += (m - n) * handledCPCountPlusOne;
      n = m;
      for (const currentValue of input) {
        if (currentValue < n && ++delta > maxInt) {
          error("overflow");
        }
        if (currentValue === n) {
          let q = delta;
          for (let k = base;; k += base) {
            const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
            if (q < t) {
              break;
            }
            const qMinusT = q - t;
            const baseMinusT = base - t;
            output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
            q = floor(qMinusT / baseMinusT);
          }
          output.push(stringFromCharCode(digitToBasic(q, 0)));
          bias = adapt(delta, handledCPCountPlusOne, handledCPCount === basicLength);
          delta = 0;
          ++handledCPCount;
        }
      }
      ++delta;
      ++n;
    }
    return output.join("");
  };
  var toUnicode = function(input) {
    return mapDomain(input, function(string) {
      return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
    });
  };
  var toASCII = function(input) {
    return mapDomain(input, function(string) {
      return regexNonASCII.test(string) ? "xn--" + encode(string) : string;
    });
  };
  var punycode = {
    version: "2.3.1",
    ucs2: {
      decode: ucs2decode,
      encode: ucs2encode
    },
    decode,
    encode,
    toASCII,
    toUnicode
  };
  module.exports = punycode;
});

// node_modules/nodemailer/lib/base64/index.js
var require_base64 = __commonJS((exports, module) => {
  var encode = function(buffer) {
    if (typeof buffer === "string") {
      buffer = Buffer.from(buffer, "utf-8");
    }
    return buffer.toString("base64");
  };
  var wrap = function(str, lineLength) {
    str = (str || "").toString();
    lineLength = lineLength || 76;
    if (str.length <= lineLength) {
      return str;
    }
    let result = [];
    let pos = 0;
    let chunkLength = lineLength * 1024;
    while (pos < str.length) {
      let wrappedLines = str.substr(pos, chunkLength).replace(new RegExp(".{" + lineLength + "}", "g"), "$&\r\n").trim();
      result.push(wrappedLines);
      pos += chunkLength;
    }
    return result.join("\r\n").trim();
  };
  var Transform = import.meta.require("stream").Transform;

  class Encoder extends Transform {
    constructor(options) {
      super();
      this.options = options || {};
      if (this.options.lineLength !== false) {
        this.options.lineLength = this.options.lineLength || 76;
      }
      this._curLine = "";
      this._remainingBytes = false;
      this.inputBytes = 0;
      this.outputBytes = 0;
    }
    _transform(chunk, encoding, done) {
      if (encoding !== "buffer") {
        chunk = Buffer.from(chunk, encoding);
      }
      if (!chunk || !chunk.length) {
        return setImmediate(done);
      }
      this.inputBytes += chunk.length;
      if (this._remainingBytes && this._remainingBytes.length) {
        chunk = Buffer.concat([this._remainingBytes, chunk], this._remainingBytes.length + chunk.length);
        this._remainingBytes = false;
      }
      if (chunk.length % 3) {
        this._remainingBytes = chunk.slice(chunk.length - chunk.length % 3);
        chunk = chunk.slice(0, chunk.length - chunk.length % 3);
      } else {
        this._remainingBytes = false;
      }
      let b64 = this._curLine + encode(chunk);
      if (this.options.lineLength) {
        b64 = wrap(b64, this.options.lineLength);
        let lastLF = b64.lastIndexOf("\n");
        if (lastLF < 0) {
          this._curLine = b64;
          b64 = "";
        } else if (lastLF === b64.length - 1) {
          this._curLine = "";
        } else {
          this._curLine = b64.substr(lastLF + 1);
          b64 = b64.substr(0, lastLF + 1);
        }
      }
      if (b64) {
        this.outputBytes += b64.length;
        this.push(Buffer.from(b64, "ascii"));
      }
      setImmediate(done);
    }
    _flush(done) {
      if (this._remainingBytes && this._remainingBytes.length) {
        this._curLine += encode(this._remainingBytes);
      }
      if (this._curLine) {
        this._curLine = wrap(this._curLine, this.options.lineLength);
        this.outputBytes += this._curLine.length;
        this.push(this._curLine, "ascii");
        this._curLine = "";
      }
      done();
    }
  }
  module.exports = {
    encode,
    wrap,
    Encoder
  };
});

// node_modules/nodemailer/lib/qp/index.js
var require_qp = __commonJS((exports, module) => {
  var encode = function(buffer) {
    if (typeof buffer === "string") {
      buffer = Buffer.from(buffer, "utf-8");
    }
    let ranges = [
      [9],
      [10],
      [13],
      [32, 60],
      [62, 126]
    ];
    let result = "";
    let ord;
    for (let i = 0, len = buffer.length;i < len; i++) {
      ord = buffer[i];
      if (checkRanges(ord, ranges) && !((ord === 32 || ord === 9) && (i === len - 1 || buffer[i + 1] === 10 || buffer[i + 1] === 13))) {
        result += String.fromCharCode(ord);
        continue;
      }
      result += "=" + (ord < 16 ? "0" : "") + ord.toString(16).toUpperCase();
    }
    return result;
  };
  var wrap = function(str, lineLength) {
    str = (str || "").toString();
    lineLength = lineLength || 76;
    if (str.length <= lineLength) {
      return str;
    }
    let pos = 0;
    let len = str.length;
    let match, code, line;
    let lineMargin = Math.floor(lineLength / 3);
    let result = "";
    while (pos < len) {
      line = str.substr(pos, lineLength);
      if (match = line.match(/\r\n/)) {
        line = line.substr(0, match.index + match[0].length);
        result += line;
        pos += line.length;
        continue;
      }
      if (line.substr(-1) === "\n") {
        result += line;
        pos += line.length;
        continue;
      } else if (match = line.substr(-lineMargin).match(/\n.*?$/)) {
        line = line.substr(0, line.length - (match[0].length - 1));
        result += line;
        pos += line.length;
        continue;
      } else if (line.length > lineLength - lineMargin && (match = line.substr(-lineMargin).match(/[ \t.,!?][^ \t.,!?]*$/))) {
        line = line.substr(0, line.length - (match[0].length - 1));
      } else if (line.match(/[=][\da-f]{0,2}$/i)) {
        if (match = line.match(/[=][\da-f]{0,1}$/i)) {
          line = line.substr(0, line.length - match[0].length);
        }
        while (line.length > 3 && line.length < len - pos && !line.match(/^(?:=[\da-f]{2}){1,4}$/i) && (match = line.match(/[=][\da-f]{2}$/gi))) {
          code = parseInt(match[0].substr(1, 2), 16);
          if (code < 128) {
            break;
          }
          line = line.substr(0, line.length - 3);
          if (code >= 192) {
            break;
          }
        }
      }
      if (pos + line.length < len && line.substr(-1) !== "\n") {
        if (line.length === lineLength && line.match(/[=][\da-f]{2}$/i)) {
          line = line.substr(0, line.length - 3);
        } else if (line.length === lineLength) {
          line = line.substr(0, line.length - 1);
        }
        pos += line.length;
        line += "=\r\n";
      } else {
        pos += line.length;
      }
      result += line;
    }
    return result;
  };
  var checkRanges = function(nr, ranges) {
    for (let i = ranges.length - 1;i >= 0; i--) {
      if (!ranges[i].length) {
        continue;
      }
      if (ranges[i].length === 1 && nr === ranges[i][0]) {
        return true;
      }
      if (ranges[i].length === 2 && nr >= ranges[i][0] && nr <= ranges[i][1]) {
        return true;
      }
    }
    return false;
  };
  var Transform = import.meta.require("stream").Transform;

  class Encoder extends Transform {
    constructor(options) {
      super();
      this.options = options || {};
      if (this.options.lineLength !== false) {
        this.options.lineLength = this.options.lineLength || 76;
      }
      this._curLine = "";
      this.inputBytes = 0;
      this.outputBytes = 0;
    }
    _transform(chunk, encoding, done) {
      let qp;
      if (encoding !== "buffer") {
        chunk = Buffer.from(chunk, encoding);
      }
      if (!chunk || !chunk.length) {
        return done();
      }
      this.inputBytes += chunk.length;
      if (this.options.lineLength) {
        qp = this._curLine + encode(chunk);
        qp = wrap(qp, this.options.lineLength);
        qp = qp.replace(/(^|\n)([^\n]*)$/, (match, lineBreak, lastLine) => {
          this._curLine = lastLine;
          return lineBreak;
        });
        if (qp) {
          this.outputBytes += qp.length;
          this.push(qp);
        }
      } else {
        qp = encode(chunk);
        this.outputBytes += qp.length;
        this.push(qp, "ascii");
      }
      done();
    }
    _flush(done) {
      if (this._curLine) {
        this.outputBytes += this._curLine.length;
        this.push(this._curLine, "ascii");
      }
      done();
    }
  }
  module.exports = {
    encode,
    wrap,
    Encoder
  };
});

// node_modules/nodemailer/lib/mime-funcs/index.js
var require_mime_funcs = __commonJS((exports, module) => {
  var base64 = require_base64();
  var qp = require_qp();
  var mimeTypes = require_mime_types();
  module.exports = {
    isPlainText(value, isParam) {
      const re = isParam ? /[\x00-\x08\x0b\x0c\x0e-\x1f"\u0080-\uFFFF]/ : /[\x00-\x08\x0b\x0c\x0e-\x1f\u0080-\uFFFF]/;
      if (typeof value !== "string" || re.test(value)) {
        return false;
      } else {
        return true;
      }
    },
    hasLongerLines(str, lineLength) {
      if (str.length > 128 * 1024) {
        return true;
      }
      return new RegExp("^.{" + (lineLength + 1) + ",}", "m").test(str);
    },
    encodeWord(data, mimeWordEncoding, maxLength) {
      mimeWordEncoding = (mimeWordEncoding || "Q").toString().toUpperCase().trim().charAt(0);
      maxLength = maxLength || 0;
      let encodedStr;
      let toCharset = "UTF-8";
      if (maxLength && maxLength > 7 + toCharset.length) {
        maxLength -= 7 + toCharset.length;
      }
      if (mimeWordEncoding === "Q") {
        encodedStr = qp.encode(data).replace(/[^a-z0-9!*+\-/=]/gi, (chr) => {
          let ord = chr.charCodeAt(0).toString(16).toUpperCase();
          if (chr === " ") {
            return "_";
          } else {
            return "=" + (ord.length === 1 ? "0" + ord : ord);
          }
        });
      } else if (mimeWordEncoding === "B") {
        encodedStr = typeof data === "string" ? data : base64.encode(data);
        maxLength = maxLength ? Math.max(3, (maxLength - maxLength % 4) / 4 * 3) : 0;
      }
      if (maxLength && (mimeWordEncoding !== "B" ? encodedStr : base64.encode(data)).length > maxLength) {
        if (mimeWordEncoding === "Q") {
          encodedStr = this.splitMimeEncodedString(encodedStr, maxLength).join("?= =?" + toCharset + "?" + mimeWordEncoding + "?");
        } else {
          let parts = [];
          let lpart = "";
          for (let i = 0, len = encodedStr.length;i < len; i++) {
            let chr = encodedStr.charAt(i);
            if (/[\ud83c\ud83d\ud83e]/.test(chr) && i < len - 1) {
              chr += encodedStr.charAt(++i);
            }
            if (Buffer.byteLength(lpart + chr) <= maxLength || i === 0) {
              lpart += chr;
            } else {
              parts.push(base64.encode(lpart));
              lpart = chr;
            }
          }
          if (lpart) {
            parts.push(base64.encode(lpart));
          }
          if (parts.length > 1) {
            encodedStr = parts.join("?= =?" + toCharset + "?" + mimeWordEncoding + "?");
          } else {
            encodedStr = parts.join("");
          }
        }
      } else if (mimeWordEncoding === "B") {
        encodedStr = base64.encode(data);
      }
      return "=?" + toCharset + "?" + mimeWordEncoding + "?" + encodedStr + (encodedStr.substr(-2) === "?=" ? "" : "?=");
    },
    encodeWords(value, mimeWordEncoding, maxLength, encodeAll) {
      maxLength = maxLength || 0;
      let encodedValue;
      let firstMatch = value.match(/(?:^|\s)([^\s]*["\u0080-\uFFFF])/);
      if (!firstMatch) {
        return value;
      }
      if (encodeAll) {
        return this.encodeWord(value, mimeWordEncoding, maxLength);
      }
      let lastMatch = value.match(/(["\u0080-\uFFFF][^\s]*)[^"\u0080-\uFFFF]*$/);
      if (!lastMatch) {
        return value;
      }
      let startIndex = firstMatch.index + (firstMatch[0].match(/[^\s]/) || {
        index: 0
      }).index;
      let endIndex = lastMatch.index + (lastMatch[1] || "").length;
      encodedValue = (startIndex ? value.substr(0, startIndex) : "") + this.encodeWord(value.substring(startIndex, endIndex), mimeWordEncoding || "Q", maxLength) + (endIndex < value.length ? value.substr(endIndex) : "");
      return encodedValue;
    },
    buildHeaderValue(structured) {
      let paramsArray = [];
      Object.keys(structured.params || {}).forEach((param) => {
        let value = structured.params[param];
        if (!this.isPlainText(value, true) || value.length >= 75) {
          this.buildHeaderParam(param, value, 50).forEach((encodedParam) => {
            if (!/[\s"\\;:/=(),<>@[\]?]|^[-']|'$/.test(encodedParam.value) || encodedParam.key.substr(-1) === "*") {
              paramsArray.push(encodedParam.key + "=" + encodedParam.value);
            } else {
              paramsArray.push(encodedParam.key + "=" + JSON.stringify(encodedParam.value));
            }
          });
        } else if (/[\s'"\\;:/=(),<>@[\]?]|^-/.test(value)) {
          paramsArray.push(param + "=" + JSON.stringify(value));
        } else {
          paramsArray.push(param + "=" + value);
        }
      });
      return structured.value + (paramsArray.length ? "; " + paramsArray.join("; ") : "");
    },
    buildHeaderParam(key, data, maxLength) {
      let list = [];
      let encodedStr = typeof data === "string" ? data : (data || "").toString();
      let encodedStrArr;
      let chr, ord;
      let line;
      let startPos = 0;
      let i, len;
      maxLength = maxLength || 50;
      if (this.isPlainText(data, true)) {
        if (encodedStr.length <= maxLength) {
          return [
            {
              key,
              value: encodedStr
            }
          ];
        }
        encodedStr = encodedStr.replace(new RegExp(".{" + maxLength + "}", "g"), (str) => {
          list.push({
            line: str
          });
          return "";
        });
        if (encodedStr) {
          list.push({
            line: encodedStr
          });
        }
      } else {
        if (/[\uD800-\uDBFF]/.test(encodedStr)) {
          encodedStrArr = [];
          for (i = 0, len = encodedStr.length;i < len; i++) {
            chr = encodedStr.charAt(i);
            ord = chr.charCodeAt(0);
            if (ord >= 55296 && ord <= 56319 && i < len - 1) {
              chr += encodedStr.charAt(i + 1);
              encodedStrArr.push(chr);
              i++;
            } else {
              encodedStrArr.push(chr);
            }
          }
          encodedStr = encodedStrArr;
        }
        line = "utf-8''";
        let encoded = true;
        startPos = 0;
        for (i = 0, len = encodedStr.length;i < len; i++) {
          chr = encodedStr[i];
          if (encoded) {
            chr = this.safeEncodeURIComponent(chr);
          } else {
            chr = chr === " " ? chr : this.safeEncodeURIComponent(chr);
            if (chr !== encodedStr[i]) {
              if ((this.safeEncodeURIComponent(line) + chr).length >= maxLength) {
                list.push({
                  line,
                  encoded
                });
                line = "";
                startPos = i - 1;
              } else {
                encoded = true;
                i = startPos;
                line = "";
                continue;
              }
            }
          }
          if ((line + chr).length >= maxLength) {
            list.push({
              line,
              encoded
            });
            line = chr = encodedStr[i] === " " ? " " : this.safeEncodeURIComponent(encodedStr[i]);
            if (chr === encodedStr[i]) {
              encoded = false;
              startPos = i - 1;
            } else {
              encoded = true;
            }
          } else {
            line += chr;
          }
        }
        if (line) {
          list.push({
            line,
            encoded
          });
        }
      }
      return list.map((item, i2) => ({
        key: key + "*" + i2 + (item.encoded ? "*" : ""),
        value: item.line
      }));
    },
    parseHeaderValue(str) {
      let response = {
        value: false,
        params: {}
      };
      let key = false;
      let value = "";
      let type = "value";
      let quote = false;
      let escaped = false;
      let chr;
      for (let i = 0, len = str.length;i < len; i++) {
        chr = str.charAt(i);
        if (type === "key") {
          if (chr === "=") {
            key = value.trim().toLowerCase();
            type = "value";
            value = "";
            continue;
          }
          value += chr;
        } else {
          if (escaped) {
            value += chr;
          } else if (chr === "\\") {
            escaped = true;
            continue;
          } else if (quote && chr === quote) {
            quote = false;
          } else if (!quote && chr === '"') {
            quote = chr;
          } else if (!quote && chr === ";") {
            if (key === false) {
              response.value = value.trim();
            } else {
              response.params[key] = value.trim();
            }
            type = "key";
            value = "";
          } else {
            value += chr;
          }
          escaped = false;
        }
      }
      if (type === "value") {
        if (key === false) {
          response.value = value.trim();
        } else {
          response.params[key] = value.trim();
        }
      } else if (value.trim()) {
        response.params[value.trim().toLowerCase()] = "";
      }
      Object.keys(response.params).forEach((key2) => {
        let actualKey, nr, match, value2;
        if (match = key2.match(/(\*(\d+)|\*(\d+)\*|\*)$/)) {
          actualKey = key2.substr(0, match.index);
          nr = Number(match[2] || match[3]) || 0;
          if (!response.params[actualKey] || typeof response.params[actualKey] !== "object") {
            response.params[actualKey] = {
              charset: false,
              values: []
            };
          }
          value2 = response.params[key2];
          if (nr === 0 && match[0].substr(-1) === "*" && (match = value2.match(/^([^']*)'[^']*'(.*)$/))) {
            response.params[actualKey].charset = match[1] || "iso-8859-1";
            value2 = match[2];
          }
          response.params[actualKey].values[nr] = value2;
          delete response.params[key2];
        }
      });
      Object.keys(response.params).forEach((key2) => {
        let value2;
        if (response.params[key2] && Array.isArray(response.params[key2].values)) {
          value2 = response.params[key2].values.map((val) => val || "").join("");
          if (response.params[key2].charset) {
            response.params[key2] = "=?" + response.params[key2].charset + "?Q?" + value2.replace(/[=?_\s]/g, (s) => {
              let c = s.charCodeAt(0).toString(16);
              if (s === " ") {
                return "_";
              } else {
                return "%" + (c.length < 2 ? "0" : "") + c;
              }
            }).replace(/%/g, "=") + "?=";
          } else {
            response.params[key2] = value2;
          }
        }
      });
      return response;
    },
    detectExtension: (mimeType) => mimeTypes.detectExtension(mimeType),
    detectMimeType: (extension) => mimeTypes.detectMimeType(extension),
    foldLines(str, lineLength, afterSpace) {
      str = (str || "").toString();
      lineLength = lineLength || 76;
      let pos = 0, len = str.length, result = "", line, match;
      while (pos < len) {
        line = str.substr(pos, lineLength);
        if (line.length < lineLength) {
          result += line;
          break;
        }
        if (match = line.match(/^[^\n\r]*(\r?\n|\r)/)) {
          line = match[0];
          result += line;
          pos += line.length;
          continue;
        } else if ((match = line.match(/(\s+)[^\s]*$/)) && match[0].length - (afterSpace ? (match[1] || "").length : 0) < line.length) {
          line = line.substr(0, line.length - (match[0].length - (afterSpace ? (match[1] || "").length : 0)));
        } else if (match = str.substr(pos + line.length).match(/^[^\s]+(\s*)/)) {
          line = line + match[0].substr(0, match[0].length - (!afterSpace ? (match[1] || "").length : 0));
        }
        result += line;
        pos += line.length;
        if (pos < len) {
          result += "\r\n";
        }
      }
      return result;
    },
    splitMimeEncodedString: (str, maxlen) => {
      let curLine, match, chr, done, lines = [];
      maxlen = Math.max(maxlen || 0, 12);
      while (str.length) {
        curLine = str.substr(0, maxlen);
        if (match = curLine.match(/[=][0-9A-F]?$/i)) {
          curLine = curLine.substr(0, match.index);
        }
        done = false;
        while (!done) {
          done = true;
          if (match = str.substr(curLine.length).match(/^[=]([0-9A-F]{2})/i)) {
            chr = parseInt(match[1], 16);
            if (chr < 194 && chr > 127) {
              curLine = curLine.substr(0, curLine.length - 3);
              done = false;
            }
          }
        }
        if (curLine.length) {
          lines.push(curLine);
        }
        str = str.substr(curLine.length);
      }
      return lines;
    },
    encodeURICharComponent: (chr) => {
      let res = "";
      let ord = chr.charCodeAt(0).toString(16).toUpperCase();
      if (ord.length % 2) {
        ord = "0" + ord;
      }
      if (ord.length > 2) {
        for (let i = 0, len = ord.length / 2;i < len; i++) {
          res += "%" + ord.substr(i, 2);
        }
      } else {
        res += "%" + ord;
      }
      return res;
    },
    safeEncodeURIComponent(str) {
      str = (str || "").toString();
      try {
        str = encodeURIComponent(str);
      } catch (E) {
        return str.replace(/[^\x00-\x1F *'()<>@,;:\\"[\]?=\u007F-\uFFFF]+/g, "");
      }
      return str.replace(/[\x00-\x1F *'()<>@,;:\\"[\]?=\u007F-\uFFFF]/g, (chr) => this.encodeURICharComponent(chr));
    }
  };
});

// node_modules/nodemailer/lib/addressparser/index.js
var require_addressparser = __commonJS((exports, module) => {
  var _handleAddress = function(tokens) {
    let token;
    let isGroup = false;
    let state = "text";
    let address;
    let addresses = [];
    let data = {
      address: [],
      comment: [],
      group: [],
      text: []
    };
    let i;
    let len;
    for (i = 0, len = tokens.length;i < len; i++) {
      token = tokens[i];
      if (token.type === "operator") {
        switch (token.value) {
          case "<":
            state = "address";
            break;
          case "(":
            state = "comment";
            break;
          case ":":
            state = "group";
            isGroup = true;
            break;
          default:
            state = "text";
        }
      } else if (token.value) {
        if (state === "address") {
          token.value = token.value.replace(/^[^<]*<\s*/, "");
        }
        data[state].push(token.value);
      }
    }
    if (!data.text.length && data.comment.length) {
      data.text = data.comment;
      data.comment = [];
    }
    if (isGroup) {
      data.text = data.text.join(" ");
      addresses.push({
        name: data.text || address && address.name,
        group: data.group.length ? addressparser(data.group.join(",")) : []
      });
    } else {
      if (!data.address.length && data.text.length) {
        for (i = data.text.length - 1;i >= 0; i--) {
          if (data.text[i].match(/^[^@\s]+@[^@\s]+$/)) {
            data.address = data.text.splice(i, 1);
            break;
          }
        }
        let _regexHandler = function(address2) {
          if (!data.address.length) {
            data.address = [address2.trim()];
            return " ";
          } else {
            return address2;
          }
        };
        if (!data.address.length) {
          for (i = data.text.length - 1;i >= 0; i--) {
            data.text[i] = data.text[i].replace(/\s*\b[^@\s]+@[^\s]+\b\s*/, _regexHandler).trim();
            if (data.address.length) {
              break;
            }
          }
        }
      }
      if (!data.text.length && data.comment.length) {
        data.text = data.comment;
        data.comment = [];
      }
      if (data.address.length > 1) {
        data.text = data.text.concat(data.address.splice(1));
      }
      data.text = data.text.join(" ");
      data.address = data.address.join(" ");
      if (!data.address && isGroup) {
        return [];
      } else {
        address = {
          address: data.address || data.text || "",
          name: data.text || data.address || ""
        };
        if (address.address === address.name) {
          if ((address.address || "").match(/@/)) {
            address.name = "";
          } else {
            address.address = "";
          }
        }
        addresses.push(address);
      }
    }
    return addresses;
  };
  var addressparser = function(str, options) {
    options = options || {};
    let tokenizer = new Tokenizer(str);
    let tokens = tokenizer.tokenize();
    let addresses = [];
    let address = [];
    let parsedAddresses = [];
    tokens.forEach((token) => {
      if (token.type === "operator" && (token.value === "," || token.value === ";")) {
        if (address.length) {
          addresses.push(address);
        }
        address = [];
      } else {
        address.push(token);
      }
    });
    if (address.length) {
      addresses.push(address);
    }
    addresses.forEach((address2) => {
      address2 = _handleAddress(address2);
      if (address2.length) {
        parsedAddresses = parsedAddresses.concat(address2);
      }
    });
    if (options.flatten) {
      let addresses2 = [];
      let walkAddressList = (list) => {
        list.forEach((address2) => {
          if (address2.group) {
            return walkAddressList(address2.group);
          } else {
            addresses2.push(address2);
          }
        });
      };
      walkAddressList(parsedAddresses);
      return addresses2;
    }
    return parsedAddresses;
  };

  class Tokenizer {
    constructor(str) {
      this.str = (str || "").toString();
      this.operatorCurrent = "";
      this.operatorExpecting = "";
      this.node = null;
      this.escaped = false;
      this.list = [];
      this.operators = {
        '"': '"',
        "(": ")",
        "<": ">",
        ",": "",
        ":": ";",
        ";": ""
      };
    }
    tokenize() {
      let chr, list = [];
      for (let i = 0, len = this.str.length;i < len; i++) {
        chr = this.str.charAt(i);
        this.checkChar(chr);
      }
      this.list.forEach((node) => {
        node.value = (node.value || "").toString().trim();
        if (node.value) {
          list.push(node);
        }
      });
      return list;
    }
    checkChar(chr) {
      if (this.escaped) {
      } else if (chr === this.operatorExpecting) {
        this.node = {
          type: "operator",
          value: chr
        };
        this.list.push(this.node);
        this.node = null;
        this.operatorExpecting = "";
        this.escaped = false;
        return;
      } else if (!this.operatorExpecting && chr in this.operators) {
        this.node = {
          type: "operator",
          value: chr
        };
        this.list.push(this.node);
        this.node = null;
        this.operatorExpecting = this.operators[chr];
        this.escaped = false;
        return;
      } else if (['"', "'"].includes(this.operatorExpecting) && chr === "\\") {
        this.escaped = true;
        return;
      }
      if (!this.node) {
        this.node = {
          type: "text",
          value: ""
        };
        this.list.push(this.node);
      }
      if (chr === "\n") {
        chr = " ";
      }
      if (chr.charCodeAt(0) >= 33 || [" ", "\t"].includes(chr)) {
        this.node.value += chr;
      }
      this.escaped = false;
    }
  }
  module.exports = addressparser;
});

// node_modules/nodemailer/lib/mime-node/last-newline.js
var require_last_newline = __commonJS((exports, module) => {
  var Transform = import.meta.require("stream").Transform;

  class LastNewline extends Transform {
    constructor() {
      super();
      this.lastByte = false;
    }
    _transform(chunk, encoding, done) {
      if (chunk.length) {
        this.lastByte = chunk[chunk.length - 1];
      }
      this.push(chunk);
      done();
    }
    _flush(done) {
      if (this.lastByte === 10) {
        return done();
      }
      if (this.lastByte === 13) {
        this.push(Buffer.from("\n"));
        return done();
      }
      this.push(Buffer.from("\r\n"));
      return done();
    }
  }
  module.exports = LastNewline;
});

// node_modules/nodemailer/lib/mime-node/le-windows.js
var require_le_windows = __commonJS((exports, module) => {
  var stream = import.meta.require("stream");
  var Transform = stream.Transform;

  class LeWindows extends Transform {
    constructor(options) {
      super(options);
      this.options = options || {};
      this.lastByte = false;
    }
    _transform(chunk, encoding, done) {
      let buf;
      let lastPos = 0;
      for (let i = 0, len = chunk.length;i < len; i++) {
        if (chunk[i] === 10) {
          if (i && chunk[i - 1] !== 13 || !i && this.lastByte !== 13) {
            if (i > lastPos) {
              buf = chunk.slice(lastPos, i);
              this.push(buf);
            }
            this.push(Buffer.from("\r\n"));
            lastPos = i + 1;
          }
        }
      }
      if (lastPos && lastPos < chunk.length) {
        buf = chunk.slice(lastPos);
        this.push(buf);
      } else if (!lastPos) {
        this.push(chunk);
      }
      this.lastByte = chunk[chunk.length - 1];
      done();
    }
  }
  module.exports = LeWindows;
});

// node_modules/nodemailer/lib/mime-node/le-unix.js
var require_le_unix = __commonJS((exports, module) => {
  var stream = import.meta.require("stream");
  var Transform = stream.Transform;

  class LeWindows extends Transform {
    constructor(options) {
      super(options);
      this.options = options || {};
    }
    _transform(chunk, encoding, done) {
      let buf;
      let lastPos = 0;
      for (let i = 0, len = chunk.length;i < len; i++) {
        if (chunk[i] === 13) {
          buf = chunk.slice(lastPos, i);
          lastPos = i + 1;
          this.push(buf);
        }
      }
      if (lastPos && lastPos < chunk.length) {
        buf = chunk.slice(lastPos);
        this.push(buf);
      } else if (!lastPos) {
        this.push(chunk);
      }
      done();
    }
  }
  module.exports = LeWindows;
});

// node_modules/nodemailer/lib/mime-node/index.js
var require_mime_node = __commonJS((exports, module) => {
  var crypto2 = import.meta.require("crypto");
  var fs2 = import.meta.require("fs");
  var punycode = require_punycode();
  var PassThrough = import.meta.require("stream").PassThrough;
  var shared = require_shared();
  var mimeFuncs = require_mime_funcs();
  var qp = require_qp();
  var base64 = require_base64();
  var addressparser = require_addressparser();
  var nmfetch = require_fetch();
  var LastNewline = require_last_newline();
  var LeWindows = require_le_windows();
  var LeUnix = require_le_unix();

  class MimeNode {
    constructor(contentType, options) {
      this.nodeCounter = 0;
      options = options || {};
      this.baseBoundary = options.baseBoundary || crypto2.randomBytes(8).toString("hex");
      this.boundaryPrefix = options.boundaryPrefix || "--_NmP";
      this.disableFileAccess = !!options.disableFileAccess;
      this.disableUrlAccess = !!options.disableUrlAccess;
      this.normalizeHeaderKey = options.normalizeHeaderKey;
      this.date = new Date;
      this.rootNode = options.rootNode || this;
      this.keepBcc = !!options.keepBcc;
      if (options.filename) {
        this.filename = options.filename;
        if (!contentType) {
          contentType = mimeFuncs.detectMimeType(this.filename.split(".").pop());
        }
      }
      this.textEncoding = (options.textEncoding || "").toString().trim().charAt(0).toUpperCase();
      this.parentNode = options.parentNode;
      this.hostname = options.hostname;
      this.newline = options.newline;
      this.childNodes = [];
      this._nodeId = ++this.rootNode.nodeCounter;
      this._headers = [];
      this._isPlainText = false;
      this._hasLongLines = false;
      this._envelope = false;
      this._raw = false;
      this._transforms = [];
      this._processFuncs = [];
      if (contentType) {
        this.setHeader("Content-Type", contentType);
      }
    }
    createChild(contentType, options) {
      if (!options && typeof contentType === "object") {
        options = contentType;
        contentType = undefined;
      }
      let node = new MimeNode(contentType, options);
      this.appendChild(node);
      return node;
    }
    appendChild(childNode) {
      if (childNode.rootNode !== this.rootNode) {
        childNode.rootNode = this.rootNode;
        childNode._nodeId = ++this.rootNode.nodeCounter;
      }
      childNode.parentNode = this;
      this.childNodes.push(childNode);
      return childNode;
    }
    replace(node) {
      if (node === this) {
        return this;
      }
      this.parentNode.childNodes.forEach((childNode, i) => {
        if (childNode === this) {
          node.rootNode = this.rootNode;
          node.parentNode = this.parentNode;
          node._nodeId = this._nodeId;
          this.rootNode = this;
          this.parentNode = undefined;
          node.parentNode.childNodes[i] = node;
        }
      });
      return node;
    }
    remove() {
      if (!this.parentNode) {
        return this;
      }
      for (let i = this.parentNode.childNodes.length - 1;i >= 0; i--) {
        if (this.parentNode.childNodes[i] === this) {
          this.parentNode.childNodes.splice(i, 1);
          this.parentNode = undefined;
          this.rootNode = this;
          return this;
        }
      }
    }
    setHeader(key, value) {
      let added = false, headerValue;
      if (!value && key && typeof key === "object") {
        if (key.key && "value" in key) {
          this.setHeader(key.key, key.value);
        } else if (Array.isArray(key)) {
          key.forEach((i) => {
            this.setHeader(i.key, i.value);
          });
        } else {
          Object.keys(key).forEach((i) => {
            this.setHeader(i, key[i]);
          });
        }
        return this;
      }
      key = this._normalizeHeaderKey(key);
      headerValue = {
        key,
        value
      };
      for (let i = 0, len = this._headers.length;i < len; i++) {
        if (this._headers[i].key === key) {
          if (!added) {
            this._headers[i] = headerValue;
            added = true;
          } else {
            this._headers.splice(i, 1);
            i--;
            len--;
          }
        }
      }
      if (!added) {
        this._headers.push(headerValue);
      }
      return this;
    }
    addHeader(key, value) {
      if (!value && key && typeof key === "object") {
        if (key.key && key.value) {
          this.addHeader(key.key, key.value);
        } else if (Array.isArray(key)) {
          key.forEach((i) => {
            this.addHeader(i.key, i.value);
          });
        } else {
          Object.keys(key).forEach((i) => {
            this.addHeader(i, key[i]);
          });
        }
        return this;
      } else if (Array.isArray(value)) {
        value.forEach((val) => {
          this.addHeader(key, val);
        });
        return this;
      }
      this._headers.push({
        key: this._normalizeHeaderKey(key),
        value
      });
      return this;
    }
    getHeader(key) {
      key = this._normalizeHeaderKey(key);
      for (let i = 0, len = this._headers.length;i < len; i++) {
        if (this._headers[i].key === key) {
          return this._headers[i].value;
        }
      }
    }
    setContent(content) {
      this.content = content;
      if (typeof this.content.pipe === "function") {
        this._contentErrorHandler = (err) => {
          this.content.removeListener("error", this._contentErrorHandler);
          this.content = err;
        };
        this.content.once("error", this._contentErrorHandler);
      } else if (typeof this.content === "string") {
        this._isPlainText = mimeFuncs.isPlainText(this.content);
        if (this._isPlainText && mimeFuncs.hasLongerLines(this.content, 76)) {
          this._hasLongLines = true;
        }
      }
      return this;
    }
    build(callback) {
      let promise;
      if (!callback) {
        promise = new Promise((resolve, reject) => {
          callback = shared.callbackPromise(resolve, reject);
        });
      }
      let stream = this.createReadStream();
      let buf = [];
      let buflen = 0;
      let returned = false;
      stream.on("readable", () => {
        let chunk;
        while ((chunk = stream.read()) !== null) {
          buf.push(chunk);
          buflen += chunk.length;
        }
      });
      stream.once("error", (err) => {
        if (returned) {
          return;
        }
        returned = true;
        return callback(err);
      });
      stream.once("end", (chunk) => {
        if (returned) {
          return;
        }
        returned = true;
        if (chunk && chunk.length) {
          buf.push(chunk);
          buflen += chunk.length;
        }
        return callback(null, Buffer.concat(buf, buflen));
      });
      return promise;
    }
    getTransferEncoding() {
      let transferEncoding = false;
      let contentType = (this.getHeader("Content-Type") || "").toString().toLowerCase().trim();
      if (this.content) {
        transferEncoding = (this.getHeader("Content-Transfer-Encoding") || "").toString().toLowerCase().trim();
        if (!transferEncoding || !["base64", "quoted-printable"].includes(transferEncoding)) {
          if (/^text\//i.test(contentType)) {
            if (this._isPlainText && !this._hasLongLines) {
              transferEncoding = "7bit";
            } else if (typeof this.content === "string" || this.content instanceof Buffer) {
              transferEncoding = this._getTextEncoding(this.content) === "Q" ? "quoted-printable" : "base64";
            } else {
              transferEncoding = this.textEncoding === "B" ? "base64" : "quoted-printable";
            }
          } else if (!/^(multipart|message)\//i.test(contentType)) {
            transferEncoding = transferEncoding || "base64";
          }
        }
      }
      return transferEncoding;
    }
    buildHeaders() {
      let transferEncoding = this.getTransferEncoding();
      let headers = [];
      if (transferEncoding) {
        this.setHeader("Content-Transfer-Encoding", transferEncoding);
      }
      if (this.filename && !this.getHeader("Content-Disposition")) {
        this.setHeader("Content-Disposition", "attachment");
      }
      if (this.rootNode === this) {
        if (!this.getHeader("Date")) {
          this.setHeader("Date", this.date.toUTCString().replace(/GMT/, "+0000"));
        }
        this.messageId();
        if (!this.getHeader("MIME-Version")) {
          this.setHeader("MIME-Version", "1.0");
        }
        for (let i = this._headers.length - 2;i >= 0; i--) {
          let header = this._headers[i];
          if (header.key === "Content-Type") {
            this._headers.splice(i, 1);
            this._headers.push(header);
          }
        }
      }
      this._headers.forEach((header) => {
        let key = header.key;
        let value = header.value;
        let structured;
        let param;
        let options = {};
        let formattedHeaders = ["From", "Sender", "To", "Cc", "Bcc", "Reply-To", "Date", "References"];
        if (value && typeof value === "object" && !formattedHeaders.includes(key)) {
          Object.keys(value).forEach((key2) => {
            if (key2 !== "value") {
              options[key2] = value[key2];
            }
          });
          value = (value.value || "").toString();
          if (!value.trim()) {
            return;
          }
        }
        if (options.prepared) {
          if (options.foldLines) {
            headers.push(mimeFuncs.foldLines(key + ": " + value));
          } else {
            headers.push(key + ": " + value);
          }
          return;
        }
        switch (header.key) {
          case "Content-Disposition":
            structured = mimeFuncs.parseHeaderValue(value);
            if (this.filename) {
              structured.params.filename = this.filename;
            }
            value = mimeFuncs.buildHeaderValue(structured);
            break;
          case "Content-Type":
            structured = mimeFuncs.parseHeaderValue(value);
            this._handleContentType(structured);
            if (structured.value.match(/^text\/plain\b/) && typeof this.content === "string" && /[\u0080-\uFFFF]/.test(this.content)) {
              structured.params.charset = "utf-8";
            }
            value = mimeFuncs.buildHeaderValue(structured);
            if (this.filename) {
              param = this._encodeWords(this.filename);
              if (param !== this.filename || /[\s'"\\;:/=(),<>@[\]?]|^-/.test(param)) {
                param = '"' + param + '"';
              }
              value += "; name=" + param;
            }
            break;
          case "Bcc":
            if (!this.keepBcc) {
              return;
            }
            break;
        }
        value = this._encodeHeaderValue(key, value);
        if (!(value || "").toString().trim()) {
          return;
        }
        if (typeof this.normalizeHeaderKey === "function") {
          let normalized = this.normalizeHeaderKey(key, value);
          if (normalized && typeof normalized === "string" && normalized.length) {
            key = normalized;
          }
        }
        headers.push(mimeFuncs.foldLines(key + ": " + value, 76));
      });
      return headers.join("\r\n");
    }
    createReadStream(options) {
      options = options || {};
      let stream = new PassThrough(options);
      let outputStream = stream;
      let transform;
      this.stream(stream, options, (err) => {
        if (err) {
          outputStream.emit("error", err);
          return;
        }
        stream.end();
      });
      for (let i = 0, len = this._transforms.length;i < len; i++) {
        transform = typeof this._transforms[i] === "function" ? this._transforms[i]() : this._transforms[i];
        outputStream.once("error", (err) => {
          transform.emit("error", err);
        });
        outputStream = outputStream.pipe(transform);
      }
      transform = new LastNewline;
      outputStream.once("error", (err) => {
        transform.emit("error", err);
      });
      outputStream = outputStream.pipe(transform);
      for (let i = 0, len = this._processFuncs.length;i < len; i++) {
        transform = this._processFuncs[i];
        outputStream = transform(outputStream);
      }
      if (this.newline) {
        const winbreak = ["win", "windows", "dos", "\r\n"].includes(this.newline.toString().toLowerCase());
        const newlineTransform = winbreak ? new LeWindows : new LeUnix;
        const stream2 = outputStream.pipe(newlineTransform);
        outputStream.on("error", (err) => stream2.emit("error", err));
        return stream2;
      }
      return outputStream;
    }
    transform(transform) {
      this._transforms.push(transform);
    }
    processFunc(processFunc) {
      this._processFuncs.push(processFunc);
    }
    stream(outputStream, options, done) {
      let transferEncoding = this.getTransferEncoding();
      let contentStream;
      let localStream;
      let returned = false;
      let callback = (err) => {
        if (returned) {
          return;
        }
        returned = true;
        done(err);
      };
      let finalize = () => {
        let childId = 0;
        let processChildNode = () => {
          if (childId >= this.childNodes.length) {
            outputStream.write("\r\n--" + this.boundary + "--\r\n");
            return callback();
          }
          let child = this.childNodes[childId++];
          outputStream.write((childId > 1 ? "\r\n" : "") + "--" + this.boundary + "\r\n");
          child.stream(outputStream, options, (err) => {
            if (err) {
              return callback(err);
            }
            setImmediate(processChildNode);
          });
        };
        if (this.multipart) {
          setImmediate(processChildNode);
        } else {
          return callback();
        }
      };
      let sendContent = () => {
        if (this.content) {
          if (Object.prototype.toString.call(this.content) === "[object Error]") {
            return callback(this.content);
          }
          if (typeof this.content.pipe === "function") {
            this.content.removeListener("error", this._contentErrorHandler);
            this._contentErrorHandler = (err) => callback(err);
            this.content.once("error", this._contentErrorHandler);
          }
          let createStream = () => {
            if (["quoted-printable", "base64"].includes(transferEncoding)) {
              contentStream = new (transferEncoding === "base64" ? base64 : qp).Encoder(options);
              contentStream.pipe(outputStream, {
                end: false
              });
              contentStream.once("end", finalize);
              contentStream.once("error", (err) => callback(err));
              localStream = this._getStream(this.content);
              localStream.pipe(contentStream);
            } else {
              localStream = this._getStream(this.content);
              localStream.pipe(outputStream, {
                end: false
              });
              localStream.once("end", finalize);
            }
            localStream.once("error", (err) => callback(err));
          };
          if (this.content._resolve) {
            let chunks = [];
            let chunklen = 0;
            let returned2 = false;
            let sourceStream = this._getStream(this.content);
            sourceStream.on("error", (err) => {
              if (returned2) {
                return;
              }
              returned2 = true;
              callback(err);
            });
            sourceStream.on("readable", () => {
              let chunk;
              while ((chunk = sourceStream.read()) !== null) {
                chunks.push(chunk);
                chunklen += chunk.length;
              }
            });
            sourceStream.on("end", () => {
              if (returned2) {
                return;
              }
              returned2 = true;
              this.content._resolve = false;
              this.content._resolvedValue = Buffer.concat(chunks, chunklen);
              setImmediate(createStream);
            });
          } else {
            setImmediate(createStream);
          }
          return;
        } else {
          return setImmediate(finalize);
        }
      };
      if (this._raw) {
        setImmediate(() => {
          if (Object.prototype.toString.call(this._raw) === "[object Error]") {
            return callback(this._raw);
          }
          if (typeof this._raw.pipe === "function") {
            this._raw.removeListener("error", this._contentErrorHandler);
          }
          let raw2 = this._getStream(this._raw);
          raw2.pipe(outputStream, {
            end: false
          });
          raw2.on("error", (err) => outputStream.emit("error", err));
          raw2.on("end", finalize);
        });
      } else {
        outputStream.write(this.buildHeaders() + "\r\n\r\n");
        setImmediate(sendContent);
      }
    }
    setEnvelope(envelope) {
      let list;
      this._envelope = {
        from: false,
        to: []
      };
      if (envelope.from) {
        list = [];
        this._convertAddresses(this._parseAddresses(envelope.from), list);
        list = list.filter((address) => address && address.address);
        if (list.length && list[0]) {
          this._envelope.from = list[0].address;
        }
      }
      ["to", "cc", "bcc"].forEach((key) => {
        if (envelope[key]) {
          this._convertAddresses(this._parseAddresses(envelope[key]), this._envelope.to);
        }
      });
      this._envelope.to = this._envelope.to.map((to) => to.address).filter((address) => address);
      let standardFields = ["to", "cc", "bcc", "from"];
      Object.keys(envelope).forEach((key) => {
        if (!standardFields.includes(key)) {
          this._envelope[key] = envelope[key];
        }
      });
      return this;
    }
    getAddresses() {
      let addresses = {};
      this._headers.forEach((header) => {
        let key = header.key.toLowerCase();
        if (["from", "sender", "reply-to", "to", "cc", "bcc"].includes(key)) {
          if (!Array.isArray(addresses[key])) {
            addresses[key] = [];
          }
          this._convertAddresses(this._parseAddresses(header.value), addresses[key]);
        }
      });
      return addresses;
    }
    getEnvelope() {
      if (this._envelope) {
        return this._envelope;
      }
      let envelope = {
        from: false,
        to: []
      };
      this._headers.forEach((header) => {
        let list = [];
        if (header.key === "From" || !envelope.from && ["Reply-To", "Sender"].includes(header.key)) {
          this._convertAddresses(this._parseAddresses(header.value), list);
          if (list.length && list[0]) {
            envelope.from = list[0].address;
          }
        } else if (["To", "Cc", "Bcc"].includes(header.key)) {
          this._convertAddresses(this._parseAddresses(header.value), envelope.to);
        }
      });
      envelope.to = envelope.to.map((to) => to.address);
      return envelope;
    }
    messageId() {
      let messageId = this.getHeader("Message-ID");
      if (!messageId) {
        messageId = this._generateMessageId();
        this.setHeader("Message-ID", messageId);
      }
      return messageId;
    }
    setRaw(raw2) {
      this._raw = raw2;
      if (this._raw && typeof this._raw.pipe === "function") {
        this._contentErrorHandler = (err) => {
          this._raw.removeListener("error", this._contentErrorHandler);
          this._raw = err;
        };
        this._raw.once("error", this._contentErrorHandler);
      }
      return this;
    }
    _getStream(content) {
      let contentStream;
      if (content._resolvedValue) {
        contentStream = new PassThrough;
        setImmediate(() => {
          try {
            contentStream.end(content._resolvedValue);
          } catch (err) {
            contentStream.emit("error", err);
          }
        });
        return contentStream;
      } else if (typeof content.pipe === "function") {
        return content;
      } else if (content && typeof content.path === "string" && !content.href) {
        if (this.disableFileAccess) {
          contentStream = new PassThrough;
          setImmediate(() => contentStream.emit("error", new Error("File access rejected for " + content.path)));
          return contentStream;
        }
        return fs2.createReadStream(content.path);
      } else if (content && typeof content.href === "string") {
        if (this.disableUrlAccess) {
          contentStream = new PassThrough;
          setImmediate(() => contentStream.emit("error", new Error("Url access rejected for " + content.href)));
          return contentStream;
        }
        return nmfetch(content.href, { headers: content.httpHeaders });
      } else {
        contentStream = new PassThrough;
        setImmediate(() => {
          try {
            contentStream.end(content || "");
          } catch (err) {
            contentStream.emit("error", err);
          }
        });
        return contentStream;
      }
    }
    _parseAddresses(addresses) {
      return [].concat.apply([], [].concat(addresses).map((address) => {
        if (address && address.address) {
          address.address = this._normalizeAddress(address.address);
          address.name = address.name || "";
          return [address];
        }
        return addressparser(address);
      }));
    }
    _normalizeHeaderKey(key) {
      key = (key || "").toString().replace(/\r?\n|\r/g, " ").trim().toLowerCase().replace(/^X-SMTPAPI$|^(MIME|DKIM|ARC|BIMI)\b|^[a-z]|-(SPF|FBL|ID|MD5)$|-[a-z]/gi, (c) => c.toUpperCase()).replace(/^Content-Features$/i, "Content-features");
      return key;
    }
    _handleContentType(structured) {
      this.contentType = structured.value.trim().toLowerCase();
      this.multipart = /^multipart\//i.test(this.contentType) ? this.contentType.substr(this.contentType.indexOf("/") + 1) : false;
      if (this.multipart) {
        this.boundary = structured.params.boundary = structured.params.boundary || this.boundary || this._generateBoundary();
      } else {
        this.boundary = false;
      }
    }
    _generateBoundary() {
      return this.rootNode.boundaryPrefix + "-" + this.rootNode.baseBoundary + "-Part_" + this._nodeId;
    }
    _encodeHeaderValue(key, value) {
      key = this._normalizeHeaderKey(key);
      switch (key) {
        case "From":
        case "Sender":
        case "To":
        case "Cc":
        case "Bcc":
        case "Reply-To":
          return this._convertAddresses(this._parseAddresses(value));
        case "Message-ID":
        case "In-Reply-To":
        case "Content-Id":
          value = (value || "").toString().replace(/\r?\n|\r/g, " ");
          if (value.charAt(0) !== "<") {
            value = "<" + value;
          }
          if (value.charAt(value.length - 1) !== ">") {
            value = value + ">";
          }
          return value;
        case "References":
          value = [].concat.apply([], [].concat(value || "").map((elm) => {
            elm = (elm || "").toString().replace(/\r?\n|\r/g, " ").trim();
            return elm.replace(/<[^>]*>/g, (str) => str.replace(/\s/g, "")).split(/\s+/);
          })).map((elm) => {
            if (elm.charAt(0) !== "<") {
              elm = "<" + elm;
            }
            if (elm.charAt(elm.length - 1) !== ">") {
              elm = elm + ">";
            }
            return elm;
          });
          return value.join(" ").trim();
        case "Date":
          if (Object.prototype.toString.call(value) === "[object Date]") {
            return value.toUTCString().replace(/GMT/, "+0000");
          }
          value = (value || "").toString().replace(/\r?\n|\r/g, " ");
          return this._encodeWords(value);
        case "Content-Type":
        case "Content-Disposition":
          return (value || "").toString().replace(/\r?\n|\r/g, " ");
        default:
          value = (value || "").toString().replace(/\r?\n|\r/g, " ");
          return this._encodeWords(value);
      }
    }
    _convertAddresses(addresses, uniqueList) {
      let values = [];
      uniqueList = uniqueList || [];
      [].concat(addresses || []).forEach((address) => {
        if (address.address) {
          address.address = this._normalizeAddress(address.address);
          if (!address.name) {
            values.push(address.address.indexOf(" ") >= 0 ? `<${address.address}>` : `${address.address}`);
          } else if (address.name) {
            values.push(`${this._encodeAddressName(address.name)} <${address.address}>`);
          }
          if (address.address) {
            if (!uniqueList.filter((a) => a.address === address.address).length) {
              uniqueList.push(address);
            }
          }
        } else if (address.group) {
          let groupListAddresses = (address.group.length ? this._convertAddresses(address.group, uniqueList) : "").trim();
          values.push(`${this._encodeAddressName(address.name)}:${groupListAddresses};`);
        }
      });
      return values.join(", ");
    }
    _normalizeAddress(address) {
      address = (address || "").toString().replace(/[\x00-\x1F<>]+/g, " ").trim();
      let lastAt = address.lastIndexOf("@");
      if (lastAt < 0) {
        return address;
      }
      let user = address.substr(0, lastAt);
      let domain = address.substr(lastAt + 1);
      let encodedDomain;
      try {
        encodedDomain = punycode.toASCII(domain.toLowerCase());
      } catch (err) {
      }
      if (user.indexOf(" ") >= 0) {
        if (user.charAt(0) !== '"') {
          user = '"' + user;
        }
        if (user.substr(-1) !== '"') {
          user = user + '"';
        }
      }
      return `${user}@${encodedDomain}`;
    }
    _encodeAddressName(name) {
      if (!/^[\w ]*$/.test(name)) {
        if (/^[\x20-\x7e]*$/.test(name)) {
          return '"' + name.replace(/([\\"])/g, "\\$1") + '"';
        } else {
          return mimeFuncs.encodeWord(name, this._getTextEncoding(name), 52);
        }
      }
      return name;
    }
    _encodeWords(value) {
      return mimeFuncs.encodeWords(value, this._getTextEncoding(value), 52, true);
    }
    _getTextEncoding(value) {
      value = (value || "").toString();
      let encoding = this.textEncoding;
      let latinLen;
      let nonLatinLen;
      if (!encoding) {
        nonLatinLen = (value.match(/[\x00-\x08\x0B\x0C\x0E-\x1F\u0080-\uFFFF]/g) || []).length;
        latinLen = (value.match(/[a-z]/gi) || []).length;
        encoding = nonLatinLen < latinLen ? "Q" : "B";
      }
      return encoding;
    }
    _generateMessageId() {
      return "<" + [2, 2, 2, 6].reduce((prev, len) => prev + "-" + crypto2.randomBytes(len).toString("hex"), crypto2.randomBytes(4).toString("hex")) + "@" + (this.getEnvelope().from || this.hostname || "localhost").split("@").pop() + ">";
    }
  }
  module.exports = MimeNode;
});

// node_modules/nodemailer/lib/mail-composer/index.js
var require_mail_composer = __commonJS((exports, module) => {
  var MimeNode = require_mime_node();
  var mimeFuncs = require_mime_funcs();
  var parseDataURI = require_shared().parseDataURI;

  class MailComposer {
    constructor(mail) {
      this.mail = mail || {};
      this.message = false;
    }
    compile() {
      this._alternatives = this.getAlternatives();
      this._htmlNode = this._alternatives.filter((alternative) => /^text\/html\b/i.test(alternative.contentType)).pop();
      this._attachments = this.getAttachments(!!this._htmlNode);
      this._useRelated = !!(this._htmlNode && this._attachments.related.length);
      this._useAlternative = this._alternatives.length > 1;
      this._useMixed = this._attachments.attached.length > 1 || this._alternatives.length && this._attachments.attached.length === 1;
      if (this.mail.raw) {
        this.message = new MimeNode("message/rfc822", { newline: this.mail.newline }).setRaw(this.mail.raw);
      } else if (this._useMixed) {
        this.message = this._createMixed();
      } else if (this._useAlternative) {
        this.message = this._createAlternative();
      } else if (this._useRelated) {
        this.message = this._createRelated();
      } else {
        this.message = this._createContentNode(false, [].concat(this._alternatives || []).concat(this._attachments.attached || []).shift() || {
          contentType: "text/plain",
          content: ""
        });
      }
      if (this.mail.headers) {
        this.message.addHeader(this.mail.headers);
      }
      ["from", "sender", "to", "cc", "bcc", "reply-to", "in-reply-to", "references", "subject", "message-id", "date"].forEach((header) => {
        let key = header.replace(/-(\w)/g, (o, c) => c.toUpperCase());
        if (this.mail[key]) {
          this.message.setHeader(header, this.mail[key]);
        }
      });
      if (this.mail.envelope) {
        this.message.setEnvelope(this.mail.envelope);
      }
      this.message.messageId();
      return this.message;
    }
    getAttachments(findRelated) {
      let icalEvent, eventObject;
      let attachments = [].concat(this.mail.attachments || []).map((attachment, i) => {
        let data;
        let isMessageNode = /^message\//i.test(attachment.contentType);
        if (/^data:/i.test(attachment.path || attachment.href)) {
          attachment = this._processDataUrl(attachment);
        }
        let contentType = attachment.contentType || mimeFuncs.detectMimeType(attachment.filename || attachment.path || attachment.href || "bin");
        let isImage = /^image\//i.test(contentType);
        let contentDisposition = attachment.contentDisposition || (isMessageNode || isImage && attachment.cid ? "inline" : "attachment");
        data = {
          contentType,
          contentDisposition,
          contentTransferEncoding: "contentTransferEncoding" in attachment ? attachment.contentTransferEncoding : "base64"
        };
        if (attachment.filename) {
          data.filename = attachment.filename;
        } else if (!isMessageNode && attachment.filename !== false) {
          data.filename = (attachment.path || attachment.href || "").split("/").pop().split("?").shift() || "attachment-" + (i + 1);
          if (data.filename.indexOf(".") < 0) {
            data.filename += "." + mimeFuncs.detectExtension(data.contentType);
          }
        }
        if (/^https?:\/\//i.test(attachment.path)) {
          attachment.href = attachment.path;
          attachment.path = undefined;
        }
        if (attachment.cid) {
          data.cid = attachment.cid;
        }
        if (attachment.raw) {
          data.raw = attachment.raw;
        } else if (attachment.path) {
          data.content = {
            path: attachment.path
          };
        } else if (attachment.href) {
          data.content = {
            href: attachment.href,
            httpHeaders: attachment.httpHeaders
          };
        } else {
          data.content = attachment.content || "";
        }
        if (attachment.encoding) {
          data.encoding = attachment.encoding;
        }
        if (attachment.headers) {
          data.headers = attachment.headers;
        }
        return data;
      });
      if (this.mail.icalEvent) {
        if (typeof this.mail.icalEvent === "object" && (this.mail.icalEvent.content || this.mail.icalEvent.path || this.mail.icalEvent.href || this.mail.icalEvent.raw)) {
          icalEvent = this.mail.icalEvent;
        } else {
          icalEvent = {
            content: this.mail.icalEvent
          };
        }
        eventObject = {};
        Object.keys(icalEvent).forEach((key) => {
          eventObject[key] = icalEvent[key];
        });
        eventObject.contentType = "application/ics";
        if (!eventObject.headers) {
          eventObject.headers = {};
        }
        eventObject.filename = eventObject.filename || "invite.ics";
        eventObject.headers["Content-Disposition"] = "attachment";
        eventObject.headers["Content-Transfer-Encoding"] = "base64";
      }
      if (!findRelated) {
        return {
          attached: attachments.concat(eventObject || []),
          related: []
        };
      } else {
        return {
          attached: attachments.filter((attachment) => !attachment.cid).concat(eventObject || []),
          related: attachments.filter((attachment) => !!attachment.cid)
        };
      }
    }
    getAlternatives() {
      let alternatives = [], text2, html, watchHtml, amp, icalEvent, eventObject;
      if (this.mail.text) {
        if (typeof this.mail.text === "object" && (this.mail.text.content || this.mail.text.path || this.mail.text.href || this.mail.text.raw)) {
          text2 = this.mail.text;
        } else {
          text2 = {
            content: this.mail.text
          };
        }
        text2.contentType = "text/plain; charset=utf-8";
      }
      if (this.mail.watchHtml) {
        if (typeof this.mail.watchHtml === "object" && (this.mail.watchHtml.content || this.mail.watchHtml.path || this.mail.watchHtml.href || this.mail.watchHtml.raw)) {
          watchHtml = this.mail.watchHtml;
        } else {
          watchHtml = {
            content: this.mail.watchHtml
          };
        }
        watchHtml.contentType = "text/watch-html; charset=utf-8";
      }
      if (this.mail.amp) {
        if (typeof this.mail.amp === "object" && (this.mail.amp.content || this.mail.amp.path || this.mail.amp.href || this.mail.amp.raw)) {
          amp = this.mail.amp;
        } else {
          amp = {
            content: this.mail.amp
          };
        }
        amp.contentType = "text/x-amp-html; charset=utf-8";
      }
      if (this.mail.icalEvent) {
        if (typeof this.mail.icalEvent === "object" && (this.mail.icalEvent.content || this.mail.icalEvent.path || this.mail.icalEvent.href || this.mail.icalEvent.raw)) {
          icalEvent = this.mail.icalEvent;
        } else {
          icalEvent = {
            content: this.mail.icalEvent
          };
        }
        eventObject = {};
        Object.keys(icalEvent).forEach((key) => {
          eventObject[key] = icalEvent[key];
        });
        if (eventObject.content && typeof eventObject.content === "object") {
          eventObject.content._resolve = true;
        }
        eventObject.filename = false;
        eventObject.contentType = "text/calendar; charset=utf-8; method=" + (eventObject.method || "PUBLISH").toString().trim().toUpperCase();
        if (!eventObject.headers) {
          eventObject.headers = {};
        }
      }
      if (this.mail.html) {
        if (typeof this.mail.html === "object" && (this.mail.html.content || this.mail.html.path || this.mail.html.href || this.mail.html.raw)) {
          html = this.mail.html;
        } else {
          html = {
            content: this.mail.html
          };
        }
        html.contentType = "text/html; charset=utf-8";
      }
      [].concat(text2 || []).concat(watchHtml || []).concat(amp || []).concat(html || []).concat(eventObject || []).concat(this.mail.alternatives || []).forEach((alternative) => {
        let data;
        if (/^data:/i.test(alternative.path || alternative.href)) {
          alternative = this._processDataUrl(alternative);
        }
        data = {
          contentType: alternative.contentType || mimeFuncs.detectMimeType(alternative.filename || alternative.path || alternative.href || "txt"),
          contentTransferEncoding: alternative.contentTransferEncoding
        };
        if (alternative.filename) {
          data.filename = alternative.filename;
        }
        if (/^https?:\/\//i.test(alternative.path)) {
          alternative.href = alternative.path;
          alternative.path = undefined;
        }
        if (alternative.raw) {
          data.raw = alternative.raw;
        } else if (alternative.path) {
          data.content = {
            path: alternative.path
          };
        } else if (alternative.href) {
          data.content = {
            href: alternative.href
          };
        } else {
          data.content = alternative.content || "";
        }
        if (alternative.encoding) {
          data.encoding = alternative.encoding;
        }
        if (alternative.headers) {
          data.headers = alternative.headers;
        }
        alternatives.push(data);
      });
      return alternatives;
    }
    _createMixed(parentNode) {
      let node;
      if (!parentNode) {
        node = new MimeNode("multipart/mixed", {
          baseBoundary: this.mail.baseBoundary,
          textEncoding: this.mail.textEncoding,
          boundaryPrefix: this.mail.boundaryPrefix,
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      } else {
        node = parentNode.createChild("multipart/mixed", {
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      }
      if (this._useAlternative) {
        this._createAlternative(node);
      } else if (this._useRelated) {
        this._createRelated(node);
      }
      [].concat(!this._useAlternative && this._alternatives || []).concat(this._attachments.attached || []).forEach((element) => {
        if (!this._useRelated || element !== this._htmlNode) {
          this._createContentNode(node, element);
        }
      });
      return node;
    }
    _createAlternative(parentNode) {
      let node;
      if (!parentNode) {
        node = new MimeNode("multipart/alternative", {
          baseBoundary: this.mail.baseBoundary,
          textEncoding: this.mail.textEncoding,
          boundaryPrefix: this.mail.boundaryPrefix,
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      } else {
        node = parentNode.createChild("multipart/alternative", {
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      }
      this._alternatives.forEach((alternative) => {
        if (this._useRelated && this._htmlNode === alternative) {
          this._createRelated(node);
        } else {
          this._createContentNode(node, alternative);
        }
      });
      return node;
    }
    _createRelated(parentNode) {
      let node;
      if (!parentNode) {
        node = new MimeNode('multipart/related; type="text/html"', {
          baseBoundary: this.mail.baseBoundary,
          textEncoding: this.mail.textEncoding,
          boundaryPrefix: this.mail.boundaryPrefix,
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      } else {
        node = parentNode.createChild('multipart/related; type="text/html"', {
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      }
      this._createContentNode(node, this._htmlNode);
      this._attachments.related.forEach((alternative) => this._createContentNode(node, alternative));
      return node;
    }
    _createContentNode(parentNode, element) {
      element = element || {};
      element.content = element.content || "";
      let node;
      let encoding = (element.encoding || "utf8").toString().toLowerCase().replace(/[-_\s]/g, "");
      if (!parentNode) {
        node = new MimeNode(element.contentType, {
          filename: element.filename,
          baseBoundary: this.mail.baseBoundary,
          textEncoding: this.mail.textEncoding,
          boundaryPrefix: this.mail.boundaryPrefix,
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      } else {
        node = parentNode.createChild(element.contentType, {
          filename: element.filename,
          textEncoding: this.mail.textEncoding,
          disableUrlAccess: this.mail.disableUrlAccess,
          disableFileAccess: this.mail.disableFileAccess,
          normalizeHeaderKey: this.mail.normalizeHeaderKey,
          newline: this.mail.newline
        });
      }
      if (element.headers) {
        node.addHeader(element.headers);
      }
      if (element.cid) {
        node.setHeader("Content-Id", "<" + element.cid.replace(/[<>]/g, "") + ">");
      }
      if (element.contentTransferEncoding) {
        node.setHeader("Content-Transfer-Encoding", element.contentTransferEncoding);
      } else if (this.mail.encoding && /^text\//i.test(element.contentType)) {
        node.setHeader("Content-Transfer-Encoding", this.mail.encoding);
      }
      if (!/^text\//i.test(element.contentType) || element.contentDisposition) {
        node.setHeader("Content-Disposition", element.contentDisposition || (element.cid && /^image\//i.test(element.contentType) ? "inline" : "attachment"));
      }
      if (typeof element.content === "string" && !["utf8", "usascii", "ascii"].includes(encoding)) {
        element.content = Buffer.from(element.content, encoding);
      }
      if (element.raw) {
        node.setRaw(element.raw);
      } else {
        node.setContent(element.content);
      }
      return node;
    }
    _processDataUrl(element) {
      let parsedDataUri;
      if ((element.path || element.href).match(/^data:/)) {
        parsedDataUri = parseDataURI(element.path || element.href);
      }
      if (!parsedDataUri) {
        return element;
      }
      element.content = parsedDataUri.data;
      element.contentType = element.contentType || parsedDataUri.contentType;
      if ("path" in element) {
        element.path = false;
      }
      if ("href" in element) {
        element.href = false;
      }
      return element;
    }
  }
  module.exports = MailComposer;
});

// node_modules/nodemailer/lib/dkim/message-parser.js
var require_message_parser = __commonJS((exports, module) => {
  var Transform = import.meta.require("stream").Transform;

  class MessageParser extends Transform {
    constructor(options) {
      super(options);
      this.lastBytes = Buffer.alloc(4);
      this.headersParsed = false;
      this.headerBytes = 0;
      this.headerChunks = [];
      this.rawHeaders = false;
      this.bodySize = 0;
    }
    updateLastBytes(data) {
      let lblen = this.lastBytes.length;
      let nblen = Math.min(data.length, lblen);
      for (let i = 0, len = lblen - nblen;i < len; i++) {
        this.lastBytes[i] = this.lastBytes[i + nblen];
      }
      for (let i = 1;i <= nblen; i++) {
        this.lastBytes[lblen - i] = data[data.length - i];
      }
    }
    checkHeaders(data) {
      if (this.headersParsed) {
        return true;
      }
      let lblen = this.lastBytes.length;
      let headerPos = 0;
      this.curLinePos = 0;
      for (let i = 0, len = this.lastBytes.length + data.length;i < len; i++) {
        let chr;
        if (i < lblen) {
          chr = this.lastBytes[i];
        } else {
          chr = data[i - lblen];
        }
        if (chr === 10 && i) {
          let pr1 = i - 1 < lblen ? this.lastBytes[i - 1] : data[i - 1 - lblen];
          let pr2 = i > 1 ? i - 2 < lblen ? this.lastBytes[i - 2] : data[i - 2 - lblen] : false;
          if (pr1 === 10) {
            this.headersParsed = true;
            headerPos = i - lblen + 1;
            this.headerBytes += headerPos;
            break;
          } else if (pr1 === 13 && pr2 === 10) {
            this.headersParsed = true;
            headerPos = i - lblen + 1;
            this.headerBytes += headerPos;
            break;
          }
        }
      }
      if (this.headersParsed) {
        this.headerChunks.push(data.slice(0, headerPos));
        this.rawHeaders = Buffer.concat(this.headerChunks, this.headerBytes);
        this.headerChunks = null;
        this.emit("headers", this.parseHeaders());
        if (data.length - 1 > headerPos) {
          let chunk = data.slice(headerPos);
          this.bodySize += chunk.length;
          setImmediate(() => this.push(chunk));
        }
        return false;
      } else {
        this.headerBytes += data.length;
        this.headerChunks.push(data);
      }
      this.updateLastBytes(data);
      return false;
    }
    _transform(chunk, encoding, callback) {
      if (!chunk || !chunk.length) {
        return callback();
      }
      if (typeof chunk === "string") {
        chunk = Buffer.from(chunk, encoding);
      }
      let headersFound;
      try {
        headersFound = this.checkHeaders(chunk);
      } catch (E) {
        return callback(E);
      }
      if (headersFound) {
        this.bodySize += chunk.length;
        this.push(chunk);
      }
      setImmediate(callback);
    }
    _flush(callback) {
      if (this.headerChunks) {
        let chunk = Buffer.concat(this.headerChunks, this.headerBytes);
        this.bodySize += chunk.length;
        this.push(chunk);
        this.headerChunks = null;
      }
      callback();
    }
    parseHeaders() {
      let lines = (this.rawHeaders || "").toString().split(/\r?\n/);
      for (let i = lines.length - 1;i > 0; i--) {
        if (/^\s/.test(lines[i])) {
          lines[i - 1] += "\n" + lines[i];
          lines.splice(i, 1);
        }
      }
      return lines.filter((line) => line.trim()).map((line) => ({
        key: line.substr(0, line.indexOf(":")).trim().toLowerCase(),
        line
      }));
    }
  }
  module.exports = MessageParser;
});

// node_modules/nodemailer/lib/dkim/relaxed-body.js
var require_relaxed_body = __commonJS((exports, module) => {
  var Transform = import.meta.require("stream").Transform;
  var crypto2 = import.meta.require("crypto");

  class RelaxedBody extends Transform {
    constructor(options) {
      super();
      options = options || {};
      this.chunkBuffer = [];
      this.chunkBufferLen = 0;
      this.bodyHash = crypto2.createHash(options.hashAlgo || "sha1");
      this.remainder = "";
      this.byteLength = 0;
      this.debug = options.debug;
      this._debugBody = options.debug ? [] : false;
    }
    updateHash(chunk) {
      let bodyStr;
      let nextRemainder = "";
      let state = "file";
      for (let i = chunk.length - 1;i >= 0; i--) {
        let c = chunk[i];
        if (state === "file" && (c === 10 || c === 13)) {
        } else if (state === "file" && (c === 9 || c === 32)) {
          state = "line";
        } else if (state === "line" && (c === 9 || c === 32)) {
        } else if (state === "file" || state === "line") {
          state = "body";
          if (i === chunk.length - 1) {
            break;
          }
        }
        if (i === 0) {
          if (state === "file" && (!this.remainder || /[\r\n]$/.test(this.remainder)) || state === "line" && (!this.remainder || /[ \t]$/.test(this.remainder))) {
            this.remainder += chunk.toString("binary");
            return;
          } else if (state === "line" || state === "file") {
            nextRemainder = chunk.toString("binary");
            chunk = false;
            break;
          }
        }
        if (state !== "body") {
          continue;
        }
        nextRemainder = chunk.slice(i + 1).toString("binary");
        chunk = chunk.slice(0, i + 1);
        break;
      }
      let needsFixing = !!this.remainder;
      if (chunk && !needsFixing) {
        for (let i = 0, len = chunk.length;i < len; i++) {
          if (i && chunk[i] === 10 && chunk[i - 1] !== 13) {
            needsFixing = true;
            break;
          } else if (i && chunk[i] === 13 && chunk[i - 1] === 32) {
            needsFixing = true;
            break;
          } else if (i && chunk[i] === 32 && chunk[i - 1] === 32) {
            needsFixing = true;
            break;
          } else if (chunk[i] === 9) {
            needsFixing = true;
            break;
          }
        }
      }
      if (needsFixing) {
        bodyStr = this.remainder + (chunk ? chunk.toString("binary") : "");
        this.remainder = nextRemainder;
        bodyStr = bodyStr.replace(/\r?\n/g, "\n").replace(/[ \t]*$/gm, "").replace(/[ \t]+/gm, " ").replace(/\n/g, "\r\n");
        chunk = Buffer.from(bodyStr, "binary");
      } else if (nextRemainder) {
        this.remainder = nextRemainder;
      }
      if (this.debug) {
        this._debugBody.push(chunk);
      }
      this.bodyHash.update(chunk);
    }
    _transform(chunk, encoding, callback) {
      if (!chunk || !chunk.length) {
        return callback();
      }
      if (typeof chunk === "string") {
        chunk = Buffer.from(chunk, encoding);
      }
      this.updateHash(chunk);
      this.byteLength += chunk.length;
      this.push(chunk);
      callback();
    }
    _flush(callback) {
      if (/[\r\n]$/.test(this.remainder) && this.byteLength > 2) {
        this.bodyHash.update(Buffer.from("\r\n"));
      }
      if (!this.byteLength) {
        this.push(Buffer.from("\r\n"));
      }
      this.emit("hash", this.bodyHash.digest("base64"), this.debug ? Buffer.concat(this._debugBody) : false);
      callback();
    }
  }
  module.exports = RelaxedBody;
});

// node_modules/nodemailer/lib/dkim/sign.js
var require_sign = __commonJS((exports, module) => {
  var generateDKIMHeader = function(domainName, keySelector, fieldNames, hashAlgo, bodyHash) {
    let dkim = [
      "v=1",
      "a=rsa-" + hashAlgo,
      "c=relaxed/relaxed",
      "d=" + punycode.toASCII(domainName),
      "q=dns/txt",
      "s=" + keySelector,
      "bh=" + bodyHash,
      "h=" + fieldNames
    ].join("; ");
    return mimeFuncs.foldLines("DKIM-Signature: " + dkim, 76) + ";\r\n b=";
  };
  var relaxedHeaders = function(headers, fieldNames, skipFields) {
    let includedFields = new Set;
    let skip = new Set;
    let headerFields = new Map;
    (skipFields || "").toLowerCase().split(":").forEach((field) => {
      skip.add(field.trim());
    });
    (fieldNames || "").toLowerCase().split(":").filter((field) => !skip.has(field.trim())).forEach((field) => {
      includedFields.add(field.trim());
    });
    for (let i = headers.length - 1;i >= 0; i--) {
      let line = headers[i];
      if (includedFields.has(line.key) && !headerFields.has(line.key)) {
        headerFields.set(line.key, relaxedHeaderLine(line.line));
      }
    }
    let headersList = [];
    let fields = [];
    includedFields.forEach((field) => {
      if (headerFields.has(field)) {
        fields.push(field);
        headersList.push(field + ":" + headerFields.get(field));
      }
    });
    return {
      headers: headersList.join("\r\n") + "\r\n",
      fieldNames: fields.join(":")
    };
  };
  var relaxedHeaderLine = function(line) {
    return line.substr(line.indexOf(":") + 1).replace(/\r?\n/g, "").replace(/\s+/g, " ").trim();
  };
  var punycode = require_punycode();
  var mimeFuncs = require_mime_funcs();
  var crypto2 = import.meta.require("crypto");
  module.exports = (headers, hashAlgo, bodyHash, options) => {
    options = options || {};
    let defaultFieldNames = "From:Sender:Reply-To:Subject:Date:Message-ID:To:" + "Cc:MIME-Version:Content-Type:Content-Transfer-Encoding:Content-ID:" + "Content-Description:Resent-Date:Resent-From:Resent-Sender:" + "Resent-To:Resent-Cc:Resent-Message-ID:In-Reply-To:References:" + "List-Id:List-Help:List-Unsubscribe:List-Subscribe:List-Post:" + "List-Owner:List-Archive";
    let fieldNames = options.headerFieldNames || defaultFieldNames;
    let canonicalizedHeaderData = relaxedHeaders(headers, fieldNames, options.skipFields);
    let dkimHeader = generateDKIMHeader(options.domainName, options.keySelector, canonicalizedHeaderData.fieldNames, hashAlgo, bodyHash);
    let signer, signature;
    canonicalizedHeaderData.headers += "dkim-signature:" + relaxedHeaderLine(dkimHeader);
    signer = crypto2.createSign(("rsa-" + hashAlgo).toUpperCase());
    signer.update(canonicalizedHeaderData.headers);
    try {
      signature = signer.sign(options.privateKey, "base64");
    } catch (E) {
      return false;
    }
    return dkimHeader + signature.replace(/(^.{73}|.{75}(?!\r?\n|\r))/g, "$&\r\n ").trim();
  };
  module.exports.relaxedHeaders = relaxedHeaders;
});

// node_modules/nodemailer/lib/dkim/index.js
var require_dkim = __commonJS((exports, module) => {
  var MessageParser = require_message_parser();
  var RelaxedBody = require_relaxed_body();
  var sign = require_sign();
  var PassThrough = import.meta.require("stream").PassThrough;
  var fs2 = import.meta.require("fs");
  var path2 = import.meta.require("path");
  var crypto2 = import.meta.require("crypto");
  var DKIM_ALGO = "sha256";
  var MAX_MESSAGE_SIZE = 128 * 1024;

  class DKIMSigner {
    constructor(options, keys, input, output) {
      this.options = options || {};
      this.keys = keys;
      this.cacheTreshold = Number(this.options.cacheTreshold) || MAX_MESSAGE_SIZE;
      this.hashAlgo = this.options.hashAlgo || DKIM_ALGO;
      this.cacheDir = this.options.cacheDir || false;
      this.chunks = [];
      this.chunklen = 0;
      this.readPos = 0;
      this.cachePath = this.cacheDir ? path2.join(this.cacheDir, "message." + Date.now() + "-" + crypto2.randomBytes(14).toString("hex")) : false;
      this.cache = false;
      this.headers = false;
      this.bodyHash = false;
      this.parser = false;
      this.relaxedBody = false;
      this.input = input;
      this.output = output;
      this.output.usingCache = false;
      this.hasErrored = false;
      this.input.on("error", (err) => {
        this.hasErrored = true;
        this.cleanup();
        output.emit("error", err);
      });
    }
    cleanup() {
      if (!this.cache || !this.cachePath) {
        return;
      }
      fs2.unlink(this.cachePath, () => false);
    }
    createReadCache() {
      this.cache = fs2.createReadStream(this.cachePath);
      this.cache.once("error", (err) => {
        this.cleanup();
        this.output.emit("error", err);
      });
      this.cache.once("close", () => {
        this.cleanup();
      });
      this.cache.pipe(this.output);
    }
    sendNextChunk() {
      if (this.hasErrored) {
        return;
      }
      if (this.readPos >= this.chunks.length) {
        if (!this.cache) {
          return this.output.end();
        }
        return this.createReadCache();
      }
      let chunk = this.chunks[this.readPos++];
      if (this.output.write(chunk) === false) {
        return this.output.once("drain", () => {
          this.sendNextChunk();
        });
      }
      setImmediate(() => this.sendNextChunk());
    }
    sendSignedOutput() {
      let keyPos = 0;
      let signNextKey = () => {
        if (keyPos >= this.keys.length) {
          this.output.write(this.parser.rawHeaders);
          return setImmediate(() => this.sendNextChunk());
        }
        let key = this.keys[keyPos++];
        let dkimField = sign(this.headers, this.hashAlgo, this.bodyHash, {
          domainName: key.domainName,
          keySelector: key.keySelector,
          privateKey: key.privateKey,
          headerFieldNames: this.options.headerFieldNames,
          skipFields: this.options.skipFields
        });
        if (dkimField) {
          this.output.write(Buffer.from(dkimField + "\r\n"));
        }
        return setImmediate(signNextKey);
      };
      if (this.bodyHash && this.headers) {
        return signNextKey();
      }
      this.output.write(this.parser.rawHeaders);
      this.sendNextChunk();
    }
    createWriteCache() {
      this.output.usingCache = true;
      this.cache = fs2.createWriteStream(this.cachePath);
      this.cache.once("error", (err) => {
        this.cleanup();
        this.relaxedBody.unpipe(this.cache);
        this.relaxedBody.on("readable", () => {
          while (this.relaxedBody.read() !== null) {
          }
        });
        this.hasErrored = true;
        this.output.emit("error", err);
      });
      this.cache.once("close", () => {
        this.sendSignedOutput();
      });
      this.relaxedBody.removeAllListeners("readable");
      this.relaxedBody.pipe(this.cache);
    }
    signStream() {
      this.parser = new MessageParser;
      this.relaxedBody = new RelaxedBody({
        hashAlgo: this.hashAlgo
      });
      this.parser.on("headers", (value) => {
        this.headers = value;
      });
      this.relaxedBody.on("hash", (value) => {
        this.bodyHash = value;
      });
      this.relaxedBody.on("readable", () => {
        let chunk;
        if (this.cache) {
          return;
        }
        while ((chunk = this.relaxedBody.read()) !== null) {
          this.chunks.push(chunk);
          this.chunklen += chunk.length;
          if (this.chunklen >= this.cacheTreshold && this.cachePath) {
            return this.createWriteCache();
          }
        }
      });
      this.relaxedBody.on("end", () => {
        if (this.cache) {
          return;
        }
        this.sendSignedOutput();
      });
      this.parser.pipe(this.relaxedBody);
      setImmediate(() => this.input.pipe(this.parser));
    }
  }

  class DKIM {
    constructor(options) {
      this.options = options || {};
      this.keys = [].concat(this.options.keys || {
        domainName: options.domainName,
        keySelector: options.keySelector,
        privateKey: options.privateKey
      });
    }
    sign(input, extraOptions) {
      let output = new PassThrough;
      let inputStream = input;
      let writeValue = false;
      if (Buffer.isBuffer(input)) {
        writeValue = input;
        inputStream = new PassThrough;
      } else if (typeof input === "string") {
        writeValue = Buffer.from(input);
        inputStream = new PassThrough;
      }
      let options = this.options;
      if (extraOptions && Object.keys(extraOptions).length) {
        options = {};
        Object.keys(this.options || {}).forEach((key) => {
          options[key] = this.options[key];
        });
        Object.keys(extraOptions || {}).forEach((key) => {
          if (!(key in options)) {
            options[key] = extraOptions[key];
          }
        });
      }
      let signer = new DKIMSigner(options, this.keys, inputStream, output);
      setImmediate(() => {
        signer.signStream();
        if (writeValue) {
          setImmediate(() => {
            inputStream.end(writeValue);
          });
        }
      });
      return output;
    }
  }
  module.exports = DKIM;
});

// node_modules/nodemailer/lib/smtp-connection/http-proxy-client.js
var require_http_proxy_client = __commonJS((exports, module) => {
  var httpProxyClient = function(proxyUrl, destinationPort, destinationHost, callback) {
    let proxy = urllib.parse(proxyUrl);
    let options;
    let connect;
    let socket;
    options = {
      host: proxy.hostname,
      port: Number(proxy.port) ? Number(proxy.port) : proxy.protocol === "https:" ? 443 : 80
    };
    if (proxy.protocol === "https:") {
      options.rejectUnauthorized = false;
      connect = tls.connect.bind(tls);
    } else {
      connect = net.connect.bind(net);
    }
    let finished = false;
    let tempSocketErr = (err) => {
      if (finished) {
        return;
      }
      finished = true;
      try {
        socket.destroy();
      } catch (E) {
      }
      callback(err);
    };
    let timeoutErr = () => {
      let err = new Error("Proxy socket timed out");
      err.code = "ETIMEDOUT";
      tempSocketErr(err);
    };
    socket = connect(options, () => {
      if (finished) {
        return;
      }
      let reqHeaders = {
        Host: destinationHost + ":" + destinationPort,
        Connection: "close"
      };
      if (proxy.auth) {
        reqHeaders["Proxy-Authorization"] = "Basic " + Buffer.from(proxy.auth).toString("base64");
      }
      socket.write("CONNECT " + destinationHost + ":" + destinationPort + " HTTP/1.1\r\n" + Object.keys(reqHeaders).map((key) => key + ": " + reqHeaders[key]).join("\r\n") + "\r\n\r\n");
      let headers = "";
      let onSocketData = (chunk) => {
        let match;
        let remainder;
        if (finished) {
          return;
        }
        headers += chunk.toString("binary");
        if (match = headers.match(/\r\n\r\n/)) {
          socket.removeListener("data", onSocketData);
          remainder = headers.substr(match.index + match[0].length);
          headers = headers.substr(0, match.index);
          if (remainder) {
            socket.unshift(Buffer.from(remainder, "binary"));
          }
          finished = true;
          match = headers.match(/^HTTP\/\d+\.\d+ (\d+)/i);
          if (!match || (match[1] || "").charAt(0) !== "2") {
            try {
              socket.destroy();
            } catch (E) {
            }
            return callback(new Error("Invalid response from proxy" + (match && ": " + match[1] || "")));
          }
          socket.removeListener("error", tempSocketErr);
          socket.removeListener("timeout", timeoutErr);
          socket.setTimeout(0);
          return callback(null, socket);
        }
      };
      socket.on("data", onSocketData);
    });
    socket.setTimeout(httpProxyClient.timeout || 30 * 1000);
    socket.on("timeout", timeoutErr);
    socket.once("error", tempSocketErr);
  };
  var net = import.meta.require("net");
  var tls = import.meta.require("tls");
  var urllib = import.meta.require("url");
  module.exports = httpProxyClient;
});

// node_modules/nodemailer/lib/mailer/mail-message.js
var require_mail_message = __commonJS((exports, module) => {
  var shared = require_shared();
  var MimeNode = require_mime_node();
  var mimeFuncs = require_mime_funcs();

  class MailMessage {
    constructor(mailer, data) {
      this.mailer = mailer;
      this.data = {};
      this.message = null;
      data = data || {};
      let options = mailer.options || {};
      let defaults = mailer._defaults || {};
      Object.keys(data).forEach((key) => {
        this.data[key] = data[key];
      });
      this.data.headers = this.data.headers || {};
      Object.keys(defaults).forEach((key) => {
        if (!(key in this.data)) {
          this.data[key] = defaults[key];
        } else if (key === "headers") {
          Object.keys(defaults.headers).forEach((key2) => {
            if (!(key2 in this.data.headers)) {
              this.data.headers[key2] = defaults.headers[key2];
            }
          });
        }
      });
      ["disableFileAccess", "disableUrlAccess", "normalizeHeaderKey"].forEach((key) => {
        if (key in options) {
          this.data[key] = options[key];
        }
      });
    }
    resolveContent(...args) {
      return shared.resolveContent(...args);
    }
    resolveAll(callback) {
      let keys = [
        [this.data, "html"],
        [this.data, "text"],
        [this.data, "watchHtml"],
        [this.data, "amp"],
        [this.data, "icalEvent"]
      ];
      if (this.data.alternatives && this.data.alternatives.length) {
        this.data.alternatives.forEach((alternative, i) => {
          keys.push([this.data.alternatives, i]);
        });
      }
      if (this.data.attachments && this.data.attachments.length) {
        this.data.attachments.forEach((attachment, i) => {
          if (!attachment.filename) {
            attachment.filename = (attachment.path || attachment.href || "").split("/").pop().split("?").shift() || "attachment-" + (i + 1);
            if (attachment.filename.indexOf(".") < 0) {
              attachment.filename += "." + mimeFuncs.detectExtension(attachment.contentType);
            }
          }
          if (!attachment.contentType) {
            attachment.contentType = mimeFuncs.detectMimeType(attachment.filename || attachment.path || attachment.href || "bin");
          }
          keys.push([this.data.attachments, i]);
        });
      }
      let mimeNode = new MimeNode;
      let addressKeys = ["from", "to", "cc", "bcc", "sender", "replyTo"];
      addressKeys.forEach((address) => {
        let value;
        if (this.message) {
          value = [].concat(mimeNode._parseAddresses(this.message.getHeader(address === "replyTo" ? "reply-to" : address)) || []);
        } else if (this.data[address]) {
          value = [].concat(mimeNode._parseAddresses(this.data[address]) || []);
        }
        if (value && value.length) {
          this.data[address] = value;
        } else if (address in this.data) {
          this.data[address] = null;
        }
      });
      let singleKeys = ["from", "sender"];
      singleKeys.forEach((address) => {
        if (this.data[address]) {
          this.data[address] = this.data[address].shift();
        }
      });
      let pos = 0;
      let resolveNext = () => {
        if (pos >= keys.length) {
          return callback(null, this.data);
        }
        let args = keys[pos++];
        if (!args[0] || !args[0][args[1]]) {
          return resolveNext();
        }
        shared.resolveContent(...args, (err, value) => {
          if (err) {
            return callback(err);
          }
          let node = {
            content: value
          };
          if (args[0][args[1]] && typeof args[0][args[1]] === "object" && !Buffer.isBuffer(args[0][args[1]])) {
            Object.keys(args[0][args[1]]).forEach((key) => {
              if (!(key in node) && !["content", "path", "href", "raw"].includes(key)) {
                node[key] = args[0][args[1]][key];
              }
            });
          }
          args[0][args[1]] = node;
          resolveNext();
        });
      };
      setImmediate(() => resolveNext());
    }
    normalize(callback) {
      let envelope = this.data.envelope || this.message.getEnvelope();
      let messageId = this.message.messageId();
      this.resolveAll((err, data) => {
        if (err) {
          return callback(err);
        }
        data.envelope = envelope;
        data.messageId = messageId;
        ["html", "text", "watchHtml", "amp"].forEach((key) => {
          if (data[key] && data[key].content) {
            if (typeof data[key].content === "string") {
              data[key] = data[key].content;
            } else if (Buffer.isBuffer(data[key].content)) {
              data[key] = data[key].content.toString();
            }
          }
        });
        if (data.icalEvent && Buffer.isBuffer(data.icalEvent.content)) {
          data.icalEvent.content = data.icalEvent.content.toString("base64");
          data.icalEvent.encoding = "base64";
        }
        if (data.alternatives && data.alternatives.length) {
          data.alternatives.forEach((alternative) => {
            if (alternative && alternative.content && Buffer.isBuffer(alternative.content)) {
              alternative.content = alternative.content.toString("base64");
              alternative.encoding = "base64";
            }
          });
        }
        if (data.attachments && data.attachments.length) {
          data.attachments.forEach((attachment) => {
            if (attachment && attachment.content && Buffer.isBuffer(attachment.content)) {
              attachment.content = attachment.content.toString("base64");
              attachment.encoding = "base64";
            }
          });
        }
        data.normalizedHeaders = {};
        Object.keys(data.headers || {}).forEach((key) => {
          let value = [].concat(data.headers[key] || []).shift();
          value = value && value.value || value;
          if (value) {
            if (["references", "in-reply-to", "message-id", "content-id"].includes(key)) {
              value = this.message._encodeHeaderValue(key, value);
            }
            data.normalizedHeaders[key] = value;
          }
        });
        if (data.list && typeof data.list === "object") {
          let listHeaders = this._getListHeaders(data.list);
          listHeaders.forEach((entry) => {
            data.normalizedHeaders[entry.key] = entry.value.map((val) => val && val.value || val).join(", ");
          });
        }
        if (data.references) {
          data.normalizedHeaders.references = this.message._encodeHeaderValue("references", data.references);
        }
        if (data.inReplyTo) {
          data.normalizedHeaders["in-reply-to"] = this.message._encodeHeaderValue("in-reply-to", data.inReplyTo);
        }
        return callback(null, data);
      });
    }
    setMailerHeader() {
      if (!this.message || !this.data.xMailer) {
        return;
      }
      this.message.setHeader("X-Mailer", this.data.xMailer);
    }
    setPriorityHeaders() {
      if (!this.message || !this.data.priority) {
        return;
      }
      switch ((this.data.priority || "").toString().toLowerCase()) {
        case "high":
          this.message.setHeader("X-Priority", "1 (Highest)");
          this.message.setHeader("X-MSMail-Priority", "High");
          this.message.setHeader("Importance", "High");
          break;
        case "low":
          this.message.setHeader("X-Priority", "5 (Lowest)");
          this.message.setHeader("X-MSMail-Priority", "Low");
          this.message.setHeader("Importance", "Low");
          break;
        default:
      }
    }
    setListHeaders() {
      if (!this.message || !this.data.list || typeof this.data.list !== "object") {
        return;
      }
      if (this.data.list && typeof this.data.list === "object") {
        this._getListHeaders(this.data.list).forEach((listHeader) => {
          listHeader.value.forEach((value) => {
            this.message.addHeader(listHeader.key, value);
          });
        });
      }
    }
    _getListHeaders(listData) {
      return Object.keys(listData).map((key) => ({
        key: "list-" + key.toLowerCase().trim(),
        value: [].concat(listData[key] || []).map((value) => ({
          prepared: true,
          foldLines: true,
          value: [].concat(value || []).map((value2) => {
            if (typeof value2 === "string") {
              value2 = {
                url: value2
              };
            }
            if (value2 && value2.url) {
              if (key.toLowerCase().trim() === "id") {
                let comment2 = value2.comment || "";
                if (mimeFuncs.isPlainText(comment2)) {
                  comment2 = '"' + comment2 + '"';
                } else {
                  comment2 = mimeFuncs.encodeWord(comment2);
                }
                return (value2.comment ? comment2 + " " : "") + this._formatListUrl(value2.url).replace(/^<[^:]+\/{,2}/, "");
              }
              let comment = value2.comment || "";
              if (!mimeFuncs.isPlainText(comment)) {
                comment = mimeFuncs.encodeWord(comment);
              }
              return this._formatListUrl(value2.url) + (value2.comment ? " (" + comment + ")" : "");
            }
            return "";
          }).filter((value2) => value2).join(", ")
        }))
      }));
    }
    _formatListUrl(url) {
      url = url.replace(/[\s<]+|[\s>]+/g, "");
      if (/^(https?|mailto|ftp):/.test(url)) {
        return "<" + url + ">";
      }
      if (/^[^@]+@[^@]+$/.test(url)) {
        return "<mailto:" + url + ">";
      }
      return "<http://" + url + ">";
    }
  }
  module.exports = MailMessage;
});

// node_modules/nodemailer/lib/mailer/index.js
var require_mailer = __commonJS((exports, module) => {
  var EventEmitter = import.meta.require("events");
  var shared = require_shared();
  var mimeTypes = require_mime_types();
  var MailComposer = require_mail_composer();
  var DKIM = require_dkim();
  var httpProxyClient = require_http_proxy_client();
  var util = import.meta.require("util");
  var urllib = import.meta.require("url");
  var packageData = require_package();
  var MailMessage = require_mail_message();
  var net = import.meta.require("net");
  var dns = import.meta.require("dns");
  var crypto2 = import.meta.require("crypto");

  class Mail extends EventEmitter {
    constructor(transporter, options, defaults) {
      super();
      this.options = options || {};
      this._defaults = defaults || {};
      this._defaultPlugins = {
        compile: [(...args) => this._convertDataImages(...args)],
        stream: []
      };
      this._userPlugins = {
        compile: [],
        stream: []
      };
      this.meta = new Map;
      this.dkim = this.options.dkim ? new DKIM(this.options.dkim) : false;
      this.transporter = transporter;
      this.transporter.mailer = this;
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "mail"
      });
      this.logger.debug({
        tnx: "create"
      }, "Creating transport: %s", this.getVersionString());
      if (typeof this.transporter.on === "function") {
        this.transporter.on("log", (log) => {
          this.logger.debug({
            tnx: "transport"
          }, "%s: %s", log.type, log.message);
        });
        this.transporter.on("error", (err) => {
          this.logger.error({
            err,
            tnx: "transport"
          }, "Transport Error: %s", err.message);
          this.emit("error", err);
        });
        this.transporter.on("idle", (...args) => {
          this.emit("idle", ...args);
        });
      }
      ["close", "isIdle", "verify"].forEach((method) => {
        this[method] = (...args) => {
          if (typeof this.transporter[method] === "function") {
            if (method === "verify" && typeof this.getSocket === "function") {
              this.transporter.getSocket = this.getSocket;
              this.getSocket = false;
            }
            return this.transporter[method](...args);
          } else {
            this.logger.warn({
              tnx: "transport",
              methodName: method
            }, "Non existing method %s called for transport", method);
            return false;
          }
        };
      });
      if (this.options.proxy && typeof this.options.proxy === "string") {
        this.setupProxy(this.options.proxy);
      }
    }
    use(step, plugin) {
      step = (step || "").toString();
      if (!this._userPlugins.hasOwnProperty(step)) {
        this._userPlugins[step] = [plugin];
      } else {
        this._userPlugins[step].push(plugin);
      }
      return this;
    }
    sendMail(data, callback = null) {
      let promise;
      if (!callback) {
        promise = new Promise((resolve, reject) => {
          callback = shared.callbackPromise(resolve, reject);
        });
      }
      if (typeof this.getSocket === "function") {
        this.transporter.getSocket = this.getSocket;
        this.getSocket = false;
      }
      let mail = new MailMessage(this, data);
      this.logger.debug({
        tnx: "transport",
        name: this.transporter.name,
        version: this.transporter.version,
        action: "send"
      }, "Sending mail using %s/%s", this.transporter.name, this.transporter.version);
      this._processPlugins("compile", mail, (err) => {
        if (err) {
          this.logger.error({
            err,
            tnx: "plugin",
            action: "compile"
          }, "PluginCompile Error: %s", err.message);
          return callback(err);
        }
        mail.message = new MailComposer(mail.data).compile();
        mail.setMailerHeader();
        mail.setPriorityHeaders();
        mail.setListHeaders();
        this._processPlugins("stream", mail, (err2) => {
          if (err2) {
            this.logger.error({
              err: err2,
              tnx: "plugin",
              action: "stream"
            }, "PluginStream Error: %s", err2.message);
            return callback(err2);
          }
          if (mail.data.dkim || this.dkim) {
            mail.message.processFunc((input) => {
              let dkim = mail.data.dkim ? new DKIM(mail.data.dkim) : this.dkim;
              this.logger.debug({
                tnx: "DKIM",
                messageId: mail.message.messageId(),
                dkimDomains: dkim.keys.map((key) => key.keySelector + "." + key.domainName).join(", ")
              }, "Signing outgoing message with %s keys", dkim.keys.length);
              return dkim.sign(input, mail.data._dkim);
            });
          }
          this.transporter.send(mail, (...args) => {
            if (args[0]) {
              this.logger.error({
                err: args[0],
                tnx: "transport",
                action: "send"
              }, "Send Error: %s", args[0].message);
            }
            callback(...args);
          });
        });
      });
      return promise;
    }
    getVersionString() {
      return util.format("%s (%s; +%s; %s/%s)", packageData.name, packageData.version, packageData.homepage, this.transporter.name, this.transporter.version);
    }
    _processPlugins(step, mail, callback) {
      step = (step || "").toString();
      if (!this._userPlugins.hasOwnProperty(step)) {
        return callback();
      }
      let userPlugins = this._userPlugins[step] || [];
      let defaultPlugins = this._defaultPlugins[step] || [];
      if (userPlugins.length) {
        this.logger.debug({
          tnx: "transaction",
          pluginCount: userPlugins.length,
          step
        }, "Using %s plugins for %s", userPlugins.length, step);
      }
      if (userPlugins.length + defaultPlugins.length === 0) {
        return callback();
      }
      let pos = 0;
      let block = "default";
      let processPlugins = () => {
        let curplugins = block === "default" ? defaultPlugins : userPlugins;
        if (pos >= curplugins.length) {
          if (block === "default" && userPlugins.length) {
            block = "user";
            pos = 0;
            curplugins = userPlugins;
          } else {
            return callback();
          }
        }
        let plugin = curplugins[pos++];
        plugin(mail, (err) => {
          if (err) {
            return callback(err);
          }
          processPlugins();
        });
      };
      processPlugins();
    }
    setupProxy(proxyUrl) {
      let proxy = urllib.parse(proxyUrl);
      this.getSocket = (options, callback) => {
        let protocol = proxy.protocol.replace(/:$/, "").toLowerCase();
        if (this.meta.has("proxy_handler_" + protocol)) {
          return this.meta.get("proxy_handler_" + protocol)(proxy, options, callback);
        }
        switch (protocol) {
          case "http":
          case "https":
            httpProxyClient(proxy.href, options.port, options.host, (err, socket) => {
              if (err) {
                return callback(err);
              }
              return callback(null, {
                connection: socket
              });
            });
            return;
          case "socks":
          case "socks5":
          case "socks4":
          case "socks4a": {
            if (!this.meta.has("proxy_socks_module")) {
              return callback(new Error("Socks module not loaded"));
            }
            let connect = (ipaddress) => {
              let proxyV2 = !!this.meta.get("proxy_socks_module").SocksClient;
              let socksClient = proxyV2 ? this.meta.get("proxy_socks_module").SocksClient : this.meta.get("proxy_socks_module");
              let proxyType = Number(proxy.protocol.replace(/\D/g, "")) || 5;
              let connectionOpts = {
                proxy: {
                  ipaddress,
                  port: Number(proxy.port),
                  type: proxyType
                },
                [proxyV2 ? "destination" : "target"]: {
                  host: options.host,
                  port: options.port
                },
                command: "connect"
              };
              if (proxy.auth) {
                let username = decodeURIComponent(proxy.auth.split(":").shift());
                let password = decodeURIComponent(proxy.auth.split(":").pop());
                if (proxyV2) {
                  connectionOpts.proxy.userId = username;
                  connectionOpts.proxy.password = password;
                } else if (proxyType === 4) {
                  connectionOpts.userid = username;
                } else {
                  connectionOpts.authentication = {
                    username,
                    password
                  };
                }
              }
              socksClient.createConnection(connectionOpts, (err, info) => {
                if (err) {
                  return callback(err);
                }
                return callback(null, {
                  connection: info.socket || info
                });
              });
            };
            if (net.isIP(proxy.hostname)) {
              return connect(proxy.hostname);
            }
            return dns.resolve(proxy.hostname, (err, address) => {
              if (err) {
                return callback(err);
              }
              connect(Array.isArray(address) ? address[0] : address);
            });
          }
        }
        callback(new Error("Unknown proxy configuration"));
      };
    }
    _convertDataImages(mail, callback) {
      if (!this.options.attachDataUrls && !mail.data.attachDataUrls || !mail.data.html) {
        return callback();
      }
      mail.resolveContent(mail.data, "html", (err, html) => {
        if (err) {
          return callback(err);
        }
        let cidCounter = 0;
        html = (html || "").toString().replace(/(<img\b[^<>]{0,1024} src\s{0,20}=[\s"']{0,20})(data:([^;]+);[^"'>\s]+)/gi, (match, prefix, dataUri, mimeType) => {
          let cid = crypto2.randomBytes(10).toString("hex") + "@localhost";
          if (!mail.data.attachments) {
            mail.data.attachments = [];
          }
          if (!Array.isArray(mail.data.attachments)) {
            mail.data.attachments = [].concat(mail.data.attachments || []);
          }
          mail.data.attachments.push({
            path: dataUri,
            cid,
            filename: "image-" + ++cidCounter + "." + mimeTypes.detectExtension(mimeType)
          });
          return prefix + "cid:" + cid;
        });
        mail.data.html = html;
        callback();
      });
    }
    set(key, value) {
      return this.meta.set(key, value);
    }
    get(key) {
      return this.meta.get(key);
    }
  }
  module.exports = Mail;
});

// node_modules/nodemailer/lib/smtp-connection/data-stream.js
var require_data_stream = __commonJS((exports, module) => {
  var stream = import.meta.require("stream");
  var Transform = stream.Transform;

  class DataStream extends Transform {
    constructor(options) {
      super(options);
      this.options = options || {};
      this._curLine = "";
      this.inByteCount = 0;
      this.outByteCount = 0;
      this.lastByte = false;
    }
    _transform(chunk, encoding, done) {
      let chunks = [];
      let chunklen = 0;
      let i, len, lastPos = 0;
      let buf;
      if (!chunk || !chunk.length) {
        return done();
      }
      if (typeof chunk === "string") {
        chunk = Buffer.from(chunk);
      }
      this.inByteCount += chunk.length;
      for (i = 0, len = chunk.length;i < len; i++) {
        if (chunk[i] === 46) {
          if (i && chunk[i - 1] === 10 || !i && (!this.lastByte || this.lastByte === 10)) {
            buf = chunk.slice(lastPos, i + 1);
            chunks.push(buf);
            chunks.push(Buffer.from("."));
            chunklen += buf.length + 1;
            lastPos = i + 1;
          }
        } else if (chunk[i] === 10) {
          if (i && chunk[i - 1] !== 13 || !i && this.lastByte !== 13) {
            if (i > lastPos) {
              buf = chunk.slice(lastPos, i);
              chunks.push(buf);
              chunklen += buf.length + 2;
            } else {
              chunklen += 2;
            }
            chunks.push(Buffer.from("\r\n"));
            lastPos = i + 1;
          }
        }
      }
      if (chunklen) {
        if (lastPos < chunk.length) {
          buf = chunk.slice(lastPos);
          chunks.push(buf);
          chunklen += buf.length;
        }
        this.outByteCount += chunklen;
        this.push(Buffer.concat(chunks, chunklen));
      } else {
        this.outByteCount += chunk.length;
        this.push(chunk);
      }
      this.lastByte = chunk[chunk.length - 1];
      done();
    }
    _flush(done) {
      let buf;
      if (this.lastByte === 10) {
        buf = Buffer.from(".\r\n");
      } else if (this.lastByte === 13) {
        buf = Buffer.from("\n.\r\n");
      } else {
        buf = Buffer.from("\r\n.\r\n");
      }
      this.outByteCount += buf.length;
      this.push(buf);
      done();
    }
  }
  module.exports = DataStream;
});

// node_modules/nodemailer/lib/smtp-connection/index.js
var require_smtp_connection = __commonJS((exports, module) => {
  var packageInfo = require_package();
  var EventEmitter = import.meta.require("events").EventEmitter;
  var net = import.meta.require("net");
  var tls = import.meta.require("tls");
  var os = import.meta.require("os");
  var crypto2 = import.meta.require("crypto");
  var DataStream = require_data_stream();
  var PassThrough = import.meta.require("stream").PassThrough;
  var shared = require_shared();
  var CONNECTION_TIMEOUT = 2 * 60 * 1000;
  var SOCKET_TIMEOUT = 10 * 60 * 1000;
  var GREETING_TIMEOUT = 30 * 1000;
  var DNS_TIMEOUT = 30 * 1000;

  class SMTPConnection extends EventEmitter {
    constructor(options) {
      super(options);
      this.id = crypto2.randomBytes(8).toString("base64").replace(/\W/g, "");
      this.stage = "init";
      this.options = options || {};
      this.secureConnection = !!this.options.secure;
      this.alreadySecured = !!this.options.secured;
      this.port = Number(this.options.port) || (this.secureConnection ? 465 : 587);
      this.host = this.options.host || "localhost";
      this.servername = this.options.servername ? this.options.servername : !net.isIP(this.host) ? this.host : false;
      this.allowInternalNetworkInterfaces = this.options.allowInternalNetworkInterfaces || false;
      if (typeof this.options.secure === "undefined" && this.port === 465) {
        this.secureConnection = true;
      }
      this.name = this.options.name || this._getHostname();
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "smtp-connection",
        sid: this.id
      });
      this.customAuth = new Map;
      Object.keys(this.options.customAuth || {}).forEach((key) => {
        let mapKey = (key || "").toString().trim().toUpperCase();
        if (!mapKey) {
          return;
        }
        this.customAuth.set(mapKey, this.options.customAuth[key]);
      });
      this.version = packageInfo.version;
      this.authenticated = false;
      this.destroyed = false;
      this.secure = !!this.secureConnection;
      this._remainder = "";
      this._responseQueue = [];
      this.lastServerResponse = false;
      this._socket = false;
      this._supportedAuth = [];
      this.allowsAuth = false;
      this._envelope = false;
      this._supportedExtensions = [];
      this._maxAllowedSize = 0;
      this._responseActions = [];
      this._recipientQueue = [];
      this._greetingTimeout = false;
      this._connectionTimeout = false;
      this._destroyed = false;
      this._closing = false;
      this._onSocketData = (chunk) => this._onData(chunk);
      this._onSocketError = (error) => this._onError(error, "ESOCKET", false, "CONN");
      this._onSocketClose = () => this._onClose();
      this._onSocketEnd = () => this._onEnd();
      this._onSocketTimeout = () => this._onTimeout();
    }
    connect(connectCallback) {
      if (typeof connectCallback === "function") {
        this.once("connect", () => {
          this.logger.debug({
            tnx: "smtp"
          }, "SMTP handshake finished");
          connectCallback();
        });
        const isDestroyedMessage = this._isDestroyedMessage("connect");
        if (isDestroyedMessage) {
          return connectCallback(this._formatError(isDestroyedMessage, "ECONNECTION", false, "CONN"));
        }
      }
      let opts = {
        port: this.port,
        host: this.host,
        allowInternalNetworkInterfaces: this.allowInternalNetworkInterfaces,
        timeout: this.options.dnsTimeout || DNS_TIMEOUT
      };
      if (this.options.localAddress) {
        opts.localAddress = this.options.localAddress;
      }
      let setupConnectionHandlers = () => {
        this._connectionTimeout = setTimeout(() => {
          this._onError("Connection timeout", "ETIMEDOUT", false, "CONN");
        }, this.options.connectionTimeout || CONNECTION_TIMEOUT);
        this._socket.on("error", this._onSocketError);
      };
      if (this.options.connection) {
        this._socket = this.options.connection;
        if (this.secureConnection && !this.alreadySecured) {
          setImmediate(() => this._upgradeConnection((err) => {
            if (err) {
              this._onError(new Error("Error initiating TLS - " + (err.message || err)), "ETLS", false, "CONN");
              return;
            }
            this._onConnect();
          }));
        } else {
          setImmediate(() => this._onConnect());
        }
        return;
      } else if (this.options.socket) {
        this._socket = this.options.socket;
        return shared.resolveHostname(opts, (err, resolved) => {
          if (err) {
            return setImmediate(() => this._onError(err, "EDNS", false, "CONN"));
          }
          this.logger.debug({
            tnx: "dns",
            source: opts.host,
            resolved: resolved.host,
            cached: !!resolved.cached
          }, "Resolved %s as %s [cache %s]", opts.host, resolved.host, resolved.cached ? "hit" : "miss");
          Object.keys(resolved).forEach((key) => {
            if (key.charAt(0) !== "_" && resolved[key]) {
              opts[key] = resolved[key];
            }
          });
          try {
            this._socket.connect(this.port, this.host, () => {
              this._socket.setKeepAlive(true);
              this._onConnect();
            });
            setupConnectionHandlers();
          } catch (E) {
            return setImmediate(() => this._onError(E, "ECONNECTION", false, "CONN"));
          }
        });
      } else if (this.secureConnection) {
        if (this.options.tls) {
          Object.keys(this.options.tls).forEach((key) => {
            opts[key] = this.options.tls[key];
          });
        }
        if (this.servername && !opts.servername) {
          opts.servername = this.servername;
        }
        return shared.resolveHostname(opts, (err, resolved) => {
          if (err) {
            return setImmediate(() => this._onError(err, "EDNS", false, "CONN"));
          }
          this.logger.debug({
            tnx: "dns",
            source: opts.host,
            resolved: resolved.host,
            cached: !!resolved.cached
          }, "Resolved %s as %s [cache %s]", opts.host, resolved.host, resolved.cached ? "hit" : "miss");
          Object.keys(resolved).forEach((key) => {
            if (key.charAt(0) !== "_" && resolved[key]) {
              opts[key] = resolved[key];
            }
          });
          try {
            this._socket = tls.connect(opts, () => {
              this._socket.setKeepAlive(true);
              this._onConnect();
            });
            setupConnectionHandlers();
          } catch (E) {
            return setImmediate(() => this._onError(E, "ECONNECTION", false, "CONN"));
          }
        });
      } else {
        return shared.resolveHostname(opts, (err, resolved) => {
          if (err) {
            return setImmediate(() => this._onError(err, "EDNS", false, "CONN"));
          }
          this.logger.debug({
            tnx: "dns",
            source: opts.host,
            resolved: resolved.host,
            cached: !!resolved.cached
          }, "Resolved %s as %s [cache %s]", opts.host, resolved.host, resolved.cached ? "hit" : "miss");
          Object.keys(resolved).forEach((key) => {
            if (key.charAt(0) !== "_" && resolved[key]) {
              opts[key] = resolved[key];
            }
          });
          try {
            this._socket = net.connect(opts, () => {
              this._socket.setKeepAlive(true);
              this._onConnect();
            });
            setupConnectionHandlers();
          } catch (E) {
            return setImmediate(() => this._onError(E, "ECONNECTION", false, "CONN"));
          }
        });
      }
    }
    quit() {
      this._sendCommand("QUIT");
      this._responseActions.push(this.close);
    }
    close() {
      clearTimeout(this._connectionTimeout);
      clearTimeout(this._greetingTimeout);
      this._responseActions = [];
      if (this._closing) {
        return;
      }
      this._closing = true;
      let closeMethod = "end";
      if (this.stage === "init") {
        closeMethod = "destroy";
      }
      this.logger.debug({
        tnx: "smtp"
      }, 'Closing connection to the server using "%s"', closeMethod);
      let socket = this._socket && this._socket.socket || this._socket;
      if (socket && !socket.destroyed) {
        try {
          this._socket[closeMethod]();
        } catch (E) {
        }
      }
      this._destroy();
    }
    login(authData, callback) {
      const isDestroyedMessage = this._isDestroyedMessage("login");
      if (isDestroyedMessage) {
        return callback(this._formatError(isDestroyedMessage, "ECONNECTION", false, "API"));
      }
      this._auth = authData || {};
      this._authMethod = (this._auth.method || "").toString().trim().toUpperCase() || false;
      if (!this._authMethod && this._auth.oauth2 && !this._auth.credentials) {
        this._authMethod = "XOAUTH2";
      } else if (!this._authMethod || this._authMethod === "XOAUTH2" && !this._auth.oauth2) {
        this._authMethod = (this._supportedAuth[0] || "PLAIN").toUpperCase().trim();
      }
      if (this._authMethod !== "XOAUTH2" && (!this._auth.credentials || !this._auth.credentials.user || !this._auth.credentials.pass)) {
        if (this._auth.user && this._auth.pass || this.customAuth.has(this._authMethod)) {
          this._auth.credentials = {
            user: this._auth.user,
            pass: this._auth.pass,
            options: this._auth.options
          };
        } else {
          return callback(this._formatError('Missing credentials for "' + this._authMethod + '"', "EAUTH", false, "API"));
        }
      }
      if (this.customAuth.has(this._authMethod)) {
        let handler = this.customAuth.get(this._authMethod);
        let lastResponse;
        let returned = false;
        let resolve = () => {
          if (returned) {
            return;
          }
          returned = true;
          this.logger.info({
            tnx: "smtp",
            username: this._auth.user,
            action: "authenticated",
            method: this._authMethod
          }, "User %s authenticated", JSON.stringify(this._auth.user));
          this.authenticated = true;
          callback(null, true);
        };
        let reject = (err) => {
          if (returned) {
            return;
          }
          returned = true;
          callback(this._formatError(err, "EAUTH", lastResponse, "AUTH " + this._authMethod));
        };
        let handlerResponse = handler({
          auth: this._auth,
          method: this._authMethod,
          extensions: [].concat(this._supportedExtensions),
          authMethods: [].concat(this._supportedAuth),
          maxAllowedSize: this._maxAllowedSize || false,
          sendCommand: (cmd, done) => {
            let promise;
            if (!done) {
              promise = new Promise((resolve2, reject2) => {
                done = shared.callbackPromise(resolve2, reject2);
              });
            }
            this._responseActions.push((str) => {
              lastResponse = str;
              let codes = str.match(/^(\d+)(?:\s(\d+\.\d+\.\d+))?\s/);
              let data = {
                command: cmd,
                response: str
              };
              if (codes) {
                data.status = Number(codes[1]) || 0;
                if (codes[2]) {
                  data.code = codes[2];
                }
                data.text = str.substr(codes[0].length);
              } else {
                data.text = str;
                data.status = 0;
              }
              done(null, data);
            });
            setImmediate(() => this._sendCommand(cmd));
            return promise;
          },
          resolve,
          reject
        });
        if (handlerResponse && typeof handlerResponse.catch === "function") {
          handlerResponse.then(resolve).catch(reject);
        }
        return;
      }
      switch (this._authMethod) {
        case "XOAUTH2":
          this._handleXOauth2Token(false, callback);
          return;
        case "LOGIN":
          this._responseActions.push((str) => {
            this._actionAUTH_LOGIN_USER(str, callback);
          });
          this._sendCommand("AUTH LOGIN");
          return;
        case "PLAIN":
          this._responseActions.push((str) => {
            this._actionAUTHComplete(str, callback);
          });
          this._sendCommand("AUTH PLAIN " + Buffer.from("\0" + this._auth.credentials.user + "\0" + this._auth.credentials.pass, "utf-8").toString("base64"), "AUTH PLAIN " + Buffer.from("\0" + this._auth.credentials.user + "\0" + "/* secret */", "utf-8").toString("base64"));
          return;
        case "CRAM-MD5":
          this._responseActions.push((str) => {
            this._actionAUTH_CRAM_MD5(str, callback);
          });
          this._sendCommand("AUTH CRAM-MD5");
          return;
      }
      return callback(this._formatError('Unknown authentication method "' + this._authMethod + '"', "EAUTH", false, "API"));
    }
    send(envelope, message, done) {
      if (!message) {
        return done(this._formatError("Empty message", "EMESSAGE", false, "API"));
      }
      const isDestroyedMessage = this._isDestroyedMessage("send message");
      if (isDestroyedMessage) {
        return done(this._formatError(isDestroyedMessage, "ECONNECTION", false, "API"));
      }
      if (this._maxAllowedSize && envelope.size > this._maxAllowedSize) {
        return setImmediate(() => {
          done(this._formatError("Message size larger than allowed " + this._maxAllowedSize, "EMESSAGE", false, "MAIL FROM"));
        });
      }
      let returned = false;
      let callback = function() {
        if (returned) {
          return;
        }
        returned = true;
        done(...arguments);
      };
      if (typeof message.on === "function") {
        message.on("error", (err) => callback(this._formatError(err, "ESTREAM", false, "API")));
      }
      let startTime = Date.now();
      this._setEnvelope(envelope, (err, info) => {
        if (err) {
          return callback(err);
        }
        let envelopeTime = Date.now();
        let stream = this._createSendStream((err2, str) => {
          if (err2) {
            return callback(err2);
          }
          info.envelopeTime = envelopeTime - startTime;
          info.messageTime = Date.now() - envelopeTime;
          info.messageSize = stream.outByteCount;
          info.response = str;
          return callback(null, info);
        });
        if (typeof message.pipe === "function") {
          message.pipe(stream);
        } else {
          stream.write(message);
          stream.end();
        }
      });
    }
    reset(callback) {
      this._sendCommand("RSET");
      this._responseActions.push((str) => {
        if (str.charAt(0) !== "2") {
          return callback(this._formatError("Could not reset session state. response=" + str, "EPROTOCOL", str, "RSET"));
        }
        this._envelope = false;
        return callback(null, true);
      });
    }
    _onConnect() {
      clearTimeout(this._connectionTimeout);
      this.logger.info({
        tnx: "network",
        localAddress: this._socket.localAddress,
        localPort: this._socket.localPort,
        remoteAddress: this._socket.remoteAddress,
        remotePort: this._socket.remotePort
      }, "%s established to %s:%s", this.secure ? "Secure connection" : "Connection", this._socket.remoteAddress, this._socket.remotePort);
      if (this._destroyed) {
        this.close();
        return;
      }
      this.stage = "connected";
      this._socket.removeListener("data", this._onSocketData);
      this._socket.removeListener("timeout", this._onSocketTimeout);
      this._socket.removeListener("close", this._onSocketClose);
      this._socket.removeListener("end", this._onSocketEnd);
      this._socket.on("data", this._onSocketData);
      this._socket.once("close", this._onSocketClose);
      this._socket.once("end", this._onSocketEnd);
      this._socket.setTimeout(this.options.socketTimeout || SOCKET_TIMEOUT);
      this._socket.on("timeout", this._onSocketTimeout);
      this._greetingTimeout = setTimeout(() => {
        if (this._socket && !this._destroyed && this._responseActions[0] === this._actionGreeting) {
          this._onError("Greeting never received", "ETIMEDOUT", false, "CONN");
        }
      }, this.options.greetingTimeout || GREETING_TIMEOUT);
      this._responseActions.push(this._actionGreeting);
      this._socket.resume();
    }
    _onData(chunk) {
      if (this._destroyed || !chunk || !chunk.length) {
        return;
      }
      let data = (chunk || "").toString("binary");
      let lines = (this._remainder + data).split(/\r?\n/);
      let lastline;
      this._remainder = lines.pop();
      for (let i = 0, len = lines.length;i < len; i++) {
        if (this._responseQueue.length) {
          lastline = this._responseQueue[this._responseQueue.length - 1];
          if (/^\d+-/.test(lastline.split("\n").pop())) {
            this._responseQueue[this._responseQueue.length - 1] += "\n" + lines[i];
            continue;
          }
        }
        this._responseQueue.push(lines[i]);
      }
      if (this._responseQueue.length) {
        lastline = this._responseQueue[this._responseQueue.length - 1];
        if (/^\d+-/.test(lastline.split("\n").pop())) {
          return;
        }
      }
      this._processResponse();
    }
    _onError(err, type, data, command) {
      clearTimeout(this._connectionTimeout);
      clearTimeout(this._greetingTimeout);
      if (this._destroyed) {
        return;
      }
      err = this._formatError(err, type, data, command);
      this.logger.error(data, err.message);
      this.emit("error", err);
      this.close();
    }
    _formatError(message, type, response, command) {
      let err;
      if (/Error\]$/i.test(Object.prototype.toString.call(message))) {
        err = message;
      } else {
        err = new Error(message);
      }
      if (type && type !== "Error") {
        err.code = type;
      }
      if (response) {
        err.response = response;
        err.message += ": " + response;
      }
      let responseCode = typeof response === "string" && Number((response.match(/^\d+/) || [])[0]) || false;
      if (responseCode) {
        err.responseCode = responseCode;
      }
      if (command) {
        err.command = command;
      }
      return err;
    }
    _onClose() {
      let serverResponse = false;
      if (this._remainder && this._remainder.trim()) {
        if (this.options.debug || this.options.transactionLog) {
          this.logger.debug({
            tnx: "server"
          }, this._remainder.replace(/\r?\n$/, ""));
        }
        this.lastServerResponse = serverResponse = this._remainder.trim();
      }
      this.logger.info({
        tnx: "network"
      }, "Connection closed");
      if (this.upgrading && !this._destroyed) {
        return this._onError(new Error("Connection closed unexpectedly"), "ETLS", serverResponse, "CONN");
      } else if (![this._actionGreeting, this.close].includes(this._responseActions[0]) && !this._destroyed) {
        return this._onError(new Error("Connection closed unexpectedly"), "ECONNECTION", serverResponse, "CONN");
      } else if (/^[45]\d{2}\b/.test(serverResponse)) {
        return this._onError(new Error("Connection closed unexpectedly"), "ECONNECTION", serverResponse, "CONN");
      }
      this._destroy();
    }
    _onEnd() {
      if (this._socket && !this._socket.destroyed) {
        this._socket.destroy();
      }
    }
    _onTimeout() {
      return this._onError(new Error("Timeout"), "ETIMEDOUT", false, "CONN");
    }
    _destroy() {
      if (this._destroyed) {
        return;
      }
      this._destroyed = true;
      this.emit("end");
    }
    _upgradeConnection(callback) {
      this._socket.removeListener("data", this._onSocketData);
      this._socket.removeListener("timeout", this._onSocketTimeout);
      let socketPlain = this._socket;
      let opts = {
        socket: this._socket,
        host: this.host
      };
      Object.keys(this.options.tls || {}).forEach((key) => {
        opts[key] = this.options.tls[key];
      });
      if (this.servername && !opts.servername) {
        opts.servername = this.servername;
      }
      this.upgrading = true;
      try {
        this._socket = tls.connect(opts, () => {
          this.secure = true;
          this.upgrading = false;
          this._socket.on("data", this._onSocketData);
          socketPlain.removeListener("close", this._onSocketClose);
          socketPlain.removeListener("end", this._onSocketEnd);
          return callback(null, true);
        });
      } catch (err) {
        return callback(err);
      }
      this._socket.on("error", this._onSocketError);
      this._socket.once("close", this._onSocketClose);
      this._socket.once("end", this._onSocketEnd);
      this._socket.setTimeout(this.options.socketTimeout || SOCKET_TIMEOUT);
      this._socket.on("timeout", this._onSocketTimeout);
      socketPlain.resume();
    }
    _processResponse() {
      if (!this._responseQueue.length) {
        return false;
      }
      let str = this.lastServerResponse = (this._responseQueue.shift() || "").toString();
      if (/^\d+-/.test(str.split("\n").pop())) {
        return;
      }
      if (this.options.debug || this.options.transactionLog) {
        this.logger.debug({
          tnx: "server"
        }, str.replace(/\r?\n$/, ""));
      }
      if (!str.trim()) {
        setImmediate(() => this._processResponse());
      }
      let action = this._responseActions.shift();
      if (typeof action === "function") {
        action.call(this, str);
        setImmediate(() => this._processResponse());
      } else {
        return this._onError(new Error("Unexpected Response"), "EPROTOCOL", str, "CONN");
      }
    }
    _sendCommand(str, logStr) {
      if (this._destroyed) {
        return;
      }
      if (this._socket.destroyed) {
        return this.close();
      }
      if (this.options.debug || this.options.transactionLog) {
        this.logger.debug({
          tnx: "client"
        }, (logStr || str || "").toString().replace(/\r?\n$/, ""));
      }
      this._socket.write(Buffer.from(str + "\r\n", "utf-8"));
    }
    _setEnvelope(envelope, callback) {
      let args = [];
      let useSmtpUtf8 = false;
      this._envelope = envelope || {};
      this._envelope.from = (this._envelope.from && this._envelope.from.address || this._envelope.from || "").toString().trim();
      this._envelope.to = [].concat(this._envelope.to || []).map((to) => (to && to.address || to || "").toString().trim());
      if (!this._envelope.to.length) {
        return callback(this._formatError("No recipients defined", "EENVELOPE", false, "API"));
      }
      if (this._envelope.from && /[\r\n<>]/.test(this._envelope.from)) {
        return callback(this._formatError("Invalid sender " + JSON.stringify(this._envelope.from), "EENVELOPE", false, "API"));
      }
      if (/[\x80-\uFFFF]/.test(this._envelope.from)) {
        useSmtpUtf8 = true;
      }
      for (let i = 0, len = this._envelope.to.length;i < len; i++) {
        if (!this._envelope.to[i] || /[\r\n<>]/.test(this._envelope.to[i])) {
          return callback(this._formatError("Invalid recipient " + JSON.stringify(this._envelope.to[i]), "EENVELOPE", false, "API"));
        }
        if (/[\x80-\uFFFF]/.test(this._envelope.to[i])) {
          useSmtpUtf8 = true;
        }
      }
      this._envelope.rcptQueue = JSON.parse(JSON.stringify(this._envelope.to || []));
      this._envelope.rejected = [];
      this._envelope.rejectedErrors = [];
      this._envelope.accepted = [];
      if (this._envelope.dsn) {
        try {
          this._envelope.dsn = this._setDsnEnvelope(this._envelope.dsn);
        } catch (err) {
          return callback(this._formatError("Invalid DSN " + err.message, "EENVELOPE", false, "API"));
        }
      }
      this._responseActions.push((str) => {
        this._actionMAIL(str, callback);
      });
      if (useSmtpUtf8 && this._supportedExtensions.includes("SMTPUTF8")) {
        args.push("SMTPUTF8");
        this._usingSmtpUtf8 = true;
      }
      if (this._envelope.use8BitMime && this._supportedExtensions.includes("8BITMIME")) {
        args.push("BODY=8BITMIME");
        this._using8BitMime = true;
      }
      if (this._envelope.size && this._supportedExtensions.includes("SIZE")) {
        args.push("SIZE=" + this._envelope.size);
      }
      if (this._envelope.dsn && this._supportedExtensions.includes("DSN")) {
        if (this._envelope.dsn.ret) {
          args.push("RET=" + shared.encodeXText(this._envelope.dsn.ret));
        }
        if (this._envelope.dsn.envid) {
          args.push("ENVID=" + shared.encodeXText(this._envelope.dsn.envid));
        }
      }
      this._sendCommand("MAIL FROM:<" + this._envelope.from + ">" + (args.length ? " " + args.join(" ") : ""));
    }
    _setDsnEnvelope(params) {
      let ret = (params.ret || params.return || "").toString().toUpperCase() || null;
      if (ret) {
        switch (ret) {
          case "HDRS":
          case "HEADERS":
            ret = "HDRS";
            break;
          case "FULL":
          case "BODY":
            ret = "FULL";
            break;
        }
      }
      if (ret && !["FULL", "HDRS"].includes(ret)) {
        throw new Error("ret: " + JSON.stringify(ret));
      }
      let envid = (params.envid || params.id || "").toString() || null;
      let notify = params.notify || null;
      if (notify) {
        if (typeof notify === "string") {
          notify = notify.split(",");
        }
        notify = notify.map((n) => n.trim().toUpperCase());
        let validNotify = ["NEVER", "SUCCESS", "FAILURE", "DELAY"];
        let invaliNotify = notify.filter((n) => !validNotify.includes(n));
        if (invaliNotify.length || notify.length > 1 && notify.includes("NEVER")) {
          throw new Error("notify: " + JSON.stringify(notify.join(",")));
        }
        notify = notify.join(",");
      }
      let orcpt = (params.recipient || params.orcpt || "").toString() || null;
      if (orcpt && orcpt.indexOf(";") < 0) {
        orcpt = "rfc822;" + orcpt;
      }
      return {
        ret,
        envid,
        notify,
        orcpt
      };
    }
    _getDsnRcptToArgs() {
      let args = [];
      if (this._envelope.dsn && this._supportedExtensions.includes("DSN")) {
        if (this._envelope.dsn.notify) {
          args.push("NOTIFY=" + shared.encodeXText(this._envelope.dsn.notify));
        }
        if (this._envelope.dsn.orcpt) {
          args.push("ORCPT=" + shared.encodeXText(this._envelope.dsn.orcpt));
        }
      }
      return args.length ? " " + args.join(" ") : "";
    }
    _createSendStream(callback) {
      let dataStream = new DataStream;
      let logStream;
      if (this.options.lmtp) {
        this._envelope.accepted.forEach((recipient, i) => {
          let final = i === this._envelope.accepted.length - 1;
          this._responseActions.push((str) => {
            this._actionLMTPStream(recipient, final, str, callback);
          });
        });
      } else {
        this._responseActions.push((str) => {
          this._actionSMTPStream(str, callback);
        });
      }
      dataStream.pipe(this._socket, {
        end: false
      });
      if (this.options.debug) {
        logStream = new PassThrough;
        logStream.on("readable", () => {
          let chunk;
          while (chunk = logStream.read()) {
            this.logger.debug({
              tnx: "message"
            }, chunk.toString("binary").replace(/\r?\n$/, ""));
          }
        });
        dataStream.pipe(logStream);
      }
      dataStream.once("end", () => {
        this.logger.info({
          tnx: "message",
          inByteCount: dataStream.inByteCount,
          outByteCount: dataStream.outByteCount
        }, "<%s bytes encoded mime message (source size %s bytes)>", dataStream.outByteCount, dataStream.inByteCount);
      });
      return dataStream;
    }
    _actionGreeting(str) {
      clearTimeout(this._greetingTimeout);
      if (str.substr(0, 3) !== "220") {
        this._onError(new Error("Invalid greeting. response=" + str), "EPROTOCOL", str, "CONN");
        return;
      }
      if (this.options.lmtp) {
        this._responseActions.push(this._actionLHLO);
        this._sendCommand("LHLO " + this.name);
      } else {
        this._responseActions.push(this._actionEHLO);
        this._sendCommand("EHLO " + this.name);
      }
    }
    _actionLHLO(str) {
      if (str.charAt(0) !== "2") {
        this._onError(new Error("Invalid LHLO. response=" + str), "EPROTOCOL", str, "LHLO");
        return;
      }
      this._actionEHLO(str);
    }
    _actionEHLO(str) {
      let match;
      if (str.substr(0, 3) === "421") {
        this._onError(new Error("Server terminates connection. response=" + str), "ECONNECTION", str, "EHLO");
        return;
      }
      if (str.charAt(0) !== "2") {
        if (this.options.requireTLS) {
          this._onError(new Error("EHLO failed but HELO does not support required STARTTLS. response=" + str), "ECONNECTION", str, "EHLO");
          return;
        }
        this._responseActions.push(this._actionHELO);
        this._sendCommand("HELO " + this.name);
        return;
      }
      this._ehloLines = str.split(/\r?\n/).map((line) => line.replace(/^\d+[ -]/, "").trim()).filter((line) => line).slice(1);
      if (!this.secure && !this.options.ignoreTLS && (/[ -]STARTTLS\b/im.test(str) || this.options.requireTLS)) {
        this._sendCommand("STARTTLS");
        this._responseActions.push(this._actionSTARTTLS);
        return;
      }
      if (/[ -]SMTPUTF8\b/im.test(str)) {
        this._supportedExtensions.push("SMTPUTF8");
      }
      if (/[ -]DSN\b/im.test(str)) {
        this._supportedExtensions.push("DSN");
      }
      if (/[ -]8BITMIME\b/im.test(str)) {
        this._supportedExtensions.push("8BITMIME");
      }
      if (/[ -]PIPELINING\b/im.test(str)) {
        this._supportedExtensions.push("PIPELINING");
      }
      if (/[ -]AUTH\b/i.test(str)) {
        this.allowsAuth = true;
      }
      if (/[ -]AUTH(?:(\s+|=)[^\n]*\s+|\s+|=)PLAIN/i.test(str)) {
        this._supportedAuth.push("PLAIN");
      }
      if (/[ -]AUTH(?:(\s+|=)[^\n]*\s+|\s+|=)LOGIN/i.test(str)) {
        this._supportedAuth.push("LOGIN");
      }
      if (/[ -]AUTH(?:(\s+|=)[^\n]*\s+|\s+|=)CRAM-MD5/i.test(str)) {
        this._supportedAuth.push("CRAM-MD5");
      }
      if (/[ -]AUTH(?:(\s+|=)[^\n]*\s+|\s+|=)XOAUTH2/i.test(str)) {
        this._supportedAuth.push("XOAUTH2");
      }
      if (match = str.match(/[ -]SIZE(?:[ \t]+(\d+))?/im)) {
        this._supportedExtensions.push("SIZE");
        this._maxAllowedSize = Number(match[1]) || 0;
      }
      this.emit("connect");
    }
    _actionHELO(str) {
      if (str.charAt(0) !== "2") {
        this._onError(new Error("Invalid HELO. response=" + str), "EPROTOCOL", str, "HELO");
        return;
      }
      this.allowsAuth = true;
      this.emit("connect");
    }
    _actionSTARTTLS(str) {
      if (str.charAt(0) !== "2") {
        if (this.options.opportunisticTLS) {
          this.logger.info({
            tnx: "smtp"
          }, "Failed STARTTLS upgrade, continuing unencrypted");
          return this.emit("connect");
        }
        this._onError(new Error("Error upgrading connection with STARTTLS"), "ETLS", str, "STARTTLS");
        return;
      }
      this._upgradeConnection((err, secured) => {
        if (err) {
          this._onError(new Error("Error initiating TLS - " + (err.message || err)), "ETLS", false, "STARTTLS");
          return;
        }
        this.logger.info({
          tnx: "smtp"
        }, "Connection upgraded with STARTTLS");
        if (secured) {
          if (this.options.lmtp) {
            this._responseActions.push(this._actionLHLO);
            this._sendCommand("LHLO " + this.name);
          } else {
            this._responseActions.push(this._actionEHLO);
            this._sendCommand("EHLO " + this.name);
          }
        } else {
          this.emit("connect");
        }
      });
    }
    _actionAUTH_LOGIN_USER(str, callback) {
      if (!/^334[ -]/.test(str)) {
        callback(this._formatError('Invalid login sequence while waiting for "334 VXNlcm5hbWU6"', "EAUTH", str, "AUTH LOGIN"));
        return;
      }
      this._responseActions.push((str2) => {
        this._actionAUTH_LOGIN_PASS(str2, callback);
      });
      this._sendCommand(Buffer.from(this._auth.credentials.user + "", "utf-8").toString("base64"));
    }
    _actionAUTH_CRAM_MD5(str, callback) {
      let challengeMatch = str.match(/^334\s+(.+)$/);
      let challengeString = "";
      if (!challengeMatch) {
        return callback(this._formatError("Invalid login sequence while waiting for server challenge string", "EAUTH", str, "AUTH CRAM-MD5"));
      } else {
        challengeString = challengeMatch[1];
      }
      let base64decoded = Buffer.from(challengeString, "base64").toString("ascii"), hmacMD5 = crypto2.createHmac("md5", this._auth.credentials.pass);
      hmacMD5.update(base64decoded);
      let prepended = this._auth.credentials.user + " " + hmacMD5.digest("hex");
      this._responseActions.push((str2) => {
        this._actionAUTH_CRAM_MD5_PASS(str2, callback);
      });
      this._sendCommand(Buffer.from(prepended).toString("base64"), Buffer.from(this._auth.credentials.user + " /* secret */").toString("base64"));
    }
    _actionAUTH_CRAM_MD5_PASS(str, callback) {
      if (!str.match(/^235\s+/)) {
        return callback(this._formatError('Invalid login sequence while waiting for "235"', "EAUTH", str, "AUTH CRAM-MD5"));
      }
      this.logger.info({
        tnx: "smtp",
        username: this._auth.user,
        action: "authenticated",
        method: this._authMethod
      }, "User %s authenticated", JSON.stringify(this._auth.user));
      this.authenticated = true;
      callback(null, true);
    }
    _actionAUTH_LOGIN_PASS(str, callback) {
      if (!/^334[ -]/.test(str)) {
        return callback(this._formatError('Invalid login sequence while waiting for "334 UGFzc3dvcmQ6"', "EAUTH", str, "AUTH LOGIN"));
      }
      this._responseActions.push((str2) => {
        this._actionAUTHComplete(str2, callback);
      });
      this._sendCommand(Buffer.from((this._auth.credentials.pass || "").toString(), "utf-8").toString("base64"), Buffer.from("/* secret */", "utf-8").toString("base64"));
    }
    _actionAUTHComplete(str, isRetry, callback) {
      if (!callback && typeof isRetry === "function") {
        callback = isRetry;
        isRetry = false;
      }
      if (str.substr(0, 3) === "334") {
        this._responseActions.push((str2) => {
          if (isRetry || this._authMethod !== "XOAUTH2") {
            this._actionAUTHComplete(str2, true, callback);
          } else {
            setImmediate(() => this._handleXOauth2Token(true, callback));
          }
        });
        this._sendCommand("");
        return;
      }
      if (str.charAt(0) !== "2") {
        this.logger.info({
          tnx: "smtp",
          username: this._auth.user,
          action: "authfail",
          method: this._authMethod
        }, "User %s failed to authenticate", JSON.stringify(this._auth.user));
        return callback(this._formatError("Invalid login", "EAUTH", str, "AUTH " + this._authMethod));
      }
      this.logger.info({
        tnx: "smtp",
        username: this._auth.user,
        action: "authenticated",
        method: this._authMethod
      }, "User %s authenticated", JSON.stringify(this._auth.user));
      this.authenticated = true;
      callback(null, true);
    }
    _actionMAIL(str, callback) {
      let message, curRecipient;
      if (Number(str.charAt(0)) !== 2) {
        if (this._usingSmtpUtf8 && /^550 /.test(str) && /[\x80-\uFFFF]/.test(this._envelope.from)) {
          message = "Internationalized mailbox name not allowed";
        } else {
          message = "Mail command failed";
        }
        return callback(this._formatError(message, "EENVELOPE", str, "MAIL FROM"));
      }
      if (!this._envelope.rcptQueue.length) {
        return callback(this._formatError("Can't send mail - no recipients defined", "EENVELOPE", false, "API"));
      } else {
        this._recipientQueue = [];
        if (this._supportedExtensions.includes("PIPELINING")) {
          while (this._envelope.rcptQueue.length) {
            curRecipient = this._envelope.rcptQueue.shift();
            this._recipientQueue.push(curRecipient);
            this._responseActions.push((str2) => {
              this._actionRCPT(str2, callback);
            });
            this._sendCommand("RCPT TO:<" + curRecipient + ">" + this._getDsnRcptToArgs());
          }
        } else {
          curRecipient = this._envelope.rcptQueue.shift();
          this._recipientQueue.push(curRecipient);
          this._responseActions.push((str2) => {
            this._actionRCPT(str2, callback);
          });
          this._sendCommand("RCPT TO:<" + curRecipient + ">" + this._getDsnRcptToArgs());
        }
      }
    }
    _actionRCPT(str, callback) {
      let message, err, curRecipient = this._recipientQueue.shift();
      if (Number(str.charAt(0)) !== 2) {
        if (this._usingSmtpUtf8 && /^553 /.test(str) && /[\x80-\uFFFF]/.test(curRecipient)) {
          message = "Internationalized mailbox name not allowed";
        } else {
          message = "Recipient command failed";
        }
        this._envelope.rejected.push(curRecipient);
        err = this._formatError(message, "EENVELOPE", str, "RCPT TO");
        err.recipient = curRecipient;
        this._envelope.rejectedErrors.push(err);
      } else {
        this._envelope.accepted.push(curRecipient);
      }
      if (!this._envelope.rcptQueue.length && !this._recipientQueue.length) {
        if (this._envelope.rejected.length < this._envelope.to.length) {
          this._responseActions.push((str2) => {
            this._actionDATA(str2, callback);
          });
          this._sendCommand("DATA");
        } else {
          err = this._formatError("Can't send mail - all recipients were rejected", "EENVELOPE", str, "RCPT TO");
          err.rejected = this._envelope.rejected;
          err.rejectedErrors = this._envelope.rejectedErrors;
          return callback(err);
        }
      } else if (this._envelope.rcptQueue.length) {
        curRecipient = this._envelope.rcptQueue.shift();
        this._recipientQueue.push(curRecipient);
        this._responseActions.push((str2) => {
          this._actionRCPT(str2, callback);
        });
        this._sendCommand("RCPT TO:<" + curRecipient + ">" + this._getDsnRcptToArgs());
      }
    }
    _actionDATA(str, callback) {
      if (!/^[23]/.test(str)) {
        return callback(this._formatError("Data command failed", "EENVELOPE", str, "DATA"));
      }
      let response = {
        accepted: this._envelope.accepted,
        rejected: this._envelope.rejected
      };
      if (this._ehloLines && this._ehloLines.length) {
        response.ehlo = this._ehloLines;
      }
      if (this._envelope.rejectedErrors.length) {
        response.rejectedErrors = this._envelope.rejectedErrors;
      }
      callback(null, response);
    }
    _actionSMTPStream(str, callback) {
      if (Number(str.charAt(0)) !== 2) {
        return callback(this._formatError("Message failed", "EMESSAGE", str, "DATA"));
      } else {
        return callback(null, str);
      }
    }
    _actionLMTPStream(recipient, final, str, callback) {
      let err;
      if (Number(str.charAt(0)) !== 2) {
        err = this._formatError("Message failed for recipient " + recipient, "EMESSAGE", str, "DATA");
        err.recipient = recipient;
        this._envelope.rejected.push(recipient);
        this._envelope.rejectedErrors.push(err);
        for (let i = 0, len = this._envelope.accepted.length;i < len; i++) {
          if (this._envelope.accepted[i] === recipient) {
            this._envelope.accepted.splice(i, 1);
          }
        }
      }
      if (final) {
        return callback(null, str);
      }
    }
    _handleXOauth2Token(isRetry, callback) {
      this._auth.oauth2.getToken(isRetry, (err, accessToken) => {
        if (err) {
          this.logger.info({
            tnx: "smtp",
            username: this._auth.user,
            action: "authfail",
            method: this._authMethod
          }, "User %s failed to authenticate", JSON.stringify(this._auth.user));
          return callback(this._formatError(err, "EAUTH", false, "AUTH XOAUTH2"));
        }
        this._responseActions.push((str) => {
          this._actionAUTHComplete(str, isRetry, callback);
        });
        this._sendCommand("AUTH XOAUTH2 " + this._auth.oauth2.buildXOAuth2Token(accessToken), "AUTH XOAUTH2 " + this._auth.oauth2.buildXOAuth2Token("/* secret */"));
      });
    }
    _isDestroyedMessage(command) {
      if (this._destroyed) {
        return "Cannot " + command + " - smtp connection is already destroyed.";
      }
      if (this._socket) {
        if (this._socket.destroyed) {
          return "Cannot " + command + " - smtp connection socket is already destroyed.";
        }
        if (!this._socket.writable) {
          return "Cannot " + command + " - smtp connection socket is already half-closed.";
        }
      }
    }
    _getHostname() {
      let defaultHostname;
      try {
        defaultHostname = os.hostname() || "";
      } catch (err) {
        defaultHostname = "localhost";
      }
      if (!defaultHostname || defaultHostname.indexOf(".") < 0) {
        defaultHostname = "[127.0.0.1]";
      }
      if (defaultHostname.match(/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/)) {
        defaultHostname = "[" + defaultHostname + "]";
      }
      return defaultHostname;
    }
  }
  module.exports = SMTPConnection;
});

// node_modules/nodemailer/lib/xoauth2/index.js
var require_xoauth2 = __commonJS((exports, module) => {
  var Stream = import.meta.require("stream").Stream;
  var nmfetch = require_fetch();
  var crypto2 = import.meta.require("crypto");
  var shared = require_shared();

  class XOAuth2 extends Stream {
    constructor(options, logger3) {
      super();
      this.options = options || {};
      if (options && options.serviceClient) {
        if (!options.privateKey || !options.user) {
          setImmediate(() => this.emit("error", new Error('Options "privateKey" and "user" are required for service account!')));
          return;
        }
        let serviceRequestTimeout = Math.min(Math.max(Number(this.options.serviceRequestTimeout) || 0, 0), 3600);
        this.options.serviceRequestTimeout = serviceRequestTimeout || 5 * 60;
      }
      this.logger = shared.getLogger({
        logger: logger3
      }, {
        component: this.options.component || "OAuth2"
      });
      this.provisionCallback = typeof this.options.provisionCallback === "function" ? this.options.provisionCallback : false;
      this.options.accessUrl = this.options.accessUrl || "https://accounts.google.com/o/oauth2/token";
      this.options.customHeaders = this.options.customHeaders || {};
      this.options.customParams = this.options.customParams || {};
      this.accessToken = this.options.accessToken || false;
      if (this.options.expires && Number(this.options.expires)) {
        this.expires = this.options.expires;
      } else {
        let timeout = Math.max(Number(this.options.timeout) || 0, 0);
        this.expires = timeout && Date.now() + timeout * 1000 || 0;
      }
    }
    getToken(renew, callback) {
      if (!renew && this.accessToken && (!this.expires || this.expires > Date.now())) {
        return callback(null, this.accessToken);
      }
      let generateCallback = (...args) => {
        if (args[0]) {
          this.logger.error({
            err: args[0],
            tnx: "OAUTH2",
            user: this.options.user,
            action: "renew"
          }, "Failed generating new Access Token for %s", this.options.user);
        } else {
          this.logger.info({
            tnx: "OAUTH2",
            user: this.options.user,
            action: "renew"
          }, "Generated new Access Token for %s", this.options.user);
        }
        callback(...args);
      };
      if (this.provisionCallback) {
        this.provisionCallback(this.options.user, !!renew, (err, accessToken, expires) => {
          if (!err && accessToken) {
            this.accessToken = accessToken;
            this.expires = expires || 0;
          }
          generateCallback(err, accessToken);
        });
      } else {
        this.generateToken(generateCallback);
      }
    }
    updateToken(accessToken, timeout) {
      this.accessToken = accessToken;
      timeout = Math.max(Number(timeout) || 0, 0);
      this.expires = timeout && Date.now() + timeout * 1000 || 0;
      this.emit("token", {
        user: this.options.user,
        accessToken: accessToken || "",
        expires: this.expires
      });
    }
    generateToken(callback) {
      let urlOptions;
      let loggedUrlOptions;
      if (this.options.serviceClient) {
        let iat = Math.floor(Date.now() / 1000);
        let tokenData = {
          iss: this.options.serviceClient,
          scope: this.options.scope || "https://mail.google.com/",
          sub: this.options.user,
          aud: this.options.accessUrl,
          iat,
          exp: iat + this.options.serviceRequestTimeout
        };
        let token;
        try {
          token = this.jwtSignRS256(tokenData);
        } catch (err) {
          return callback(new Error("Can't generate token. Check your auth options"));
        }
        urlOptions = {
          grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
          assertion: token
        };
        loggedUrlOptions = {
          grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
          assertion: tokenData
        };
      } else {
        if (!this.options.refreshToken) {
          return callback(new Error("Can't create new access token for user"));
        }
        urlOptions = {
          client_id: this.options.clientId || "",
          client_secret: this.options.clientSecret || "",
          refresh_token: this.options.refreshToken,
          grant_type: "refresh_token"
        };
        loggedUrlOptions = {
          client_id: this.options.clientId || "",
          client_secret: (this.options.clientSecret || "").substr(0, 6) + "...",
          refresh_token: (this.options.refreshToken || "").substr(0, 6) + "...",
          grant_type: "refresh_token"
        };
      }
      Object.keys(this.options.customParams).forEach((key) => {
        urlOptions[key] = this.options.customParams[key];
        loggedUrlOptions[key] = this.options.customParams[key];
      });
      this.logger.debug({
        tnx: "OAUTH2",
        user: this.options.user,
        action: "generate"
      }, "Requesting token using: %s", JSON.stringify(loggedUrlOptions));
      this.postRequest(this.options.accessUrl, urlOptions, this.options, (error, body) => {
        let data;
        if (error) {
          return callback(error);
        }
        try {
          data = JSON.parse(body.toString());
        } catch (E) {
          return callback(E);
        }
        if (!data || typeof data !== "object") {
          this.logger.debug({
            tnx: "OAUTH2",
            user: this.options.user,
            action: "post"
          }, "Response: %s", (body || "").toString());
          return callback(new Error("Invalid authentication response"));
        }
        let logData = {};
        Object.keys(data).forEach((key) => {
          if (key !== "access_token") {
            logData[key] = data[key];
          } else {
            logData[key] = (data[key] || "").toString().substr(0, 6) + "...";
          }
        });
        this.logger.debug({
          tnx: "OAUTH2",
          user: this.options.user,
          action: "post"
        }, "Response: %s", JSON.stringify(logData));
        if (data.error) {
          let errorMessage = data.error;
          if (data.error_description) {
            errorMessage += ": " + data.error_description;
          }
          if (data.error_uri) {
            errorMessage += " (" + data.error_uri + ")";
          }
          return callback(new Error(errorMessage));
        }
        if (data.access_token) {
          this.updateToken(data.access_token, data.expires_in);
          return callback(null, this.accessToken);
        }
        return callback(new Error("No access token"));
      });
    }
    buildXOAuth2Token(accessToken) {
      let authData = ["user=" + (this.options.user || ""), "auth=Bearer " + (accessToken || this.accessToken), "", ""];
      return Buffer.from(authData.join("\x01"), "utf-8").toString("base64");
    }
    postRequest(url, payload, params, callback) {
      let returned = false;
      let chunks = [];
      let chunklen = 0;
      let req = nmfetch(url, {
        method: "post",
        headers: params.customHeaders,
        body: payload,
        allowErrorResponse: true
      });
      req.on("readable", () => {
        let chunk;
        while ((chunk = req.read()) !== null) {
          chunks.push(chunk);
          chunklen += chunk.length;
        }
      });
      req.once("error", (err) => {
        if (returned) {
          return;
        }
        returned = true;
        return callback(err);
      });
      req.once("end", () => {
        if (returned) {
          return;
        }
        returned = true;
        return callback(null, Buffer.concat(chunks, chunklen));
      });
    }
    toBase64URL(data) {
      if (typeof data === "string") {
        data = Buffer.from(data);
      }
      return data.toString("base64").replace(/[=]+/g, "").replace(/\+/g, "-").replace(/\//g, "_");
    }
    jwtSignRS256(payload) {
      payload = ['{"alg":"RS256","typ":"JWT"}', JSON.stringify(payload)].map((val) => this.toBase64URL(val)).join(".");
      let signature = crypto2.createSign("RSA-SHA256").update(payload).sign(this.options.privateKey);
      return payload + "." + this.toBase64URL(signature);
    }
  }
  module.exports = XOAuth2;
});

// node_modules/nodemailer/lib/smtp-pool/pool-resource.js
var require_pool_resource = __commonJS((exports, module) => {
  var SMTPConnection = require_smtp_connection();
  var assign = require_shared().assign;
  var XOAuth2 = require_xoauth2();
  var EventEmitter = import.meta.require("events");

  class PoolResource extends EventEmitter {
    constructor(pool) {
      super();
      this.pool = pool;
      this.options = pool.options;
      this.logger = this.pool.logger;
      if (this.options.auth) {
        switch ((this.options.auth.type || "").toString().toUpperCase()) {
          case "OAUTH2": {
            let oauth2 = new XOAuth2(this.options.auth, this.logger);
            oauth2.provisionCallback = this.pool.mailer && this.pool.mailer.get("oauth2_provision_cb") || oauth2.provisionCallback;
            this.auth = {
              type: "OAUTH2",
              user: this.options.auth.user,
              oauth2,
              method: "XOAUTH2"
            };
            oauth2.on("token", (token) => this.pool.mailer.emit("token", token));
            oauth2.on("error", (err) => this.emit("error", err));
            break;
          }
          default:
            if (!this.options.auth.user && !this.options.auth.pass) {
              break;
            }
            this.auth = {
              type: (this.options.auth.type || "").toString().toUpperCase() || "LOGIN",
              user: this.options.auth.user,
              credentials: {
                user: this.options.auth.user || "",
                pass: this.options.auth.pass,
                options: this.options.auth.options
              },
              method: (this.options.auth.method || "").trim().toUpperCase() || this.options.authMethod || false
            };
        }
      }
      this._connection = false;
      this._connected = false;
      this.messages = 0;
      this.available = true;
    }
    connect(callback) {
      this.pool.getSocket(this.options, (err, socketOptions) => {
        if (err) {
          return callback(err);
        }
        let returned = false;
        let options = this.options;
        if (socketOptions && socketOptions.connection) {
          this.logger.info({
            tnx: "proxy",
            remoteAddress: socketOptions.connection.remoteAddress,
            remotePort: socketOptions.connection.remotePort,
            destHost: options.host || "",
            destPort: options.port || "",
            action: "connected"
          }, "Using proxied socket from %s:%s to %s:%s", socketOptions.connection.remoteAddress, socketOptions.connection.remotePort, options.host || "", options.port || "");
          options = assign(false, options);
          Object.keys(socketOptions).forEach((key) => {
            options[key] = socketOptions[key];
          });
        }
        this.connection = new SMTPConnection(options);
        this.connection.once("error", (err2) => {
          this.emit("error", err2);
          if (returned) {
            return;
          }
          returned = true;
          return callback(err2);
        });
        this.connection.once("end", () => {
          this.close();
          if (returned) {
            return;
          }
          returned = true;
          let timer = setTimeout(() => {
            if (returned) {
              return;
            }
            let err2 = new Error("Unexpected socket close");
            if (this.connection && this.connection._socket && this.connection._socket.upgrading) {
              err2.code = "ETLS";
            }
            callback(err2);
          }, 1000);
          try {
            timer.unref();
          } catch (E) {
          }
        });
        this.connection.connect(() => {
          if (returned) {
            return;
          }
          if (this.auth && (this.connection.allowsAuth || options.forceAuth)) {
            this.connection.login(this.auth, (err2) => {
              if (returned) {
                return;
              }
              returned = true;
              if (err2) {
                this.connection.close();
                this.emit("error", err2);
                return callback(err2);
              }
              this._connected = true;
              callback(null, true);
            });
          } else {
            returned = true;
            this._connected = true;
            return callback(null, true);
          }
        });
      });
    }
    send(mail, callback) {
      if (!this._connected) {
        return this.connect((err) => {
          if (err) {
            return callback(err);
          }
          return this.send(mail, callback);
        });
      }
      let envelope = mail.message.getEnvelope();
      let messageId = mail.message.messageId();
      let recipients = [].concat(envelope.to || []);
      if (recipients.length > 3) {
        recipients.push("...and " + recipients.splice(2).length + " more");
      }
      this.logger.info({
        tnx: "send",
        messageId,
        cid: this.id
      }, "Sending message %s using #%s to <%s>", messageId, this.id, recipients.join(", "));
      if (mail.data.dsn) {
        envelope.dsn = mail.data.dsn;
      }
      this.connection.send(envelope, mail.message.createReadStream(), (err, info) => {
        this.messages++;
        if (err) {
          this.connection.close();
          this.emit("error", err);
          return callback(err);
        }
        info.envelope = {
          from: envelope.from,
          to: envelope.to
        };
        info.messageId = messageId;
        setImmediate(() => {
          let err2;
          if (this.messages >= this.options.maxMessages) {
            err2 = new Error("Resource exhausted");
            err2.code = "EMAXLIMIT";
            this.connection.close();
            this.emit("error", err2);
          } else {
            this.pool._checkRateLimit(() => {
              this.available = true;
              this.emit("available");
            });
          }
        });
        callback(null, info);
      });
    }
    close() {
      this._connected = false;
      if (this.auth && this.auth.oauth2) {
        this.auth.oauth2.removeAllListeners();
      }
      if (this.connection) {
        this.connection.close();
      }
      this.emit("close");
    }
  }
  module.exports = PoolResource;
});

// node_modules/nodemailer/lib/well-known/services.json
var require_services = __commonJS((exports, module) => {
  module.exports = {
    "1und1": {
      host: "smtp.1und1.de",
      port: 465,
      secure: true,
      authMethod: "LOGIN"
    },
    Aliyun: {
      domains: ["aliyun.com"],
      host: "smtp.aliyun.com",
      port: 465,
      secure: true
    },
    AOL: {
      domains: ["aol.com"],
      host: "smtp.aol.com",
      port: 587
    },
    Bluewin: {
      host: "smtpauths.bluewin.ch",
      domains: ["bluewin.ch"],
      port: 465
    },
    DebugMail: {
      host: "debugmail.io",
      port: 25
    },
    DynectEmail: {
      aliases: ["Dynect"],
      host: "smtp.dynect.net",
      port: 25
    },
    Ethereal: {
      aliases: ["ethereal.email"],
      host: "smtp.ethereal.email",
      port: 587
    },
    FastMail: {
      domains: ["fastmail.fm"],
      host: "smtp.fastmail.com",
      port: 465,
      secure: true
    },
    "Forward Email": {
      aliases: ["FE", "ForwardEmail"],
      domains: ["forwardemail.net"],
      host: "smtp.forwardemail.net",
      port: 465,
      secure: true
    },
    "Feishu Mail": {
      aliases: ["Feishu", "FeishuMail"],
      domains: ["www.feishu.cn"],
      host: "smtp.feishu.cn",
      port: 465,
      secure: true
    },
    GandiMail: {
      aliases: ["Gandi", "Gandi Mail"],
      host: "mail.gandi.net",
      port: 587
    },
    Gmail: {
      aliases: ["Google Mail"],
      domains: ["gmail.com", "googlemail.com"],
      host: "smtp.gmail.com",
      port: 465,
      secure: true
    },
    Godaddy: {
      host: "smtpout.secureserver.net",
      port: 25
    },
    GodaddyAsia: {
      host: "smtp.asia.secureserver.net",
      port: 25
    },
    GodaddyEurope: {
      host: "smtp.europe.secureserver.net",
      port: 25
    },
    "hot.ee": {
      host: "mail.hot.ee"
    },
    Hotmail: {
      aliases: ["Outlook", "Outlook.com", "Hotmail.com"],
      domains: ["hotmail.com", "outlook.com"],
      host: "smtp-mail.outlook.com",
      port: 587
    },
    iCloud: {
      aliases: ["Me", "Mac"],
      domains: ["me.com", "mac.com"],
      host: "smtp.mail.me.com",
      port: 587
    },
    Infomaniak: {
      host: "mail.infomaniak.com",
      domains: ["ik.me", "ikmail.com", "etik.com"],
      port: 587
    },
    Loopia: {
      host: "mailcluster.loopia.se",
      port: 465
    },
    "mail.ee": {
      host: "smtp.mail.ee"
    },
    "Mail.ru": {
      host: "smtp.mail.ru",
      port: 465,
      secure: true
    },
    "Mailcatch.app": {
      host: "sandbox-smtp.mailcatch.app",
      port: 2525
    },
    Maildev: {
      port: 1025,
      ignoreTLS: true
    },
    Mailgun: {
      host: "smtp.mailgun.org",
      port: 465,
      secure: true
    },
    Mailjet: {
      host: "in.mailjet.com",
      port: 587
    },
    Mailosaur: {
      host: "mailosaur.io",
      port: 25
    },
    Mailtrap: {
      host: "live.smtp.mailtrap.io",
      port: 587
    },
    Mandrill: {
      host: "smtp.mandrillapp.com",
      port: 587
    },
    Naver: {
      host: "smtp.naver.com",
      port: 587
    },
    One: {
      host: "send.one.com",
      port: 465,
      secure: true
    },
    OpenMailBox: {
      aliases: ["OMB", "openmailbox.org"],
      host: "smtp.openmailbox.org",
      port: 465,
      secure: true
    },
    Outlook365: {
      host: "smtp.office365.com",
      port: 587,
      secure: false
    },
    OhMySMTP: {
      host: "smtp.ohmysmtp.com",
      port: 587,
      secure: false
    },
    Postmark: {
      aliases: ["PostmarkApp"],
      host: "smtp.postmarkapp.com",
      port: 2525
    },
    "qiye.aliyun": {
      host: "smtp.mxhichina.com",
      port: "465",
      secure: true
    },
    QQ: {
      domains: ["qq.com"],
      host: "smtp.qq.com",
      port: 465,
      secure: true
    },
    QQex: {
      aliases: ["QQ Enterprise"],
      domains: ["exmail.qq.com"],
      host: "smtp.exmail.qq.com",
      port: 465,
      secure: true
    },
    SendCloud: {
      host: "smtp.sendcloud.net",
      port: 2525
    },
    SendGrid: {
      host: "smtp.sendgrid.net",
      port: 587
    },
    SendinBlue: {
      aliases: ["Brevo"],
      host: "smtp-relay.brevo.com",
      port: 587
    },
    SendPulse: {
      host: "smtp-pulse.com",
      port: 465,
      secure: true
    },
    SES: {
      host: "email-smtp.us-east-1.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-US-EAST-1": {
      host: "email-smtp.us-east-1.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-US-WEST-2": {
      host: "email-smtp.us-west-2.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-EU-WEST-1": {
      host: "email-smtp.eu-west-1.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-AP-SOUTH-1": {
      host: "email-smtp.ap-south-1.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-AP-NORTHEAST-1": {
      host: "email-smtp.ap-northeast-1.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-AP-NORTHEAST-2": {
      host: "email-smtp.ap-northeast-2.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-AP-NORTHEAST-3": {
      host: "email-smtp.ap-northeast-3.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-AP-SOUTHEAST-1": {
      host: "email-smtp.ap-southeast-1.amazonaws.com",
      port: 465,
      secure: true
    },
    "SES-AP-SOUTHEAST-2": {
      host: "email-smtp.ap-southeast-2.amazonaws.com",
      port: 465,
      secure: true
    },
    Sparkpost: {
      aliases: ["SparkPost", "SparkPost Mail"],
      domains: ["sparkpost.com"],
      host: "smtp.sparkpostmail.com",
      port: 587,
      secure: false
    },
    Tipimail: {
      host: "smtp.tipimail.com",
      port: 587
    },
    Yahoo: {
      domains: ["yahoo.com"],
      host: "smtp.mail.yahoo.com",
      port: 465,
      secure: true
    },
    Yandex: {
      domains: ["yandex.ru"],
      host: "smtp.yandex.ru",
      port: 465,
      secure: true
    },
    Zoho: {
      host: "smtp.zoho.com",
      port: 465,
      secure: true,
      authMethod: "LOGIN"
    },
    "126": {
      host: "smtp.126.com",
      port: 465,
      secure: true
    },
    "163": {
      host: "smtp.163.com",
      port: 465,
      secure: true
    }
  };
});

// node_modules/nodemailer/lib/well-known/index.js
var require_well_known = __commonJS((exports, module) => {
  var normalizeKey = function(key) {
    return key.replace(/[^a-zA-Z0-9.-]/g, "").toLowerCase();
  };
  var normalizeService = function(service) {
    let filter = ["domains", "aliases"];
    let response = {};
    Object.keys(service).forEach((key) => {
      if (filter.indexOf(key) < 0) {
        response[key] = service[key];
      }
    });
    return response;
  };
  var services = require_services();
  var normalized = {};
  Object.keys(services).forEach((key) => {
    let service = services[key];
    normalized[normalizeKey(key)] = normalizeService(service);
    [].concat(service.aliases || []).forEach((alias3) => {
      normalized[normalizeKey(alias3)] = normalizeService(service);
    });
    [].concat(service.domains || []).forEach((domain) => {
      normalized[normalizeKey(domain)] = normalizeService(service);
    });
  });
  module.exports = function(key) {
    key = normalizeKey(key.split("@").pop());
    return normalized[key] || false;
  };
});

// node_modules/nodemailer/lib/smtp-pool/index.js
var require_smtp_pool = __commonJS((exports, module) => {
  var EventEmitter = import.meta.require("events");
  var PoolResource = require_pool_resource();
  var SMTPConnection = require_smtp_connection();
  var wellKnown = require_well_known();
  var shared = require_shared();
  var packageData = require_package();

  class SMTPPool extends EventEmitter {
    constructor(options) {
      super();
      options = options || {};
      if (typeof options === "string") {
        options = {
          url: options
        };
      }
      let urlData;
      let service = options.service;
      if (typeof options.getSocket === "function") {
        this.getSocket = options.getSocket;
      }
      if (options.url) {
        urlData = shared.parseConnectionUrl(options.url);
        service = service || urlData.service;
      }
      this.options = shared.assign(false, options, urlData, service && wellKnown(service));
      this.options.maxConnections = this.options.maxConnections || 5;
      this.options.maxMessages = this.options.maxMessages || 100;
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "smtp-pool"
      });
      let connection = new SMTPConnection(this.options);
      this.name = "SMTP (pool)";
      this.version = packageData.version + "[client:" + connection.version + "]";
      this._rateLimit = {
        counter: 0,
        timeout: null,
        waiting: [],
        checkpoint: false,
        delta: Number(this.options.rateDelta) || 1000,
        limit: Number(this.options.rateLimit) || 0
      };
      this._closed = false;
      this._queue = [];
      this._connections = [];
      this._connectionCounter = 0;
      this.idling = true;
      setImmediate(() => {
        if (this.idling) {
          this.emit("idle");
        }
      });
    }
    getSocket(options, callback) {
      return setImmediate(() => callback(null, false));
    }
    send(mail, callback) {
      if (this._closed) {
        return false;
      }
      this._queue.push({
        mail,
        requeueAttempts: 0,
        callback
      });
      if (this.idling && this._queue.length >= this.options.maxConnections) {
        this.idling = false;
      }
      setImmediate(() => this._processMessages());
      return true;
    }
    close() {
      let connection;
      let len = this._connections.length;
      this._closed = true;
      clearTimeout(this._rateLimit.timeout);
      if (!len && !this._queue.length) {
        return;
      }
      for (let i = len - 1;i >= 0; i--) {
        if (this._connections[i] && this._connections[i].available) {
          connection = this._connections[i];
          connection.close();
          this.logger.info({
            tnx: "connection",
            cid: connection.id,
            action: "removed"
          }, "Connection #%s removed", connection.id);
        }
      }
      if (len && !this._connections.length) {
        this.logger.debug({
          tnx: "connection"
        }, "All connections removed");
      }
      if (!this._queue.length) {
        return;
      }
      let invokeCallbacks = () => {
        if (!this._queue.length) {
          this.logger.debug({
            tnx: "connection"
          }, "Pending queue entries cleared");
          return;
        }
        let entry = this._queue.shift();
        if (entry && typeof entry.callback === "function") {
          try {
            entry.callback(new Error("Connection pool was closed"));
          } catch (E) {
            this.logger.error({
              err: E,
              tnx: "callback",
              cid: connection.id
            }, "Callback error for #%s: %s", connection.id, E.message);
          }
        }
        setImmediate(invokeCallbacks);
      };
      setImmediate(invokeCallbacks);
    }
    _processMessages() {
      let connection;
      let i, len;
      if (this._closed) {
        return;
      }
      if (!this._queue.length) {
        if (!this.idling) {
          this.idling = true;
          this.emit("idle");
        }
        return;
      }
      for (i = 0, len = this._connections.length;i < len; i++) {
        if (this._connections[i].available) {
          connection = this._connections[i];
          break;
        }
      }
      if (!connection && this._connections.length < this.options.maxConnections) {
        connection = this._createConnection();
      }
      if (!connection) {
        this.idling = false;
        return;
      }
      if (!this.idling && this._queue.length < this.options.maxConnections) {
        this.idling = true;
        this.emit("idle");
      }
      let entry = connection.queueEntry = this._queue.shift();
      entry.messageId = (connection.queueEntry.mail.message.getHeader("message-id") || "").replace(/[<>\s]/g, "");
      connection.available = false;
      this.logger.debug({
        tnx: "pool",
        cid: connection.id,
        messageId: entry.messageId,
        action: "assign"
      }, "Assigned message <%s> to #%s (%s)", entry.messageId, connection.id, connection.messages + 1);
      if (this._rateLimit.limit) {
        this._rateLimit.counter++;
        if (!this._rateLimit.checkpoint) {
          this._rateLimit.checkpoint = Date.now();
        }
      }
      connection.send(entry.mail, (err, info) => {
        if (entry === connection.queueEntry) {
          try {
            entry.callback(err, info);
          } catch (E) {
            this.logger.error({
              err: E,
              tnx: "callback",
              cid: connection.id
            }, "Callback error for #%s: %s", connection.id, E.message);
          }
          connection.queueEntry = false;
        }
      });
    }
    _createConnection() {
      let connection = new PoolResource(this);
      connection.id = ++this._connectionCounter;
      this.logger.info({
        tnx: "pool",
        cid: connection.id,
        action: "conection"
      }, "Created new pool resource #%s", connection.id);
      connection.on("available", () => {
        this.logger.debug({
          tnx: "connection",
          cid: connection.id,
          action: "available"
        }, "Connection #%s became available", connection.id);
        if (this._closed) {
          this.close();
        } else {
          this._processMessages();
        }
      });
      connection.once("error", (err) => {
        if (err.code !== "EMAXLIMIT") {
          this.logger.error({
            err,
            tnx: "pool",
            cid: connection.id
          }, "Pool Error for #%s: %s", connection.id, err.message);
        } else {
          this.logger.debug({
            tnx: "pool",
            cid: connection.id,
            action: "maxlimit"
          }, "Max messages limit exchausted for #%s", connection.id);
        }
        if (connection.queueEntry) {
          try {
            connection.queueEntry.callback(err);
          } catch (E) {
            this.logger.error({
              err: E,
              tnx: "callback",
              cid: connection.id
            }, "Callback error for #%s: %s", connection.id, E.message);
          }
          connection.queueEntry = false;
        }
        this._removeConnection(connection);
        this._continueProcessing();
      });
      connection.once("close", () => {
        this.logger.info({
          tnx: "connection",
          cid: connection.id,
          action: "closed"
        }, "Connection #%s was closed", connection.id);
        this._removeConnection(connection);
        if (connection.queueEntry) {
          setTimeout(() => {
            if (connection.queueEntry) {
              if (this._shouldRequeuOnConnectionClose(connection.queueEntry)) {
                this._requeueEntryOnConnectionClose(connection);
              } else {
                this._failDeliveryOnConnectionClose(connection);
              }
            }
            this._continueProcessing();
          }, 50);
        } else {
          this._continueProcessing();
        }
      });
      this._connections.push(connection);
      return connection;
    }
    _shouldRequeuOnConnectionClose(queueEntry) {
      if (this.options.maxRequeues === undefined || this.options.maxRequeues < 0) {
        return true;
      }
      return queueEntry.requeueAttempts < this.options.maxRequeues;
    }
    _failDeliveryOnConnectionClose(connection) {
      if (connection.queueEntry && connection.queueEntry.callback) {
        try {
          connection.queueEntry.callback(new Error("Reached maximum number of retries after connection was closed"));
        } catch (E) {
          this.logger.error({
            err: E,
            tnx: "callback",
            messageId: connection.queueEntry.messageId,
            cid: connection.id
          }, "Callback error for #%s: %s", connection.id, E.message);
        }
        connection.queueEntry = false;
      }
    }
    _requeueEntryOnConnectionClose(connection) {
      connection.queueEntry.requeueAttempts = connection.queueEntry.requeueAttempts + 1;
      this.logger.debug({
        tnx: "pool",
        cid: connection.id,
        messageId: connection.queueEntry.messageId,
        action: "requeue"
      }, "Re-queued message <%s> for #%s. Attempt: #%s", connection.queueEntry.messageId, connection.id, connection.queueEntry.requeueAttempts);
      this._queue.unshift(connection.queueEntry);
      connection.queueEntry = false;
    }
    _continueProcessing() {
      if (this._closed) {
        this.close();
      } else {
        setTimeout(() => this._processMessages(), 100);
      }
    }
    _removeConnection(connection) {
      let index = this._connections.indexOf(connection);
      if (index !== -1) {
        this._connections.splice(index, 1);
      }
    }
    _checkRateLimit(callback) {
      if (!this._rateLimit.limit) {
        return callback();
      }
      let now = Date.now();
      if (this._rateLimit.counter < this._rateLimit.limit) {
        return callback();
      }
      this._rateLimit.waiting.push(callback);
      if (this._rateLimit.checkpoint <= now - this._rateLimit.delta) {
        return this._clearRateLimit();
      } else if (!this._rateLimit.timeout) {
        this._rateLimit.timeout = setTimeout(() => this._clearRateLimit(), this._rateLimit.delta - (now - this._rateLimit.checkpoint));
        this._rateLimit.checkpoint = now;
      }
    }
    _clearRateLimit() {
      clearTimeout(this._rateLimit.timeout);
      this._rateLimit.timeout = null;
      this._rateLimit.counter = 0;
      this._rateLimit.checkpoint = false;
      while (this._rateLimit.waiting.length) {
        let cb = this._rateLimit.waiting.shift();
        setImmediate(cb);
      }
    }
    isIdle() {
      return this.idling;
    }
    verify(callback) {
      let promise;
      if (!callback) {
        promise = new Promise((resolve, reject) => {
          callback = shared.callbackPromise(resolve, reject);
        });
      }
      let auth = new PoolResource(this).auth;
      this.getSocket(this.options, (err, socketOptions) => {
        if (err) {
          return callback(err);
        }
        let options = this.options;
        if (socketOptions && socketOptions.connection) {
          this.logger.info({
            tnx: "proxy",
            remoteAddress: socketOptions.connection.remoteAddress,
            remotePort: socketOptions.connection.remotePort,
            destHost: options.host || "",
            destPort: options.port || "",
            action: "connected"
          }, "Using proxied socket from %s:%s to %s:%s", socketOptions.connection.remoteAddress, socketOptions.connection.remotePort, options.host || "", options.port || "");
          options = shared.assign(false, options);
          Object.keys(socketOptions).forEach((key) => {
            options[key] = socketOptions[key];
          });
        }
        let connection = new SMTPConnection(options);
        let returned = false;
        connection.once("error", (err2) => {
          if (returned) {
            return;
          }
          returned = true;
          connection.close();
          return callback(err2);
        });
        connection.once("end", () => {
          if (returned) {
            return;
          }
          returned = true;
          return callback(new Error("Connection closed"));
        });
        let finalize = () => {
          if (returned) {
            return;
          }
          returned = true;
          connection.quit();
          return callback(null, true);
        };
        connection.connect(() => {
          if (returned) {
            return;
          }
          if (auth && (connection.allowsAuth || options.forceAuth)) {
            connection.login(auth, (err2) => {
              if (returned) {
                return;
              }
              if (err2) {
                returned = true;
                connection.close();
                return callback(err2);
              }
              finalize();
            });
          } else if (!auth && connection.allowsAuth && options.forceAuth) {
            let err2 = new Error("Authentication info was not provided");
            err2.code = "NoAuth";
            returned = true;
            connection.close();
            return callback(err2);
          } else {
            finalize();
          }
        });
      });
      return promise;
    }
  }
  module.exports = SMTPPool;
});

// node_modules/nodemailer/lib/smtp-transport/index.js
var require_smtp_transport = __commonJS((exports, module) => {
  var EventEmitter = import.meta.require("events");
  var SMTPConnection = require_smtp_connection();
  var wellKnown = require_well_known();
  var shared = require_shared();
  var XOAuth2 = require_xoauth2();
  var packageData = require_package();

  class SMTPTransport extends EventEmitter {
    constructor(options) {
      super();
      options = options || {};
      if (typeof options === "string") {
        options = {
          url: options
        };
      }
      let urlData;
      let service = options.service;
      if (typeof options.getSocket === "function") {
        this.getSocket = options.getSocket;
      }
      if (options.url) {
        urlData = shared.parseConnectionUrl(options.url);
        service = service || urlData.service;
      }
      this.options = shared.assign(false, options, urlData, service && wellKnown(service));
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "smtp-transport"
      });
      let connection = new SMTPConnection(this.options);
      this.name = "SMTP";
      this.version = packageData.version + "[client:" + connection.version + "]";
      if (this.options.auth) {
        this.auth = this.getAuth({});
      }
    }
    getSocket(options, callback) {
      return setImmediate(() => callback(null, false));
    }
    getAuth(authOpts) {
      if (!authOpts) {
        return this.auth;
      }
      let hasAuth = false;
      let authData = {};
      if (this.options.auth && typeof this.options.auth === "object") {
        Object.keys(this.options.auth).forEach((key) => {
          hasAuth = true;
          authData[key] = this.options.auth[key];
        });
      }
      if (authOpts && typeof authOpts === "object") {
        Object.keys(authOpts).forEach((key) => {
          hasAuth = true;
          authData[key] = authOpts[key];
        });
      }
      if (!hasAuth) {
        return false;
      }
      switch ((authData.type || "").toString().toUpperCase()) {
        case "OAUTH2": {
          if (!authData.service && !authData.user) {
            return false;
          }
          let oauth2 = new XOAuth2(authData, this.logger);
          oauth2.provisionCallback = this.mailer && this.mailer.get("oauth2_provision_cb") || oauth2.provisionCallback;
          oauth2.on("token", (token) => this.mailer.emit("token", token));
          oauth2.on("error", (err) => this.emit("error", err));
          return {
            type: "OAUTH2",
            user: authData.user,
            oauth2,
            method: "XOAUTH2"
          };
        }
        default:
          return {
            type: (authData.type || "").toString().toUpperCase() || "LOGIN",
            user: authData.user,
            credentials: {
              user: authData.user || "",
              pass: authData.pass,
              options: authData.options
            },
            method: (authData.method || "").trim().toUpperCase() || this.options.authMethod || false
          };
      }
    }
    send(mail, callback) {
      this.getSocket(this.options, (err, socketOptions) => {
        if (err) {
          return callback(err);
        }
        let returned = false;
        let options = this.options;
        if (socketOptions && socketOptions.connection) {
          this.logger.info({
            tnx: "proxy",
            remoteAddress: socketOptions.connection.remoteAddress,
            remotePort: socketOptions.connection.remotePort,
            destHost: options.host || "",
            destPort: options.port || "",
            action: "connected"
          }, "Using proxied socket from %s:%s to %s:%s", socketOptions.connection.remoteAddress, socketOptions.connection.remotePort, options.host || "", options.port || "");
          options = shared.assign(false, options);
          Object.keys(socketOptions).forEach((key) => {
            options[key] = socketOptions[key];
          });
        }
        let connection = new SMTPConnection(options);
        connection.once("error", (err2) => {
          if (returned) {
            return;
          }
          returned = true;
          connection.close();
          return callback(err2);
        });
        connection.once("end", () => {
          if (returned) {
            return;
          }
          let timer = setTimeout(() => {
            if (returned) {
              return;
            }
            returned = true;
            let err2 = new Error("Unexpected socket close");
            if (connection && connection._socket && connection._socket.upgrading) {
              err2.code = "ETLS";
            }
            callback(err2);
          }, 1000);
          try {
            timer.unref();
          } catch (E) {
          }
        });
        let sendMessage = () => {
          let envelope = mail.message.getEnvelope();
          let messageId = mail.message.messageId();
          let recipients = [].concat(envelope.to || []);
          if (recipients.length > 3) {
            recipients.push("...and " + recipients.splice(2).length + " more");
          }
          if (mail.data.dsn) {
            envelope.dsn = mail.data.dsn;
          }
          this.logger.info({
            tnx: "send",
            messageId
          }, "Sending message %s to <%s>", messageId, recipients.join(", "));
          connection.send(envelope, mail.message.createReadStream(), (err2, info) => {
            returned = true;
            connection.close();
            if (err2) {
              this.logger.error({
                err: err2,
                tnx: "send"
              }, "Send error for %s: %s", messageId, err2.message);
              return callback(err2);
            }
            info.envelope = {
              from: envelope.from,
              to: envelope.to
            };
            info.messageId = messageId;
            try {
              return callback(null, info);
            } catch (E) {
              this.logger.error({
                err: E,
                tnx: "callback"
              }, "Callback error for %s: %s", messageId, E.message);
            }
          });
        };
        connection.connect(() => {
          if (returned) {
            return;
          }
          let auth = this.getAuth(mail.data.auth);
          if (auth && (connection.allowsAuth || options.forceAuth)) {
            connection.login(auth, (err2) => {
              if (auth && auth !== this.auth && auth.oauth2) {
                auth.oauth2.removeAllListeners();
              }
              if (returned) {
                return;
              }
              if (err2) {
                returned = true;
                connection.close();
                return callback(err2);
              }
              sendMessage();
            });
          } else {
            sendMessage();
          }
        });
      });
    }
    verify(callback) {
      let promise;
      if (!callback) {
        promise = new Promise((resolve, reject) => {
          callback = shared.callbackPromise(resolve, reject);
        });
      }
      this.getSocket(this.options, (err, socketOptions) => {
        if (err) {
          return callback(err);
        }
        let options = this.options;
        if (socketOptions && socketOptions.connection) {
          this.logger.info({
            tnx: "proxy",
            remoteAddress: socketOptions.connection.remoteAddress,
            remotePort: socketOptions.connection.remotePort,
            destHost: options.host || "",
            destPort: options.port || "",
            action: "connected"
          }, "Using proxied socket from %s:%s to %s:%s", socketOptions.connection.remoteAddress, socketOptions.connection.remotePort, options.host || "", options.port || "");
          options = shared.assign(false, options);
          Object.keys(socketOptions).forEach((key) => {
            options[key] = socketOptions[key];
          });
        }
        let connection = new SMTPConnection(options);
        let returned = false;
        connection.once("error", (err2) => {
          if (returned) {
            return;
          }
          returned = true;
          connection.close();
          return callback(err2);
        });
        connection.once("end", () => {
          if (returned) {
            return;
          }
          returned = true;
          return callback(new Error("Connection closed"));
        });
        let finalize = () => {
          if (returned) {
            return;
          }
          returned = true;
          connection.quit();
          return callback(null, true);
        };
        connection.connect(() => {
          if (returned) {
            return;
          }
          let authData = this.getAuth({});
          if (authData && (connection.allowsAuth || options.forceAuth)) {
            connection.login(authData, (err2) => {
              if (returned) {
                return;
              }
              if (err2) {
                returned = true;
                connection.close();
                return callback(err2);
              }
              finalize();
            });
          } else if (!authData && connection.allowsAuth && options.forceAuth) {
            let err2 = new Error("Authentication info was not provided");
            err2.code = "NoAuth";
            returned = true;
            connection.close();
            return callback(err2);
          } else {
            finalize();
          }
        });
      });
      return promise;
    }
    close() {
      if (this.auth && this.auth.oauth2) {
        this.auth.oauth2.removeAllListeners();
      }
      this.emit("close");
    }
  }
  module.exports = SMTPTransport;
});

// node_modules/nodemailer/lib/sendmail-transport/index.js
var require_sendmail_transport = __commonJS((exports, module) => {
  var spawn = import.meta.require("child_process").spawn;
  var packageData = require_package();
  var shared = require_shared();

  class SendmailTransport {
    constructor(options) {
      options = options || {};
      this._spawn = spawn;
      this.options = options || {};
      this.name = "Sendmail";
      this.version = packageData.version;
      this.path = "sendmail";
      this.args = false;
      this.winbreak = false;
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "sendmail"
      });
      if (options) {
        if (typeof options === "string") {
          this.path = options;
        } else if (typeof options === "object") {
          if (options.path) {
            this.path = options.path;
          }
          if (Array.isArray(options.args)) {
            this.args = options.args;
          }
          this.winbreak = ["win", "windows", "dos", "\r\n"].includes((options.newline || "").toString().toLowerCase());
        }
      }
    }
    send(mail, done) {
      mail.message.keepBcc = true;
      let envelope = mail.data.envelope || mail.message.getEnvelope();
      let messageId = mail.message.messageId();
      let args;
      let sendmail;
      let returned;
      const hasInvalidAddresses = [].concat(envelope.from || []).concat(envelope.to || []).some((addr) => /^-/.test(addr));
      if (hasInvalidAddresses) {
        return done(new Error("Can not send mail. Invalid envelope addresses."));
      }
      if (this.args) {
        args = ["-i"].concat(this.args).concat(envelope.to);
      } else {
        args = ["-i"].concat(envelope.from ? ["-f", envelope.from] : []).concat(envelope.to);
      }
      let callback = (err) => {
        if (returned) {
          return;
        }
        returned = true;
        if (typeof done === "function") {
          if (err) {
            return done(err);
          } else {
            return done(null, {
              envelope: mail.data.envelope || mail.message.getEnvelope(),
              messageId,
              response: "Messages queued for delivery"
            });
          }
        }
      };
      try {
        sendmail = this._spawn(this.path, args);
      } catch (E) {
        this.logger.error({
          err: E,
          tnx: "spawn",
          messageId
        }, "Error occurred while spawning sendmail. %s", E.message);
        return callback(E);
      }
      if (sendmail) {
        sendmail.on("error", (err) => {
          this.logger.error({
            err,
            tnx: "spawn",
            messageId
          }, "Error occurred when sending message %s. %s", messageId, err.message);
          callback(err);
        });
        sendmail.once("exit", (code) => {
          if (!code) {
            return callback();
          }
          let err;
          if (code === 127) {
            err = new Error("Sendmail command not found, process exited with code " + code);
          } else {
            err = new Error("Sendmail exited with code " + code);
          }
          this.logger.error({
            err,
            tnx: "stdin",
            messageId
          }, "Error sending message %s to sendmail. %s", messageId, err.message);
          callback(err);
        });
        sendmail.once("close", callback);
        sendmail.stdin.on("error", (err) => {
          this.logger.error({
            err,
            tnx: "stdin",
            messageId
          }, "Error occurred when piping message %s to sendmail. %s", messageId, err.message);
          callback(err);
        });
        let recipients = [].concat(envelope.to || []);
        if (recipients.length > 3) {
          recipients.push("...and " + recipients.splice(2).length + " more");
        }
        this.logger.info({
          tnx: "send",
          messageId
        }, "Sending message %s to <%s>", messageId, recipients.join(", "));
        let sourceStream = mail.message.createReadStream();
        sourceStream.once("error", (err) => {
          this.logger.error({
            err,
            tnx: "stdin",
            messageId
          }, "Error occurred when generating message %s. %s", messageId, err.message);
          sendmail.kill("SIGINT");
          callback(err);
        });
        sourceStream.pipe(sendmail.stdin);
      } else {
        return callback(new Error("sendmail was not found"));
      }
    }
  }
  module.exports = SendmailTransport;
});

// node_modules/nodemailer/lib/stream-transport/index.js
var require_stream_transport = __commonJS((exports, module) => {
  var packageData = require_package();
  var shared = require_shared();

  class StreamTransport {
    constructor(options) {
      options = options || {};
      this.options = options || {};
      this.name = "StreamTransport";
      this.version = packageData.version;
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "stream-transport"
      });
      this.winbreak = ["win", "windows", "dos", "\r\n"].includes((options.newline || "").toString().toLowerCase());
    }
    send(mail, done) {
      mail.message.keepBcc = true;
      let envelope = mail.data.envelope || mail.message.getEnvelope();
      let messageId = mail.message.messageId();
      let recipients = [].concat(envelope.to || []);
      if (recipients.length > 3) {
        recipients.push("...and " + recipients.splice(2).length + " more");
      }
      this.logger.info({
        tnx: "send",
        messageId
      }, "Sending message %s to <%s> using %s line breaks", messageId, recipients.join(", "), this.winbreak ? "<CR><LF>" : "<LF>");
      setImmediate(() => {
        let stream;
        try {
          stream = mail.message.createReadStream();
        } catch (E) {
          this.logger.error({
            err: E,
            tnx: "send",
            messageId
          }, "Creating send stream failed for %s. %s", messageId, E.message);
          return done(E);
        }
        if (!this.options.buffer) {
          stream.once("error", (err) => {
            this.logger.error({
              err,
              tnx: "send",
              messageId
            }, "Failed creating message for %s. %s", messageId, err.message);
          });
          return done(null, {
            envelope: mail.data.envelope || mail.message.getEnvelope(),
            messageId,
            message: stream
          });
        }
        let chunks = [];
        let chunklen = 0;
        stream.on("readable", () => {
          let chunk;
          while ((chunk = stream.read()) !== null) {
            chunks.push(chunk);
            chunklen += chunk.length;
          }
        });
        stream.once("error", (err) => {
          this.logger.error({
            err,
            tnx: "send",
            messageId
          }, "Failed creating message for %s. %s", messageId, err.message);
          return done(err);
        });
        stream.on("end", () => done(null, {
          envelope: mail.data.envelope || mail.message.getEnvelope(),
          messageId,
          message: Buffer.concat(chunks, chunklen)
        }));
      });
    }
  }
  module.exports = StreamTransport;
});

// node_modules/nodemailer/lib/json-transport/index.js
var require_json_transport = __commonJS((exports, module) => {
  var packageData = require_package();
  var shared = require_shared();

  class JSONTransport {
    constructor(options) {
      options = options || {};
      this.options = options || {};
      this.name = "JSONTransport";
      this.version = packageData.version;
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "json-transport"
      });
    }
    send(mail, done) {
      mail.message.keepBcc = true;
      let envelope = mail.data.envelope || mail.message.getEnvelope();
      let messageId = mail.message.messageId();
      let recipients = [].concat(envelope.to || []);
      if (recipients.length > 3) {
        recipients.push("...and " + recipients.splice(2).length + " more");
      }
      this.logger.info({
        tnx: "send",
        messageId
      }, "Composing JSON structure of %s to <%s>", messageId, recipients.join(", "));
      setImmediate(() => {
        mail.normalize((err, data) => {
          if (err) {
            this.logger.error({
              err,
              tnx: "send",
              messageId
            }, "Failed building JSON structure for %s. %s", messageId, err.message);
            return done(err);
          }
          delete data.envelope;
          delete data.normalizedHeaders;
          return done(null, {
            envelope,
            messageId,
            message: this.options.skipEncoding ? data : JSON.stringify(data)
          });
        });
      });
    }
  }
  module.exports = JSONTransport;
});

// node_modules/nodemailer/lib/ses-transport/index.js
var require_ses_transport = __commonJS((exports, module) => {
  var EventEmitter = import.meta.require("events");
  var packageData = require_package();
  var shared = require_shared();
  var LeWindows = require_le_windows();

  class SESTransport extends EventEmitter {
    constructor(options) {
      super();
      options = options || {};
      this.options = options || {};
      this.ses = this.options.SES;
      this.name = "SESTransport";
      this.version = packageData.version;
      this.logger = shared.getLogger(this.options, {
        component: this.options.component || "ses-transport"
      });
      this.maxConnections = Number(this.options.maxConnections) || Infinity;
      this.connections = 0;
      this.sendingRate = Number(this.options.sendingRate) || Infinity;
      this.sendingRateTTL = null;
      this.rateInterval = 1000;
      this.rateMessages = [];
      this.pending = [];
      this.idling = true;
      setImmediate(() => {
        if (this.idling) {
          this.emit("idle");
        }
      });
    }
    send(mail, callback) {
      if (this.connections >= this.maxConnections) {
        this.idling = false;
        return this.pending.push({
          mail,
          callback
        });
      }
      if (!this._checkSendingRate()) {
        this.idling = false;
        return this.pending.push({
          mail,
          callback
        });
      }
      this._send(mail, (...args) => {
        setImmediate(() => callback(...args));
        this._sent();
      });
    }
    _checkRatedQueue() {
      if (this.connections >= this.maxConnections || !this._checkSendingRate()) {
        return;
      }
      if (!this.pending.length) {
        if (!this.idling) {
          this.idling = true;
          this.emit("idle");
        }
        return;
      }
      let next = this.pending.shift();
      this._send(next.mail, (...args) => {
        setImmediate(() => next.callback(...args));
        this._sent();
      });
    }
    _checkSendingRate() {
      clearTimeout(this.sendingRateTTL);
      let now = Date.now();
      let oldest = false;
      for (let i = this.rateMessages.length - 1;i >= 0; i--) {
        if (this.rateMessages[i].ts >= now - this.rateInterval && (!oldest || this.rateMessages[i].ts < oldest)) {
          oldest = this.rateMessages[i].ts;
        }
        if (this.rateMessages[i].ts < now - this.rateInterval && !this.rateMessages[i].pending) {
          this.rateMessages.splice(i, 1);
        }
      }
      if (this.rateMessages.length < this.sendingRate) {
        return true;
      }
      let delay = Math.max(oldest + 1001, now + 20);
      this.sendingRateTTL = setTimeout(() => this._checkRatedQueue(), now - delay);
      try {
        this.sendingRateTTL.unref();
      } catch (E) {
      }
      return false;
    }
    _sent() {
      this.connections--;
      this._checkRatedQueue();
    }
    isIdle() {
      return this.idling;
    }
    _send(mail, callback) {
      let statObject = {
        ts: Date.now(),
        pending: true
      };
      this.connections++;
      this.rateMessages.push(statObject);
      let envelope = mail.data.envelope || mail.message.getEnvelope();
      let messageId = mail.message.messageId();
      let recipients = [].concat(envelope.to || []);
      if (recipients.length > 3) {
        recipients.push("...and " + recipients.splice(2).length + " more");
      }
      this.logger.info({
        tnx: "send",
        messageId
      }, "Sending message %s to <%s>", messageId, recipients.join(", "));
      let getRawMessage = (next) => {
        if (!mail.data._dkim) {
          mail.data._dkim = {};
        }
        if (mail.data._dkim.skipFields && typeof mail.data._dkim.skipFields === "string") {
          mail.data._dkim.skipFields += ":date:message-id";
        } else {
          mail.data._dkim.skipFields = "date:message-id";
        }
        let sourceStream = mail.message.createReadStream();
        let stream = sourceStream.pipe(new LeWindows);
        let chunks = [];
        let chunklen = 0;
        stream.on("readable", () => {
          let chunk;
          while ((chunk = stream.read()) !== null) {
            chunks.push(chunk);
            chunklen += chunk.length;
          }
        });
        sourceStream.once("error", (err) => stream.emit("error", err));
        stream.once("error", (err) => {
          next(err);
        });
        stream.once("end", () => next(null, Buffer.concat(chunks, chunklen)));
      };
      setImmediate(() => getRawMessage((err, raw2) => {
        if (err) {
          this.logger.error({
            err,
            tnx: "send",
            messageId
          }, "Failed creating message for %s. %s", messageId, err.message);
          statObject.pending = false;
          return callback(err);
        }
        let sesMessage = {
          RawMessage: {
            Data: raw2
          },
          Source: envelope.from,
          Destinations: envelope.to
        };
        Object.keys(mail.data.ses || {}).forEach((key) => {
          sesMessage[key] = mail.data.ses[key];
        });
        let ses = (this.ses.aws ? this.ses.ses : this.ses) || {};
        let aws = this.ses.aws || {};
        let getRegion = (cb) => {
          if (ses.config && typeof ses.config.region === "function") {
            return ses.config.region().then((region) => cb(null, region)).catch((err2) => cb(err2));
          }
          return cb(null, ses.config && ses.config.region || "us-east-1");
        };
        getRegion((err2, region) => {
          if (err2 || !region) {
            region = "us-east-1";
          }
          let sendPromise;
          if (typeof ses.send === "function" && aws.SendRawEmailCommand) {
            sendPromise = ses.send(new aws.SendRawEmailCommand(sesMessage));
          } else {
            sendPromise = ses.sendRawEmail(sesMessage).promise();
          }
          sendPromise.then((data) => {
            if (region === "us-east-1") {
              region = "email";
            }
            statObject.pending = false;
            callback(null, {
              envelope: {
                from: envelope.from,
                to: envelope.to
              },
              messageId: "<" + data.MessageId + (!/@/.test(data.MessageId) ? "@" + region + ".amazonses.com" : "") + ">",
              response: data.MessageId,
              raw: raw2
            });
          }).catch((err3) => {
            this.logger.error({
              err: err3,
              tnx: "send"
            }, "Send error for %s: %s", messageId, err3.message);
            statObject.pending = false;
            callback(err3);
          });
        });
      }));
    }
    verify(callback) {
      let promise;
      let ses = (this.ses.aws ? this.ses.ses : this.ses) || {};
      let aws = this.ses.aws || {};
      const sesMessage = {
        RawMessage: {
          Data: "From: invalid@invalid\r\nTo: invalid@invalid\r\n Subject: Invalid\r\n\r\nInvalid"
        },
        Source: "invalid@invalid",
        Destinations: ["invalid@invalid"]
      };
      if (!callback) {
        promise = new Promise((resolve, reject) => {
          callback = shared.callbackPromise(resolve, reject);
        });
      }
      const cb = (err) => {
        if (err && (err.code || err.Code) !== "InvalidParameterValue") {
          return callback(err);
        }
        return callback(null, true);
      };
      if (typeof ses.send === "function" && aws.SendRawEmailCommand) {
        sesMessage.RawMessage.Data = Buffer.from(sesMessage.RawMessage.Data);
        ses.send(new aws.SendRawEmailCommand(sesMessage), cb);
      } else {
        ses.sendRawEmail(sesMessage, cb);
      }
      return promise;
    }
  }
  module.exports = SESTransport;
});

// node_modules/safe-buffer/index.js
var require_safe_buffer = __commonJS((exports, module) => {
  var copyProps = function(src, dst) {
    for (var key in src) {
      dst[key] = src[key];
    }
  };
  var SafeBuffer = function(arg, encodingOrOffset, length) {
    return Buffer2(arg, encodingOrOffset, length);
  };
  /*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
  var buffer = import.meta.require("buffer");
  var Buffer2 = buffer.Buffer;
  if (Buffer2.from && Buffer2.alloc && Buffer2.allocUnsafe && Buffer2.allocUnsafeSlow) {
    module.exports = buffer;
  } else {
    copyProps(buffer, exports);
    exports.Buffer = SafeBuffer;
  }
  SafeBuffer.prototype = Object.create(Buffer2.prototype);
  copyProps(Buffer2, SafeBuffer);
  SafeBuffer.from = function(arg, encodingOrOffset, length) {
    if (typeof arg === "number") {
      throw new TypeError("Argument must not be a number");
    }
    return Buffer2(arg, encodingOrOffset, length);
  };
  SafeBuffer.alloc = function(size2, fill, encoding) {
    if (typeof size2 !== "number") {
      throw new TypeError("Argument must be a number");
    }
    var buf = Buffer2(size2);
    if (fill !== undefined) {
      if (typeof encoding === "string") {
        buf.fill(fill, encoding);
      } else {
        buf.fill(fill);
      }
    } else {
      buf.fill(0);
    }
    return buf;
  };
  SafeBuffer.allocUnsafe = function(size2) {
    if (typeof size2 !== "number") {
      throw new TypeError("Argument must be a number");
    }
    return Buffer2(size2);
  };
  SafeBuffer.allocUnsafeSlow = function(size2) {
    if (typeof size2 !== "number") {
      throw new TypeError("Argument must be a number");
    }
    return buffer.SlowBuffer(size2);
  };
});

// node_modules/jws/lib/data-stream.js
var require_data_stream2 = __commonJS((exports, module) => {
  var DataStream = function(data) {
    this.buffer = null;
    this.writable = true;
    this.readable = true;
    if (!data) {
      this.buffer = Buffer2.alloc(0);
      return this;
    }
    if (typeof data.pipe === "function") {
      this.buffer = Buffer2.alloc(0);
      data.pipe(this);
      return this;
    }
    if (data.length || typeof data === "object") {
      this.buffer = data;
      this.writable = false;
      process.nextTick(function() {
        this.emit("end", data);
        this.readable = false;
        this.emit("close");
      }.bind(this));
      return this;
    }
    throw new TypeError("Unexpected data type (" + typeof data + ")");
  };
  var Buffer2 = require_safe_buffer().Buffer;
  var Stream = import.meta.require("stream");
  var util = import.meta.require("util");
  util.inherits(DataStream, Stream);
  DataStream.prototype.write = function write(data) {
    this.buffer = Buffer2.concat([this.buffer, Buffer2.from(data)]);
    this.emit("data", data);
  };
  DataStream.prototype.end = function end(data) {
    if (data)
      this.write(data);
    this.emit("end", data);
    this.emit("close");
    this.writable = false;
    this.readable = false;
  };
  module.exports = DataStream;
});

// node_modules/buffer-equal-constant-time/index.js
var require_buffer_equal_constant_time = __commonJS((exports, module) => {
  var bufferEq = function(a, b) {
    if (!Buffer2.isBuffer(a) || !Buffer2.isBuffer(b)) {
      return false;
    }
    if (a.length !== b.length) {
      return false;
    }
    var c = 0;
    for (var i = 0;i < a.length; i++) {
      c |= a[i] ^ b[i];
    }
    return c === 0;
  };
  var Buffer2 = import.meta.require("buffer").Buffer;
  var SlowBuffer = import.meta.require("buffer").SlowBuffer;
  module.exports = bufferEq;
  bufferEq.install = function() {
    Buffer2.prototype.equal = SlowBuffer.prototype.equal = function equal(that) {
      return bufferEq(this, that);
    };
  };
  var origBufEqual = Buffer2.prototype.equal;
  var origSlowBufEqual = SlowBuffer.prototype.equal;
  bufferEq.restore = function() {
    Buffer2.prototype.equal = origBufEqual;
    SlowBuffer.prototype.equal = origSlowBufEqual;
  };
});

// node_modules/ecdsa-sig-formatter/src/param-bytes-for-alg.js
var require_param_bytes_for_alg = __commonJS((exports, module) => {
  var getParamSize = function(keySize) {
    var result = (keySize / 8 | 0) + (keySize % 8 === 0 ? 0 : 1);
    return result;
  };
  var getParamBytesForAlg = function(alg) {
    var paramBytes = paramBytesForAlg[alg];
    if (paramBytes) {
      return paramBytes;
    }
    throw new Error('Unknown algorithm "' + alg + '"');
  };
  var paramBytesForAlg = {
    ES256: getParamSize(256),
    ES384: getParamSize(384),
    ES512: getParamSize(521)
  };
  module.exports = getParamBytesForAlg;
});

// node_modules/ecdsa-sig-formatter/src/ecdsa-sig-formatter.js
var require_ecdsa_sig_formatter = __commonJS((exports, module) => {
  var base64Url = function(base64) {
    return base64.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  };
  var signatureAsBuffer = function(signature) {
    if (Buffer2.isBuffer(signature)) {
      return signature;
    } else if (typeof signature === "string") {
      return Buffer2.from(signature, "base64");
    }
    throw new TypeError("ECDSA signature must be a Base64 string or a Buffer");
  };
  var derToJose = function(signature, alg) {
    signature = signatureAsBuffer(signature);
    var paramBytes = getParamBytesForAlg(alg);
    var maxEncodedParamLength = paramBytes + 1;
    var inputLength = signature.length;
    var offset2 = 0;
    if (signature[offset2++] !== ENCODED_TAG_SEQ) {
      throw new Error('Could not find expected "seq"');
    }
    var seqLength = signature[offset2++];
    if (seqLength === (MAX_OCTET | 1)) {
      seqLength = signature[offset2++];
    }
    if (inputLength - offset2 < seqLength) {
      throw new Error('"seq" specified length of "' + seqLength + '", only "' + (inputLength - offset2) + '" remaining');
    }
    if (signature[offset2++] !== ENCODED_TAG_INT) {
      throw new Error('Could not find expected "int" for "r"');
    }
    var rLength = signature[offset2++];
    if (inputLength - offset2 - 2 < rLength) {
      throw new Error('"r" specified length of "' + rLength + '", only "' + (inputLength - offset2 - 2) + '" available');
    }
    if (maxEncodedParamLength < rLength) {
      throw new Error('"r" specified length of "' + rLength + '", max of "' + maxEncodedParamLength + '" is acceptable');
    }
    var rOffset = offset2;
    offset2 += rLength;
    if (signature[offset2++] !== ENCODED_TAG_INT) {
      throw new Error('Could not find expected "int" for "s"');
    }
    var sLength = signature[offset2++];
    if (inputLength - offset2 !== sLength) {
      throw new Error('"s" specified length of "' + sLength + '", expected "' + (inputLength - offset2) + '"');
    }
    if (maxEncodedParamLength < sLength) {
      throw new Error('"s" specified length of "' + sLength + '", max of "' + maxEncodedParamLength + '" is acceptable');
    }
    var sOffset = offset2;
    offset2 += sLength;
    if (offset2 !== inputLength) {
      throw new Error('Expected to consume entire buffer, but "' + (inputLength - offset2) + '" bytes remain');
    }
    var rPadding = paramBytes - rLength, sPadding = paramBytes - sLength;
    var dst = Buffer2.allocUnsafe(rPadding + rLength + sPadding + sLength);
    for (offset2 = 0;offset2 < rPadding; ++offset2) {
      dst[offset2] = 0;
    }
    signature.copy(dst, offset2, rOffset + Math.max(-rPadding, 0), rOffset + rLength);
    offset2 = paramBytes;
    for (var o = offset2;offset2 < o + sPadding; ++offset2) {
      dst[offset2] = 0;
    }
    signature.copy(dst, offset2, sOffset + Math.max(-sPadding, 0), sOffset + sLength);
    dst = dst.toString("base64");
    dst = base64Url(dst);
    return dst;
  };
  var countPadding = function(buf, start, stop) {
    var padding = 0;
    while (start + padding < stop && buf[start + padding] === 0) {
      ++padding;
    }
    var needsSign = buf[start + padding] >= MAX_OCTET;
    if (needsSign) {
      --padding;
    }
    return padding;
  };
  var joseToDer = function(signature, alg) {
    signature = signatureAsBuffer(signature);
    var paramBytes = getParamBytesForAlg(alg);
    var signatureBytes = signature.length;
    if (signatureBytes !== paramBytes * 2) {
      throw new TypeError('"' + alg + '" signatures must be "' + paramBytes * 2 + '" bytes, saw "' + signatureBytes + '"');
    }
    var rPadding = countPadding(signature, 0, paramBytes);
    var sPadding = countPadding(signature, paramBytes, signature.length);
    var rLength = paramBytes - rPadding;
    var sLength = paramBytes - sPadding;
    var rsBytes = 1 + 1 + rLength + 1 + 1 + sLength;
    var shortLength = rsBytes < MAX_OCTET;
    var dst = Buffer2.allocUnsafe((shortLength ? 2 : 3) + rsBytes);
    var offset2 = 0;
    dst[offset2++] = ENCODED_TAG_SEQ;
    if (shortLength) {
      dst[offset2++] = rsBytes;
    } else {
      dst[offset2++] = MAX_OCTET | 1;
      dst[offset2++] = rsBytes & 255;
    }
    dst[offset2++] = ENCODED_TAG_INT;
    dst[offset2++] = rLength;
    if (rPadding < 0) {
      dst[offset2++] = 0;
      offset2 += signature.copy(dst, offset2, 0, paramBytes);
    } else {
      offset2 += signature.copy(dst, offset2, rPadding, paramBytes);
    }
    dst[offset2++] = ENCODED_TAG_INT;
    dst[offset2++] = sLength;
    if (sPadding < 0) {
      dst[offset2++] = 0;
      signature.copy(dst, offset2, paramBytes);
    } else {
      signature.copy(dst, offset2, paramBytes + sPadding);
    }
    return dst;
  };
  var Buffer2 = require_safe_buffer().Buffer;
  var getParamBytesForAlg = require_param_bytes_for_alg();
  var MAX_OCTET = 128;
  var CLASS_UNIVERSAL = 0;
  var PRIMITIVE_BIT = 32;
  var TAG_SEQ = 16;
  var TAG_INT = 2;
  var ENCODED_TAG_SEQ = TAG_SEQ | PRIMITIVE_BIT | CLASS_UNIVERSAL << 6;
  var ENCODED_TAG_INT = TAG_INT | CLASS_UNIVERSAL << 6;
  module.exports = {
    derToJose,
    joseToDer
  };
});

// node_modules/jwa/index.js
var require_jwa = __commonJS((exports, module) => {
  var checkIsPublicKey = function(key) {
    if (Buffer2.isBuffer(key)) {
      return;
    }
    if (typeof key === "string") {
      return;
    }
    if (!supportsKeyObjects) {
      throw typeError(MSG_INVALID_VERIFIER_KEY);
    }
    if (typeof key !== "object") {
      throw typeError(MSG_INVALID_VERIFIER_KEY);
    }
    if (typeof key.type !== "string") {
      throw typeError(MSG_INVALID_VERIFIER_KEY);
    }
    if (typeof key.asymmetricKeyType !== "string") {
      throw typeError(MSG_INVALID_VERIFIER_KEY);
    }
    if (typeof key.export !== "function") {
      throw typeError(MSG_INVALID_VERIFIER_KEY);
    }
  };
  var checkIsPrivateKey = function(key) {
    if (Buffer2.isBuffer(key)) {
      return;
    }
    if (typeof key === "string") {
      return;
    }
    if (typeof key === "object") {
      return;
    }
    throw typeError(MSG_INVALID_SIGNER_KEY);
  };
  var checkIsSecretKey = function(key) {
    if (Buffer2.isBuffer(key)) {
      return;
    }
    if (typeof key === "string") {
      return key;
    }
    if (!supportsKeyObjects) {
      throw typeError(MSG_INVALID_SECRET);
    }
    if (typeof key !== "object") {
      throw typeError(MSG_INVALID_SECRET);
    }
    if (key.type !== "secret") {
      throw typeError(MSG_INVALID_SECRET);
    }
    if (typeof key.export !== "function") {
      throw typeError(MSG_INVALID_SECRET);
    }
  };
  var fromBase64 = function(base64) {
    return base64.replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  };
  var toBase64 = function(base64url) {
    base64url = base64url.toString();
    var padding = 4 - base64url.length % 4;
    if (padding !== 4) {
      for (var i = 0;i < padding; ++i) {
        base64url += "=";
      }
    }
    return base64url.replace(/\-/g, "+").replace(/_/g, "/");
  };
  var typeError = function(template) {
    var args = [].slice.call(arguments, 1);
    var errMsg = util.format.bind(util, template).apply(null, args);
    return new TypeError(errMsg);
  };
  var bufferOrString = function(obj) {
    return Buffer2.isBuffer(obj) || typeof obj === "string";
  };
  var normalizeInput = function(thing) {
    if (!bufferOrString(thing))
      thing = JSON.stringify(thing);
    return thing;
  };
  var createHmacSigner = function(bits) {
    return function sign(thing, secret) {
      checkIsSecretKey(secret);
      thing = normalizeInput(thing);
      var hmac = crypto2.createHmac("sha" + bits, secret);
      var sig = (hmac.update(thing), hmac.digest("base64"));
      return fromBase64(sig);
    };
  };
  var createHmacVerifier = function(bits) {
    return function verify(thing, signature, secret) {
      var computedSig = createHmacSigner(bits)(thing, secret);
      return bufferEqual(Buffer2.from(signature), Buffer2.from(computedSig));
    };
  };
  var createKeySigner = function(bits) {
    return function sign(thing, privateKey) {
      checkIsPrivateKey(privateKey);
      thing = normalizeInput(thing);
      var signer = crypto2.createSign("RSA-SHA" + bits);
      var sig = (signer.update(thing), signer.sign(privateKey, "base64"));
      return fromBase64(sig);
    };
  };
  var createKeyVerifier = function(bits) {
    return function verify(thing, signature, publicKey) {
      checkIsPublicKey(publicKey);
      thing = normalizeInput(thing);
      signature = toBase64(signature);
      var verifier = crypto2.createVerify("RSA-SHA" + bits);
      verifier.update(thing);
      return verifier.verify(publicKey, signature, "base64");
    };
  };
  var createPSSKeySigner = function(bits) {
    return function sign(thing, privateKey) {
      checkIsPrivateKey(privateKey);
      thing = normalizeInput(thing);
      var signer = crypto2.createSign("RSA-SHA" + bits);
      var sig = (signer.update(thing), signer.sign({
        key: privateKey,
        padding: crypto2.constants.RSA_PKCS1_PSS_PADDING,
        saltLength: crypto2.constants.RSA_PSS_SALTLEN_DIGEST
      }, "base64"));
      return fromBase64(sig);
    };
  };
  var createPSSKeyVerifier = function(bits) {
    return function verify(thing, signature, publicKey) {
      checkIsPublicKey(publicKey);
      thing = normalizeInput(thing);
      signature = toBase64(signature);
      var verifier = crypto2.createVerify("RSA-SHA" + bits);
      verifier.update(thing);
      return verifier.verify({
        key: publicKey,
        padding: crypto2.constants.RSA_PKCS1_PSS_PADDING,
        saltLength: crypto2.constants.RSA_PSS_SALTLEN_DIGEST
      }, signature, "base64");
    };
  };
  var createECDSASigner = function(bits) {
    var inner = createKeySigner(bits);
    return function sign() {
      var signature = inner.apply(null, arguments);
      signature = formatEcdsa.derToJose(signature, "ES" + bits);
      return signature;
    };
  };
  var createECDSAVerifer = function(bits) {
    var inner = createKeyVerifier(bits);
    return function verify(thing, signature, publicKey) {
      signature = formatEcdsa.joseToDer(signature, "ES" + bits).toString("base64");
      var result = inner(thing, signature, publicKey);
      return result;
    };
  };
  var createNoneSigner = function() {
    return function sign() {
      return "";
    };
  };
  var createNoneVerifier = function() {
    return function verify(thing, signature) {
      return signature === "";
    };
  };
  var bufferEqual = require_buffer_equal_constant_time();
  var Buffer2 = require_safe_buffer().Buffer;
  var crypto2 = import.meta.require("crypto");
  var formatEcdsa = require_ecdsa_sig_formatter();
  var util = import.meta.require("util");
  var MSG_INVALID_ALGORITHM = '"%s" is not a valid algorithm.\n  Supported algorithms are:\n  "HS256", "HS384", "HS512", "RS256", "RS384", "RS512", "PS256", "PS384", "PS512", "ES256", "ES384", "ES512" and "none".';
  var MSG_INVALID_SECRET = "secret must be a string or buffer";
  var MSG_INVALID_VERIFIER_KEY = "key must be a string or a buffer";
  var MSG_INVALID_SIGNER_KEY = "key must be a string, a buffer or an object";
  var supportsKeyObjects = typeof crypto2.createPublicKey === "function";
  if (supportsKeyObjects) {
    MSG_INVALID_VERIFIER_KEY += " or a KeyObject";
    MSG_INVALID_SECRET += "or a KeyObject";
  }
  module.exports = function jwa(algorithm) {
    var signerFactories = {
      hs: createHmacSigner,
      rs: createKeySigner,
      ps: createPSSKeySigner,
      es: createECDSASigner,
      none: createNoneSigner
    };
    var verifierFactories = {
      hs: createHmacVerifier,
      rs: createKeyVerifier,
      ps: createPSSKeyVerifier,
      es: createECDSAVerifer,
      none: createNoneVerifier
    };
    var match = algorithm.match(/^(RS|PS|ES|HS)(256|384|512)$|^(none)$/i);
    if (!match)
      throw typeError(MSG_INVALID_ALGORITHM, algorithm);
    var algo = (match[1] || match[3]).toLowerCase();
    var bits = match[2];
    return {
      sign: signerFactories[algo](bits),
      verify: verifierFactories[algo](bits)
    };
  };
});

// node_modules/jws/lib/tostring.js
var require_tostring = __commonJS((exports, module) => {
  var Buffer2 = import.meta.require("buffer").Buffer;
  module.exports = function toString(obj) {
    if (typeof obj === "string")
      return obj;
    if (typeof obj === "number" || Buffer2.isBuffer(obj))
      return obj.toString();
    return JSON.stringify(obj);
  };
});

// node_modules/jws/lib/sign-stream.js
var require_sign_stream = __commonJS((exports, module) => {
  var base64url = function(string, encoding) {
    return Buffer2.from(string, encoding).toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
  };
  var jwsSecuredInput = function(header, payload, encoding) {
    encoding = encoding || "utf8";
    var encodedHeader = base64url(toString2(header), "binary");
    var encodedPayload = base64url(toString2(payload), encoding);
    return util.format("%s.%s", encodedHeader, encodedPayload);
  };
  var jwsSign = function(opts) {
    var header = opts.header;
    var payload = opts.payload;
    var secretOrKey = opts.secret || opts.privateKey;
    var encoding = opts.encoding;
    var algo = jwa(header.alg);
    var securedInput = jwsSecuredInput(header, payload, encoding);
    var signature = algo.sign(securedInput, secretOrKey);
    return util.format("%s.%s", securedInput, signature);
  };
  var SignStream = function(opts) {
    var secret = opts.secret || opts.privateKey || opts.key;
    var secretStream = new DataStream(secret);
    this.readable = true;
    this.header = opts.header;
    this.encoding = opts.encoding;
    this.secret = this.privateKey = this.key = secretStream;
    this.payload = new DataStream(opts.payload);
    this.secret.once("close", function() {
      if (!this.payload.writable && this.readable)
        this.sign();
    }.bind(this));
    this.payload.once("close", function() {
      if (!this.secret.writable && this.readable)
        this.sign();
    }.bind(this));
  };
  var Buffer2 = require_safe_buffer().Buffer;
  var DataStream = require_data_stream2();
  var jwa = require_jwa();
  var Stream = import.meta.require("stream");
  var toString2 = require_tostring();
  var util = import.meta.require("util");
  util.inherits(SignStream, Stream);
  SignStream.prototype.sign = function sign() {
    try {
      var signature = jwsSign({
        header: this.header,
        payload: this.payload.buffer,
        secret: this.secret.buffer,
        encoding: this.encoding
      });
      this.emit("done", signature);
      this.emit("data", signature);
      this.emit("end");
      this.readable = false;
      return signature;
    } catch (e) {
      this.readable = false;
      this.emit("error", e);
      this.emit("close");
    }
  };
  SignStream.sign = jwsSign;
  module.exports = SignStream;
});

// node_modules/jws/lib/verify-stream.js
var require_verify_stream = __commonJS((exports, module) => {
  var isObject2 = function(thing) {
    return Object.prototype.toString.call(thing) === "[object Object]";
  };
  var safeJsonParse = function(thing) {
    if (isObject2(thing))
      return thing;
    try {
      return JSON.parse(thing);
    } catch (e) {
      return;
    }
  };
  var headerFromJWS = function(jwsSig) {
    var encodedHeader = jwsSig.split(".", 1)[0];
    return safeJsonParse(Buffer2.from(encodedHeader, "base64").toString("binary"));
  };
  var securedInputFromJWS = function(jwsSig) {
    return jwsSig.split(".", 2).join(".");
  };
  var signatureFromJWS = function(jwsSig) {
    return jwsSig.split(".")[2];
  };
  var payloadFromJWS = function(jwsSig, encoding) {
    encoding = encoding || "utf8";
    var payload = jwsSig.split(".")[1];
    return Buffer2.from(payload, "base64").toString(encoding);
  };
  var isValidJws = function(string) {
    return JWS_REGEX.test(string) && !!headerFromJWS(string);
  };
  var jwsVerify = function(jwsSig, algorithm, secretOrKey) {
    if (!algorithm) {
      var err = new Error("Missing algorithm parameter for jws.verify");
      err.code = "MISSING_ALGORITHM";
      throw err;
    }
    jwsSig = toString2(jwsSig);
    var signature = signatureFromJWS(jwsSig);
    var securedInput = securedInputFromJWS(jwsSig);
    var algo = jwa(algorithm);
    return algo.verify(securedInput, signature, secretOrKey);
  };
  var jwsDecode = function(jwsSig, opts) {
    opts = opts || {};
    jwsSig = toString2(jwsSig);
    if (!isValidJws(jwsSig))
      return null;
    var header = headerFromJWS(jwsSig);
    if (!header)
      return null;
    var payload = payloadFromJWS(jwsSig);
    if (header.typ === "JWT" || opts.json)
      payload = JSON.parse(payload, opts.encoding);
    return {
      header,
      payload,
      signature: signatureFromJWS(jwsSig)
    };
  };
  var VerifyStream = function(opts) {
    opts = opts || {};
    var secretOrKey = opts.secret || opts.publicKey || opts.key;
    var secretStream = new DataStream(secretOrKey);
    this.readable = true;
    this.algorithm = opts.algorithm;
    this.encoding = opts.encoding;
    this.secret = this.publicKey = this.key = secretStream;
    this.signature = new DataStream(opts.signature);
    this.secret.once("close", function() {
      if (!this.signature.writable && this.readable)
        this.verify();
    }.bind(this));
    this.signature.once("close", function() {
      if (!this.secret.writable && this.readable)
        this.verify();
    }.bind(this));
  };
  var Buffer2 = require_safe_buffer().Buffer;
  var DataStream = require_data_stream2();
  var jwa = require_jwa();
  var Stream = import.meta.require("stream");
  var toString2 = require_tostring();
  var util = import.meta.require("util");
  var JWS_REGEX = /^[a-zA-Z0-9\-_]+?\.[a-zA-Z0-9\-_]+?\.([a-zA-Z0-9\-_]+)?$/;
  util.inherits(VerifyStream, Stream);
  VerifyStream.prototype.verify = function verify() {
    try {
      var valid = jwsVerify(this.signature.buffer, this.algorithm, this.key.buffer);
      var obj = jwsDecode(this.signature.buffer, this.encoding);
      this.emit("done", valid, obj);
      this.emit("data", valid);
      this.emit("end");
      this.readable = false;
      return valid;
    } catch (e) {
      this.readable = false;
      this.emit("error", e);
      this.emit("close");
    }
  };
  VerifyStream.decode = jwsDecode;
  VerifyStream.isValid = isValidJws;
  VerifyStream.verify = jwsVerify;
  module.exports = VerifyStream;
});

// node_modules/jws/index.js
var require_jws = __commonJS((exports) => {
  var SignStream = require_sign_stream();
  var VerifyStream = require_verify_stream();
  var ALGORITHMS = [
    "HS256",
    "HS384",
    "HS512",
    "RS256",
    "RS384",
    "RS512",
    "PS256",
    "PS384",
    "PS512",
    "ES256",
    "ES384",
    "ES512"
  ];
  exports.ALGORITHMS = ALGORITHMS;
  exports.sign = SignStream.sign;
  exports.verify = VerifyStream.verify;
  exports.decode = VerifyStream.decode;
  exports.isValid = VerifyStream.isValid;
  exports.createSign = function createSign(opts) {
    return new SignStream(opts);
  };
  exports.createVerify = function createVerify(opts) {
    return new VerifyStream(opts);
  };
});

// node_modules/jsonwebtoken/decode.js
var require_decode = __commonJS((exports, module) => {
  var jws = require_jws();
  module.exports = function(jwt, options2) {
    options2 = options2 || {};
    var decoded = jws.decode(jwt, options2);
    if (!decoded) {
      return null;
    }
    var payload = decoded.payload;
    if (typeof payload === "string") {
      try {
        var obj = JSON.parse(payload);
        if (obj !== null && typeof obj === "object") {
          payload = obj;
        }
      } catch (e) {
      }
    }
    if (options2.complete === true) {
      return {
        header: decoded.header,
        payload,
        signature: decoded.signature
      };
    }
    return payload;
  };
});

// node_modules/jsonwebtoken/lib/JsonWebTokenError.js
var require_JsonWebTokenError = __commonJS((exports, module) => {
  var JsonWebTokenError = function(message, error) {
    Error.call(this, message);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
    this.name = "JsonWebTokenError";
    this.message = message;
    if (error)
      this.inner = error;
  };
  JsonWebTokenError.prototype = Object.create(Error.prototype);
  JsonWebTokenError.prototype.constructor = JsonWebTokenError;
  module.exports = JsonWebTokenError;
});

// node_modules/jsonwebtoken/lib/NotBeforeError.js
var require_NotBeforeError = __commonJS((exports, module) => {
  var JsonWebTokenError = require_JsonWebTokenError();
  var NotBeforeError = function(message, date2) {
    JsonWebTokenError.call(this, message);
    this.name = "NotBeforeError";
    this.date = date2;
  };
  NotBeforeError.prototype = Object.create(JsonWebTokenError.prototype);
  NotBeforeError.prototype.constructor = NotBeforeError;
  module.exports = NotBeforeError;
});

// node_modules/jsonwebtoken/lib/TokenExpiredError.js
var require_TokenExpiredError = __commonJS((exports, module) => {
  var JsonWebTokenError = require_JsonWebTokenError();
  var TokenExpiredError = function(message, expiredAt) {
    JsonWebTokenError.call(this, message);
    this.name = "TokenExpiredError";
    this.expiredAt = expiredAt;
  };
  TokenExpiredError.prototype = Object.create(JsonWebTokenError.prototype);
  TokenExpiredError.prototype.constructor = TokenExpiredError;
  module.exports = TokenExpiredError;
});

// node_modules/ms/index.js
var require_ms = __commonJS((exports, module) => {
  var parse2 = function(str2) {
    str2 = String(str2);
    if (str2.length > 100) {
      return;
    }
    var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str2);
    if (!match) {
      return;
    }
    var n = parseFloat(match[1]);
    var type = (match[2] || "ms").toLowerCase();
    switch (type) {
      case "years":
      case "year":
      case "yrs":
      case "yr":
      case "y":
        return n * y;
      case "weeks":
      case "week":
      case "w":
        return n * w;
      case "days":
      case "day":
      case "d":
        return n * d;
      case "hours":
      case "hour":
      case "hrs":
      case "hr":
      case "h":
        return n * h;
      case "minutes":
      case "minute":
      case "mins":
      case "min":
      case "m":
        return n * m;
      case "seconds":
      case "second":
      case "secs":
      case "sec":
      case "s":
        return n * s;
      case "milliseconds":
      case "millisecond":
      case "msecs":
      case "msec":
      case "ms":
        return n;
      default:
        return;
    }
  };
  var fmtShort = function(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
      return Math.round(ms / d) + "d";
    }
    if (msAbs >= h) {
      return Math.round(ms / h) + "h";
    }
    if (msAbs >= m) {
      return Math.round(ms / m) + "m";
    }
    if (msAbs >= s) {
      return Math.round(ms / s) + "s";
    }
    return ms + "ms";
  };
  var fmtLong = function(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
      return plural(ms, msAbs, d, "day");
    }
    if (msAbs >= h) {
      return plural(ms, msAbs, h, "hour");
    }
    if (msAbs >= m) {
      return plural(ms, msAbs, m, "minute");
    }
    if (msAbs >= s) {
      return plural(ms, msAbs, s, "second");
    }
    return ms + " ms";
  };
  var plural = function(ms, msAbs, n, name) {
    var isPlural = msAbs >= n * 1.5;
    return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
  };
  var s = 1000;
  var m = s * 60;
  var h = m * 60;
  var d = h * 24;
  var w = d * 7;
  var y = d * 365.25;
  module.exports = function(val, options2) {
    options2 = options2 || {};
    var type = typeof val;
    if (type === "string" && val.length > 0) {
      return parse2(val);
    } else if (type === "number" && isFinite(val)) {
      return options2.long ? fmtLong(val) : fmtShort(val);
    }
    throw new Error("val is not a non-empty string or a valid number. val=" + JSON.stringify(val));
  };
});

// node_modules/jsonwebtoken/lib/timespan.js
var require_timespan = __commonJS((exports, module) => {
  var ms = require_ms();
  module.exports = function(time, iat) {
    var timestamp = iat || Math.floor(Date.now() / 1000);
    if (typeof time === "string") {
      var milliseconds = ms(time);
      if (typeof milliseconds === "undefined") {
        return;
      }
      return Math.floor(timestamp + milliseconds / 1000);
    } else if (typeof time === "number") {
      return timestamp + time;
    } else {
      return;
    }
  };
});

// node_modules/semver/internal/constants.js
var require_constants = __commonJS((exports, module) => {
  var SEMVER_SPEC_VERSION = "2.0.0";
  var MAX_LENGTH = 256;
  var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;
  var MAX_SAFE_COMPONENT_LENGTH = 16;
  var MAX_SAFE_BUILD_LENGTH = MAX_LENGTH - 6;
  var RELEASE_TYPES = [
    "major",
    "premajor",
    "minor",
    "preminor",
    "patch",
    "prepatch",
    "prerelease"
  ];
  module.exports = {
    MAX_LENGTH,
    MAX_SAFE_COMPONENT_LENGTH,
    MAX_SAFE_BUILD_LENGTH,
    MAX_SAFE_INTEGER,
    RELEASE_TYPES,
    SEMVER_SPEC_VERSION,
    FLAG_INCLUDE_PRERELEASE: 1,
    FLAG_LOOSE: 2
  };
});

// node_modules/semver/internal/debug.js
var require_debug = __commonJS((exports, module) => {
  var debug = typeof process === "object" && process.env && process.env.NODE_DEBUG && /\bsemver\b/i.test(process.env.NODE_DEBUG) ? (...args) => console.error("SEMVER", ...args) : () => {
  };
  module.exports = debug;
});

// node_modules/semver/internal/re.js
var require_re = __commonJS((exports, module) => {
  var {
    MAX_SAFE_COMPONENT_LENGTH,
    MAX_SAFE_BUILD_LENGTH,
    MAX_LENGTH
  } = require_constants();
  var debug = require_debug();
  exports = module.exports = {};
  var re = exports.re = [];
  var safeRe = exports.safeRe = [];
  var src = exports.src = [];
  var t = exports.t = {};
  var R = 0;
  var LETTERDASHNUMBER = "[a-zA-Z0-9-]";
  var safeRegexReplacements = [
    ["\\s", 1],
    ["\\d", MAX_LENGTH],
    [LETTERDASHNUMBER, MAX_SAFE_BUILD_LENGTH]
  ];
  var makeSafeRegex = (value) => {
    for (const [token, max] of safeRegexReplacements) {
      value = value.split(`${token}*`).join(`${token}{0,${max}}`).split(`${token}+`).join(`${token}{1,${max}}`);
    }
    return value;
  };
  var createToken = (name, value, isGlobal) => {
    const safe = makeSafeRegex(value);
    const index = R++;
    debug(name, index, value);
    t[name] = index;
    src[index] = value;
    re[index] = new RegExp(value, isGlobal ? "g" : undefined);
    safeRe[index] = new RegExp(safe, isGlobal ? "g" : undefined);
  };
  createToken("NUMERICIDENTIFIER", "0|[1-9]\\d*");
  createToken("NUMERICIDENTIFIERLOOSE", "\\d+");
  createToken("NONNUMERICIDENTIFIER", `\\d*[a-zA-Z-]${LETTERDASHNUMBER}*`);
  createToken("MAINVERSION", `(${src[t.NUMERICIDENTIFIER]})\\.` + `(${src[t.NUMERICIDENTIFIER]})\\.` + `(${src[t.NUMERICIDENTIFIER]})`);
  createToken("MAINVERSIONLOOSE", `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.` + `(${src[t.NUMERICIDENTIFIERLOOSE]})\\.` + `(${src[t.NUMERICIDENTIFIERLOOSE]})`);
  createToken("PRERELEASEIDENTIFIER", `(?:${src[t.NUMERICIDENTIFIER]}|${src[t.NONNUMERICIDENTIFIER]})`);
  createToken("PRERELEASEIDENTIFIERLOOSE", `(?:${src[t.NUMERICIDENTIFIERLOOSE]}|${src[t.NONNUMERICIDENTIFIER]})`);
  createToken("PRERELEASE", `(?:-(${src[t.PRERELEASEIDENTIFIER]}(?:\\.${src[t.PRERELEASEIDENTIFIER]})*))`);
  createToken("PRERELEASELOOSE", `(?:-?(${src[t.PRERELEASEIDENTIFIERLOOSE]}(?:\\.${src[t.PRERELEASEIDENTIFIERLOOSE]})*))`);
  createToken("BUILDIDENTIFIER", `${LETTERDASHNUMBER}+`);
  createToken("BUILD", `(?:\\+(${src[t.BUILDIDENTIFIER]}(?:\\.${src[t.BUILDIDENTIFIER]})*))`);
  createToken("FULLPLAIN", `v?${src[t.MAINVERSION]}${src[t.PRERELEASE]}?${src[t.BUILD]}?`);
  createToken("FULL", `^${src[t.FULLPLAIN]}\$`);
  createToken("LOOSEPLAIN", `[v=\\s]*${src[t.MAINVERSIONLOOSE]}${src[t.PRERELEASELOOSE]}?${src[t.BUILD]}?`);
  createToken("LOOSE", `^${src[t.LOOSEPLAIN]}\$`);
  createToken("GTLT", "((?:<|>)?=?)");
  createToken("XRANGEIDENTIFIERLOOSE", `${src[t.NUMERICIDENTIFIERLOOSE]}|x|X|\\*`);
  createToken("XRANGEIDENTIFIER", `${src[t.NUMERICIDENTIFIER]}|x|X|\\*`);
  createToken("XRANGEPLAIN", `[v=\\s]*(${src[t.XRANGEIDENTIFIER]})` + `(?:\\.(${src[t.XRANGEIDENTIFIER]})` + `(?:\\.(${src[t.XRANGEIDENTIFIER]})` + `(?:${src[t.PRERELEASE]})?${src[t.BUILD]}?` + `)?)?`);
  createToken("XRANGEPLAINLOOSE", `[v=\\s]*(${src[t.XRANGEIDENTIFIERLOOSE]})` + `(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})` + `(?:\\.(${src[t.XRANGEIDENTIFIERLOOSE]})` + `(?:${src[t.PRERELEASELOOSE]})?${src[t.BUILD]}?` + `)?)?`);
  createToken("XRANGE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAIN]}\$`);
  createToken("XRANGELOOSE", `^${src[t.GTLT]}\\s*${src[t.XRANGEPLAINLOOSE]}\$`);
  createToken("COERCEPLAIN", `${"(^|[^\\d])" + "(\\d{1,"}${MAX_SAFE_COMPONENT_LENGTH}})` + `(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?` + `(?:\\.(\\d{1,${MAX_SAFE_COMPONENT_LENGTH}}))?`);
  createToken("COERCE", `${src[t.COERCEPLAIN]}(?:\$|[^\\d])`);
  createToken("COERCEFULL", src[t.COERCEPLAIN] + `(?:${src[t.PRERELEASE]})?` + `(?:${src[t.BUILD]})?` + `(?:\$|[^\\d])`);
  createToken("COERCERTL", src[t.COERCE], true);
  createToken("COERCERTLFULL", src[t.COERCEFULL], true);
  createToken("LONETILDE", "(?:~>?)");
  createToken("TILDETRIM", `(\\s*)${src[t.LONETILDE]}\\s+`, true);
  exports.tildeTrimReplace = "$1~";
  createToken("TILDE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAIN]}\$`);
  createToken("TILDELOOSE", `^${src[t.LONETILDE]}${src[t.XRANGEPLAINLOOSE]}\$`);
  createToken("LONECARET", "(?:\\^)");
  createToken("CARETTRIM", `(\\s*)${src[t.LONECARET]}\\s+`, true);
  exports.caretTrimReplace = "$1^";
  createToken("CARET", `^${src[t.LONECARET]}${src[t.XRANGEPLAIN]}\$`);
  createToken("CARETLOOSE", `^${src[t.LONECARET]}${src[t.XRANGEPLAINLOOSE]}\$`);
  createToken("COMPARATORLOOSE", `^${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]})\$|^\$`);
  createToken("COMPARATOR", `^${src[t.GTLT]}\\s*(${src[t.FULLPLAIN]})\$|^\$`);
  createToken("COMPARATORTRIM", `(\\s*)${src[t.GTLT]}\\s*(${src[t.LOOSEPLAIN]}|${src[t.XRANGEPLAIN]})`, true);
  exports.comparatorTrimReplace = "$1$2$3";
  createToken("HYPHENRANGE", `^\\s*(${src[t.XRANGEPLAIN]})` + `\\s+-\\s+` + `(${src[t.XRANGEPLAIN]})` + `\\s*\$`);
  createToken("HYPHENRANGELOOSE", `^\\s*(${src[t.XRANGEPLAINLOOSE]})` + `\\s+-\\s+` + `(${src[t.XRANGEPLAINLOOSE]})` + `\\s*\$`);
  createToken("STAR", "(<|>)?=?\\s*\\*");
  createToken("GTE0", "^\\s*>=\\s*0\\.0\\.0\\s*$");
  createToken("GTE0PRE", "^\\s*>=\\s*0\\.0\\.0-0\\s*$");
});

// node_modules/semver/internal/parse-options.js
var require_parse_options = __commonJS((exports, module) => {
  var looseOption = Object.freeze({ loose: true });
  var emptyOpts = Object.freeze({});
  var parseOptions = (options2) => {
    if (!options2) {
      return emptyOpts;
    }
    if (typeof options2 !== "object") {
      return looseOption;
    }
    return options2;
  };
  module.exports = parseOptions;
});

// node_modules/semver/internal/identifiers.js
var require_identifiers = __commonJS((exports, module) => {
  var numeric = /^[0-9]+$/;
  var compareIdentifiers = (a, b) => {
    const anum = numeric.test(a);
    const bnum = numeric.test(b);
    if (anum && bnum) {
      a = +a;
      b = +b;
    }
    return a === b ? 0 : anum && !bnum ? -1 : bnum && !anum ? 1 : a < b ? -1 : 1;
  };
  var rcompareIdentifiers = (a, b) => compareIdentifiers(b, a);
  module.exports = {
    compareIdentifiers,
    rcompareIdentifiers
  };
});

// node_modules/semver/classes/semver.js
var require_semver = __commonJS((exports, module) => {
  var debug = require_debug();
  var { MAX_LENGTH, MAX_SAFE_INTEGER } = require_constants();
  var { safeRe: re, t } = require_re();
  var parseOptions = require_parse_options();
  var { compareIdentifiers } = require_identifiers();

  class SemVer {
    constructor(version4, options2) {
      options2 = parseOptions(options2);
      if (version4 instanceof SemVer) {
        if (version4.loose === !!options2.loose && version4.includePrerelease === !!options2.includePrerelease) {
          return version4;
        } else {
          version4 = version4.version;
        }
      } else if (typeof version4 !== "string") {
        throw new TypeError(`Invalid version. Must be a string. Got type "${typeof version4}".`);
      }
      if (version4.length > MAX_LENGTH) {
        throw new TypeError(`version is longer than ${MAX_LENGTH} characters`);
      }
      debug("SemVer", version4, options2);
      this.options = options2;
      this.loose = !!options2.loose;
      this.includePrerelease = !!options2.includePrerelease;
      const m = version4.trim().match(options2.loose ? re[t.LOOSE] : re[t.FULL]);
      if (!m) {
        throw new TypeError(`Invalid Version: ${version4}`);
      }
      this.raw = version4;
      this.major = +m[1];
      this.minor = +m[2];
      this.patch = +m[3];
      if (this.major > MAX_SAFE_INTEGER || this.major < 0) {
        throw new TypeError("Invalid major version");
      }
      if (this.minor > MAX_SAFE_INTEGER || this.minor < 0) {
        throw new TypeError("Invalid minor version");
      }
      if (this.patch > MAX_SAFE_INTEGER || this.patch < 0) {
        throw new TypeError("Invalid patch version");
      }
      if (!m[4]) {
        this.prerelease = [];
      } else {
        this.prerelease = m[4].split(".").map((id) => {
          if (/^[0-9]+$/.test(id)) {
            const num2 = +id;
            if (num2 >= 0 && num2 < MAX_SAFE_INTEGER) {
              return num2;
            }
          }
          return id;
        });
      }
      this.build = m[5] ? m[5].split(".") : [];
      this.format();
    }
    format() {
      this.version = `${this.major}.${this.minor}.${this.patch}`;
      if (this.prerelease.length) {
        this.version += `-${this.prerelease.join(".")}`;
      }
      return this.version;
    }
    toString() {
      return this.version;
    }
    compare(other) {
      debug("SemVer.compare", this.version, this.options, other);
      if (!(other instanceof SemVer)) {
        if (typeof other === "string" && other === this.version) {
          return 0;
        }
        other = new SemVer(other, this.options);
      }
      if (other.version === this.version) {
        return 0;
      }
      return this.compareMain(other) || this.comparePre(other);
    }
    compareMain(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      return compareIdentifiers(this.major, other.major) || compareIdentifiers(this.minor, other.minor) || compareIdentifiers(this.patch, other.patch);
    }
    comparePre(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      if (this.prerelease.length && !other.prerelease.length) {
        return -1;
      } else if (!this.prerelease.length && other.prerelease.length) {
        return 1;
      } else if (!this.prerelease.length && !other.prerelease.length) {
        return 0;
      }
      let i = 0;
      do {
        const a = this.prerelease[i];
        const b = other.prerelease[i];
        debug("prerelease compare", i, a, b);
        if (a === undefined && b === undefined) {
          return 0;
        } else if (b === undefined) {
          return 1;
        } else if (a === undefined) {
          return -1;
        } else if (a === b) {
          continue;
        } else {
          return compareIdentifiers(a, b);
        }
      } while (++i);
    }
    compareBuild(other) {
      if (!(other instanceof SemVer)) {
        other = new SemVer(other, this.options);
      }
      let i = 0;
      do {
        const a = this.build[i];
        const b = other.build[i];
        debug("build compare", i, a, b);
        if (a === undefined && b === undefined) {
          return 0;
        } else if (b === undefined) {
          return 1;
        } else if (a === undefined) {
          return -1;
        } else if (a === b) {
          continue;
        } else {
          return compareIdentifiers(a, b);
        }
      } while (++i);
    }
    inc(release, identifier, identifierBase) {
      switch (release) {
        case "premajor":
          this.prerelease.length = 0;
          this.patch = 0;
          this.minor = 0;
          this.major++;
          this.inc("pre", identifier, identifierBase);
          break;
        case "preminor":
          this.prerelease.length = 0;
          this.patch = 0;
          this.minor++;
          this.inc("pre", identifier, identifierBase);
          break;
        case "prepatch":
          this.prerelease.length = 0;
          this.inc("patch", identifier, identifierBase);
          this.inc("pre", identifier, identifierBase);
          break;
        case "prerelease":
          if (this.prerelease.length === 0) {
            this.inc("patch", identifier, identifierBase);
          }
          this.inc("pre", identifier, identifierBase);
          break;
        case "major":
          if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0) {
            this.major++;
          }
          this.minor = 0;
          this.patch = 0;
          this.prerelease = [];
          break;
        case "minor":
          if (this.patch !== 0 || this.prerelease.length === 0) {
            this.minor++;
          }
          this.patch = 0;
          this.prerelease = [];
          break;
        case "patch":
          if (this.prerelease.length === 0) {
            this.patch++;
          }
          this.prerelease = [];
          break;
        case "pre": {
          const base = Number(identifierBase) ? 1 : 0;
          if (!identifier && identifierBase === false) {
            throw new Error("invalid increment argument: identifier is empty");
          }
          if (this.prerelease.length === 0) {
            this.prerelease = [base];
          } else {
            let i = this.prerelease.length;
            while (--i >= 0) {
              if (typeof this.prerelease[i] === "number") {
                this.prerelease[i]++;
                i = -2;
              }
            }
            if (i === -1) {
              if (identifier === this.prerelease.join(".") && identifierBase === false) {
                throw new Error("invalid increment argument: identifier already exists");
              }
              this.prerelease.push(base);
            }
          }
          if (identifier) {
            let prerelease = [identifier, base];
            if (identifierBase === false) {
              prerelease = [identifier];
            }
            if (compareIdentifiers(this.prerelease[0], identifier) === 0) {
              if (isNaN(this.prerelease[1])) {
                this.prerelease = prerelease;
              }
            } else {
              this.prerelease = prerelease;
            }
          }
          break;
        }
        default:
          throw new Error(`invalid increment argument: ${release}`);
      }
      this.raw = this.format();
      if (this.build.length) {
        this.raw += `+${this.build.join(".")}`;
      }
      return this;
    }
  }
  module.exports = SemVer;
});

// node_modules/semver/functions/parse.js
var require_parse2 = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var parse2 = (version4, options2, throwErrors = false) => {
    if (version4 instanceof SemVer) {
      return version4;
    }
    try {
      return new SemVer(version4, options2);
    } catch (er) {
      if (!throwErrors) {
        return null;
      }
      throw er;
    }
  };
  module.exports = parse2;
});

// node_modules/semver/functions/valid.js
var require_valid = __commonJS((exports, module) => {
  var parse2 = require_parse2();
  var valid = (version4, options2) => {
    const v = parse2(version4, options2);
    return v ? v.version : null;
  };
  module.exports = valid;
});

// node_modules/semver/functions/clean.js
var require_clean = __commonJS((exports, module) => {
  var parse2 = require_parse2();
  var clean = (version4, options2) => {
    const s = parse2(version4.trim().replace(/^[=v]+/, ""), options2);
    return s ? s.version : null;
  };
  module.exports = clean;
});

// node_modules/semver/functions/inc.js
var require_inc = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var inc = (version4, release, options2, identifier, identifierBase) => {
    if (typeof options2 === "string") {
      identifierBase = identifier;
      identifier = options2;
      options2 = undefined;
    }
    try {
      return new SemVer(version4 instanceof SemVer ? version4.version : version4, options2).inc(release, identifier, identifierBase).version;
    } catch (er) {
      return null;
    }
  };
  module.exports = inc;
});

// node_modules/semver/functions/diff.js
var require_diff = __commonJS((exports, module) => {
  var parse2 = require_parse2();
  var diff = (version1, version22) => {
    const v12 = parse2(version1, null, true);
    const v2 = parse2(version22, null, true);
    const comparison = v12.compare(v2);
    if (comparison === 0) {
      return null;
    }
    const v1Higher = comparison > 0;
    const highVersion = v1Higher ? v12 : v2;
    const lowVersion = v1Higher ? v2 : v12;
    const highHasPre = !!highVersion.prerelease.length;
    const lowHasPre = !!lowVersion.prerelease.length;
    if (lowHasPre && !highHasPre) {
      if (!lowVersion.patch && !lowVersion.minor) {
        return "major";
      }
      if (highVersion.patch) {
        return "patch";
      }
      if (highVersion.minor) {
        return "minor";
      }
      return "major";
    }
    const prefix = highHasPre ? "pre" : "";
    if (v12.major !== v2.major) {
      return prefix + "major";
    }
    if (v12.minor !== v2.minor) {
      return prefix + "minor";
    }
    if (v12.patch !== v2.patch) {
      return prefix + "patch";
    }
    return "prerelease";
  };
  module.exports = diff;
});

// node_modules/semver/functions/major.js
var require_major = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var major = (a, loose) => new SemVer(a, loose).major;
  module.exports = major;
});

// node_modules/semver/functions/minor.js
var require_minor = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var minor = (a, loose) => new SemVer(a, loose).minor;
  module.exports = minor;
});

// node_modules/semver/functions/patch.js
var require_patch = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var patch = (a, loose) => new SemVer(a, loose).patch;
  module.exports = patch;
});

// node_modules/semver/functions/prerelease.js
var require_prerelease = __commonJS((exports, module) => {
  var parse2 = require_parse2();
  var prerelease = (version4, options2) => {
    const parsed = parse2(version4, options2);
    return parsed && parsed.prerelease.length ? parsed.prerelease : null;
  };
  module.exports = prerelease;
});

// node_modules/semver/functions/compare.js
var require_compare = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var compare = (a, b, loose) => new SemVer(a, loose).compare(new SemVer(b, loose));
  module.exports = compare;
});

// node_modules/semver/functions/rcompare.js
var require_rcompare = __commonJS((exports, module) => {
  var compare = require_compare();
  var rcompare = (a, b, loose) => compare(b, a, loose);
  module.exports = rcompare;
});

// node_modules/semver/functions/compare-loose.js
var require_compare_loose = __commonJS((exports, module) => {
  var compare = require_compare();
  var compareLoose = (a, b) => compare(a, b, true);
  module.exports = compareLoose;
});

// node_modules/semver/functions/compare-build.js
var require_compare_build = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var compareBuild = (a, b, loose) => {
    const versionA = new SemVer(a, loose);
    const versionB = new SemVer(b, loose);
    return versionA.compare(versionB) || versionA.compareBuild(versionB);
  };
  module.exports = compareBuild;
});

// node_modules/semver/functions/sort.js
var require_sort = __commonJS((exports, module) => {
  var compareBuild = require_compare_build();
  var sort2 = (list2, loose) => list2.sort((a, b) => compareBuild(a, b, loose));
  module.exports = sort2;
});

// node_modules/semver/functions/rsort.js
var require_rsort = __commonJS((exports, module) => {
  var compareBuild = require_compare_build();
  var rsort = (list2, loose) => list2.sort((a, b) => compareBuild(b, a, loose));
  module.exports = rsort;
});

// node_modules/semver/functions/gt.js
var require_gt = __commonJS((exports, module) => {
  var compare = require_compare();
  var gt2 = (a, b, loose) => compare(a, b, loose) > 0;
  module.exports = gt2;
});

// node_modules/semver/functions/lt.js
var require_lt = __commonJS((exports, module) => {
  var compare = require_compare();
  var lt2 = (a, b, loose) => compare(a, b, loose) < 0;
  module.exports = lt2;
});

// node_modules/semver/functions/eq.js
var require_eq = __commonJS((exports, module) => {
  var compare = require_compare();
  var eq2 = (a, b, loose) => compare(a, b, loose) === 0;
  module.exports = eq2;
});

// node_modules/semver/functions/neq.js
var require_neq = __commonJS((exports, module) => {
  var compare = require_compare();
  var neq = (a, b, loose) => compare(a, b, loose) !== 0;
  module.exports = neq;
});

// node_modules/semver/functions/gte.js
var require_gte = __commonJS((exports, module) => {
  var compare = require_compare();
  var gte2 = (a, b, loose) => compare(a, b, loose) >= 0;
  module.exports = gte2;
});

// node_modules/semver/functions/lte.js
var require_lte = __commonJS((exports, module) => {
  var compare = require_compare();
  var lte2 = (a, b, loose) => compare(a, b, loose) <= 0;
  module.exports = lte2;
});

// node_modules/semver/functions/cmp.js
var require_cmp = __commonJS((exports, module) => {
  var eq2 = require_eq();
  var neq = require_neq();
  var gt2 = require_gt();
  var gte2 = require_gte();
  var lt2 = require_lt();
  var lte2 = require_lte();
  var cmp = (a, op, b, loose) => {
    switch (op) {
      case "===":
        if (typeof a === "object") {
          a = a.version;
        }
        if (typeof b === "object") {
          b = b.version;
        }
        return a === b;
      case "!==":
        if (typeof a === "object") {
          a = a.version;
        }
        if (typeof b === "object") {
          b = b.version;
        }
        return a !== b;
      case "":
      case "=":
      case "==":
        return eq2(a, b, loose);
      case "!=":
        return neq(a, b, loose);
      case ">":
        return gt2(a, b, loose);
      case ">=":
        return gte2(a, b, loose);
      case "<":
        return lt2(a, b, loose);
      case "<=":
        return lte2(a, b, loose);
      default:
        throw new TypeError(`Invalid operator: ${op}`);
    }
  };
  module.exports = cmp;
});

// node_modules/semver/functions/coerce.js
var require_coerce = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var parse2 = require_parse2();
  var { safeRe: re, t } = require_re();
  var coerce = (version4, options2) => {
    if (version4 instanceof SemVer) {
      return version4;
    }
    if (typeof version4 === "number") {
      version4 = String(version4);
    }
    if (typeof version4 !== "string") {
      return null;
    }
    options2 = options2 || {};
    let match = null;
    if (!options2.rtl) {
      match = version4.match(options2.includePrerelease ? re[t.COERCEFULL] : re[t.COERCE]);
    } else {
      const coerceRtlRegex = options2.includePrerelease ? re[t.COERCERTLFULL] : re[t.COERCERTL];
      let next;
      while ((next = coerceRtlRegex.exec(version4)) && (!match || match.index + match[0].length !== version4.length)) {
        if (!match || next.index + next[0].length !== match.index + match[0].length) {
          match = next;
        }
        coerceRtlRegex.lastIndex = next.index + next[1].length + next[2].length;
      }
      coerceRtlRegex.lastIndex = -1;
    }
    if (match === null) {
      return null;
    }
    const major = match[2];
    const minor = match[3] || "0";
    const patch = match[4] || "0";
    const prerelease = options2.includePrerelease && match[5] ? `-${match[5]}` : "";
    const build = options2.includePrerelease && match[6] ? `+${match[6]}` : "";
    return parse2(`${major}.${minor}.${patch}${prerelease}${build}`, options2);
  };
  module.exports = coerce;
});

// node_modules/semver/internal/lrucache.js
var require_lrucache = __commonJS((exports, module) => {
  class LRUCache {
    constructor() {
      this.max = 1000;
      this.map = new Map;
    }
    get(key) {
      const value = this.map.get(key);
      if (value === undefined) {
        return;
      } else {
        this.map.delete(key);
        this.map.set(key, value);
        return value;
      }
    }
    delete(key) {
      return this.map.delete(key);
    }
    set(key, value) {
      const deleted = this.delete(key);
      if (!deleted && value !== undefined) {
        if (this.map.size >= this.max) {
          const firstKey = this.map.keys().next().value;
          this.delete(firstKey);
        }
        this.map.set(key, value);
      }
      return this;
    }
  }
  module.exports = LRUCache;
});

// node_modules/semver/classes/range.js
var require_range = __commonJS((exports, module) => {
  class Range {
    constructor(range2, options2) {
      options2 = parseOptions(options2);
      if (range2 instanceof Range) {
        if (range2.loose === !!options2.loose && range2.includePrerelease === !!options2.includePrerelease) {
          return range2;
        } else {
          return new Range(range2.raw, options2);
        }
      }
      if (range2 instanceof Comparator) {
        this.raw = range2.value;
        this.set = [[range2]];
        this.format();
        return this;
      }
      this.options = options2;
      this.loose = !!options2.loose;
      this.includePrerelease = !!options2.includePrerelease;
      this.raw = range2.trim().split(/\s+/).join(" ");
      this.set = this.raw.split("||").map((r) => this.parseRange(r.trim())).filter((c) => c.length);
      if (!this.set.length) {
        throw new TypeError(`Invalid SemVer Range: ${this.raw}`);
      }
      if (this.set.length > 1) {
        const first2 = this.set[0];
        this.set = this.set.filter((c) => !isNullSet(c[0]));
        if (this.set.length === 0) {
          this.set = [first2];
        } else if (this.set.length > 1) {
          for (const c of this.set) {
            if (c.length === 1 && isAny(c[0])) {
              this.set = [c];
              break;
            }
          }
        }
      }
      this.format();
    }
    format() {
      this.range = this.set.map((comps) => comps.join(" ").trim()).join("||").trim();
      return this.range;
    }
    toString() {
      return this.range;
    }
    parseRange(range2) {
      const memoOpts = (this.options.includePrerelease && FLAG_INCLUDE_PRERELEASE) | (this.options.loose && FLAG_LOOSE);
      const memoKey = memoOpts + ":" + range2;
      const cached = cache.get(memoKey);
      if (cached) {
        return cached;
      }
      const loose = this.options.loose;
      const hr2 = loose ? re[t.HYPHENRANGELOOSE] : re[t.HYPHENRANGE];
      range2 = range2.replace(hr2, hyphenReplace(this.options.includePrerelease));
      debug("hyphen replace", range2);
      range2 = range2.replace(re[t.COMPARATORTRIM], comparatorTrimReplace);
      debug("comparator trim", range2);
      range2 = range2.replace(re[t.TILDETRIM], tildeTrimReplace);
      debug("tilde trim", range2);
      range2 = range2.replace(re[t.CARETTRIM], caretTrimReplace);
      debug("caret trim", range2);
      let rangeList = range2.split(" ").map((comp) => parseComparator(comp, this.options)).join(" ").split(/\s+/).map((comp) => replaceGTE0(comp, this.options));
      if (loose) {
        rangeList = rangeList.filter((comp) => {
          debug("loose invalid filter", comp, this.options);
          return !!comp.match(re[t.COMPARATORLOOSE]);
        });
      }
      debug("range list", rangeList);
      const rangeMap = new Map;
      const comparators = rangeList.map((comp) => new Comparator(comp, this.options));
      for (const comp of comparators) {
        if (isNullSet(comp)) {
          return [comp];
        }
        rangeMap.set(comp.value, comp);
      }
      if (rangeMap.size > 1 && rangeMap.has("")) {
        rangeMap.delete("");
      }
      const result = [...rangeMap.values()];
      cache.set(memoKey, result);
      return result;
    }
    intersects(range2, options2) {
      if (!(range2 instanceof Range)) {
        throw new TypeError("a Range is required");
      }
      return this.set.some((thisComparators) => {
        return isSatisfiable(thisComparators, options2) && range2.set.some((rangeComparators) => {
          return isSatisfiable(rangeComparators, options2) && thisComparators.every((thisComparator) => {
            return rangeComparators.every((rangeComparator) => {
              return thisComparator.intersects(rangeComparator, options2);
            });
          });
        });
      });
    }
    test(version4) {
      if (!version4) {
        return false;
      }
      if (typeof version4 === "string") {
        try {
          version4 = new SemVer(version4, this.options);
        } catch (er) {
          return false;
        }
      }
      for (let i = 0;i < this.set.length; i++) {
        if (testSet(this.set[i], version4, this.options)) {
          return true;
        }
      }
      return false;
    }
  }
  module.exports = Range;
  var LRU2 = require_lrucache();
  var cache = new LRU2;
  var parseOptions = require_parse_options();
  var Comparator = require_comparator();
  var debug = require_debug();
  var SemVer = require_semver();
  var {
    safeRe: re,
    t,
    comparatorTrimReplace,
    tildeTrimReplace,
    caretTrimReplace
  } = require_re();
  var { FLAG_INCLUDE_PRERELEASE, FLAG_LOOSE } = require_constants();
  var isNullSet = (c) => c.value === "<0.0.0-0";
  var isAny = (c) => c.value === "";
  var isSatisfiable = (comparators, options2) => {
    let result = true;
    const remainingComparators = comparators.slice();
    let testComparator = remainingComparators.pop();
    while (result && remainingComparators.length) {
      result = remainingComparators.every((otherComparator) => {
        return testComparator.intersects(otherComparator, options2);
      });
      testComparator = remainingComparators.pop();
    }
    return result;
  };
  var parseComparator = (comp, options2) => {
    debug("comp", comp, options2);
    comp = replaceCarets(comp, options2);
    debug("caret", comp);
    comp = replaceTildes(comp, options2);
    debug("tildes", comp);
    comp = replaceXRanges(comp, options2);
    debug("xrange", comp);
    comp = replaceStars(comp, options2);
    debug("stars", comp);
    return comp;
  };
  var isX = (id) => !id || id.toLowerCase() === "x" || id === "*";
  var replaceTildes = (comp, options2) => {
    return comp.trim().split(/\s+/).map((c) => replaceTilde(c, options2)).join(" ");
  };
  var replaceTilde = (comp, options2) => {
    const r = options2.loose ? re[t.TILDELOOSE] : re[t.TILDE];
    return comp.replace(r, (_, M, m, p, pr) => {
      debug("tilde", comp, _, M, m, p, pr);
      let ret;
      if (isX(M)) {
        ret = "";
      } else if (isX(m)) {
        ret = `>=${M}.0.0 <${+M + 1}.0.0-0`;
      } else if (isX(p)) {
        ret = `>=${M}.${m}.0 <${M}.${+m + 1}.0-0`;
      } else if (pr) {
        debug("replaceTilde pr", pr);
        ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
      } else {
        ret = `>=${M}.${m}.${p} <${M}.${+m + 1}.0-0`;
      }
      debug("tilde return", ret);
      return ret;
    });
  };
  var replaceCarets = (comp, options2) => {
    return comp.trim().split(/\s+/).map((c) => replaceCaret(c, options2)).join(" ");
  };
  var replaceCaret = (comp, options2) => {
    debug("caret", comp, options2);
    const r = options2.loose ? re[t.CARETLOOSE] : re[t.CARET];
    const z = options2.includePrerelease ? "-0" : "";
    return comp.replace(r, (_, M, m, p, pr) => {
      debug("caret", comp, _, M, m, p, pr);
      let ret;
      if (isX(M)) {
        ret = "";
      } else if (isX(m)) {
        ret = `>=${M}.0.0${z} <${+M + 1}.0.0-0`;
      } else if (isX(p)) {
        if (M === "0") {
          ret = `>=${M}.${m}.0${z} <${M}.${+m + 1}.0-0`;
        } else {
          ret = `>=${M}.${m}.0${z} <${+M + 1}.0.0-0`;
        }
      } else if (pr) {
        debug("replaceCaret pr", pr);
        if (M === "0") {
          if (m === "0") {
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${m}.${+p + 1}-0`;
          } else {
            ret = `>=${M}.${m}.${p}-${pr} <${M}.${+m + 1}.0-0`;
          }
        } else {
          ret = `>=${M}.${m}.${p}-${pr} <${+M + 1}.0.0-0`;
        }
      } else {
        debug("no pr");
        if (M === "0") {
          if (m === "0") {
            ret = `>=${M}.${m}.${p}${z} <${M}.${m}.${+p + 1}-0`;
          } else {
            ret = `>=${M}.${m}.${p}${z} <${M}.${+m + 1}.0-0`;
          }
        } else {
          ret = `>=${M}.${m}.${p} <${+M + 1}.0.0-0`;
        }
      }
      debug("caret return", ret);
      return ret;
    });
  };
  var replaceXRanges = (comp, options2) => {
    debug("replaceXRanges", comp, options2);
    return comp.split(/\s+/).map((c) => replaceXRange(c, options2)).join(" ");
  };
  var replaceXRange = (comp, options2) => {
    comp = comp.trim();
    const r = options2.loose ? re[t.XRANGELOOSE] : re[t.XRANGE];
    return comp.replace(r, (ret, gtlt, M, m, p, pr) => {
      debug("xRange", comp, ret, gtlt, M, m, p, pr);
      const xM = isX(M);
      const xm = xM || isX(m);
      const xp = xm || isX(p);
      const anyX = xp;
      if (gtlt === "=" && anyX) {
        gtlt = "";
      }
      pr = options2.includePrerelease ? "-0" : "";
      if (xM) {
        if (gtlt === ">" || gtlt === "<") {
          ret = "<0.0.0-0";
        } else {
          ret = "*";
        }
      } else if (gtlt && anyX) {
        if (xm) {
          m = 0;
        }
        p = 0;
        if (gtlt === ">") {
          gtlt = ">=";
          if (xm) {
            M = +M + 1;
            m = 0;
            p = 0;
          } else {
            m = +m + 1;
            p = 0;
          }
        } else if (gtlt === "<=") {
          gtlt = "<";
          if (xm) {
            M = +M + 1;
          } else {
            m = +m + 1;
          }
        }
        if (gtlt === "<") {
          pr = "-0";
        }
        ret = `${gtlt + M}.${m}.${p}${pr}`;
      } else if (xm) {
        ret = `>=${M}.0.0${pr} <${+M + 1}.0.0-0`;
      } else if (xp) {
        ret = `>=${M}.${m}.0${pr} <${M}.${+m + 1}.0-0`;
      }
      debug("xRange return", ret);
      return ret;
    });
  };
  var replaceStars = (comp, options2) => {
    debug("replaceStars", comp, options2);
    return comp.trim().replace(re[t.STAR], "");
  };
  var replaceGTE0 = (comp, options2) => {
    debug("replaceGTE0", comp, options2);
    return comp.trim().replace(re[options2.includePrerelease ? t.GTE0PRE : t.GTE0], "");
  };
  var hyphenReplace = (incPr) => ($0, from, fM, fm, fp, fpr, fb, to, tM, tm, tp, tpr) => {
    if (isX(fM)) {
      from = "";
    } else if (isX(fm)) {
      from = `>=${fM}.0.0${incPr ? "-0" : ""}`;
    } else if (isX(fp)) {
      from = `>=${fM}.${fm}.0${incPr ? "-0" : ""}`;
    } else if (fpr) {
      from = `>=${from}`;
    } else {
      from = `>=${from}${incPr ? "-0" : ""}`;
    }
    if (isX(tM)) {
      to = "";
    } else if (isX(tm)) {
      to = `<${+tM + 1}.0.0-0`;
    } else if (isX(tp)) {
      to = `<${tM}.${+tm + 1}.0-0`;
    } else if (tpr) {
      to = `<=${tM}.${tm}.${tp}-${tpr}`;
    } else if (incPr) {
      to = `<${tM}.${tm}.${+tp + 1}-0`;
    } else {
      to = `<=${to}`;
    }
    return `${from} ${to}`.trim();
  };
  var testSet = (set, version4, options2) => {
    for (let i = 0;i < set.length; i++) {
      if (!set[i].test(version4)) {
        return false;
      }
    }
    if (version4.prerelease.length && !options2.includePrerelease) {
      for (let i = 0;i < set.length; i++) {
        debug(set[i].semver);
        if (set[i].semver === Comparator.ANY) {
          continue;
        }
        if (set[i].semver.prerelease.length > 0) {
          const allowed = set[i].semver;
          if (allowed.major === version4.major && allowed.minor === version4.minor && allowed.patch === version4.patch) {
            return true;
          }
        }
      }
      return false;
    }
    return true;
  };
});

// node_modules/semver/classes/comparator.js
var require_comparator = __commonJS((exports, module) => {
  var ANY = Symbol("SemVer ANY");

  class Comparator {
    static get ANY() {
      return ANY;
    }
    constructor(comp, options2) {
      options2 = parseOptions(options2);
      if (comp instanceof Comparator) {
        if (comp.loose === !!options2.loose) {
          return comp;
        } else {
          comp = comp.value;
        }
      }
      comp = comp.trim().split(/\s+/).join(" ");
      debug("comparator", comp, options2);
      this.options = options2;
      this.loose = !!options2.loose;
      this.parse(comp);
      if (this.semver === ANY) {
        this.value = "";
      } else {
        this.value = this.operator + this.semver.version;
      }
      debug("comp", this);
    }
    parse(comp) {
      const r = this.options.loose ? re[t.COMPARATORLOOSE] : re[t.COMPARATOR];
      const m = comp.match(r);
      if (!m) {
        throw new TypeError(`Invalid comparator: ${comp}`);
      }
      this.operator = m[1] !== undefined ? m[1] : "";
      if (this.operator === "=") {
        this.operator = "";
      }
      if (!m[2]) {
        this.semver = ANY;
      } else {
        this.semver = new SemVer(m[2], this.options.loose);
      }
    }
    toString() {
      return this.value;
    }
    test(version4) {
      debug("Comparator.test", version4, this.options.loose);
      if (this.semver === ANY || version4 === ANY) {
        return true;
      }
      if (typeof version4 === "string") {
        try {
          version4 = new SemVer(version4, this.options);
        } catch (er) {
          return false;
        }
      }
      return cmp(version4, this.operator, this.semver, this.options);
    }
    intersects(comp, options2) {
      if (!(comp instanceof Comparator)) {
        throw new TypeError("a Comparator is required");
      }
      if (this.operator === "") {
        if (this.value === "") {
          return true;
        }
        return new Range(comp.value, options2).test(this.value);
      } else if (comp.operator === "") {
        if (comp.value === "") {
          return true;
        }
        return new Range(this.value, options2).test(comp.semver);
      }
      options2 = parseOptions(options2);
      if (options2.includePrerelease && (this.value === "<0.0.0-0" || comp.value === "<0.0.0-0")) {
        return false;
      }
      if (!options2.includePrerelease && (this.value.startsWith("<0.0.0") || comp.value.startsWith("<0.0.0"))) {
        return false;
      }
      if (this.operator.startsWith(">") && comp.operator.startsWith(">")) {
        return true;
      }
      if (this.operator.startsWith("<") && comp.operator.startsWith("<")) {
        return true;
      }
      if (this.semver.version === comp.semver.version && this.operator.includes("=") && comp.operator.includes("=")) {
        return true;
      }
      if (cmp(this.semver, "<", comp.semver, options2) && this.operator.startsWith(">") && comp.operator.startsWith("<")) {
        return true;
      }
      if (cmp(this.semver, ">", comp.semver, options2) && this.operator.startsWith("<") && comp.operator.startsWith(">")) {
        return true;
      }
      return false;
    }
  }
  module.exports = Comparator;
  var parseOptions = require_parse_options();
  var { safeRe: re, t } = require_re();
  var cmp = require_cmp();
  var debug = require_debug();
  var SemVer = require_semver();
  var Range = require_range();
});

// node_modules/semver/functions/satisfies.js
var require_satisfies = __commonJS((exports, module) => {
  var Range = require_range();
  var satisfies = (version4, range2, options2) => {
    try {
      range2 = new Range(range2, options2);
    } catch (er) {
      return false;
    }
    return range2.test(version4);
  };
  module.exports = satisfies;
});

// node_modules/semver/ranges/to-comparators.js
var require_to_comparators = __commonJS((exports, module) => {
  var Range = require_range();
  var toComparators = (range2, options2) => new Range(range2, options2).set.map((comp) => comp.map((c) => c.value).join(" ").trim().split(" "));
  module.exports = toComparators;
});

// node_modules/semver/ranges/max-satisfying.js
var require_max_satisfying = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var Range = require_range();
  var maxSatisfying = (versions, range2, options2) => {
    let max = null;
    let maxSV = null;
    let rangeObj = null;
    try {
      rangeObj = new Range(range2, options2);
    } catch (er) {
      return null;
    }
    versions.forEach((v) => {
      if (rangeObj.test(v)) {
        if (!max || maxSV.compare(v) === -1) {
          max = v;
          maxSV = new SemVer(max, options2);
        }
      }
    });
    return max;
  };
  module.exports = maxSatisfying;
});

// node_modules/semver/ranges/min-satisfying.js
var require_min_satisfying = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var Range = require_range();
  var minSatisfying = (versions, range2, options2) => {
    let min = null;
    let minSV = null;
    let rangeObj = null;
    try {
      rangeObj = new Range(range2, options2);
    } catch (er) {
      return null;
    }
    versions.forEach((v) => {
      if (rangeObj.test(v)) {
        if (!min || minSV.compare(v) === 1) {
          min = v;
          minSV = new SemVer(min, options2);
        }
      }
    });
    return min;
  };
  module.exports = minSatisfying;
});

// node_modules/semver/ranges/min-version.js
var require_min_version = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var Range = require_range();
  var gt2 = require_gt();
  var minVersion = (range2, loose) => {
    range2 = new Range(range2, loose);
    let minver = new SemVer("0.0.0");
    if (range2.test(minver)) {
      return minver;
    }
    minver = new SemVer("0.0.0-0");
    if (range2.test(minver)) {
      return minver;
    }
    minver = null;
    for (let i = 0;i < range2.set.length; ++i) {
      const comparators = range2.set[i];
      let setMin = null;
      comparators.forEach((comparator) => {
        const compver = new SemVer(comparator.semver.version);
        switch (comparator.operator) {
          case ">":
            if (compver.prerelease.length === 0) {
              compver.patch++;
            } else {
              compver.prerelease.push(0);
            }
            compver.raw = compver.format();
          case "":
          case ">=":
            if (!setMin || gt2(compver, setMin)) {
              setMin = compver;
            }
            break;
          case "<":
          case "<=":
            break;
          default:
            throw new Error(`Unexpected operation: ${comparator.operator}`);
        }
      });
      if (setMin && (!minver || gt2(minver, setMin))) {
        minver = setMin;
      }
    }
    if (minver && range2.test(minver)) {
      return minver;
    }
    return null;
  };
  module.exports = minVersion;
});

// node_modules/semver/ranges/valid.js
var require_valid2 = __commonJS((exports, module) => {
  var Range = require_range();
  var validRange = (range2, options2) => {
    try {
      return new Range(range2, options2).range || "*";
    } catch (er) {
      return null;
    }
  };
  module.exports = validRange;
});

// node_modules/semver/ranges/outside.js
var require_outside = __commonJS((exports, module) => {
  var SemVer = require_semver();
  var Comparator = require_comparator();
  var { ANY } = Comparator;
  var Range = require_range();
  var satisfies = require_satisfies();
  var gt2 = require_gt();
  var lt2 = require_lt();
  var lte2 = require_lte();
  var gte2 = require_gte();
  var outside = (version4, range2, hilo, options2) => {
    version4 = new SemVer(version4, options2);
    range2 = new Range(range2, options2);
    let gtfn, ltefn, ltfn, comp, ecomp;
    switch (hilo) {
      case ">":
        gtfn = gt2;
        ltefn = lte2;
        ltfn = lt2;
        comp = ">";
        ecomp = ">=";
        break;
      case "<":
        gtfn = lt2;
        ltefn = gte2;
        ltfn = gt2;
        comp = "<";
        ecomp = "<=";
        break;
      default:
        throw new TypeError('Must provide a hilo val of "<" or ">"');
    }
    if (satisfies(version4, range2, options2)) {
      return false;
    }
    for (let i = 0;i < range2.set.length; ++i) {
      const comparators = range2.set[i];
      let high = null;
      let low = null;
      comparators.forEach((comparator) => {
        if (comparator.semver === ANY) {
          comparator = new Comparator(">=0.0.0");
        }
        high = high || comparator;
        low = low || comparator;
        if (gtfn(comparator.semver, high.semver, options2)) {
          high = comparator;
        } else if (ltfn(comparator.semver, low.semver, options2)) {
          low = comparator;
        }
      });
      if (high.operator === comp || high.operator === ecomp) {
        return false;
      }
      if ((!low.operator || low.operator === comp) && ltefn(version4, low.semver)) {
        return false;
      } else if (low.operator === ecomp && ltfn(version4, low.semver)) {
        return false;
      }
    }
    return true;
  };
  module.exports = outside;
});

// node_modules/semver/ranges/gtr.js
var require_gtr = __commonJS((exports, module) => {
  var outside = require_outside();
  var gtr = (version4, range2, options2) => outside(version4, range2, ">", options2);
  module.exports = gtr;
});

// node_modules/semver/ranges/ltr.js
var require_ltr = __commonJS((exports, module) => {
  var outside = require_outside();
  var ltr = (version4, range2, options2) => outside(version4, range2, "<", options2);
  module.exports = ltr;
});

// node_modules/semver/ranges/intersects.js
var require_intersects = __commonJS((exports, module) => {
  var Range = require_range();
  var intersects = (r1, r2, options2) => {
    r1 = new Range(r1, options2);
    r2 = new Range(r2, options2);
    return r1.intersects(r2, options2);
  };
  module.exports = intersects;
});

// node_modules/semver/ranges/simplify.js
var require_simplify = __commonJS((exports, module) => {
  var satisfies = require_satisfies();
  var compare = require_compare();
  module.exports = (versions, range2, options2) => {
    const set = [];
    let first2 = null;
    let prev = null;
    const v = versions.sort((a, b) => compare(a, b, options2));
    for (const version4 of v) {
      const included = satisfies(version4, range2, options2);
      if (included) {
        prev = version4;
        if (!first2) {
          first2 = version4;
        }
      } else {
        if (prev) {
          set.push([first2, prev]);
        }
        prev = null;
        first2 = null;
      }
    }
    if (first2) {
      set.push([first2, null]);
    }
    const ranges = [];
    for (const [min, max] of set) {
      if (min === max) {
        ranges.push(min);
      } else if (!max && min === v[0]) {
        ranges.push("*");
      } else if (!max) {
        ranges.push(`>=${min}`);
      } else if (min === v[0]) {
        ranges.push(`<=${max}`);
      } else {
        ranges.push(`${min} - ${max}`);
      }
    }
    const simplified = ranges.join(" || ");
    const original = typeof range2.raw === "string" ? range2.raw : String(range2);
    return simplified.length < original.length ? simplified : range2;
  };
});

// node_modules/semver/ranges/subset.js
var require_subset = __commonJS((exports, module) => {
  var Range = require_range();
  var Comparator = require_comparator();
  var { ANY } = Comparator;
  var satisfies = require_satisfies();
  var compare = require_compare();
  var subset = (sub, dom, options2 = {}) => {
    if (sub === dom) {
      return true;
    }
    sub = new Range(sub, options2);
    dom = new Range(dom, options2);
    let sawNonNull = false;
    OUTER:
      for (const simpleSub of sub.set) {
        for (const simpleDom of dom.set) {
          const isSub = simpleSubset(simpleSub, simpleDom, options2);
          sawNonNull = sawNonNull || isSub !== null;
          if (isSub) {
            continue OUTER;
          }
        }
        if (sawNonNull) {
          return false;
        }
      }
    return true;
  };
  var minimumVersionWithPreRelease = [new Comparator(">=0.0.0-0")];
  var minimumVersion = [new Comparator(">=0.0.0")];
  var simpleSubset = (sub, dom, options2) => {
    if (sub === dom) {
      return true;
    }
    if (sub.length === 1 && sub[0].semver === ANY) {
      if (dom.length === 1 && dom[0].semver === ANY) {
        return true;
      } else if (options2.includePrerelease) {
        sub = minimumVersionWithPreRelease;
      } else {
        sub = minimumVersion;
      }
    }
    if (dom.length === 1 && dom[0].semver === ANY) {
      if (options2.includePrerelease) {
        return true;
      } else {
        dom = minimumVersion;
      }
    }
    const eqSet = new Set;
    let gt2, lt2;
    for (const c of sub) {
      if (c.operator === ">" || c.operator === ">=") {
        gt2 = higherGT(gt2, c, options2);
      } else if (c.operator === "<" || c.operator === "<=") {
        lt2 = lowerLT(lt2, c, options2);
      } else {
        eqSet.add(c.semver);
      }
    }
    if (eqSet.size > 1) {
      return null;
    }
    let gtltComp;
    if (gt2 && lt2) {
      gtltComp = compare(gt2.semver, lt2.semver, options2);
      if (gtltComp > 0) {
        return null;
      } else if (gtltComp === 0 && (gt2.operator !== ">=" || lt2.operator !== "<=")) {
        return null;
      }
    }
    for (const eq2 of eqSet) {
      if (gt2 && !satisfies(eq2, String(gt2), options2)) {
        return null;
      }
      if (lt2 && !satisfies(eq2, String(lt2), options2)) {
        return null;
      }
      for (const c of dom) {
        if (!satisfies(eq2, String(c), options2)) {
          return false;
        }
      }
      return true;
    }
    let higher, lower;
    let hasDomLT, hasDomGT;
    let needDomLTPre = lt2 && !options2.includePrerelease && lt2.semver.prerelease.length ? lt2.semver : false;
    let needDomGTPre = gt2 && !options2.includePrerelease && gt2.semver.prerelease.length ? gt2.semver : false;
    if (needDomLTPre && needDomLTPre.prerelease.length === 1 && lt2.operator === "<" && needDomLTPre.prerelease[0] === 0) {
      needDomLTPre = false;
    }
    for (const c of dom) {
      hasDomGT = hasDomGT || c.operator === ">" || c.operator === ">=";
      hasDomLT = hasDomLT || c.operator === "<" || c.operator === "<=";
      if (gt2) {
        if (needDomGTPre) {
          if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomGTPre.major && c.semver.minor === needDomGTPre.minor && c.semver.patch === needDomGTPre.patch) {
            needDomGTPre = false;
          }
        }
        if (c.operator === ">" || c.operator === ">=") {
          higher = higherGT(gt2, c, options2);
          if (higher === c && higher !== gt2) {
            return false;
          }
        } else if (gt2.operator === ">=" && !satisfies(gt2.semver, String(c), options2)) {
          return false;
        }
      }
      if (lt2) {
        if (needDomLTPre) {
          if (c.semver.prerelease && c.semver.prerelease.length && c.semver.major === needDomLTPre.major && c.semver.minor === needDomLTPre.minor && c.semver.patch === needDomLTPre.patch) {
            needDomLTPre = false;
          }
        }
        if (c.operator === "<" || c.operator === "<=") {
          lower = lowerLT(lt2, c, options2);
          if (lower === c && lower !== lt2) {
            return false;
          }
        } else if (lt2.operator === "<=" && !satisfies(lt2.semver, String(c), options2)) {
          return false;
        }
      }
      if (!c.operator && (lt2 || gt2) && gtltComp !== 0) {
        return false;
      }
    }
    if (gt2 && hasDomLT && !lt2 && gtltComp !== 0) {
      return false;
    }
    if (lt2 && hasDomGT && !gt2 && gtltComp !== 0) {
      return false;
    }
    if (needDomGTPre || needDomLTPre) {
      return false;
    }
    return true;
  };
  var higherGT = (a, b, options2) => {
    if (!a) {
      return b;
    }
    const comp = compare(a.semver, b.semver, options2);
    return comp > 0 ? a : comp < 0 ? b : b.operator === ">" && a.operator === ">=" ? b : a;
  };
  var lowerLT = (a, b, options2) => {
    if (!a) {
      return b;
    }
    const comp = compare(a.semver, b.semver, options2);
    return comp < 0 ? a : comp > 0 ? b : b.operator === "<" && a.operator === "<=" ? b : a;
  };
  module.exports = subset;
});

// node_modules/semver/index.js
var require_semver2 = __commonJS((exports, module) => {
  var internalRe = require_re();
  var constants = require_constants();
  var SemVer = require_semver();
  var identifiers = require_identifiers();
  var parse2 = require_parse2();
  var valid = require_valid();
  var clean = require_clean();
  var inc = require_inc();
  var diff = require_diff();
  var major = require_major();
  var minor = require_minor();
  var patch = require_patch();
  var prerelease = require_prerelease();
  var compare = require_compare();
  var rcompare = require_rcompare();
  var compareLoose = require_compare_loose();
  var compareBuild = require_compare_build();
  var sort2 = require_sort();
  var rsort = require_rsort();
  var gt2 = require_gt();
  var lt2 = require_lt();
  var eq2 = require_eq();
  var neq = require_neq();
  var gte2 = require_gte();
  var lte2 = require_lte();
  var cmp = require_cmp();
  var coerce = require_coerce();
  var Comparator = require_comparator();
  var Range = require_range();
  var satisfies = require_satisfies();
  var toComparators = require_to_comparators();
  var maxSatisfying = require_max_satisfying();
  var minSatisfying = require_min_satisfying();
  var minVersion = require_min_version();
  var validRange = require_valid2();
  var outside = require_outside();
  var gtr = require_gtr();
  var ltr = require_ltr();
  var intersects = require_intersects();
  var simplifyRange = require_simplify();
  var subset = require_subset();
  module.exports = {
    parse: parse2,
    valid,
    clean,
    inc,
    diff,
    major,
    minor,
    patch,
    prerelease,
    compare,
    rcompare,
    compareLoose,
    compareBuild,
    sort: sort2,
    rsort,
    gt: gt2,
    lt: lt2,
    eq: eq2,
    neq,
    gte: gte2,
    lte: lte2,
    cmp,
    coerce,
    Comparator,
    Range,
    satisfies,
    toComparators,
    maxSatisfying,
    minSatisfying,
    minVersion,
    validRange,
    outside,
    gtr,
    ltr,
    intersects,
    simplifyRange,
    subset,
    SemVer,
    re: internalRe.re,
    src: internalRe.src,
    tokens: internalRe.t,
    SEMVER_SPEC_VERSION: constants.SEMVER_SPEC_VERSION,
    RELEASE_TYPES: constants.RELEASE_TYPES,
    compareIdentifiers: identifiers.compareIdentifiers,
    rcompareIdentifiers: identifiers.rcompareIdentifiers
  };
});

// node_modules/jsonwebtoken/lib/asymmetricKeyDetailsSupported.js
var require_asymmetricKeyDetailsSupported = __commonJS((exports, module) => {
  var semver = require_semver2();
  module.exports = semver.satisfies(process.version, ">=15.7.0");
});

// node_modules/jsonwebtoken/lib/rsaPssKeyDetailsSupported.js
var require_rsaPssKeyDetailsSupported = __commonJS((exports, module) => {
  var semver = require_semver2();
  module.exports = semver.satisfies(process.version, ">=16.9.0");
});

// node_modules/jsonwebtoken/lib/validateAsymmetricKey.js
var require_validateAsymmetricKey = __commonJS((exports, module) => {
  var ASYMMETRIC_KEY_DETAILS_SUPPORTED = require_asymmetricKeyDetailsSupported();
  var RSA_PSS_KEY_DETAILS_SUPPORTED = require_rsaPssKeyDetailsSupported();
  var allowedAlgorithmsForKeys = {
    ec: ["ES256", "ES384", "ES512"],
    rsa: ["RS256", "PS256", "RS384", "PS384", "RS512", "PS512"],
    "rsa-pss": ["PS256", "PS384", "PS512"]
  };
  var allowedCurves = {
    ES256: "prime256v1",
    ES384: "secp384r1",
    ES512: "secp521r1"
  };
  module.exports = function(algorithm, key) {
    if (!algorithm || !key)
      return;
    const keyType = key.asymmetricKeyType;
    if (!keyType)
      return;
    const allowedAlgorithms = allowedAlgorithmsForKeys[keyType];
    if (!allowedAlgorithms) {
      throw new Error(`Unknown key type "${keyType}".`);
    }
    if (!allowedAlgorithms.includes(algorithm)) {
      throw new Error(`"alg" parameter for "${keyType}" key type must be one of: ${allowedAlgorithms.join(", ")}.`);
    }
    if (ASYMMETRIC_KEY_DETAILS_SUPPORTED) {
      switch (keyType) {
        case "ec":
          const keyCurve = key.asymmetricKeyDetails.namedCurve;
          const allowedCurve = allowedCurves[algorithm];
          if (keyCurve !== allowedCurve) {
            throw new Error(`"alg" parameter "${algorithm}" requires curve "${allowedCurve}".`);
          }
          break;
        case "rsa-pss":
          if (RSA_PSS_KEY_DETAILS_SUPPORTED) {
            const length = parseInt(algorithm.slice(-3), 10);
            const { hashAlgorithm, mgf1HashAlgorithm, saltLength } = key.asymmetricKeyDetails;
            if (hashAlgorithm !== `sha${length}` || mgf1HashAlgorithm !== hashAlgorithm) {
              throw new Error(`Invalid key for this operation, its RSA-PSS parameters do not meet the requirements of "alg" ${algorithm}.`);
            }
            if (saltLength !== undefined && saltLength > length >> 3) {
              throw new Error(`Invalid key for this operation, its RSA-PSS parameter saltLength does not meet the requirements of "alg" ${algorithm}.`);
            }
          }
          break;
      }
    }
  };
});

// node_modules/jsonwebtoken/lib/psSupported.js
var require_psSupported = __commonJS((exports, module) => {
  var semver = require_semver2();
  module.exports = semver.satisfies(process.version, "^6.12.0 || >=8.0.0");
});

// node_modules/jsonwebtoken/verify.js
var require_verify = __commonJS((exports, module) => {
  var JsonWebTokenError = require_JsonWebTokenError();
  var NotBeforeError = require_NotBeforeError();
  var TokenExpiredError = require_TokenExpiredError();
  var decode = require_decode();
  var timespan = require_timespan();
  var validateAsymmetricKey = require_validateAsymmetricKey();
  var PS_SUPPORTED = require_psSupported();
  var jws = require_jws();
  var { KeyObject, createSecretKey, createPublicKey } = import.meta.require("crypto");
  var PUB_KEY_ALGS = ["RS256", "RS384", "RS512"];
  var EC_KEY_ALGS = ["ES256", "ES384", "ES512"];
  var RSA_KEY_ALGS = ["RS256", "RS384", "RS512"];
  var HS_ALGS = ["HS256", "HS384", "HS512"];
  if (PS_SUPPORTED) {
    PUB_KEY_ALGS.splice(PUB_KEY_ALGS.length, 0, "PS256", "PS384", "PS512");
    RSA_KEY_ALGS.splice(RSA_KEY_ALGS.length, 0, "PS256", "PS384", "PS512");
  }
  module.exports = function(jwtString, secretOrPublicKey, options2, callback) {
    if (typeof options2 === "function" && !callback) {
      callback = options2;
      options2 = {};
    }
    if (!options2) {
      options2 = {};
    }
    options2 = Object.assign({}, options2);
    let done;
    if (callback) {
      done = callback;
    } else {
      done = function(err, data) {
        if (err)
          throw err;
        return data;
      };
    }
    if (options2.clockTimestamp && typeof options2.clockTimestamp !== "number") {
      return done(new JsonWebTokenError("clockTimestamp must be a number"));
    }
    if (options2.nonce !== undefined && (typeof options2.nonce !== "string" || options2.nonce.trim() === "")) {
      return done(new JsonWebTokenError("nonce must be a non-empty string"));
    }
    if (options2.allowInvalidAsymmetricKeyTypes !== undefined && typeof options2.allowInvalidAsymmetricKeyTypes !== "boolean") {
      return done(new JsonWebTokenError("allowInvalidAsymmetricKeyTypes must be a boolean"));
    }
    const clockTimestamp = options2.clockTimestamp || Math.floor(Date.now() / 1000);
    if (!jwtString) {
      return done(new JsonWebTokenError("jwt must be provided"));
    }
    if (typeof jwtString !== "string") {
      return done(new JsonWebTokenError("jwt must be a string"));
    }
    const parts = jwtString.split(".");
    if (parts.length !== 3) {
      return done(new JsonWebTokenError("jwt malformed"));
    }
    let decodedToken;
    try {
      decodedToken = decode(jwtString, { complete: true });
    } catch (err) {
      return done(err);
    }
    if (!decodedToken) {
      return done(new JsonWebTokenError("invalid token"));
    }
    const header = decodedToken.header;
    let getSecret;
    if (typeof secretOrPublicKey === "function") {
      if (!callback) {
        return done(new JsonWebTokenError("verify must be called asynchronous if secret or public key is provided as a callback"));
      }
      getSecret = secretOrPublicKey;
    } else {
      getSecret = function(header2, secretCallback) {
        return secretCallback(null, secretOrPublicKey);
      };
    }
    return getSecret(header, function(err, secretOrPublicKey2) {
      if (err) {
        return done(new JsonWebTokenError("error in secret or public key callback: " + err.message));
      }
      const hasSignature = parts[2].trim() !== "";
      if (!hasSignature && secretOrPublicKey2) {
        return done(new JsonWebTokenError("jwt signature is required"));
      }
      if (hasSignature && !secretOrPublicKey2) {
        return done(new JsonWebTokenError("secret or public key must be provided"));
      }
      if (!hasSignature && !options2.algorithms) {
        return done(new JsonWebTokenError('please specify "none" in "algorithms" to verify unsigned tokens'));
      }
      if (secretOrPublicKey2 != null && !(secretOrPublicKey2 instanceof KeyObject)) {
        try {
          secretOrPublicKey2 = createPublicKey(secretOrPublicKey2);
        } catch (_) {
          try {
            secretOrPublicKey2 = createSecretKey(typeof secretOrPublicKey2 === "string" ? Buffer.from(secretOrPublicKey2) : secretOrPublicKey2);
          } catch (_2) {
            return done(new JsonWebTokenError("secretOrPublicKey is not valid key material"));
          }
        }
      }
      if (!options2.algorithms) {
        if (secretOrPublicKey2.type === "secret") {
          options2.algorithms = HS_ALGS;
        } else if (["rsa", "rsa-pss"].includes(secretOrPublicKey2.asymmetricKeyType)) {
          options2.algorithms = RSA_KEY_ALGS;
        } else if (secretOrPublicKey2.asymmetricKeyType === "ec") {
          options2.algorithms = EC_KEY_ALGS;
        } else {
          options2.algorithms = PUB_KEY_ALGS;
        }
      }
      if (options2.algorithms.indexOf(decodedToken.header.alg) === -1) {
        return done(new JsonWebTokenError("invalid algorithm"));
      }
      if (header.alg.startsWith("HS") && secretOrPublicKey2.type !== "secret") {
        return done(new JsonWebTokenError(`secretOrPublicKey must be a symmetric key when using ${header.alg}`));
      } else if (/^(?:RS|PS|ES)/.test(header.alg) && secretOrPublicKey2.type !== "public") {
        return done(new JsonWebTokenError(`secretOrPublicKey must be an asymmetric key when using ${header.alg}`));
      }
      if (!options2.allowInvalidAsymmetricKeyTypes) {
        try {
          validateAsymmetricKey(header.alg, secretOrPublicKey2);
        } catch (e) {
          return done(e);
        }
      }
      let valid;
      try {
        valid = jws.verify(jwtString, decodedToken.header.alg, secretOrPublicKey2);
      } catch (e) {
        return done(e);
      }
      if (!valid) {
        return done(new JsonWebTokenError("invalid signature"));
      }
      const payload = decodedToken.payload;
      if (typeof payload.nbf !== "undefined" && !options2.ignoreNotBefore) {
        if (typeof payload.nbf !== "number") {
          return done(new JsonWebTokenError("invalid nbf value"));
        }
        if (payload.nbf > clockTimestamp + (options2.clockTolerance || 0)) {
          return done(new NotBeforeError("jwt not active", new Date(payload.nbf * 1000)));
        }
      }
      if (typeof payload.exp !== "undefined" && !options2.ignoreExpiration) {
        if (typeof payload.exp !== "number") {
          return done(new JsonWebTokenError("invalid exp value"));
        }
        if (clockTimestamp >= payload.exp + (options2.clockTolerance || 0)) {
          return done(new TokenExpiredError("jwt expired", new Date(payload.exp * 1000)));
        }
      }
      if (options2.audience) {
        const audiences = Array.isArray(options2.audience) ? options2.audience : [options2.audience];
        const target = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
        const match = target.some(function(targetAudience) {
          return audiences.some(function(audience) {
            return audience instanceof RegExp ? audience.test(targetAudience) : audience === targetAudience;
          });
        });
        if (!match) {
          return done(new JsonWebTokenError("jwt audience invalid. expected: " + audiences.join(" or ")));
        }
      }
      if (options2.issuer) {
        const invalid_issuer = typeof options2.issuer === "string" && payload.iss !== options2.issuer || Array.isArray(options2.issuer) && options2.issuer.indexOf(payload.iss) === -1;
        if (invalid_issuer) {
          return done(new JsonWebTokenError("jwt issuer invalid. expected: " + options2.issuer));
        }
      }
      if (options2.subject) {
        if (payload.sub !== options2.subject) {
          return done(new JsonWebTokenError("jwt subject invalid. expected: " + options2.subject));
        }
      }
      if (options2.jwtid) {
        if (payload.jti !== options2.jwtid) {
          return done(new JsonWebTokenError("jwt jwtid invalid. expected: " + options2.jwtid));
        }
      }
      if (options2.nonce) {
        if (payload.nonce !== options2.nonce) {
          return done(new JsonWebTokenError("jwt nonce invalid. expected: " + options2.nonce));
        }
      }
      if (options2.maxAge) {
        if (typeof payload.iat !== "number") {
          return done(new JsonWebTokenError("iat required when maxAge is specified"));
        }
        const maxAgeTimestamp = timespan(options2.maxAge, payload.iat);
        if (typeof maxAgeTimestamp === "undefined") {
          return done(new JsonWebTokenError('"maxAge" should be a number of seconds or string representing a timespan eg: "1d", "20h", 60'));
        }
        if (clockTimestamp >= maxAgeTimestamp + (options2.clockTolerance || 0)) {
          return done(new TokenExpiredError("maxAge exceeded", new Date(maxAgeTimestamp * 1000)));
        }
      }
      if (options2.complete === true) {
        const signature = decodedToken.signature;
        return done(null, {
          header,
          payload,
          signature
        });
      }
      return done(null, payload);
    });
  };
});

// node_modules/lodash.includes/index.js
var require_lodash = __commonJS((exports, module) => {
  var arrayMap = function(array, iteratee) {
    var index = -1, length = array ? array.length : 0, result = Array(length);
    while (++index < length) {
      result[index] = iteratee(array[index], index, array);
    }
    return result;
  };
  var baseFindIndex = function(array, predicate, fromIndex, fromRight) {
    var length = array.length, index = fromIndex + (fromRight ? 1 : -1);
    while (fromRight ? index-- : ++index < length) {
      if (predicate(array[index], index, array)) {
        return index;
      }
    }
    return -1;
  };
  var baseIndexOf = function(array, value, fromIndex) {
    if (value !== value) {
      return baseFindIndex(array, baseIsNaN, fromIndex);
    }
    var index = fromIndex - 1, length = array.length;
    while (++index < length) {
      if (array[index] === value) {
        return index;
      }
    }
    return -1;
  };
  var baseIsNaN = function(value) {
    return value !== value;
  };
  var baseTimes = function(n, iteratee) {
    var index = -1, result = Array(n);
    while (++index < n) {
      result[index] = iteratee(index);
    }
    return result;
  };
  var baseValues = function(object, props) {
    return arrayMap(props, function(key) {
      return object[key];
    });
  };
  var overArg = function(func, transform) {
    return function(arg) {
      return func(transform(arg));
    };
  };
  var arrayLikeKeys = function(value, inherited) {
    var result = isArray2(value) || isArguments(value) ? baseTimes(value.length, String) : [];
    var length = result.length, skipIndexes = !!length;
    for (var key in value) {
      if ((inherited || hasOwnProperty3.call(value, key)) && !(skipIndexes && (key == "length" || isIndex(key, length)))) {
        result.push(key);
      }
    }
    return result;
  };
  var baseKeys = function(object) {
    if (!isPrototype(object)) {
      return nativeKeys(object);
    }
    var result = [];
    for (var key in Object(object)) {
      if (hasOwnProperty3.call(object, key) && key != "constructor") {
        result.push(key);
      }
    }
    return result;
  };
  var isIndex = function(value, length) {
    length = length == null ? MAX_SAFE_INTEGER : length;
    return !!length && (typeof value == "number" || reIsUint.test(value)) && (value > -1 && value % 1 == 0 && value < length);
  };
  var isPrototype = function(value) {
    var Ctor = value && value.constructor, proto = typeof Ctor == "function" && Ctor.prototype || objectProto;
    return value === proto;
  };
  var includes = function(collection, value, fromIndex, guard) {
    collection = isArrayLike(collection) ? collection : values(collection);
    fromIndex = fromIndex && !guard ? toInteger(fromIndex) : 0;
    var length = collection.length;
    if (fromIndex < 0) {
      fromIndex = nativeMax(length + fromIndex, 0);
    }
    return isString2(collection) ? fromIndex <= length && collection.indexOf(value, fromIndex) > -1 : !!length && baseIndexOf(collection, value, fromIndex) > -1;
  };
  var isArguments = function(value) {
    return isArrayLikeObject(value) && hasOwnProperty3.call(value, "callee") && (!propertyIsEnumerable.call(value, "callee") || objectToString.call(value) == argsTag);
  };
  var isArrayLike = function(value) {
    return value != null && isLength(value.length) && !isFunction2(value);
  };
  var isArrayLikeObject = function(value) {
    return isObjectLike(value) && isArrayLike(value);
  };
  var isFunction2 = function(value) {
    var tag2 = isObject2(value) ? objectToString.call(value) : "";
    return tag2 == funcTag || tag2 == genTag;
  };
  var isLength = function(value) {
    return typeof value == "number" && value > -1 && value % 1 == 0 && value <= MAX_SAFE_INTEGER;
  };
  var isObject2 = function(value) {
    var type = typeof value;
    return !!value && (type == "object" || type == "function");
  };
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var isString2 = function(value) {
    return typeof value == "string" || !isArray2(value) && isObjectLike(value) && objectToString.call(value) == stringTag;
  };
  var isSymbol = function(value) {
    return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
  };
  var toFinite = function(value) {
    if (!value) {
      return value === 0 ? value : 0;
    }
    value = toNumber(value);
    if (value === INFINITY || value === -INFINITY) {
      var sign = value < 0 ? -1 : 1;
      return sign * MAX_INTEGER;
    }
    return value === value ? value : 0;
  };
  var toInteger = function(value) {
    var result = toFinite(value), remainder = result % 1;
    return result === result ? remainder ? result - remainder : result : 0;
  };
  var toNumber = function(value) {
    if (typeof value == "number") {
      return value;
    }
    if (isSymbol(value)) {
      return NAN;
    }
    if (isObject2(value)) {
      var other = typeof value.valueOf == "function" ? value.valueOf() : value;
      value = isObject2(other) ? other + "" : other;
    }
    if (typeof value != "string") {
      return value === 0 ? value : +value;
    }
    value = value.replace(reTrim, "");
    var isBinary = reIsBinary.test(value);
    return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
  };
  var keys = function(object) {
    return isArrayLike(object) ? arrayLikeKeys(object) : baseKeys(object);
  };
  var values = function(object) {
    return object ? baseValues(object, keys(object)) : [];
  };
  var INFINITY = 1 / 0;
  var MAX_SAFE_INTEGER = 9007199254740991;
  var MAX_INTEGER = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
  var NAN = 0 / 0;
  var argsTag = "[object Arguments]";
  var funcTag = "[object Function]";
  var genTag = "[object GeneratorFunction]";
  var stringTag = "[object String]";
  var symbolTag = "[object Symbol]";
  var reTrim = /^\s+|\s+$/g;
  var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
  var reIsBinary = /^0b[01]+$/i;
  var reIsOctal = /^0o[0-7]+$/i;
  var reIsUint = /^(?:0|[1-9]\d*)$/;
  var freeParseInt = parseInt;
  var objectProto = Object.prototype;
  var hasOwnProperty3 = objectProto.hasOwnProperty;
  var objectToString = objectProto.toString;
  var propertyIsEnumerable = objectProto.propertyIsEnumerable;
  var nativeKeys = overArg(Object.keys, Object);
  var nativeMax = Math.max;
  var isArray2 = Array.isArray;
  module.exports = includes;
});

// node_modules/lodash.isboolean/index.js
var require_lodash2 = __commonJS((exports, module) => {
  var isBoolean = function(value) {
    return value === true || value === false || isObjectLike(value) && objectToString.call(value) == boolTag;
  };
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var boolTag = "[object Boolean]";
  var objectProto = Object.prototype;
  var objectToString = objectProto.toString;
  module.exports = isBoolean;
});

// node_modules/lodash.isinteger/index.js
var require_lodash3 = __commonJS((exports, module) => {
  var isInteger = function(value) {
    return typeof value == "number" && value == toInteger(value);
  };
  var isObject2 = function(value) {
    var type = typeof value;
    return !!value && (type == "object" || type == "function");
  };
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var isSymbol = function(value) {
    return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
  };
  var toFinite = function(value) {
    if (!value) {
      return value === 0 ? value : 0;
    }
    value = toNumber(value);
    if (value === INFINITY || value === -INFINITY) {
      var sign = value < 0 ? -1 : 1;
      return sign * MAX_INTEGER;
    }
    return value === value ? value : 0;
  };
  var toInteger = function(value) {
    var result = toFinite(value), remainder = result % 1;
    return result === result ? remainder ? result - remainder : result : 0;
  };
  var toNumber = function(value) {
    if (typeof value == "number") {
      return value;
    }
    if (isSymbol(value)) {
      return NAN;
    }
    if (isObject2(value)) {
      var other = typeof value.valueOf == "function" ? value.valueOf() : value;
      value = isObject2(other) ? other + "" : other;
    }
    if (typeof value != "string") {
      return value === 0 ? value : +value;
    }
    value = value.replace(reTrim, "");
    var isBinary = reIsBinary.test(value);
    return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
  };
  var INFINITY = 1 / 0;
  var MAX_INTEGER = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
  var NAN = 0 / 0;
  var symbolTag = "[object Symbol]";
  var reTrim = /^\s+|\s+$/g;
  var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
  var reIsBinary = /^0b[01]+$/i;
  var reIsOctal = /^0o[0-7]+$/i;
  var freeParseInt = parseInt;
  var objectProto = Object.prototype;
  var objectToString = objectProto.toString;
  module.exports = isInteger;
});

// node_modules/lodash.isnumber/index.js
var require_lodash4 = __commonJS((exports, module) => {
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var isNumber2 = function(value) {
    return typeof value == "number" || isObjectLike(value) && objectToString.call(value) == numberTag;
  };
  var numberTag = "[object Number]";
  var objectProto = Object.prototype;
  var objectToString = objectProto.toString;
  module.exports = isNumber2;
});

// node_modules/lodash.isplainobject/index.js
var require_lodash5 = __commonJS((exports, module) => {
  var isHostObject = function(value) {
    var result = false;
    if (value != null && typeof value.toString != "function") {
      try {
        result = !!(value + "");
      } catch (e) {
      }
    }
    return result;
  };
  var overArg = function(func, transform) {
    return function(arg) {
      return func(transform(arg));
    };
  };
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var isPlainObject = function(value) {
    if (!isObjectLike(value) || objectToString.call(value) != objectTag || isHostObject(value)) {
      return false;
    }
    var proto = getPrototype(value);
    if (proto === null) {
      return true;
    }
    var Ctor = hasOwnProperty3.call(proto, "constructor") && proto.constructor;
    return typeof Ctor == "function" && Ctor instanceof Ctor && funcToString.call(Ctor) == objectCtorString;
  };
  var objectTag = "[object Object]";
  var funcProto = Function.prototype;
  var objectProto = Object.prototype;
  var funcToString = funcProto.toString;
  var hasOwnProperty3 = objectProto.hasOwnProperty;
  var objectCtorString = funcToString.call(Object);
  var objectToString = objectProto.toString;
  var getPrototype = overArg(Object.getPrototypeOf, Object);
  module.exports = isPlainObject;
});

// node_modules/lodash.isstring/index.js
var require_lodash6 = __commonJS((exports, module) => {
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var isString2 = function(value) {
    return typeof value == "string" || !isArray2(value) && isObjectLike(value) && objectToString.call(value) == stringTag;
  };
  var stringTag = "[object String]";
  var objectProto = Object.prototype;
  var objectToString = objectProto.toString;
  var isArray2 = Array.isArray;
  module.exports = isString2;
});

// node_modules/lodash.once/index.js
var require_lodash7 = __commonJS((exports, module) => {
  var before = function(n, func) {
    var result;
    if (typeof func != "function") {
      throw new TypeError(FUNC_ERROR_TEXT);
    }
    n = toInteger(n);
    return function() {
      if (--n > 0) {
        result = func.apply(this, arguments);
      }
      if (n <= 1) {
        func = undefined;
      }
      return result;
    };
  };
  var once = function(func) {
    return before(2, func);
  };
  var isObject2 = function(value) {
    var type = typeof value;
    return !!value && (type == "object" || type == "function");
  };
  var isObjectLike = function(value) {
    return !!value && typeof value == "object";
  };
  var isSymbol = function(value) {
    return typeof value == "symbol" || isObjectLike(value) && objectToString.call(value) == symbolTag;
  };
  var toFinite = function(value) {
    if (!value) {
      return value === 0 ? value : 0;
    }
    value = toNumber(value);
    if (value === INFINITY || value === -INFINITY) {
      var sign = value < 0 ? -1 : 1;
      return sign * MAX_INTEGER;
    }
    return value === value ? value : 0;
  };
  var toInteger = function(value) {
    var result = toFinite(value), remainder = result % 1;
    return result === result ? remainder ? result - remainder : result : 0;
  };
  var toNumber = function(value) {
    if (typeof value == "number") {
      return value;
    }
    if (isSymbol(value)) {
      return NAN;
    }
    if (isObject2(value)) {
      var other = typeof value.valueOf == "function" ? value.valueOf() : value;
      value = isObject2(other) ? other + "" : other;
    }
    if (typeof value != "string") {
      return value === 0 ? value : +value;
    }
    value = value.replace(reTrim, "");
    var isBinary = reIsBinary.test(value);
    return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
  };
  var FUNC_ERROR_TEXT = "Expected a function";
  var INFINITY = 1 / 0;
  var MAX_INTEGER = 179769313486231570000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000;
  var NAN = 0 / 0;
  var symbolTag = "[object Symbol]";
  var reTrim = /^\s+|\s+$/g;
  var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
  var reIsBinary = /^0b[01]+$/i;
  var reIsOctal = /^0o[0-7]+$/i;
  var freeParseInt = parseInt;
  var objectProto = Object.prototype;
  var objectToString = objectProto.toString;
  module.exports = once;
});

// node_modules/jsonwebtoken/sign.js
var require_sign2 = __commonJS((exports, module) => {
  var validate2 = function(schema3, allowUnknown, object, parameterName) {
    if (!isPlainObject(object)) {
      throw new Error('Expected "' + parameterName + '" to be a plain object.');
    }
    Object.keys(object).forEach(function(key) {
      const validator = schema3[key];
      if (!validator) {
        if (!allowUnknown) {
          throw new Error('"' + key + '" is not allowed in "' + parameterName + '"');
        }
        return;
      }
      if (!validator.isValid(object[key])) {
        throw new Error(validator.message);
      }
    });
  };
  var validateOptions = function(options2) {
    return validate2(sign_options_schema, false, options2, "options");
  };
  var validatePayload = function(payload) {
    return validate2(registered_claims_schema, true, payload, "payload");
  };
  var timespan = require_timespan();
  var PS_SUPPORTED = require_psSupported();
  var validateAsymmetricKey = require_validateAsymmetricKey();
  var jws = require_jws();
  var includes = require_lodash();
  var isBoolean = require_lodash2();
  var isInteger = require_lodash3();
  var isNumber2 = require_lodash4();
  var isPlainObject = require_lodash5();
  var isString2 = require_lodash6();
  var once = require_lodash7();
  var { KeyObject, createSecretKey, createPrivateKey } = import.meta.require("crypto");
  var SUPPORTED_ALGS = ["RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "HS256", "HS384", "HS512", "none"];
  if (PS_SUPPORTED) {
    SUPPORTED_ALGS.splice(3, 0, "PS256", "PS384", "PS512");
  }
  var sign_options_schema = {
    expiresIn: { isValid: function(value) {
      return isInteger(value) || isString2(value) && value;
    }, message: '"expiresIn" should be a number of seconds or string representing a timespan' },
    notBefore: { isValid: function(value) {
      return isInteger(value) || isString2(value) && value;
    }, message: '"notBefore" should be a number of seconds or string representing a timespan' },
    audience: { isValid: function(value) {
      return isString2(value) || Array.isArray(value);
    }, message: '"audience" must be a string or array' },
    algorithm: { isValid: includes.bind(null, SUPPORTED_ALGS), message: '"algorithm" must be a valid string enum value' },
    header: { isValid: isPlainObject, message: '"header" must be an object' },
    encoding: { isValid: isString2, message: '"encoding" must be a string' },
    issuer: { isValid: isString2, message: '"issuer" must be a string' },
    subject: { isValid: isString2, message: '"subject" must be a string' },
    jwtid: { isValid: isString2, message: '"jwtid" must be a string' },
    noTimestamp: { isValid: isBoolean, message: '"noTimestamp" must be a boolean' },
    keyid: { isValid: isString2, message: '"keyid" must be a string' },
    mutatePayload: { isValid: isBoolean, message: '"mutatePayload" must be a boolean' },
    allowInsecureKeySizes: { isValid: isBoolean, message: '"allowInsecureKeySizes" must be a boolean' },
    allowInvalidAsymmetricKeyTypes: { isValid: isBoolean, message: '"allowInvalidAsymmetricKeyTypes" must be a boolean' }
  };
  var registered_claims_schema = {
    iat: { isValid: isNumber2, message: '"iat" should be a number of seconds' },
    exp: { isValid: isNumber2, message: '"exp" should be a number of seconds' },
    nbf: { isValid: isNumber2, message: '"nbf" should be a number of seconds' }
  };
  var options_to_payload = {
    audience: "aud",
    issuer: "iss",
    subject: "sub",
    jwtid: "jti"
  };
  var options_for_objects = [
    "expiresIn",
    "notBefore",
    "noTimestamp",
    "audience",
    "issuer",
    "subject",
    "jwtid"
  ];
  module.exports = function(payload, secretOrPrivateKey, options2, callback) {
    if (typeof options2 === "function") {
      callback = options2;
      options2 = {};
    } else {
      options2 = options2 || {};
    }
    const isObjectPayload = typeof payload === "object" && !Buffer.isBuffer(payload);
    const header = Object.assign({
      alg: options2.algorithm || "HS256",
      typ: isObjectPayload ? "JWT" : undefined,
      kid: options2.keyid
    }, options2.header);
    function failure(err) {
      if (callback) {
        return callback(err);
      }
      throw err;
    }
    if (!secretOrPrivateKey && options2.algorithm !== "none") {
      return failure(new Error("secretOrPrivateKey must have a value"));
    }
    if (secretOrPrivateKey != null && !(secretOrPrivateKey instanceof KeyObject)) {
      try {
        secretOrPrivateKey = createPrivateKey(secretOrPrivateKey);
      } catch (_) {
        try {
          secretOrPrivateKey = createSecretKey(typeof secretOrPrivateKey === "string" ? Buffer.from(secretOrPrivateKey) : secretOrPrivateKey);
        } catch (_2) {
          return failure(new Error("secretOrPrivateKey is not valid key material"));
        }
      }
    }
    if (header.alg.startsWith("HS") && secretOrPrivateKey.type !== "secret") {
      return failure(new Error(`secretOrPrivateKey must be a symmetric key when using ${header.alg}`));
    } else if (/^(?:RS|PS|ES)/.test(header.alg)) {
      if (secretOrPrivateKey.type !== "private") {
        return failure(new Error(`secretOrPrivateKey must be an asymmetric key when using ${header.alg}`));
      }
      if (!options2.allowInsecureKeySizes && !header.alg.startsWith("ES") && secretOrPrivateKey.asymmetricKeyDetails !== undefined && secretOrPrivateKey.asymmetricKeyDetails.modulusLength < 2048) {
        return failure(new Error(`secretOrPrivateKey has a minimum key size of 2048 bits for ${header.alg}`));
      }
    }
    if (typeof payload === "undefined") {
      return failure(new Error("payload is required"));
    } else if (isObjectPayload) {
      try {
        validatePayload(payload);
      } catch (error) {
        return failure(error);
      }
      if (!options2.mutatePayload) {
        payload = Object.assign({}, payload);
      }
    } else {
      const invalid_options = options_for_objects.filter(function(opt) {
        return typeof options2[opt] !== "undefined";
      });
      if (invalid_options.length > 0) {
        return failure(new Error("invalid " + invalid_options.join(",") + " option for " + typeof payload + " payload"));
      }
    }
    if (typeof payload.exp !== "undefined" && typeof options2.expiresIn !== "undefined") {
      return failure(new Error('Bad "options.expiresIn" option the payload already has an "exp" property.'));
    }
    if (typeof payload.nbf !== "undefined" && typeof options2.notBefore !== "undefined") {
      return failure(new Error('Bad "options.notBefore" option the payload already has an "nbf" property.'));
    }
    try {
      validateOptions(options2);
    } catch (error) {
      return failure(error);
    }
    if (!options2.allowInvalidAsymmetricKeyTypes) {
      try {
        validateAsymmetricKey(header.alg, secretOrPrivateKey);
      } catch (error) {
        return failure(error);
      }
    }
    const timestamp = payload.iat || Math.floor(Date.now() / 1000);
    if (options2.noTimestamp) {
      delete payload.iat;
    } else if (isObjectPayload) {
      payload.iat = timestamp;
    }
    if (typeof options2.notBefore !== "undefined") {
      try {
        payload.nbf = timespan(options2.notBefore, timestamp);
      } catch (err) {
        return failure(err);
      }
      if (typeof payload.nbf === "undefined") {
        return failure(new Error('"notBefore" should be a number of seconds or string representing a timespan eg: "1d", "20h", 60'));
      }
    }
    if (typeof options2.expiresIn !== "undefined" && typeof payload === "object") {
      try {
        payload.exp = timespan(options2.expiresIn, timestamp);
      } catch (err) {
        return failure(err);
      }
      if (typeof payload.exp === "undefined") {
        return failure(new Error('"expiresIn" should be a number of seconds or string representing a timespan eg: "1d", "20h", 60'));
      }
    }
    Object.keys(options_to_payload).forEach(function(key) {
      const claim = options_to_payload[key];
      if (typeof options2[key] !== "undefined") {
        if (typeof payload[claim] !== "undefined") {
          return failure(new Error('Bad "options.' + key + '" option. The payload already has an "' + claim + '" property.'));
        }
        payload[claim] = options2[key];
      }
    });
    const encoding = options2.encoding || "utf8";
    if (typeof callback === "function") {
      callback = callback && once(callback);
      jws.createSign({
        header,
        privateKey: secretOrPrivateKey,
        payload,
        encoding
      }).once("error", callback).once("done", function(signature) {
        if (!options2.allowInsecureKeySizes && /^(?:RS|PS)/.test(header.alg) && signature.length < 256) {
          return callback(new Error(`secretOrPrivateKey has a minimum key size of 2048 bits for ${header.alg}`));
        }
        callback(null, signature);
      });
    } else {
      let signature = jws.sign({ header, payload, secret: secretOrPrivateKey, encoding });
      if (!options2.allowInsecureKeySizes && /^(?:RS|PS)/.test(header.alg) && signature.length < 256) {
        throw new Error(`secretOrPrivateKey has a minimum key size of 2048 bits for ${header.alg}`);
      }
      return signature;
    }
  };
});

// node_modules/jsonwebtoken/index.js
var require_jsonwebtoken = __commonJS((exports, module) => {
  module.exports = {
    decode: require_decode(),
    verify: require_verify(),
    sign: require_sign2(),
    JsonWebTokenError: require_JsonWebTokenError(),
    NotBeforeError: require_NotBeforeError(),
    TokenExpiredError: require_TokenExpiredError()
  };
});

// src/index.ts
import {createInterface} from "readline";

// node_modules/commander/esm.mjs
var import_ = __toESM(require_commander(), 1);
var {
  program,
  createCommand,
  createArgument,
  createOption,
  CommanderError,
  InvalidArgumentError,
  InvalidOptionArgumentError,
  Command,
  Argument,
  Option,
  Help
} = import_.default;

// node_modules/drizzle-orm/migrator.js
import crypto from "crypto";
import fs from "fs";
import path from "path";
var readMigrationFiles = function(config) {
  let migrationFolderTo;
  if (typeof config === "string") {
    const configAsString = fs.readFileSync(path.resolve(".", config), "utf8");
    const jsonConfig = JSON.parse(configAsString);
    migrationFolderTo = jsonConfig.out;
  } else {
    migrationFolderTo = config.migrationsFolder;
  }
  if (!migrationFolderTo) {
    throw new Error("no migration folder defined");
  }
  const migrationQueries = [];
  const journalPath = `${migrationFolderTo}/meta/_journal.json`;
  if (!fs.existsSync(journalPath)) {
    throw new Error(`Can't find meta/_journal.json file`);
  }
  const journalAsString = fs.readFileSync(`${migrationFolderTo}/meta/_journal.json`).toString();
  const journal = JSON.parse(journalAsString);
  for (const journalEntry of journal.entries) {
    const migrationPath = `${migrationFolderTo}/${journalEntry.tag}.sql`;
    try {
      const query = fs.readFileSync(`${migrationFolderTo}/${journalEntry.tag}.sql`).toString();
      const result = query.split("--> statement-breakpoint").map((it) => {
        return it;
      });
      migrationQueries.push({
        sql: result,
        bps: journalEntry.breakpoints,
        folderMillis: journalEntry.when,
        hash: crypto.createHash("sha256").update(query).digest("hex")
      });
    } catch {
      throw new Error(`No file ${migrationPath} found in ${migrationFolderTo} folder`);
    }
  }
  return migrationQueries;
};

// node_modules/drizzle-orm/bun-sqlite/migrator.js
var migrate = function(db, config) {
  const migrations = readMigrationFiles(config);
  db.dialect.migrate(migrations, db.session, config);
};

// node_modules/drizzle-orm/entity.js
var is = function(value, type) {
  if (!value || typeof value !== "object") {
    return false;
  }
  if (value instanceof type) {
    return true;
  }
  if (!Object.prototype.hasOwnProperty.call(type, entityKind)) {
    throw new Error(`Class "${type.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`);
  }
  let cls = value.constructor;
  if (cls) {
    while (cls) {
      if (entityKind in cls && cls[entityKind] === type[entityKind]) {
        return true;
      }
      cls = Object.getPrototypeOf(cls);
    }
  }
  return false;
};
var entityKind = Symbol.for("drizzle:entityKind");
var hasOwnEntityKind = Symbol.for("drizzle:hasOwnEntityKind");

// node_modules/drizzle-orm/column.js
class Column {
  constructor(table, config) {
    this.table = table;
    this.config = config;
    this.name = config.name;
    this.notNull = config.notNull;
    this.default = config.default;
    this.defaultFn = config.defaultFn;
    this.onUpdateFn = config.onUpdateFn;
    this.hasDefault = config.hasDefault;
    this.primary = config.primaryKey;
    this.isUnique = config.isUnique;
    this.uniqueName = config.uniqueName;
    this.uniqueType = config.uniqueType;
    this.dataType = config.dataType;
    this.columnType = config.columnType;
    this.generated = config.generated;
    this.generatedIdentity = config.generatedIdentity;
  }
  static [entityKind] = "Column";
  name;
  primary;
  notNull;
  default;
  defaultFn;
  onUpdateFn;
  hasDefault;
  isUnique;
  uniqueName;
  uniqueType;
  dataType;
  columnType;
  enumValues = undefined;
  generated = undefined;
  generatedIdentity = undefined;
  config;
  mapFromDriverValue(value) {
    return value;
  }
  mapToDriverValue(value) {
    return value;
  }
  shouldDisableInsert() {
    return this.config.generated !== undefined && this.config.generated.type !== "byDefault";
  }
}

// node_modules/drizzle-orm/column-builder.js
class ColumnBuilder {
  static [entityKind] = "ColumnBuilder";
  config;
  constructor(name, dataType, columnType) {
    this.config = {
      name,
      notNull: false,
      default: undefined,
      hasDefault: false,
      primaryKey: false,
      isUnique: false,
      uniqueName: undefined,
      uniqueType: undefined,
      dataType,
      columnType,
      generated: undefined
    };
  }
  $type() {
    return this;
  }
  notNull() {
    this.config.notNull = true;
    return this;
  }
  default(value) {
    this.config.default = value;
    this.config.hasDefault = true;
    return this;
  }
  $defaultFn(fn) {
    this.config.defaultFn = fn;
    this.config.hasDefault = true;
    return this;
  }
  $default = this.$defaultFn;
  $onUpdateFn(fn) {
    this.config.onUpdateFn = fn;
    this.config.hasDefault = true;
    return this;
  }
  $onUpdate = this.$onUpdateFn;
  primaryKey() {
    this.config.primaryKey = true;
    this.config.notNull = true;
    return this;
  }
}

// node_modules/drizzle-orm/table.js
var getTableName = function(table) {
  return table[TableName];
};
var getTableUniqueName = function(table) {
  return `${table[Schema] ?? "public"}.${table[TableName]}`;
};
var TableName = Symbol.for("drizzle:Name");
var Schema = Symbol.for("drizzle:Schema");
var Columns = Symbol.for("drizzle:Columns");
var ExtraConfigColumns = Symbol.for("drizzle:ExtraConfigColumns");
var OriginalName = Symbol.for("drizzle:OriginalName");
var BaseName = Symbol.for("drizzle:BaseName");
var IsAlias = Symbol.for("drizzle:IsAlias");
var ExtraConfigBuilder = Symbol.for("drizzle:ExtraConfigBuilder");
var IsDrizzleTable = Symbol.for("drizzle:IsDrizzleTable");

class Table {
  static [entityKind] = "Table";
  static Symbol = {
    Name: TableName,
    Schema,
    OriginalName,
    Columns,
    ExtraConfigColumns,
    BaseName,
    IsAlias,
    ExtraConfigBuilder
  };
  [TableName];
  [OriginalName];
  [Schema];
  [Columns];
  [ExtraConfigColumns];
  [BaseName];
  [IsAlias] = false;
  [ExtraConfigBuilder] = undefined;
  constructor(name, schema, baseName) {
    this[TableName] = this[OriginalName] = name;
    this[Schema] = schema;
    this[BaseName] = baseName;
  }
}

// node_modules/drizzle-orm/pg-core/table.js
var InlineForeignKeys = Symbol.for("drizzle:PgInlineForeignKeys");

class PgTable extends Table {
  static [entityKind] = "PgTable";
  static Symbol = Object.assign({}, Table.Symbol, {
    InlineForeignKeys
  });
  [InlineForeignKeys] = [];
  [Table.Symbol.ExtraConfigBuilder] = undefined;
}

// node_modules/drizzle-orm/tracing-utils.js
var iife = function(fn, ...args) {
  return fn(...args);
};

// node_modules/drizzle-orm/pg-core/unique-constraint.js
var uniqueKeyName = function(table3, columns) {
  return `${table3[PgTable.Symbol.Name]}_${columns.join("_")}_unique`;
};

// node_modules/drizzle-orm/pg-core/columns/common.js
class PgColumn extends Column {
  constructor(table3, config) {
    if (!config.uniqueName) {
      config.uniqueName = uniqueKeyName(table3, [config.name]);
    }
    super(table3, config);
    this.table = table3;
  }
  static [entityKind] = "PgColumn";
}

class ExtraConfigColumn extends PgColumn {
  static [entityKind] = "ExtraConfigColumn";
  getSQLType() {
    return this.getSQLType();
  }
  indexConfig = {
    order: this.config.order ?? "asc",
    nulls: this.config.nulls ?? "last",
    opClass: this.config.opClass
  };
  defaultConfig = {
    order: "asc",
    nulls: "last",
    opClass: undefined
  };
  asc() {
    this.indexConfig.order = "asc";
    return this;
  }
  desc() {
    this.indexConfig.order = "desc";
    return this;
  }
  nullsFirst() {
    this.indexConfig.nulls = "first";
    return this;
  }
  nullsLast() {
    this.indexConfig.nulls = "last";
    return this;
  }
  op(opClass) {
    this.indexConfig.opClass = opClass;
    return this;
  }
}

// node_modules/drizzle-orm/pg-core/columns/enum.js
var isPgEnum = function(obj) {
  return !!obj && typeof obj === "function" && isPgEnumSym in obj && obj[isPgEnumSym] === true;
};
var isPgEnumSym = Symbol.for("drizzle:isPgEnum");
class PgEnumColumn extends PgColumn {
  static [entityKind] = "PgEnumColumn";
  enum = this.config.enum;
  enumValues = this.config.enum.enumValues;
  constructor(table3, config) {
    super(table3, config);
    this.enum = config.enum;
  }
  getSQLType() {
    return this.enum.enumName;
  }
}

// node_modules/drizzle-orm/subquery.js
class Subquery {
  static [entityKind] = "Subquery";
  constructor(sql, selection, alias, isWith = false) {
    this._ = {
      brand: "Subquery",
      sql,
      selectedFields: selection,
      alias,
      isWith
    };
  }
}

class WithSubquery extends Subquery {
  static [entityKind] = "WithSubquery";
}

// node_modules/drizzle-orm/version.js
var version = "0.32.0";

// node_modules/drizzle-orm/tracing.js
var otel;
var rawTracer;
var tracer = {
  startActiveSpan(name, fn) {
    if (!otel) {
      return fn();
    }
    if (!rawTracer) {
      rawTracer = otel.trace.getTracer("drizzle-orm", version);
    }
    return iife((otel2, rawTracer2) => rawTracer2.startActiveSpan(name, (span) => {
      try {
        return fn(span);
      } catch (e) {
        span.setStatus({
          code: otel2.SpanStatusCode.ERROR,
          message: e instanceof Error ? e.message : "Unknown error"
        });
        throw e;
      } finally {
        span.end();
      }
    }), otel, rawTracer);
  }
};

// node_modules/drizzle-orm/view-common.js
var ViewBaseConfig = Symbol.for("drizzle:ViewBaseConfig");

// node_modules/drizzle-orm/sql/sql.js
var isSQLWrapper = function(value) {
  return value !== null && value !== undefined && typeof value.getSQL === "function";
};
var mergeQueries = function(queries) {
  const result = { sql: "", params: [] };
  for (const query of queries) {
    result.sql += query.sql;
    result.params.push(...query.params);
    if (query.typings?.length) {
      if (!result.typings) {
        result.typings = [];
      }
      result.typings.push(...query.typings);
    }
  }
  return result;
};
var isDriverValueEncoder = function(value) {
  return typeof value === "object" && value !== null && "mapToDriverValue" in value && typeof value.mapToDriverValue === "function";
};
var sql = function(strings, ...params) {
  const queryChunks = [];
  if (params.length > 0 || strings.length > 0 && strings[0] !== "") {
    queryChunks.push(new StringChunk(strings[0]));
  }
  for (const [paramIndex, param2] of params.entries()) {
    queryChunks.push(param2, new StringChunk(strings[paramIndex + 1]));
  }
  return new SQL(queryChunks);
};
var fillPlaceholders = function(params, values) {
  return params.map((p) => {
    if (is(p, Placeholder)) {
      if (!(p.name in values)) {
        throw new Error(`No value for placeholder "${p.name}" was provided`);
      }
      return values[p.name];
    }
    return p;
  });
};
class StringChunk {
  static [entityKind] = "StringChunk";
  value;
  constructor(value) {
    this.value = Array.isArray(value) ? value : [value];
  }
  getSQL() {
    return new SQL([this]);
  }
}

class SQL {
  constructor(queryChunks) {
    this.queryChunks = queryChunks;
  }
  static [entityKind] = "SQL";
  decoder = noopDecoder;
  shouldInlineParams = false;
  append(query) {
    this.queryChunks.push(...query.queryChunks);
    return this;
  }
  toQuery(config) {
    return tracer.startActiveSpan("drizzle.buildSQL", (span) => {
      const query = this.buildQueryFromSourceParams(this.queryChunks, config);
      span?.setAttributes({
        "drizzle.query.text": query.sql,
        "drizzle.query.params": JSON.stringify(query.params)
      });
      return query;
    });
  }
  buildQueryFromSourceParams(chunks, _config) {
    const config = Object.assign({}, _config, {
      inlineParams: _config.inlineParams || this.shouldInlineParams,
      paramStartIndex: _config.paramStartIndex || { value: 0 }
    });
    const {
      escapeName,
      escapeParam,
      prepareTyping,
      inlineParams,
      paramStartIndex
    } = config;
    return mergeQueries(chunks.map((chunk) => {
      if (is(chunk, StringChunk)) {
        return { sql: chunk.value.join(""), params: [] };
      }
      if (is(chunk, Name)) {
        return { sql: escapeName(chunk.value), params: [] };
      }
      if (chunk === undefined) {
        return { sql: "", params: [] };
      }
      if (Array.isArray(chunk)) {
        const result = [new StringChunk("(")];
        for (const [i, p] of chunk.entries()) {
          result.push(p);
          if (i < chunk.length - 1) {
            result.push(new StringChunk(", "));
          }
        }
        result.push(new StringChunk(")"));
        return this.buildQueryFromSourceParams(result, config);
      }
      if (is(chunk, SQL)) {
        return this.buildQueryFromSourceParams(chunk.queryChunks, {
          ...config,
          inlineParams: inlineParams || chunk.shouldInlineParams
        });
      }
      if (is(chunk, Table)) {
        const schemaName = chunk[Table.Symbol.Schema];
        const tableName = chunk[Table.Symbol.Name];
        return {
          sql: schemaName === undefined ? escapeName(tableName) : escapeName(schemaName) + "." + escapeName(tableName),
          params: []
        };
      }
      if (is(chunk, Column)) {
        if (_config.invokeSource === "indexes") {
          return { sql: escapeName(chunk.name), params: [] };
        }
        return { sql: escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(chunk.name), params: [] };
      }
      if (is(chunk, View)) {
        const schemaName = chunk[ViewBaseConfig].schema;
        const viewName = chunk[ViewBaseConfig].name;
        return {
          sql: schemaName === undefined ? escapeName(viewName) : escapeName(schemaName) + "." + escapeName(viewName),
          params: []
        };
      }
      if (is(chunk, Param)) {
        const mappedValue = chunk.value === null ? null : chunk.encoder.mapToDriverValue(chunk.value);
        if (is(mappedValue, SQL)) {
          return this.buildQueryFromSourceParams([mappedValue], config);
        }
        if (inlineParams) {
          return { sql: this.mapInlineParam(mappedValue, config), params: [] };
        }
        let typings;
        if (prepareTyping) {
          typings = [prepareTyping(chunk.encoder)];
        }
        return { sql: escapeParam(paramStartIndex.value++, mappedValue), params: [mappedValue], typings };
      }
      if (is(chunk, Placeholder)) {
        return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
      }
      if (is(chunk, SQL.Aliased) && chunk.fieldAlias !== undefined) {
        return { sql: escapeName(chunk.fieldAlias), params: [] };
      }
      if (is(chunk, Subquery)) {
        if (chunk._.isWith) {
          return { sql: escapeName(chunk._.alias), params: [] };
        }
        return this.buildQueryFromSourceParams([
          new StringChunk("("),
          chunk._.sql,
          new StringChunk(") "),
          new Name(chunk._.alias)
        ], config);
      }
      if (isPgEnum(chunk)) {
        if (chunk.schema) {
          return { sql: escapeName(chunk.schema) + "." + escapeName(chunk.enumName), params: [] };
        }
        return { sql: escapeName(chunk.enumName), params: [] };
      }
      if (isSQLWrapper(chunk)) {
        if (chunk.shouldOmitSQLParens?.()) {
          return this.buildQueryFromSourceParams([chunk.getSQL()], config);
        }
        return this.buildQueryFromSourceParams([
          new StringChunk("("),
          chunk.getSQL(),
          new StringChunk(")")
        ], config);
      }
      if (inlineParams) {
        return { sql: this.mapInlineParam(chunk, config), params: [] };
      }
      return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk] };
    }));
  }
  mapInlineParam(chunk, { escapeString }) {
    if (chunk === null) {
      return "null";
    }
    if (typeof chunk === "number" || typeof chunk === "boolean") {
      return chunk.toString();
    }
    if (typeof chunk === "string") {
      return escapeString(chunk);
    }
    if (typeof chunk === "object") {
      const mappedValueAsString = chunk.toString();
      if (mappedValueAsString === "[object Object]") {
        return escapeString(JSON.stringify(chunk));
      }
      return escapeString(mappedValueAsString);
    }
    throw new Error("Unexpected param value: " + chunk);
  }
  getSQL() {
    return this;
  }
  as(alias) {
    if (alias === undefined) {
      return this;
    }
    return new SQL.Aliased(this, alias);
  }
  mapWith(decoder) {
    this.decoder = typeof decoder === "function" ? { mapFromDriverValue: decoder } : decoder;
    return this;
  }
  inlineParams() {
    this.shouldInlineParams = true;
    return this;
  }
  if(condition) {
    return condition ? this : undefined;
  }
}

class Name {
  constructor(value) {
    this.value = value;
  }
  static [entityKind] = "Name";
  brand;
  getSQL() {
    return new SQL([this]);
  }
}
var noopDecoder = {
  mapFromDriverValue: (value) => value
};
var noopEncoder = {
  mapToDriverValue: (value) => value
};
var noopMapper = {
  ...noopDecoder,
  ...noopEncoder
};

class Param {
  constructor(value, encoder = noopEncoder) {
    this.value = value;
    this.encoder = encoder;
  }
  static [entityKind] = "Param";
  brand;
  getSQL() {
    return new SQL([this]);
  }
}
((sql2) => {
  function empty() {
    return new SQL([]);
  }
  sql2.empty = empty;
  function fromList(list) {
    return new SQL(list);
  }
  sql2.fromList = fromList;
  function raw(str) {
    return new SQL([new StringChunk(str)]);
  }
  sql2.raw = raw;
  function join(chunks, separator) {
    const result = [];
    for (const [i, chunk] of chunks.entries()) {
      if (i > 0 && separator !== undefined) {
        result.push(separator);
      }
      result.push(chunk);
    }
    return new SQL(result);
  }
  sql2.join = join;
  function identifier(value) {
    return new Name(value);
  }
  sql2.identifier = identifier;
  function placeholder2(name2) {
    return new Placeholder(name2);
  }
  sql2.placeholder = placeholder2;
  function param2(value, encoder) {
    return new Param(value, encoder);
  }
  sql2.param = param2;
})(sql || (sql = {}));
((SQL2) => {

  class Aliased {
    constructor(sql2, fieldAlias) {
      this.sql = sql2;
      this.fieldAlias = fieldAlias;
    }
    static [entityKind] = "SQL.Aliased";
    isSelectionField = false;
    getSQL() {
      return this.sql;
    }
    clone() {
      return new Aliased(this.sql, this.fieldAlias);
    }
  }
  SQL2.Aliased = Aliased;
})(SQL || (SQL = {}));

class Placeholder {
  constructor(name2) {
    this.name = name2;
  }
  static [entityKind] = "Placeholder";
  getSQL() {
    return new SQL([this]);
  }
}

class View {
  static [entityKind] = "View";
  [ViewBaseConfig];
  constructor({ name: name2, schema, selectedFields, query }) {
    this[ViewBaseConfig] = {
      name: name2,
      originalName: name2,
      schema,
      selectedFields,
      query,
      isExisting: !query,
      isAlias: false
    };
  }
  getSQL() {
    return new SQL([this]);
  }
}
Column.prototype.getSQL = function() {
  return new SQL([this]);
};
Table.prototype.getSQL = function() {
  return new SQL([this]);
};
Subquery.prototype.getSQL = function() {
  return new SQL([this]);
};

// node_modules/drizzle-orm/alias.js
var aliasedTable = function(table5, tableAlias) {
  return new Proxy(table5, new TableAliasProxyHandler(tableAlias, false));
};
var aliasedTableColumn = function(column4, tableAlias) {
  return new Proxy(column4, new ColumnAliasProxyHandler(new Proxy(column4.table, new TableAliasProxyHandler(tableAlias, false))));
};
var mapColumnsInAliasedSQLToAlias = function(query, alias) {
  return new SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
};
var mapColumnsInSQLToAlias = function(query, alias) {
  return sql.join(query.queryChunks.map((c) => {
    if (is(c, Column)) {
      return aliasedTableColumn(c, alias);
    }
    if (is(c, SQL)) {
      return mapColumnsInSQLToAlias(c, alias);
    }
    if (is(c, SQL.Aliased)) {
      return mapColumnsInAliasedSQLToAlias(c, alias);
    }
    return c;
  }));
};

class ColumnAliasProxyHandler {
  constructor(table5) {
    this.table = table5;
  }
  static [entityKind] = "ColumnAliasProxyHandler";
  get(columnObj, prop) {
    if (prop === "table") {
      return this.table;
    }
    return columnObj[prop];
  }
}

class TableAliasProxyHandler {
  constructor(alias, replaceOriginalName) {
    this.alias = alias;
    this.replaceOriginalName = replaceOriginalName;
  }
  static [entityKind] = "TableAliasProxyHandler";
  get(target, prop) {
    if (prop === Table.Symbol.IsAlias) {
      return true;
    }
    if (prop === Table.Symbol.Name) {
      return this.alias;
    }
    if (this.replaceOriginalName && prop === Table.Symbol.OriginalName) {
      return this.alias;
    }
    if (prop === ViewBaseConfig) {
      return {
        ...target[ViewBaseConfig],
        name: this.alias,
        isAlias: true
      };
    }
    if (prop === Table.Symbol.Columns) {
      const columns = target[Table.Symbol.Columns];
      if (!columns) {
        return columns;
      }
      const proxiedColumns = {};
      Object.keys(columns).map((key) => {
        proxiedColumns[key] = new Proxy(columns[key], new ColumnAliasProxyHandler(new Proxy(target, this)));
      });
      return proxiedColumns;
    }
    const value = target[prop];
    if (is(value, Column)) {
      return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(target, this)));
    }
    return value;
  }
}

// node_modules/drizzle-orm/errors.js
class DrizzleError extends Error {
  static [entityKind] = "DrizzleError";
  constructor({ message, cause }) {
    super(message);
    this.name = "DrizzleError";
    this.cause = cause;
  }
}

class TransactionRollbackError extends DrizzleError {
  static [entityKind] = "TransactionRollbackError";
  constructor() {
    super({ message: "Rollback" });
  }
}

// node_modules/drizzle-orm/sql/expressions/conditions.js
var bindIfParam = function(value, column5) {
  if (isDriverValueEncoder(column5) && !isSQLWrapper(value) && !is(value, Param) && !is(value, Placeholder) && !is(value, Column) && !is(value, Table) && !is(value, View)) {
    return new Param(value, column5);
  }
  return value;
};
var and = function(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter((c) => c !== undefined);
  if (conditions.length === 0) {
    return;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" and ")),
    new StringChunk(")")
  ]);
};
var or = function(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter((c) => c !== undefined);
  if (conditions.length === 0) {
    return;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" or ")),
    new StringChunk(")")
  ]);
};
var not = function(condition) {
  return sql`not ${condition}`;
};
var inArray = function(column5, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      throw new Error("inArray requires at least one value");
    }
    return sql`${column5} in ${values.map((v) => bindIfParam(v, column5))}`;
  }
  return sql`${column5} in ${bindIfParam(values, column5)}`;
};
var notInArray = function(column5, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      throw new Error("notInArray requires at least one value");
    }
    return sql`${column5} not in ${values.map((v) => bindIfParam(v, column5))}`;
  }
  return sql`${column5} not in ${bindIfParam(values, column5)}`;
};
var isNull = function(value) {
  return sql`${value} is null`;
};
var isNotNull = function(value) {
  return sql`${value} is not null`;
};
var exists = function(subquery2) {
  return sql`exists ${subquery2}`;
};
var notExists = function(subquery2) {
  return sql`not exists ${subquery2}`;
};
var between = function(column5, min, max) {
  return sql`${column5} between ${bindIfParam(min, column5)} and ${bindIfParam(max, column5)}`;
};
var notBetween = function(column5, min, max) {
  return sql`${column5} not between ${bindIfParam(min, column5)} and ${bindIfParam(max, column5)}`;
};
var like = function(column5, value) {
  return sql`${column5} like ${value}`;
};
var notLike = function(column5, value) {
  return sql`${column5} not like ${value}`;
};
var ilike = function(column5, value) {
  return sql`${column5} ilike ${value}`;
};
var notIlike = function(column5, value) {
  return sql`${column5} not ilike ${value}`;
};
var eq = (left, right) => {
  return sql`${left} = ${bindIfParam(right, left)}`;
};
var ne = (left, right) => {
  return sql`${left} <> ${bindIfParam(right, left)}`;
};
var gt = (left, right) => {
  return sql`${left} > ${bindIfParam(right, left)}`;
};
var gte = (left, right) => {
  return sql`${left} >= ${bindIfParam(right, left)}`;
};
var lt = (left, right) => {
  return sql`${left} < ${bindIfParam(right, left)}`;
};
var lte = (left, right) => {
  return sql`${left} <= ${bindIfParam(right, left)}`;
};

// node_modules/drizzle-orm/sql/expressions/select.js
var asc = function(column5) {
  return sql`${column5} asc`;
};
var desc = function(column5) {
  return sql`${column5} desc`;
};

// node_modules/drizzle-orm/logger.js
class ConsoleLogWriter {
  static [entityKind] = "ConsoleLogWriter";
  write(message) {
    console.log(message);
  }
}

class DefaultLogger {
  static [entityKind] = "DefaultLogger";
  writer;
  constructor(config) {
    this.writer = config?.writer ?? new ConsoleLogWriter;
  }
  logQuery(query, params) {
    const stringifiedParams = params.map((p) => {
      try {
        return JSON.stringify(p);
      } catch {
        return String(p);
      }
    });
    const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
    this.writer.write(`Query: ${query}${paramsStr}`);
  }
}

class NoopLogger {
  static [entityKind] = "NoopLogger";
  logQuery() {
  }
}

// node_modules/drizzle-orm/query-promise.js
class QueryPromise {
  static [entityKind] = "QueryPromise";
  [Symbol.toStringTag] = "QueryPromise";
  catch(onRejected) {
    return this.then(undefined, onRejected);
  }
  finally(onFinally) {
    return this.then((value) => {
      onFinally?.();
      return value;
    }, (reason) => {
      onFinally?.();
      throw reason;
    });
  }
  then(onFulfilled, onRejected) {
    return this.execute().then(onFulfilled, onRejected);
  }
}

// node_modules/drizzle-orm/pg-core/primary-keys.js
class PrimaryKeyBuilder {
  static [entityKind] = "PgPrimaryKeyBuilder";
  columns;
  name;
  constructor(columns, name) {
    this.columns = columns;
    this.name = name;
  }
  build(table7) {
    return new PrimaryKey(table7, this.columns, this.name);
  }
}

class PrimaryKey {
  constructor(table7, columns, name) {
    this.table = table7;
    this.columns = columns;
    this.name = name;
  }
  static [entityKind] = "PgPrimaryKey";
  columns;
  name;
  getName() {
    return this.name ?? `${this.table[PgTable.Symbol.Name]}_${this.columns.map((column5) => column5.name).join("_")}_pk`;
  }
}

// node_modules/drizzle-orm/relations.js
var getOperators = function() {
  return {
    and,
    between,
    eq,
    exists,
    gt,
    gte,
    ilike,
    inArray,
    isNull,
    isNotNull,
    like,
    lt,
    lte,
    ne,
    not,
    notBetween,
    notExists,
    notLike,
    notIlike,
    notInArray,
    or,
    sql
  };
};
var getOrderByOperators = function() {
  return {
    sql,
    asc,
    desc
  };
};
var extractTablesRelationalConfig = function(schema, configHelpers) {
  if (Object.keys(schema).length === 1 && "default" in schema && !is(schema["default"], Table)) {
    schema = schema["default"];
  }
  const tableNamesMap = {};
  const relationsBuffer = {};
  const tablesConfig = {};
  for (const [key, value] of Object.entries(schema)) {
    if (is(value, Table)) {
      const dbName = getTableUniqueName(value);
      const bufferedRelations = relationsBuffer[dbName];
      tableNamesMap[dbName] = key;
      tablesConfig[key] = {
        tsName: key,
        dbName: value[Table.Symbol.Name],
        schema: value[Table.Symbol.Schema],
        columns: value[Table.Symbol.Columns],
        relations: bufferedRelations?.relations ?? {},
        primaryKey: bufferedRelations?.primaryKey ?? []
      };
      for (const column6 of Object.values(value[Table.Symbol.Columns])) {
        if (column6.primary) {
          tablesConfig[key].primaryKey.push(column6);
        }
      }
      const extraConfig = value[Table.Symbol.ExtraConfigBuilder]?.(value[Table.Symbol.ExtraConfigColumns]);
      if (extraConfig) {
        for (const configEntry of Object.values(extraConfig)) {
          if (is(configEntry, PrimaryKeyBuilder)) {
            tablesConfig[key].primaryKey.push(...configEntry.columns);
          }
        }
      }
    } else if (is(value, Relations)) {
      const dbName = getTableUniqueName(value.table);
      const tableName = tableNamesMap[dbName];
      const relations2 = value.config(configHelpers(value.table));
      let primaryKey;
      for (const [relationName, relation] of Object.entries(relations2)) {
        if (tableName) {
          const tableConfig = tablesConfig[tableName];
          tableConfig.relations[relationName] = relation;
          if (primaryKey) {
            tableConfig.primaryKey.push(...primaryKey);
          }
        } else {
          if (!(dbName in relationsBuffer)) {
            relationsBuffer[dbName] = {
              relations: {},
              primaryKey
            };
          }
          relationsBuffer[dbName].relations[relationName] = relation;
        }
      }
    }
  }
  return { tables: tablesConfig, tableNamesMap };
};
var createOne = function(sourceTable) {
  return function one(table8, config) {
    return new One(sourceTable, table8, config, config?.fields.reduce((res, f) => res && f.notNull, true) ?? false);
  };
};
var createMany = function(sourceTable) {
  return function many(referencedTable, config) {
    return new Many(sourceTable, referencedTable, config);
  };
};
var normalizeRelation = function(schema, tableNamesMap, relation) {
  if (is(relation, One) && relation.config) {
    return {
      fields: relation.config.fields,
      references: relation.config.references
    };
  }
  const referencedTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
  if (!referencedTableTsName) {
    throw new Error(`Table "${relation.referencedTable[Table.Symbol.Name]}" not found in schema`);
  }
  const referencedTableConfig = schema[referencedTableTsName];
  if (!referencedTableConfig) {
    throw new Error(`Table "${referencedTableTsName}" not found in schema`);
  }
  const sourceTable = relation.sourceTable;
  const sourceTableTsName = tableNamesMap[getTableUniqueName(sourceTable)];
  if (!sourceTableTsName) {
    throw new Error(`Table "${sourceTable[Table.Symbol.Name]}" not found in schema`);
  }
  const reverseRelations = [];
  for (const referencedTableRelation of Object.values(referencedTableConfig.relations)) {
    if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) {
      reverseRelations.push(referencedTableRelation);
    }
  }
  if (reverseRelations.length > 1) {
    throw relation.relationName ? new Error(`There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`) : new Error(`There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[Table.Symbol.Name]}". Please specify relation name`);
  }
  if (reverseRelations[0] && is(reverseRelations[0], One) && reverseRelations[0].config) {
    return {
      fields: reverseRelations[0].config.references,
      references: reverseRelations[0].config.fields
    };
  }
  throw new Error(`There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`);
};
var createTableRelationsHelpers = function(sourceTable) {
  return {
    one: createOne(sourceTable),
    many: createMany(sourceTable)
  };
};
var mapRelationalRow = function(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
  const result = {};
  for (const [
    selectionItemIndex,
    selectionItem
  ] of buildQueryResultSelection.entries()) {
    if (selectionItem.isJson) {
      const relation = tableConfig.relations[selectionItem.tsKey];
      const rawSubRows = row[selectionItemIndex];
      const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
      result[selectionItem.tsKey] = is(relation, One) ? subRows && mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRows, selectionItem.selection, mapColumnValue) : subRows.map((subRow) => mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRow, selectionItem.selection, mapColumnValue));
    } else {
      const value = mapColumnValue(row[selectionItemIndex]);
      const field = selectionItem.field;
      let decoder;
      if (is(field, Column)) {
        decoder = field;
      } else if (is(field, SQL)) {
        decoder = field.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
    }
  }
  return result;
};

class Relation {
  constructor(sourceTable, referencedTable, relationName) {
    this.sourceTable = sourceTable;
    this.referencedTable = referencedTable;
    this.relationName = relationName;
    this.referencedTableName = referencedTable[Table.Symbol.Name];
  }
  static [entityKind] = "Relation";
  referencedTableName;
  fieldName;
}

class Relations {
  constructor(table8, config) {
    this.table = table8;
    this.config = config;
  }
  static [entityKind] = "Relations";
}

class One extends Relation {
  constructor(sourceTable, referencedTable, config, isNullable) {
    super(sourceTable, referencedTable, config?.relationName);
    this.config = config;
    this.isNullable = isNullable;
  }
  static [entityKind] = "One";
  withFieldName(fieldName) {
    const relation = new One(this.sourceTable, this.referencedTable, this.config, this.isNullable);
    relation.fieldName = fieldName;
    return relation;
  }
}

class Many extends Relation {
  constructor(sourceTable, referencedTable, config) {
    super(sourceTable, referencedTable, config?.relationName);
    this.config = config;
  }
  static [entityKind] = "Many";
  withFieldName(fieldName) {
    const relation = new Many(this.sourceTable, this.referencedTable, this.config);
    relation.fieldName = fieldName;
    return relation;
  }
}

// node_modules/drizzle-orm/utils.js
var mapResultRow = function(columns, row, joinsNotNullableMap) {
  const nullifyMap = {};
  const result = columns.reduce((result2, { path: path2, field }, columnIndex) => {
    let decoder;
    if (is(field, Column)) {
      decoder = field;
    } else if (is(field, SQL)) {
      decoder = field.decoder;
    } else {
      decoder = field.sql.decoder;
    }
    let node = result2;
    for (const [pathChunkIndex, pathChunk] of path2.entries()) {
      if (pathChunkIndex < path2.length - 1) {
        if (!(pathChunk in node)) {
          node[pathChunk] = {};
        }
        node = node[pathChunk];
      } else {
        const rawValue = row[columnIndex];
        const value = node[pathChunk] = rawValue === null ? null : decoder.mapFromDriverValue(rawValue);
        if (joinsNotNullableMap && is(field, Column) && path2.length === 2) {
          const objectName = path2[0];
          if (!(objectName in nullifyMap)) {
            nullifyMap[objectName] = value === null ? getTableName(field.table) : false;
          } else if (typeof nullifyMap[objectName] === "string" && nullifyMap[objectName] !== getTableName(field.table)) {
            nullifyMap[objectName] = false;
          }
        }
      }
    }
    return result2;
  }, {});
  if (joinsNotNullableMap && Object.keys(nullifyMap).length > 0) {
    for (const [objectName, tableName] of Object.entries(nullifyMap)) {
      if (typeof tableName === "string" && !joinsNotNullableMap[tableName]) {
        result[objectName] = null;
      }
    }
  }
  return result;
};
var orderSelectedFields = function(fields, pathPrefix) {
  return Object.entries(fields).reduce((result, [name, field]) => {
    if (typeof name !== "string") {
      return result;
    }
    const newPath = pathPrefix ? [...pathPrefix, name] : [name];
    if (is(field, Column) || is(field, SQL) || is(field, SQL.Aliased)) {
      result.push({ path: newPath, field });
    } else if (is(field, Table)) {
      result.push(...orderSelectedFields(field[Table.Symbol.Columns], newPath));
    } else {
      result.push(...orderSelectedFields(field, newPath));
    }
    return result;
  }, []);
};
var haveSameKeys = function(left, right) {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) {
    return false;
  }
  for (const [index, key] of leftKeys.entries()) {
    if (key !== rightKeys[index]) {
      return false;
    }
  }
  return true;
};
var mapUpdateSet = function(table9, values) {
  const entries = Object.entries(values).filter(([, value]) => value !== undefined).map(([key, value]) => {
    if (is(value, SQL)) {
      return [key, value];
    } else {
      return [key, new Param(value, table9[Table.Symbol.Columns][key])];
    }
  });
  if (entries.length === 0) {
    throw new Error("No values to set");
  }
  return Object.fromEntries(entries);
};
var applyMixins = function(baseClass, extendedClasses) {
  for (const extendedClass of extendedClasses) {
    for (const name of Object.getOwnPropertyNames(extendedClass.prototype)) {
      if (name === "constructor")
        continue;
      Object.defineProperty(baseClass.prototype, name, Object.getOwnPropertyDescriptor(extendedClass.prototype, name) || Object.create(null));
    }
  }
};
var getTableColumns = function(table9) {
  return table9[Table.Symbol.Columns];
};
var getTableLikeName = function(table9) {
  return is(table9, Subquery) ? table9._.alias : is(table9, View) ? table9[ViewBaseConfig].name : is(table9, SQL) ? undefined : table9[Table.Symbol.IsAlias] ? table9[Table.Symbol.Name] : table9[Table.Symbol.BaseName];
};

// src/schema.ts
var exports_schema = {};
__export(exports_schema, {
  users: () => users,
  subscribers: () => subscribers,
  smtpServers: () => smtpServers,
  sendingQueue: () => sendingQueue,
  senders: () => senders,
  events: () => events,
  emails: () => emails,
  config: () => config
});

// node_modules/drizzle-orm/sqlite-core/table.js
var sqliteTableBase = function(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new SQLiteTable(name, schema, baseName);
  const builtColumns = Object.fromEntries(Object.entries(columns).map(([name2, colBuilderBase]) => {
    const colBuilder = colBuilderBase;
    const column7 = colBuilder.build(rawTable);
    rawTable[InlineForeignKeys2].push(...colBuilder.buildForeignKeys(column7, rawTable));
    return [name2, column7];
  }));
  const table10 = Object.assign(rawTable, builtColumns);
  table10[Table.Symbol.Columns] = builtColumns;
  table10[Table.Symbol.ExtraConfigColumns] = builtColumns;
  if (extraConfig) {
    table10[SQLiteTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return table10;
};
var InlineForeignKeys2 = Symbol.for("drizzle:SQLiteInlineForeignKeys");

class SQLiteTable extends Table {
  static [entityKind] = "SQLiteTable";
  static Symbol = Object.assign({}, Table.Symbol, {
    InlineForeignKeys: InlineForeignKeys2
  });
  [Table.Symbol.Columns];
  [InlineForeignKeys2] = [];
  [Table.Symbol.ExtraConfigBuilder] = undefined;
}
var sqliteTable = (name, columns, extraConfig) => {
  return sqliteTableBase(name, columns, extraConfig);
};

// node_modules/drizzle-orm/sqlite-core/foreign-keys.js
class ForeignKeyBuilder {
  static [entityKind] = "SQLiteForeignKeyBuilder";
  reference;
  _onUpdate;
  _onDelete;
  constructor(config, actions) {
    this.reference = () => {
      const { name, columns, foreignColumns } = config();
      return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
    };
    if (actions) {
      this._onUpdate = actions.onUpdate;
      this._onDelete = actions.onDelete;
    }
  }
  onUpdate(action) {
    this._onUpdate = action;
    return this;
  }
  onDelete(action) {
    this._onDelete = action;
    return this;
  }
  build(table11) {
    return new ForeignKey(table11, this);
  }
}

class ForeignKey {
  constructor(table11, builder) {
    this.table = table11;
    this.reference = builder.reference;
    this.onUpdate = builder._onUpdate;
    this.onDelete = builder._onDelete;
  }
  static [entityKind] = "SQLiteForeignKey";
  reference;
  onUpdate;
  onDelete;
  getName() {
    const { name, columns, foreignColumns } = this.reference();
    const columnNames = columns.map((column7) => column7.name);
    const foreignColumnNames = foreignColumns.map((column7) => column7.name);
    const chunks = [
      this.table[SQLiteTable.Symbol.Name],
      ...columnNames,
      foreignColumns[0].table[SQLiteTable.Symbol.Name],
      ...foreignColumnNames
    ];
    return name ?? `${chunks.join("_")}_fk`;
  }
}

// node_modules/drizzle-orm/sqlite-core/unique-constraint.js
var uniqueKeyName2 = function(table12, columns) {
  return `${table12[SQLiteTable.Symbol.Name]}_${columns.join("_")}_unique`;
};

// node_modules/drizzle-orm/sqlite-core/columns/common.js
class SQLiteColumnBuilder extends ColumnBuilder {
  static [entityKind] = "SQLiteColumnBuilder";
  foreignKeyConfigs = [];
  references(ref, actions = {}) {
    this.foreignKeyConfigs.push({ ref, actions });
    return this;
  }
  unique(name) {
    this.config.isUnique = true;
    this.config.uniqueName = name;
    return this;
  }
  generatedAlwaysAs(as, config) {
    this.config.generated = {
      as,
      type: "always",
      mode: config?.mode ?? "virtual"
    };
    return this;
  }
  buildForeignKeys(column8, table12) {
    return this.foreignKeyConfigs.map(({ ref, actions }) => {
      return ((ref2, actions2) => {
        const builder = new ForeignKeyBuilder(() => {
          const foreignColumn = ref2();
          return { columns: [column8], foreignColumns: [foreignColumn] };
        });
        if (actions2.onUpdate) {
          builder.onUpdate(actions2.onUpdate);
        }
        if (actions2.onDelete) {
          builder.onDelete(actions2.onDelete);
        }
        return builder.build(table12);
      })(ref, actions);
    });
  }
}

class SQLiteColumn extends Column {
  constructor(table12, config) {
    if (!config.uniqueName) {
      config.uniqueName = uniqueKeyName2(table12, [config.name]);
    }
    super(table12, config);
    this.table = table12;
  }
  static [entityKind] = "SQLiteColumn";
}

// node_modules/drizzle-orm/sqlite-core/columns/integer.js
var integer = function(name, config) {
  if (config?.mode === "timestamp" || config?.mode === "timestamp_ms") {
    return new SQLiteTimestampBuilder(name, config.mode);
  }
  if (config?.mode === "boolean") {
    return new SQLiteBooleanBuilder(name, config.mode);
  }
  return new SQLiteIntegerBuilder(name);
};

class SQLiteBaseIntegerBuilder extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteBaseIntegerBuilder";
  constructor(name, dataType, columnType) {
    super(name, dataType, columnType);
    this.config.autoIncrement = false;
  }
  primaryKey(config) {
    if (config?.autoIncrement) {
      this.config.autoIncrement = true;
    }
    this.config.hasDefault = true;
    return super.primaryKey();
  }
}

class SQLiteBaseInteger extends SQLiteColumn {
  static [entityKind] = "SQLiteBaseInteger";
  autoIncrement = this.config.autoIncrement;
  getSQLType() {
    return "integer";
  }
}

class SQLiteIntegerBuilder extends SQLiteBaseIntegerBuilder {
  static [entityKind] = "SQLiteIntegerBuilder";
  constructor(name) {
    super(name, "number", "SQLiteInteger");
  }
  build(table12) {
    return new SQLiteInteger(table12, this.config);
  }
}

class SQLiteInteger extends SQLiteBaseInteger {
  static [entityKind] = "SQLiteInteger";
}

class SQLiteTimestampBuilder extends SQLiteBaseIntegerBuilder {
  static [entityKind] = "SQLiteTimestampBuilder";
  constructor(name, mode) {
    super(name, "date", "SQLiteTimestamp");
    this.config.mode = mode;
  }
  defaultNow() {
    return this.default(sql`(cast((julianday('now') - 2440587.5)*86400000 as integer))`);
  }
  build(table12) {
    return new SQLiteTimestamp(table12, this.config);
  }
}

class SQLiteTimestamp extends SQLiteBaseInteger {
  static [entityKind] = "SQLiteTimestamp";
  mode = this.config.mode;
  mapFromDriverValue(value) {
    if (this.config.mode === "timestamp") {
      return new Date(value * 1000);
    }
    return new Date(value);
  }
  mapToDriverValue(value) {
    const unix = value.getTime();
    if (this.config.mode === "timestamp") {
      return Math.floor(unix / 1000);
    }
    return unix;
  }
}

class SQLiteBooleanBuilder extends SQLiteBaseIntegerBuilder {
  static [entityKind] = "SQLiteBooleanBuilder";
  constructor(name, mode) {
    super(name, "boolean", "SQLiteBoolean");
    this.config.mode = mode;
  }
  build(table12) {
    return new SQLiteBoolean(table12, this.config);
  }
}

class SQLiteBoolean extends SQLiteBaseInteger {
  static [entityKind] = "SQLiteBoolean";
  mode = this.config.mode;
  mapFromDriverValue(value) {
    return Number(value) === 1;
  }
  mapToDriverValue(value) {
    return value ? 1 : 0;
  }
}

// node_modules/drizzle-orm/sqlite-core/columns/text.js
var text = function(name, config = {}) {
  return config.mode === "json" ? new SQLiteTextJsonBuilder(name) : new SQLiteTextBuilder(name, config);
};

class SQLiteTextBuilder extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteTextBuilder";
  constructor(name, config) {
    super(name, "string", "SQLiteText");
    this.config.enumValues = config.enum;
    this.config.length = config.length;
  }
  build(table12) {
    return new SQLiteText(table12, this.config);
  }
}

class SQLiteText extends SQLiteColumn {
  static [entityKind] = "SQLiteText";
  enumValues = this.config.enumValues;
  length = this.config.length;
  constructor(table12, config) {
    super(table12, config);
  }
  getSQLType() {
    return `text${this.config.length ? `(${this.config.length})` : ""}`;
  }
}

class SQLiteTextJsonBuilder extends SQLiteColumnBuilder {
  static [entityKind] = "SQLiteTextJsonBuilder";
  constructor(name) {
    super(name, "json", "SQLiteTextJson");
  }
  build(table12) {
    return new SQLiteTextJson(table12, this.config);
  }
}

class SQLiteTextJson extends SQLiteColumn {
  static [entityKind] = "SQLiteTextJson";
  getSQLType() {
    return "text";
  }
  mapFromDriverValue(value) {
    return JSON.parse(value);
  }
  mapToDriverValue(value) {
    return JSON.stringify(value);
  }
}

// node_modules/drizzle-orm/selection-proxy.js
class SelectionProxyHandler {
  static [entityKind] = "SelectionProxyHandler";
  config;
  constructor(config) {
    this.config = { ...config };
  }
  get(subquery4, prop) {
    if (prop === "_") {
      return {
        ...subquery4["_"],
        selectedFields: new Proxy(subquery4._.selectedFields, this)
      };
    }
    if (prop === ViewBaseConfig) {
      return {
        ...subquery4[ViewBaseConfig],
        selectedFields: new Proxy(subquery4[ViewBaseConfig].selectedFields, this)
      };
    }
    if (typeof prop === "symbol") {
      return subquery4[prop];
    }
    const columns = is(subquery4, Subquery) ? subquery4._.selectedFields : is(subquery4, View) ? subquery4[ViewBaseConfig].selectedFields : subquery4;
    const value = columns[prop];
    if (is(value, SQL.Aliased)) {
      if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) {
        return value.sql;
      }
      const newValue = value.clone();
      newValue.isSelectionField = true;
      return newValue;
    }
    if (is(value, SQL)) {
      if (this.config.sqlBehavior === "sql") {
        return value;
      }
      throw new Error(`You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`);
    }
    if (is(value, Column)) {
      if (this.config.alias) {
        return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(value.table, new TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false))));
      }
      return value;
    }
    if (typeof value !== "object" || value === null) {
      return value;
    }
    return new Proxy(value, new SelectionProxyHandler(this.config));
  }
}

// node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
class SQLiteDeleteBase extends QueryPromise {
  constructor(table13, session, dialect, withList) {
    super();
    this.table = table13;
    this.session = session;
    this.dialect = dialect;
    this.config = { table: table13, withList };
  }
  static [entityKind] = "SQLiteDelete";
  config;
  where(where) {
    this.config.where = where;
    return this;
  }
  returning(fields = this.table[SQLiteTable.Symbol.Columns]) {
    this.config.returning = orderSelectedFields(fields);
    return this;
  }
  getSQL() {
    return this.dialect.buildDeleteQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  _prepare(isOneTimeQuery = true) {
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true);
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute(placeholderValues) {
    return this._prepare().execute(placeholderValues);
  }
  $dynamic() {
    return this;
  }
}

// node_modules/drizzle-orm/sqlite-core/query-builders/insert.js
class SQLiteInsertBuilder {
  constructor(table15, session, dialect, withList) {
    this.table = table15;
    this.session = session;
    this.dialect = dialect;
    this.withList = withList;
  }
  static [entityKind] = "SQLiteInsertBuilder";
  values(values) {
    values = Array.isArray(values) ? values : [values];
    if (values.length === 0) {
      throw new Error("values() must be called with at least one value");
    }
    const mappedValues = values.map((entry) => {
      const result = {};
      const cols = this.table[Table.Symbol.Columns];
      for (const colKey of Object.keys(entry)) {
        const colValue = entry[colKey];
        result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
      }
      return result;
    });
    return new SQLiteInsertBase(this.table, mappedValues, this.session, this.dialect, this.withList);
  }
}

class SQLiteInsertBase extends QueryPromise {
  constructor(table15, values, session, dialect, withList) {
    super();
    this.session = session;
    this.dialect = dialect;
    this.config = { table: table15, values, withList };
  }
  static [entityKind] = "SQLiteInsert";
  config;
  returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
    this.config.returning = orderSelectedFields(fields);
    return this;
  }
  onConflictDoNothing(config = {}) {
    if (config.target === undefined) {
      this.config.onConflict = sql`do nothing`;
    } else {
      const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
      const whereSql = config.where ? sql` where ${config.where}` : sql``;
      this.config.onConflict = sql`${targetSql} do nothing${whereSql}`;
    }
    return this;
  }
  onConflictDoUpdate(config) {
    if (config.where && (config.targetWhere || config.setWhere)) {
      throw new Error('You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.');
    }
    const whereSql = config.where ? sql` where ${config.where}` : undefined;
    const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : undefined;
    const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : undefined;
    const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
    const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
    this.config.onConflict = sql`${targetSql}${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`;
    return this;
  }
  getSQL() {
    return this.dialect.buildInsertQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  _prepare(isOneTimeQuery = true) {
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true);
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute() {
    return this.config.returning ? this.all() : this.run();
  }
  $dynamic() {
    return this;
  }
}

// node_modules/drizzle-orm/sqlite-core/view-base.js
class SQLiteViewBase extends View {
  static [entityKind] = "SQLiteViewBase";
}

// node_modules/drizzle-orm/sqlite-core/dialect.js
class SQLiteDialect {
  static [entityKind] = "SQLiteDialect";
  escapeName(name) {
    return `"${name}"`;
  }
  escapeParam(_num) {
    return "?";
  }
  escapeString(str) {
    return `'${str.replace(/'/g, "''")}'`;
  }
  buildWithCTE(queries) {
    if (!queries?.length)
      return;
    const withSqlChunks = [sql`with `];
    for (const [i, w] of queries.entries()) {
      withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
      if (i < queries.length - 1) {
        withSqlChunks.push(sql`, `);
      }
    }
    withSqlChunks.push(sql` `);
    return sql.join(withSqlChunks);
  }
  buildDeleteQuery({ table: table17, where, returning, withList }) {
    const withSql = this.buildWithCTE(withList);
    const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : undefined;
    const whereSql = where ? sql` where ${where}` : undefined;
    return sql`${withSql}delete from ${table17}${whereSql}${returningSql}`;
  }
  buildUpdateSet(table17, set) {
    const tableColumns = table17[Table.Symbol.Columns];
    const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== undefined || tableColumns[colName]?.onUpdateFn !== undefined);
    const setSize = columnNames.length;
    return sql.join(columnNames.flatMap((colName, i) => {
      const col = tableColumns[colName];
      const value = set[colName] ?? sql.param(col.onUpdateFn(), col);
      const res = sql`${sql.identifier(col.name)} = ${value}`;
      if (i < setSize - 1) {
        return [res, sql.raw(", ")];
      }
      return [res];
    }));
  }
  buildUpdateQuery({ table: table17, set, where, returning, withList }) {
    const withSql = this.buildWithCTE(withList);
    const setSql = this.buildUpdateSet(table17, set);
    const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : undefined;
    const whereSql = where ? sql` where ${where}` : undefined;
    return sql`${withSql}update ${table17} set ${setSql}${whereSql}${returningSql}`;
  }
  buildSelection(fields, { isSingleTable = false } = {}) {
    const columnsLen = fields.length;
    const chunks = fields.flatMap(({ field }, i) => {
      const chunk = [];
      if (is(field, SQL.Aliased) && field.isSelectionField) {
        chunk.push(sql.identifier(field.fieldAlias));
      } else if (is(field, SQL.Aliased) || is(field, SQL)) {
        const query = is(field, SQL.Aliased) ? field.sql : field;
        if (isSingleTable) {
          chunk.push(new SQL(query.queryChunks.map((c) => {
            if (is(c, Column)) {
              return sql.identifier(c.name);
            }
            return c;
          })));
        } else {
          chunk.push(query);
        }
        if (is(field, SQL.Aliased)) {
          chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
        }
      } else if (is(field, Column)) {
        const tableName = field.table[Table.Symbol.Name];
        const columnName = field.name;
        if (isSingleTable) {
          chunk.push(sql.identifier(columnName));
        } else {
          chunk.push(sql`${sql.identifier(tableName)}.${sql.identifier(columnName)}`);
        }
      }
      if (i < columnsLen - 1) {
        chunk.push(sql`, `);
      }
      return chunk;
    });
    return sql.join(chunks);
  }
  buildSelectQuery({
    withList,
    fields,
    fieldsFlat,
    where,
    having,
    table: table17,
    joins,
    orderBy,
    groupBy,
    limit,
    offset,
    distinct,
    setOperators
  }) {
    const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
    for (const f of fieldsList) {
      if (is(f.field, Column) && getTableName(f.field.table) !== (is(table17, Subquery) ? table17._.alias : is(table17, SQLiteViewBase) ? table17[ViewBaseConfig].name : is(table17, SQL) ? undefined : getTableName(table17)) && !((table22) => joins?.some(({ alias: alias3 }) => alias3 === (table22[Table.Symbol.IsAlias] ? getTableName(table22) : table22[Table.Symbol.BaseName])))(f.field.table)) {
        const tableName = getTableName(f.field.table);
        throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
      }
    }
    const isSingleTable = !joins || joins.length === 0;
    const withSql = this.buildWithCTE(withList);
    const distinctSql = distinct ? sql` distinct` : undefined;
    const selection = this.buildSelection(fieldsList, { isSingleTable });
    const tableSql = (() => {
      if (is(table17, Table) && table17[Table.Symbol.OriginalName] !== table17[Table.Symbol.Name]) {
        return sql`${sql.identifier(table17[Table.Symbol.OriginalName])} ${sql.identifier(table17[Table.Symbol.Name])}`;
      }
      return table17;
    })();
    const joinsArray = [];
    if (joins) {
      for (const [index, joinMeta] of joins.entries()) {
        if (index === 0) {
          joinsArray.push(sql` `);
        }
        const table22 = joinMeta.table;
        if (is(table22, SQLiteTable)) {
          const tableName = table22[SQLiteTable.Symbol.Name];
          const tableSchema = table22[SQLiteTable.Symbol.Schema];
          const origTableName = table22[SQLiteTable.Symbol.OriginalName];
          const alias3 = tableName === origTableName ? undefined : joinMeta.alias;
          joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : undefined}${sql.identifier(origTableName)}${alias3 && sql` ${sql.identifier(alias3)}`} on ${joinMeta.on}`);
        } else {
          joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join ${table22} on ${joinMeta.on}`);
        }
        if (index < joins.length - 1) {
          joinsArray.push(sql` `);
        }
      }
    }
    const joinsSql = sql.join(joinsArray);
    const whereSql = where ? sql` where ${where}` : undefined;
    const havingSql = having ? sql` having ${having}` : undefined;
    const orderByList = [];
    if (orderBy) {
      for (const [index, orderByValue] of orderBy.entries()) {
        orderByList.push(orderByValue);
        if (index < orderBy.length - 1) {
          orderByList.push(sql`, `);
        }
      }
    }
    const groupByList = [];
    if (groupBy) {
      for (const [index, groupByValue] of groupBy.entries()) {
        groupByList.push(groupByValue);
        if (index < groupBy.length - 1) {
          groupByList.push(sql`, `);
        }
      }
    }
    const groupBySql = groupByList.length > 0 ? sql` group by ${sql.join(groupByList)}` : undefined;
    const orderBySql = orderByList.length > 0 ? sql` order by ${sql.join(orderByList)}` : undefined;
    const limitSql = limit ? sql` limit ${limit}` : undefined;
    const offsetSql = offset ? sql` offset ${offset}` : undefined;
    const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}`;
    if (setOperators.length > 0) {
      return this.buildSetOperations(finalQuery, setOperators);
    }
    return finalQuery;
  }
  buildSetOperations(leftSelect, setOperators) {
    const [setOperator, ...rest] = setOperators;
    if (!setOperator) {
      throw new Error("Cannot pass undefined values to any set operator");
    }
    if (rest.length === 0) {
      return this.buildSetOperationQuery({ leftSelect, setOperator });
    }
    return this.buildSetOperations(this.buildSetOperationQuery({ leftSelect, setOperator }), rest);
  }
  buildSetOperationQuery({
    leftSelect,
    setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
  }) {
    const leftChunk = sql`${leftSelect.getSQL()} `;
    const rightChunk = sql`${rightSelect.getSQL()}`;
    let orderBySql;
    if (orderBy && orderBy.length > 0) {
      const orderByValues = [];
      for (const singleOrderBy of orderBy) {
        if (is(singleOrderBy, SQLiteColumn)) {
          orderByValues.push(sql.identifier(singleOrderBy.name));
        } else if (is(singleOrderBy, SQL)) {
          for (let i = 0;i < singleOrderBy.queryChunks.length; i++) {
            const chunk = singleOrderBy.queryChunks[i];
            if (is(chunk, SQLiteColumn)) {
              singleOrderBy.queryChunks[i] = sql.identifier(chunk.name);
            }
          }
          orderByValues.push(sql`${singleOrderBy}`);
        } else {
          orderByValues.push(sql`${singleOrderBy}`);
        }
      }
      orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)}`;
    }
    const limitSql = limit ? sql` limit ${limit}` : undefined;
    const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
    const offsetSql = offset ? sql` offset ${offset}` : undefined;
    return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
  }
  buildInsertQuery({ table: table17, values, onConflict, returning, withList }) {
    const valuesSqlList = [];
    const columns2 = table17[Table.Symbol.Columns];
    const colEntries = Object.entries(columns2).filter(([_, col]) => !col.shouldDisableInsert());
    const insertOrder = colEntries.map(([, column10]) => sql.identifier(column10.name));
    for (const [valueIndex, value] of values.entries()) {
      const valueList = [];
      for (const [fieldName, col] of colEntries) {
        const colValue = value[fieldName];
        if (colValue === undefined || is(colValue, Param) && colValue.value === undefined) {
          let defaultValue;
          if (col.default !== null && col.default !== undefined) {
            defaultValue = is(col.default, SQL) ? col.default : sql.param(col.default, col);
          } else if (col.defaultFn !== undefined) {
            const defaultFnResult = col.defaultFn();
            defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
          } else if (!col.default && col.onUpdateFn !== undefined) {
            const onUpdateFnResult = col.onUpdateFn();
            defaultValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
          } else {
            defaultValue = sql`null`;
          }
          valueList.push(defaultValue);
        } else {
          valueList.push(colValue);
        }
      }
      valuesSqlList.push(valueList);
      if (valueIndex < values.length - 1) {
        valuesSqlList.push(sql`, `);
      }
    }
    const withSql = this.buildWithCTE(withList);
    const valuesSql = sql.join(valuesSqlList);
    const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : undefined;
    const onConflictSql = onConflict ? sql` on conflict ${onConflict}` : undefined;
    return sql`${withSql}insert into ${table17} ${insertOrder} values ${valuesSql}${onConflictSql}${returningSql}`;
  }
  sqlToQuery(sql22, invokeSource) {
    return sql22.toQuery({
      escapeName: this.escapeName,
      escapeParam: this.escapeParam,
      escapeString: this.escapeString,
      invokeSource
    });
  }
  buildRelationalQuery({
    fullSchema,
    schema,
    tableNamesMap,
    table: table17,
    tableConfig,
    queryConfig: config,
    tableAlias,
    nestedQueryRelation,
    joinOn
  }) {
    let selection = [];
    let limit, offset, orderBy = [], where;
    const joins = [];
    if (config === true) {
      const selectionEntries = Object.entries(tableConfig.columns);
      selection = selectionEntries.map(([key, value]) => ({
        dbKey: value.name,
        tsKey: key,
        field: aliasedTableColumn(value, tableAlias),
        relationTableTsKey: undefined,
        isJson: false,
        selection: []
      }));
    } else {
      const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]));
      if (config.where) {
        const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
        where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
      }
      const fieldsSelection = [];
      let selectedColumns = [];
      if (config.columns) {
        let isIncludeMode = false;
        for (const [field, value] of Object.entries(config.columns)) {
          if (value === undefined) {
            continue;
          }
          if (field in tableConfig.columns) {
            if (!isIncludeMode && value === true) {
              isIncludeMode = true;
            }
            selectedColumns.push(field);
          }
        }
        if (selectedColumns.length > 0) {
          selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
        }
      } else {
        selectedColumns = Object.keys(tableConfig.columns);
      }
      for (const field of selectedColumns) {
        const column10 = tableConfig.columns[field];
        fieldsSelection.push({ tsKey: field, value: column10 });
      }
      let selectedRelations = [];
      if (config.with) {
        selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({ tsKey, queryConfig, relation: tableConfig.relations[tsKey] }));
      }
      let extras;
      if (config.extras) {
        extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
        for (const [tsKey, value] of Object.entries(extras)) {
          fieldsSelection.push({
            tsKey,
            value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
          });
        }
      }
      for (const { tsKey, value } of fieldsSelection) {
        selection.push({
          dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
          tsKey,
          field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
          relationTableTsKey: undefined,
          isJson: false,
          selection: []
        });
      }
      let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
      if (!Array.isArray(orderByOrig)) {
        orderByOrig = [orderByOrig];
      }
      orderBy = orderByOrig.map((orderByValue) => {
        if (is(orderByValue, Column)) {
          return aliasedTableColumn(orderByValue, tableAlias);
        }
        return mapColumnsInSQLToAlias(orderByValue, tableAlias);
      });
      limit = config.limit;
      offset = config.offset;
      for (const {
        tsKey: selectedRelationTsKey,
        queryConfig: selectedRelationConfigValue,
        relation
      } of selectedRelations) {
        const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
        const relationTableName = getTableUniqueName(relation.referencedTable);
        const relationTableTsName = tableNamesMap[relationTableName];
        const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
        const joinOn2 = and(...normalizedRelation.fields.map((field2, i) => eq(aliasedTableColumn(normalizedRelation.references[i], relationTableAlias), aliasedTableColumn(field2, tableAlias))));
        const builtRelation = this.buildRelationalQuery({
          fullSchema,
          schema,
          tableNamesMap,
          table: fullSchema[relationTableTsName],
          tableConfig: schema[relationTableTsName],
          queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
          tableAlias: relationTableAlias,
          joinOn: joinOn2,
          nestedQueryRelation: relation
        });
        const field = sql`(${builtRelation.sql})`.as(selectedRelationTsKey);
        selection.push({
          dbKey: selectedRelationTsKey,
          tsKey: selectedRelationTsKey,
          field,
          relationTableTsKey: relationTableTsName,
          isJson: true,
          selection: builtRelation.selection
        });
      }
    }
    if (selection.length === 0) {
      throw new DrizzleError({
        message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.`
      });
    }
    let result;
    where = and(joinOn, where);
    if (nestedQueryRelation) {
      let field = sql`json_array(${sql.join(selection.map(({ field: field2 }) => is(field2, SQLiteColumn) ? sql.identifier(field2.name) : is(field2, SQL.Aliased) ? field2.sql : field2), sql`, `)})`;
      if (is(nestedQueryRelation, Many)) {
        field = sql`coalesce(json_group_array(${field}), json_array())`;
      }
      const nestedSelection = [{
        dbKey: "data",
        tsKey: "data",
        field: field.as("data"),
        isJson: true,
        relationTableTsKey: tableConfig.tsName,
        selection
      }];
      const needsSubquery = limit !== undefined || offset !== undefined || orderBy.length > 0;
      if (needsSubquery) {
        result = this.buildSelectQuery({
          table: aliasedTable(table17, tableAlias),
          fields: {},
          fieldsFlat: [
            {
              path: [],
              field: sql.raw("*")
            }
          ],
          where,
          limit,
          offset,
          orderBy,
          setOperators: []
        });
        where = undefined;
        limit = undefined;
        offset = undefined;
        orderBy = undefined;
      } else {
        result = aliasedTable(table17, tableAlias);
      }
      result = this.buildSelectQuery({
        table: is(result, SQLiteTable) ? result : new Subquery(result, {}, tableAlias),
        fields: {},
        fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
          path: [],
          field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
        })),
        joins,
        where,
        limit,
        offset,
        orderBy,
        setOperators: []
      });
    } else {
      result = this.buildSelectQuery({
        table: aliasedTable(table17, tableAlias),
        fields: {},
        fieldsFlat: selection.map(({ field }) => ({
          path: [],
          field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
        })),
        joins,
        where,
        limit,
        offset,
        orderBy,
        setOperators: []
      });
    }
    return {
      tableTsKey: tableConfig.tsName,
      sql: result,
      selection
    };
  }
}

class SQLiteSyncDialect extends SQLiteDialect {
  static [entityKind] = "SQLiteSyncDialect";
  migrate(migrations, session, config) {
    const migrationsTable = config === undefined ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
    const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
    session.run(migrationTableCreate);
    const dbMigrations = session.values(sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`);
    const lastDbMigration = dbMigrations[0] ?? undefined;
    session.run(sql`BEGIN`);
    try {
      for (const migration of migrations) {
        if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
          for (const stmt of migration.sql) {
            session.run(sql.raw(stmt));
          }
          session.run(sql`INSERT INTO ${sql.identifier(migrationsTable)} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`);
        }
      }
      session.run(sql`COMMIT`);
    } catch (e) {
      session.run(sql`ROLLBACK`);
      throw e;
    }
  }
}

// node_modules/drizzle-orm/query-builders/query-builder.js
class TypedQueryBuilder {
  static [entityKind] = "TypedQueryBuilder";
  getSelectedFields() {
    return this._.selectedFields;
  }
}

// node_modules/drizzle-orm/sqlite-core/query-builders/select.js
var createSetOperator = function(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
};

class SQLiteSelectBuilder {
  static [entityKind] = "SQLiteSelectBuilder";
  fields;
  session;
  dialect;
  withList;
  distinct;
  constructor(config) {
    this.fields = config.fields;
    this.session = config.session;
    this.dialect = config.dialect;
    this.withList = config.withList;
    this.distinct = config.distinct;
  }
  from(source) {
    const isPartialSelect = !!this.fields;
    let fields;
    if (this.fields) {
      fields = this.fields;
    } else if (is(source, Subquery)) {
      fields = Object.fromEntries(Object.keys(source._.selectedFields).map((key) => [key, source[key]]));
    } else if (is(source, SQLiteViewBase)) {
      fields = source[ViewBaseConfig].selectedFields;
    } else if (is(source, SQL)) {
      fields = {};
    } else {
      fields = getTableColumns(source);
    }
    return new SQLiteSelectBase({
      table: source,
      fields,
      isPartialSelect,
      session: this.session,
      dialect: this.dialect,
      withList: this.withList,
      distinct: this.distinct
    });
  }
}

class SQLiteSelectQueryBuilderBase extends TypedQueryBuilder {
  static [entityKind] = "SQLiteSelectQueryBuilder";
  _;
  config;
  joinsNotNullableMap;
  tableName;
  isPartialSelect;
  session;
  dialect;
  constructor({ table: table18, fields, isPartialSelect, session, dialect, withList, distinct }) {
    super();
    this.config = {
      withList,
      table: table18,
      fields: { ...fields },
      distinct,
      setOperators: []
    };
    this.isPartialSelect = isPartialSelect;
    this.session = session;
    this.dialect = dialect;
    this._ = {
      selectedFields: fields
    };
    this.tableName = getTableLikeName(table18);
    this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
  }
  createJoin(joinType) {
    return (table18, on) => {
      const baseTableName = this.tableName;
      const tableName = getTableLikeName(table18);
      if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
        throw new Error(`Alias "${tableName}" is already used in this query`);
      }
      if (!this.isPartialSelect) {
        if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
          this.config.fields = {
            [baseTableName]: this.config.fields
          };
        }
        if (typeof tableName === "string" && !is(table18, SQL)) {
          const selection = is(table18, Subquery) ? table18._.selectedFields : is(table18, View) ? table18[ViewBaseConfig].selectedFields : table18[Table.Symbol.Columns];
          this.config.fields[tableName] = selection;
        }
      }
      if (typeof on === "function") {
        on = on(new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
      }
      if (!this.config.joins) {
        this.config.joins = [];
      }
      this.config.joins.push({ on, table: table18, joinType, alias: tableName });
      if (typeof tableName === "string") {
        switch (joinType) {
          case "left": {
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
          case "right": {
            this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "inner": {
            this.joinsNotNullableMap[tableName] = true;
            break;
          }
          case "full": {
            this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
            this.joinsNotNullableMap[tableName] = false;
            break;
          }
        }
      }
      return this;
    };
  }
  leftJoin = this.createJoin("left");
  rightJoin = this.createJoin("right");
  innerJoin = this.createJoin("inner");
  fullJoin = this.createJoin("full");
  createSetOperator(type, isAll) {
    return (rightSelection) => {
      const rightSelect = typeof rightSelection === "function" ? rightSelection(getSQLiteSetOperators()) : rightSelection;
      if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) {
        throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
      }
      this.config.setOperators.push({ type, isAll, rightSelect });
      return this;
    };
  }
  union = this.createSetOperator("union", false);
  unionAll = this.createSetOperator("union", true);
  intersect = this.createSetOperator("intersect", false);
  except = this.createSetOperator("except", false);
  addSetOperators(setOperators) {
    this.config.setOperators.push(...setOperators);
    return this;
  }
  where(where) {
    if (typeof where === "function") {
      where = where(new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
    }
    this.config.where = where;
    return this;
  }
  having(having) {
    if (typeof having === "function") {
      having = having(new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
    }
    this.config.having = having;
    return this;
  }
  groupBy(...columns2) {
    if (typeof columns2[0] === "function") {
      const groupBy = columns2[0](new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })));
      this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
    } else {
      this.config.groupBy = columns2;
    }
    return this;
  }
  orderBy(...columns2) {
    if (typeof columns2[0] === "function") {
      const orderBy = columns2[0](new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })));
      const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).orderBy = orderByArray;
      } else {
        this.config.orderBy = orderByArray;
      }
    } else {
      const orderByArray = columns2;
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).orderBy = orderByArray;
      } else {
        this.config.orderBy = orderByArray;
      }
    }
    return this;
  }
  limit(limit) {
    if (this.config.setOperators.length > 0) {
      this.config.setOperators.at(-1).limit = limit;
    } else {
      this.config.limit = limit;
    }
    return this;
  }
  offset(offset) {
    if (this.config.setOperators.length > 0) {
      this.config.setOperators.at(-1).offset = offset;
    } else {
      this.config.offset = offset;
    }
    return this;
  }
  getSQL() {
    return this.dialect.buildSelectQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  as(alias3) {
    return new Proxy(new Subquery(this.getSQL(), this.config.fields, alias3), new SelectionProxyHandler({ alias: alias3, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
  }
  getSelectedFields() {
    return new Proxy(this.config.fields, new SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
  }
  $dynamic() {
    return this;
  }
}

class SQLiteSelectBase extends SQLiteSelectQueryBuilderBase {
  static [entityKind] = "SQLiteSelect";
  _prepare(isOneTimeQuery = true) {
    if (!this.session) {
      throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
    }
    const fieldsList = orderSelectedFields(this.config.fields);
    const query = this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), fieldsList, "all", true);
    query.joinsNotNullableMap = this.joinsNotNullableMap;
    return query;
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute() {
    return this.all();
  }
}
applyMixins(SQLiteSelectBase, [QueryPromise]);
var getSQLiteSetOperators = () => ({
  union,
  unionAll,
  intersect,
  except
});
var union = createSetOperator("union", false);
var unionAll = createSetOperator("union", true);
var intersect = createSetOperator("intersect", false);
var except = createSetOperator("except", false);

// node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
class QueryBuilder {
  static [entityKind] = "SQLiteQueryBuilder";
  dialect;
  $with(alias3) {
    const queryBuilder = this;
    return {
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(queryBuilder);
        }
        return new Proxy(new WithSubquery(qb.getSQL(), qb.getSelectedFields(), alias3, true), new SelectionProxyHandler({ alias: alias3, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
      }
    };
  }
  with(...queries) {
    const self = this;
    function select2(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? undefined,
        session: undefined,
        dialect: self.getDialect(),
        withList: queries
      });
    }
    function selectDistinct(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? undefined,
        session: undefined,
        dialect: self.getDialect(),
        withList: queries,
        distinct: true
      });
    }
    return { select: select2, selectDistinct };
  }
  select(fields) {
    return new SQLiteSelectBuilder({ fields: fields ?? undefined, session: undefined, dialect: this.getDialect() });
  }
  selectDistinct(fields) {
    return new SQLiteSelectBuilder({
      fields: fields ?? undefined,
      session: undefined,
      dialect: this.getDialect(),
      distinct: true
    });
  }
  getDialect() {
    if (!this.dialect) {
      this.dialect = new SQLiteSyncDialect;
    }
    return this.dialect;
  }
}

// node_modules/drizzle-orm/sqlite-core/query-builders/update.js
class SQLiteUpdateBuilder {
  constructor(table19, session, dialect2, withList) {
    this.table = table19;
    this.session = session;
    this.dialect = dialect2;
    this.withList = withList;
  }
  static [entityKind] = "SQLiteUpdateBuilder";
  set(values) {
    return new SQLiteUpdateBase(this.table, mapUpdateSet(this.table, values), this.session, this.dialect, this.withList);
  }
}

class SQLiteUpdateBase extends QueryPromise {
  constructor(table19, set, session, dialect2, withList) {
    super();
    this.session = session;
    this.dialect = dialect2;
    this.config = { set, table: table19, withList };
  }
  static [entityKind] = "SQLiteUpdate";
  config;
  where(where) {
    this.config.where = where;
    return this;
  }
  returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
    this.config.returning = orderSelectedFields(fields);
    return this;
  }
  getSQL() {
    return this.dialect.buildUpdateQuery(this.config);
  }
  toSQL() {
    const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
    return rest;
  }
  _prepare(isOneTimeQuery = true) {
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true);
  }
  prepare() {
    return this._prepare(false);
  }
  run = (placeholderValues) => {
    return this._prepare().run(placeholderValues);
  };
  all = (placeholderValues) => {
    return this._prepare().all(placeholderValues);
  };
  get = (placeholderValues) => {
    return this._prepare().get(placeholderValues);
  };
  values = (placeholderValues) => {
    return this._prepare().values(placeholderValues);
  };
  async execute() {
    return this.config.returning ? this.all() : this.run();
  }
  $dynamic() {
    return this;
  }
}

// node_modules/drizzle-orm/sqlite-core/query-builders/query.js
class RelationalQueryBuilder {
  constructor(mode, fullSchema, schema, tableNamesMap, table19, tableConfig, dialect2, session) {
    this.mode = mode;
    this.fullSchema = fullSchema;
    this.schema = schema;
    this.tableNamesMap = tableNamesMap;
    this.table = table19;
    this.tableConfig = tableConfig;
    this.dialect = dialect2;
    this.session = session;
  }
  static [entityKind] = "SQLiteAsyncRelationalQueryBuilder";
  findMany(config) {
    return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many");
  }
  findFirst(config) {
    return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? { ...config, limit: 1 } : { limit: 1 }, "first") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? { ...config, limit: 1 } : { limit: 1 }, "first");
  }
}

class SQLiteRelationalQuery extends QueryPromise {
  constructor(fullSchema, schema, tableNamesMap, table19, tableConfig, dialect2, session, config, mode) {
    super();
    this.fullSchema = fullSchema;
    this.schema = schema;
    this.tableNamesMap = tableNamesMap;
    this.table = table19;
    this.tableConfig = tableConfig;
    this.dialect = dialect2;
    this.session = session;
    this.config = config;
    this.mode = mode;
  }
  static [entityKind] = "SQLiteAsyncRelationalQuery";
  mode;
  getSQL() {
    return this.dialect.buildRelationalQuery({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    }).sql;
  }
  _prepare(isOneTimeQuery = false) {
    const { query, builtQuery } = this._toSQL();
    return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](builtQuery, undefined, this.mode === "first" ? "get" : "all", true, (rawRows, mapColumnValue) => {
      const rows = rawRows.map((row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue));
      if (this.mode === "first") {
        return rows[0];
      }
      return rows;
    });
  }
  prepare() {
    return this._prepare(false);
  }
  _toSQL() {
    const query = this.dialect.buildRelationalQuery({
      fullSchema: this.fullSchema,
      schema: this.schema,
      tableNamesMap: this.tableNamesMap,
      table: this.table,
      tableConfig: this.tableConfig,
      queryConfig: this.config,
      tableAlias: this.tableConfig.tsName
    });
    const builtQuery = this.dialect.sqlToQuery(query.sql);
    return { query, builtQuery };
  }
  toSQL() {
    return this._toSQL().builtQuery;
  }
  executeRaw() {
    if (this.mode === "first") {
      return this._prepare(false).get();
    }
    return this._prepare(false).all();
  }
  async execute() {
    return this.executeRaw();
  }
}

class SQLiteSyncRelationalQuery extends SQLiteRelationalQuery {
  static [entityKind] = "SQLiteSyncRelationalQuery";
  sync() {
    return this.executeRaw();
  }
}

// node_modules/drizzle-orm/sqlite-core/query-builders/raw.js
class SQLiteRaw extends QueryPromise {
  constructor(execute, getSQL, action, dialect2, mapBatchResult) {
    super();
    this.execute = execute;
    this.getSQL = getSQL;
    this.dialect = dialect2;
    this.mapBatchResult = mapBatchResult;
    this.config = { action };
  }
  static [entityKind] = "SQLiteRaw";
  config;
  getQuery() {
    return { ...this.dialect.sqlToQuery(this.getSQL()), method: this.config.action };
  }
  mapResult(result, isFromBatch) {
    return isFromBatch ? this.mapBatchResult(result) : result;
  }
  _prepare() {
    return this;
  }
  isResponseInArrayMode() {
    return false;
  }
}

// node_modules/drizzle-orm/sqlite-core/db.js
class BaseSQLiteDatabase {
  constructor(resultKind, dialect2, session, schema) {
    this.resultKind = resultKind;
    this.dialect = dialect2;
    this.session = session;
    this._ = schema ? {
      schema: schema.schema,
      fullSchema: schema.fullSchema,
      tableNamesMap: schema.tableNamesMap
    } : {
      schema: undefined,
      fullSchema: {},
      tableNamesMap: {}
    };
    this.query = {};
    const query2 = this.query;
    if (this._.schema) {
      for (const [tableName, columns2] of Object.entries(this._.schema)) {
        query2[tableName] = new RelationalQueryBuilder(resultKind, schema.fullSchema, this._.schema, this._.tableNamesMap, schema.fullSchema[tableName], columns2, dialect2, session);
      }
    }
  }
  static [entityKind] = "BaseSQLiteDatabase";
  query;
  $with(alias3) {
    return {
      as(qb) {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder);
        }
        return new Proxy(new WithSubquery(qb.getSQL(), qb.getSelectedFields(), alias3, true), new SelectionProxyHandler({ alias: alias3, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
      }
    };
  }
  with(...queries) {
    const self = this;
    function select2(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? undefined,
        session: self.session,
        dialect: self.dialect,
        withList: queries
      });
    }
    function selectDistinct(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? undefined,
        session: self.session,
        dialect: self.dialect,
        withList: queries,
        distinct: true
      });
    }
    function update(table19) {
      return new SQLiteUpdateBuilder(table19, self.session, self.dialect, queries);
    }
    function insert(into) {
      return new SQLiteInsertBuilder(into, self.session, self.dialect, queries);
    }
    function delete_(from) {
      return new SQLiteDeleteBase(from, self.session, self.dialect, queries);
    }
    return { select: select2, selectDistinct, update, insert, delete: delete_ };
  }
  select(fields) {
    return new SQLiteSelectBuilder({ fields: fields ?? undefined, session: this.session, dialect: this.dialect });
  }
  selectDistinct(fields) {
    return new SQLiteSelectBuilder({
      fields: fields ?? undefined,
      session: this.session,
      dialect: this.dialect,
      distinct: true
    });
  }
  update(table19) {
    return new SQLiteUpdateBuilder(table19, this.session, this.dialect);
  }
  insert(into) {
    return new SQLiteInsertBuilder(into, this.session, this.dialect);
  }
  delete(from) {
    return new SQLiteDeleteBase(from, this.session, this.dialect);
  }
  run(query2) {
    const sql14 = query2.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(async () => this.session.run(sql14), () => sql14, "run", this.dialect, this.session.extractRawRunValueFromBatchResult.bind(this.session));
    }
    return this.session.run(sql14);
  }
  all(query2) {
    const sql14 = query2.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(async () => this.session.all(sql14), () => sql14, "all", this.dialect, this.session.extractRawAllValueFromBatchResult.bind(this.session));
    }
    return this.session.all(sql14);
  }
  get(query2) {
    const sql14 = query2.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(async () => this.session.get(sql14), () => sql14, "get", this.dialect, this.session.extractRawGetValueFromBatchResult.bind(this.session));
    }
    return this.session.get(sql14);
  }
  values(query2) {
    const sql14 = query2.getSQL();
    if (this.resultKind === "async") {
      return new SQLiteRaw(async () => this.session.values(sql14), () => sql14, "values", this.dialect, this.session.extractRawValuesValueFromBatchResult.bind(this.session));
    }
    return this.session.values(sql14);
  }
  transaction(transaction, config) {
    return this.session.transaction(transaction, config);
  }
}

// node_modules/drizzle-orm/sqlite-core/session.js
class ExecuteResultSync extends QueryPromise {
  constructor(resultCb) {
    super();
    this.resultCb = resultCb;
  }
  static [entityKind] = "ExecuteResultSync";
  async execute() {
    return this.resultCb();
  }
  sync() {
    return this.resultCb();
  }
}

class SQLitePreparedQuery {
  constructor(mode, executeMethod, query2) {
    this.mode = mode;
    this.executeMethod = executeMethod;
    this.query = query2;
  }
  static [entityKind] = "PreparedQuery";
  joinsNotNullableMap;
  getQuery() {
    return this.query;
  }
  mapRunResult(result, _isFromBatch) {
    return result;
  }
  mapAllResult(_result, _isFromBatch) {
    throw new Error("Not implemented");
  }
  mapGetResult(_result, _isFromBatch) {
    throw new Error("Not implemented");
  }
  execute(placeholderValues) {
    if (this.mode === "async") {
      return this[this.executeMethod](placeholderValues);
    }
    return new ExecuteResultSync(() => this[this.executeMethod](placeholderValues));
  }
  mapResult(response, isFromBatch) {
    switch (this.executeMethod) {
      case "run": {
        return this.mapRunResult(response, isFromBatch);
      }
      case "all": {
        return this.mapAllResult(response, isFromBatch);
      }
      case "get": {
        return this.mapGetResult(response, isFromBatch);
      }
    }
  }
}

class SQLiteSession {
  constructor(dialect2) {
    this.dialect = dialect2;
  }
  static [entityKind] = "SQLiteSession";
  prepareOneTimeQuery(query2, fields, executeMethod, isResponseInArrayMode) {
    return this.prepareQuery(query2, fields, executeMethod, isResponseInArrayMode);
  }
  run(query2) {
    const staticQuery = this.dialect.sqlToQuery(query2);
    try {
      return this.prepareOneTimeQuery(staticQuery, undefined, "run", false).run();
    } catch (err) {
      throw new DrizzleError({ cause: err, message: `Failed to run the query '${staticQuery.sql}'` });
    }
  }
  extractRawRunValueFromBatchResult(result) {
    return result;
  }
  all(query2) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query2), undefined, "run", false).all();
  }
  extractRawAllValueFromBatchResult(_result) {
    throw new Error("Not implemented");
  }
  get(query2) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query2), undefined, "run", false).get();
  }
  extractRawGetValueFromBatchResult(_result) {
    throw new Error("Not implemented");
  }
  values(query2) {
    return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query2), undefined, "run", false).values();
  }
  extractRawValuesValueFromBatchResult(_result) {
    throw new Error("Not implemented");
  }
}

class SQLiteTransaction extends BaseSQLiteDatabase {
  constructor(resultType, dialect2, session, schema, nestedIndex = 0) {
    super(resultType, dialect2, session, schema);
    this.schema = schema;
    this.nestedIndex = nestedIndex;
  }
  static [entityKind] = "SQLiteTransaction";
  rollback() {
    throw new TransactionRollbackError;
  }
}

// node_modules/uuid/wrapper.mjs
var dist = __toESM(require_dist(), 1);
var v1 = dist.default.v1;
var v1ToV6 = dist.default.v1ToV6;
var v3 = dist.default.v3;
var v4 = dist.default.v4;
var v5 = dist.default.v5;
var v6 = dist.default.v6;
var v6ToV1 = dist.default.v6ToV1;
var v7 = dist.default.v7;
var NIL = dist.default.NIL;
var MAX = dist.default.MAX;
var version3 = dist.default.version;
var validate = dist.default.validate;
var stringify = dist.default.stringify;
var parse = dist.default.parse;

// src/schema.ts
var timestamps = () => ({
  createdAt: text("created_at").default(sql`(CURRENT_TIMESTAMP)`),
  updatedAt: text("updated_at").$onUpdate(() => sql`(CURRENT_TIMESTAMP)`)
});
var users = sqliteTable("users", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  ...timestamps()
});
var smtpServers = sqliteTable("smtp_servers", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  name: text("name"),
  smtpConfig: text("smtp_config", { mode: "json" }),
  ...timestamps()
});
var senders = sqliteTable("senders", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  from: text("from").notNull(),
  smtpServer: integer("smtpServer", { mode: "number" }).references(() => smtpServers.id),
  ...timestamps()
});
var subscribers = sqliteTable("subscribers", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  email: text("email").notNull(),
  name: text("name"),
  attributes: text("attributes", { mode: "json" }),
  status: text("status").$type(),
  uuid: text("uuid").$defaultFn(() => v4()),
  ...timestamps()
});
var events = sqliteTable("events", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  type: text("type").$type(),
  payload: text("payload", { mode: "json" }).$type(),
  time: text("time").default(sql`(CURRENT_TIMESTAMP)`),
  status: text("status").$type().default("pending"),
  ...timestamps()
});
var emails = sqliteTable("emails", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  type: text("type").$type(),
  subject: text("subject").notNull(),
  body: text("body").notNull(),
  createdBy: integer("created_by", { mode: "number" }).references(() => users.id),
  ...timestamps()
});
var sendingQueue = sqliteTable("sending_queue", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  sender: integer("sender", { mode: "number" }).references(() => senders.id),
  event: integer("event", { mode: "number" }).references(() => events.id),
  email: integer("email", { mode: "number" }).references(() => emails.id),
  status: text("status").$type().default("pending").notNull(),
  retries: integer("retries").default(0).notNull(),
  payload: text("payload", { mode: "json" }).$type(),
  sentAt: text("sent_at"),
  ...timestamps()
});
var config = sqliteTable("config", {
  id: integer("id", { mode: "number" }).primaryKey({ autoIncrement: true }),
  jwtSecret: text("jwt_secret"),
  defaultSender: integer("default_sender", { mode: "number" }).references(() => senders.id),
  siteUrl: text("site_url"),
  welcomeEmail: integer("welcome_email", {
    mode: "number"
  }).references(() => emails.id),
  confirmationEmail: integer("confirmation_email", {
    mode: "number"
  }).references(() => emails.id),
  ...timestamps()
});

// node_modules/drizzle-orm/bun-sqlite/session.js
class SQLiteBunSession extends SQLiteSession {
  constructor(client, dialect2, schema, options = {}) {
    super(dialect2);
    this.client = client;
    this.schema = schema;
    this.logger = options.logger ?? new NoopLogger;
  }
  static [entityKind] = "SQLiteBunSession";
  logger;
  exec(query2) {
    this.client.exec(query2);
  }
  prepareQuery(query2, fields, executeMethod, isResponseInArrayMode, customResultMapper) {
    const stmt = this.client.prepare(query2.sql);
    return new PreparedQuery(stmt, query2, this.logger, fields, executeMethod, isResponseInArrayMode, customResultMapper);
  }
  transaction(transaction, config2 = {}) {
    const tx = new SQLiteBunTransaction("sync", this.dialect, this, this.schema);
    let result;
    const nativeTx = this.client.transaction(() => {
      result = transaction(tx);
    });
    nativeTx[config2.behavior ?? "deferred"]();
    return result;
  }
}

class SQLiteBunTransaction extends SQLiteTransaction {
  static [entityKind] = "SQLiteBunTransaction";
  transaction(transaction) {
    const savepointName = `sp${this.nestedIndex}`;
    const tx = new SQLiteBunTransaction("sync", this.dialect, this.session, this.schema, this.nestedIndex + 1);
    this.session.run(sql.raw(`savepoint ${savepointName}`));
    try {
      const result = transaction(tx);
      this.session.run(sql.raw(`release savepoint ${savepointName}`));
      return result;
    } catch (err) {
      this.session.run(sql.raw(`rollback to savepoint ${savepointName}`));
      throw err;
    }
  }
}

class PreparedQuery extends SQLitePreparedQuery {
  constructor(stmt, query2, logger2, fields, executeMethod, _isResponseInArrayMode, customResultMapper) {
    super("sync", executeMethod, query2);
    this.stmt = stmt;
    this.logger = logger2;
    this.fields = fields;
    this._isResponseInArrayMode = _isResponseInArrayMode;
    this.customResultMapper = customResultMapper;
  }
  static [entityKind] = "SQLiteBunPreparedQuery";
  run(placeholderValues) {
    const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
    this.logger.logQuery(this.query.sql, params);
    return this.stmt.run(...params);
  }
  all(placeholderValues) {
    const { fields, query: query2, logger: logger2, joinsNotNullableMap, stmt, customResultMapper } = this;
    if (!fields && !customResultMapper) {
      const params = fillPlaceholders(query2.params, placeholderValues ?? {});
      logger2.logQuery(query2.sql, params);
      return stmt.all(...params);
    }
    const rows = this.values(placeholderValues);
    if (customResultMapper) {
      return customResultMapper(rows);
    }
    return rows.map((row) => mapResultRow(fields, row, joinsNotNullableMap));
  }
  get(placeholderValues) {
    const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
    this.logger.logQuery(this.query.sql, params);
    const row = this.stmt.values(...params)[0];
    if (!row) {
      return;
    }
    const { fields, joinsNotNullableMap, customResultMapper } = this;
    if (!fields && !customResultMapper) {
      return row;
    }
    if (customResultMapper) {
      return customResultMapper([row]);
    }
    return mapResultRow(fields, row, joinsNotNullableMap);
  }
  values(placeholderValues) {
    const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
    this.logger.logQuery(this.query.sql, params);
    return this.stmt.values(...params);
  }
  isResponseInArrayMode() {
    return this._isResponseInArrayMode;
  }
}

// node_modules/drizzle-orm/bun-sqlite/driver.js
var drizzle = function(client, config2 = {}) {
  const dialect3 = new SQLiteSyncDialect;
  let logger3;
  if (config2.logger === true) {
    logger3 = new DefaultLogger;
  } else if (config2.logger !== false) {
    logger3 = config2.logger;
  }
  let schema;
  if (config2.schema) {
    const tablesConfig = extractTablesRelationalConfig(config2.schema, createTableRelationsHelpers);
    schema = {
      fullSchema: config2.schema,
      schema: tablesConfig.tables,
      tableNamesMap: tablesConfig.tableNamesMap
    };
  }
  const session3 = new SQLiteBunSession(client, dialect3, schema, { logger: logger3 });
  return new BaseSQLiteDatabase("sync", dialect3, session3, schema);
};

// src/database.ts
import {Database} from "bun:sqlite";
var sqlite = new Database("data.db");
var db3 = drizzle(sqlite, { schema: exports_schema });
var database_default = db3;

// node_modules/nodemailer/lib/nodemailer.js
var Mailer = require_mailer();
var shared = require_shared();
var SMTPPool = require_smtp_pool();
var SMTPTransport = require_smtp_transport();
var SendmailTransport = require_sendmail_transport();
var StreamTransport = require_stream_transport();
var JSONTransport = require_json_transport();
var SESTransport = require_ses_transport();
var nmfetch = require_fetch();
var packageData = require_package();
var ETHEREAL_API = (process.env.ETHEREAL_API || "https://api.nodemailer.com").replace(/\/+$/, "");
var ETHEREAL_WEB = (process.env.ETHEREAL_WEB || "https://ethereal.email").replace(/\/+$/, "");
var ETHEREAL_API_KEY = (process.env.ETHEREAL_API_KEY || "").replace(/\s*/g, "") || null;
var ETHEREAL_CACHE = ["true", "yes", "y", "1"].includes((process.env.ETHEREAL_CACHE || "yes").toString().trim().toLowerCase());
var $createTransport = function(transporter, defaults) {
  let urlConfig;
  let options;
  let mailer;
  if (typeof transporter === "object" && typeof transporter.send !== "function" || typeof transporter === "string" && /^(smtps?|direct):/i.test(transporter)) {
    if (urlConfig = typeof transporter === "string" ? transporter : transporter.url) {
      options = shared.parseConnectionUrl(urlConfig);
    } else {
      options = transporter;
    }
    if (options.pool) {
      transporter = new SMTPPool(options);
    } else if (options.sendmail) {
      transporter = new SendmailTransport(options);
    } else if (options.streamTransport) {
      transporter = new StreamTransport(options);
    } else if (options.jsonTransport) {
      transporter = new JSONTransport(options);
    } else if (options.SES) {
      transporter = new SESTransport(options);
    } else {
      transporter = new SMTPTransport(options);
    }
  }
  mailer = new Mailer(transporter, options, defaults);
  return mailer;
};

// node_modules/marked/lib/marked.esm.js
var _getDefaults = function() {
  return {
    async: false,
    breaks: false,
    extensions: null,
    gfm: true,
    hooks: null,
    pedantic: false,
    renderer: null,
    silent: false,
    tokenizer: null,
    walkTokens: null
  };
};
var changeDefaults = function(newDefaults) {
  _defaults = newDefaults;
};
var escape$1 = function(html, encode) {
  if (encode) {
    if (escapeTest.test(html)) {
      return html.replace(escapeReplace, getEscapeReplacement);
    }
  } else {
    if (escapeTestNoEncode.test(html)) {
      return html.replace(escapeReplaceNoEncode, getEscapeReplacement);
    }
  }
  return html;
};
var unescape2 = function(html) {
  return html.replace(unescapeTest, (_, n) => {
    n = n.toLowerCase();
    if (n === "colon")
      return ":";
    if (n.charAt(0) === "#") {
      return n.charAt(1) === "x" ? String.fromCharCode(parseInt(n.substring(2), 16)) : String.fromCharCode(+n.substring(1));
    }
    return "";
  });
};
var edit = function(regex, opt) {
  let source = typeof regex === "string" ? regex : regex.source;
  opt = opt || "";
  const obj = {
    replace: (name, val) => {
      let valSource = typeof val === "string" ? val : val.source;
      valSource = valSource.replace(caret, "$1");
      source = source.replace(name, valSource);
      return obj;
    },
    getRegex: () => {
      return new RegExp(source, opt);
    }
  };
  return obj;
};
var cleanUrl = function(href) {
  try {
    href = encodeURI(href).replace(/%25/g, "%");
  } catch (e) {
    return null;
  }
  return href;
};
var splitCells = function(tableRow, count) {
  const row = tableRow.replace(/\|/g, (match, offset, str) => {
    let escaped = false;
    let curr = offset;
    while (--curr >= 0 && str[curr] === "\\")
      escaped = !escaped;
    if (escaped) {
      return "|";
    } else {
      return " |";
    }
  }), cells = row.split(/ \|/);
  let i = 0;
  if (!cells[0].trim()) {
    cells.shift();
  }
  if (cells.length > 0 && !cells[cells.length - 1].trim()) {
    cells.pop();
  }
  if (count) {
    if (cells.length > count) {
      cells.splice(count);
    } else {
      while (cells.length < count)
        cells.push("");
    }
  }
  for (;i < cells.length; i++) {
    cells[i] = cells[i].trim().replace(/\\\|/g, "|");
  }
  return cells;
};
var rtrim = function(str, c, invert) {
  const l = str.length;
  if (l === 0) {
    return "";
  }
  let suffLen = 0;
  while (suffLen < l) {
    const currChar = str.charAt(l - suffLen - 1);
    if (currChar === c && !invert) {
      suffLen++;
    } else if (currChar !== c && invert) {
      suffLen++;
    } else {
      break;
    }
  }
  return str.slice(0, l - suffLen);
};
var findClosingBracket = function(str, b) {
  if (str.indexOf(b[1]) === -1) {
    return -1;
  }
  let level = 0;
  for (let i = 0;i < str.length; i++) {
    if (str[i] === "\\") {
      i++;
    } else if (str[i] === b[0]) {
      level++;
    } else if (str[i] === b[1]) {
      level--;
      if (level < 0) {
        return i;
      }
    }
  }
  return -1;
};
var outputLink = function(cap, link, raw2, lexer) {
  const href = link.href;
  const title = link.title ? escape$1(link.title) : null;
  const text2 = cap[1].replace(/\\([\[\]])/g, "$1");
  if (cap[0].charAt(0) !== "!") {
    lexer.state.inLink = true;
    const token = {
      type: "link",
      raw: raw2,
      href,
      title,
      text: text2,
      tokens: lexer.inlineTokens(text2)
    };
    lexer.state.inLink = false;
    return token;
  }
  return {
    type: "image",
    raw: raw2,
    href,
    title,
    text: escape$1(text2)
  };
};
var indentCodeCompensation = function(raw2, text2) {
  const matchIndentToCode = raw2.match(/^(\s+)(?:```)/);
  if (matchIndentToCode === null) {
    return text2;
  }
  const indentToCode = matchIndentToCode[1];
  return text2.split("\n").map((node) => {
    const matchIndentInNode = node.match(/^\s+/);
    if (matchIndentInNode === null) {
      return node;
    }
    const [indentInNode] = matchIndentInNode;
    if (indentInNode.length >= indentToCode.length) {
      return node.slice(indentToCode.length);
    }
    return node;
  }).join("\n");
};
var marked = function(src, opt) {
  return markedInstance.parse(src, opt);
};
var _defaults = _getDefaults();
var escapeTest = /[&<>"']/;
var escapeReplace = new RegExp(escapeTest.source, "g");
var escapeTestNoEncode = /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/;
var escapeReplaceNoEncode = new RegExp(escapeTestNoEncode.source, "g");
var escapeReplacements = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
};
var getEscapeReplacement = (ch) => escapeReplacements[ch];
var unescapeTest = /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig;
var caret = /(^|[^\[])\^/g;
var noopTest = { exec: () => null };

class _Tokenizer {
  options;
  rules;
  lexer;
  constructor(options) {
    this.options = options || _defaults;
  }
  space(src) {
    const cap = this.rules.block.newline.exec(src);
    if (cap && cap[0].length > 0) {
      return {
        type: "space",
        raw: cap[0]
      };
    }
  }
  code(src) {
    const cap = this.rules.block.code.exec(src);
    if (cap) {
      const text2 = cap[0].replace(/^ {1,4}/gm, "");
      return {
        type: "code",
        raw: cap[0],
        codeBlockStyle: "indented",
        text: !this.options.pedantic ? rtrim(text2, "\n") : text2
      };
    }
  }
  fences(src) {
    const cap = this.rules.block.fences.exec(src);
    if (cap) {
      const raw2 = cap[0];
      const text2 = indentCodeCompensation(raw2, cap[3] || "");
      return {
        type: "code",
        raw: raw2,
        lang: cap[2] ? cap[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : cap[2],
        text: text2
      };
    }
  }
  heading(src) {
    const cap = this.rules.block.heading.exec(src);
    if (cap) {
      let text2 = cap[2].trim();
      if (/#$/.test(text2)) {
        const trimmed = rtrim(text2, "#");
        if (this.options.pedantic) {
          text2 = trimmed.trim();
        } else if (!trimmed || / $/.test(trimmed)) {
          text2 = trimmed.trim();
        }
      }
      return {
        type: "heading",
        raw: cap[0],
        depth: cap[1].length,
        text: text2,
        tokens: this.lexer.inline(text2)
      };
    }
  }
  hr(src) {
    const cap = this.rules.block.hr.exec(src);
    if (cap) {
      return {
        type: "hr",
        raw: rtrim(cap[0], "\n")
      };
    }
  }
  blockquote(src) {
    const cap = this.rules.block.blockquote.exec(src);
    if (cap) {
      let lines = rtrim(cap[0], "\n").split("\n");
      let raw2 = "";
      let text2 = "";
      const tokens = [];
      while (lines.length > 0) {
        let inBlockquote = false;
        const currentLines = [];
        let i;
        for (i = 0;i < lines.length; i++) {
          if (/^ {0,3}>/.test(lines[i])) {
            currentLines.push(lines[i]);
            inBlockquote = true;
          } else if (!inBlockquote) {
            currentLines.push(lines[i]);
          } else {
            break;
          }
        }
        lines = lines.slice(i);
        const currentRaw = currentLines.join("\n");
        const currentText = currentRaw.replace(/\n {0,3}((?:=+|-+) *)(?=\n|$)/g, "\n    $1").replace(/^ {0,3}>[ \t]?/gm, "");
        raw2 = raw2 ? `${raw2}\n${currentRaw}` : currentRaw;
        text2 = text2 ? `${text2}\n${currentText}` : currentText;
        const top = this.lexer.state.top;
        this.lexer.state.top = true;
        this.lexer.blockTokens(currentText, tokens, true);
        this.lexer.state.top = top;
        if (lines.length === 0) {
          break;
        }
        const lastToken = tokens[tokens.length - 1];
        if (lastToken?.type === "code") {
          break;
        } else if (lastToken?.type === "blockquote") {
          const oldToken = lastToken;
          const newText = oldToken.raw + "\n" + lines.join("\n");
          const newToken = this.blockquote(newText);
          tokens[tokens.length - 1] = newToken;
          raw2 = raw2.substring(0, raw2.length - oldToken.raw.length) + newToken.raw;
          text2 = text2.substring(0, text2.length - oldToken.text.length) + newToken.text;
          break;
        } else if (lastToken?.type === "list") {
          const oldToken = lastToken;
          const newText = oldToken.raw + "\n" + lines.join("\n");
          const newToken = this.list(newText);
          tokens[tokens.length - 1] = newToken;
          raw2 = raw2.substring(0, raw2.length - lastToken.raw.length) + newToken.raw;
          text2 = text2.substring(0, text2.length - oldToken.raw.length) + newToken.raw;
          lines = newText.substring(tokens[tokens.length - 1].raw.length).split("\n");
          continue;
        }
      }
      return {
        type: "blockquote",
        raw: raw2,
        tokens,
        text: text2
      };
    }
  }
  list(src) {
    let cap = this.rules.block.list.exec(src);
    if (cap) {
      let bull = cap[1].trim();
      const isordered = bull.length > 1;
      const list = {
        type: "list",
        raw: "",
        ordered: isordered,
        start: isordered ? +bull.slice(0, -1) : "",
        loose: false,
        items: []
      };
      bull = isordered ? `\\d{1,9}\\${bull.slice(-1)}` : `\\${bull}`;
      if (this.options.pedantic) {
        bull = isordered ? bull : "[*+-]";
      }
      const itemRegex = new RegExp(`^( {0,3}${bull})((?:[\t ][^\\n]*)?(?:\\n|\$))`);
      let endsWithBlankLine = false;
      while (src) {
        let endEarly = false;
        let raw2 = "";
        let itemContents = "";
        if (!(cap = itemRegex.exec(src))) {
          break;
        }
        if (this.rules.block.hr.test(src)) {
          break;
        }
        raw2 = cap[0];
        src = src.substring(raw2.length);
        let line = cap[2].split("\n", 1)[0].replace(/^\t+/, (t) => " ".repeat(3 * t.length));
        let nextLine = src.split("\n", 1)[0];
        let blankLine = !line.trim();
        let indent = 0;
        if (this.options.pedantic) {
          indent = 2;
          itemContents = line.trimStart();
        } else if (blankLine) {
          indent = cap[1].length + 1;
        } else {
          indent = cap[2].search(/[^ ]/);
          indent = indent > 4 ? 1 : indent;
          itemContents = line.slice(indent);
          indent += cap[1].length;
        }
        if (blankLine && /^ *$/.test(nextLine)) {
          raw2 += nextLine + "\n";
          src = src.substring(nextLine.length + 1);
          endEarly = true;
        }
        if (!endEarly) {
          const nextBulletRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ \t][^\\n]*)?(?:\\n|\$))`);
          const hrRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|\$)`);
          const fencesBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}(?:\`\`\`|~~~)`);
          const headingBeginRegex = new RegExp(`^ {0,${Math.min(3, indent - 1)}}#`);
          while (src) {
            const rawLine = src.split("\n", 1)[0];
            nextLine = rawLine;
            if (this.options.pedantic) {
              nextLine = nextLine.replace(/^ {1,4}(?=( {4})*[^ ])/g, "  ");
            }
            if (fencesBeginRegex.test(nextLine)) {
              break;
            }
            if (headingBeginRegex.test(nextLine)) {
              break;
            }
            if (nextBulletRegex.test(nextLine)) {
              break;
            }
            if (hrRegex.test(src)) {
              break;
            }
            if (nextLine.search(/[^ ]/) >= indent || !nextLine.trim()) {
              itemContents += "\n" + nextLine.slice(indent);
            } else {
              if (blankLine) {
                break;
              }
              if (line.search(/[^ ]/) >= 4) {
                break;
              }
              if (fencesBeginRegex.test(line)) {
                break;
              }
              if (headingBeginRegex.test(line)) {
                break;
              }
              if (hrRegex.test(line)) {
                break;
              }
              itemContents += "\n" + nextLine;
            }
            if (!blankLine && !nextLine.trim()) {
              blankLine = true;
            }
            raw2 += rawLine + "\n";
            src = src.substring(rawLine.length + 1);
            line = nextLine.slice(indent);
          }
        }
        if (!list.loose) {
          if (endsWithBlankLine) {
            list.loose = true;
          } else if (/\n *\n *$/.test(raw2)) {
            endsWithBlankLine = true;
          }
        }
        let istask = null;
        let ischecked;
        if (this.options.gfm) {
          istask = /^\[[ xX]\] /.exec(itemContents);
          if (istask) {
            ischecked = istask[0] !== "[ ] ";
            itemContents = itemContents.replace(/^\[[ xX]\] +/, "");
          }
        }
        list.items.push({
          type: "list_item",
          raw: raw2,
          task: !!istask,
          checked: ischecked,
          loose: false,
          text: itemContents,
          tokens: []
        });
        list.raw += raw2;
      }
      list.items[list.items.length - 1].raw = list.items[list.items.length - 1].raw.trimEnd();
      list.items[list.items.length - 1].text = list.items[list.items.length - 1].text.trimEnd();
      list.raw = list.raw.trimEnd();
      for (let i = 0;i < list.items.length; i++) {
        this.lexer.state.top = false;
        list.items[i].tokens = this.lexer.blockTokens(list.items[i].text, []);
        if (!list.loose) {
          const spacers = list.items[i].tokens.filter((t) => t.type === "space");
          const hasMultipleLineBreaks = spacers.length > 0 && spacers.some((t) => /\n.*\n/.test(t.raw));
          list.loose = hasMultipleLineBreaks;
        }
      }
      if (list.loose) {
        for (let i = 0;i < list.items.length; i++) {
          list.items[i].loose = true;
        }
      }
      return list;
    }
  }
  html(src) {
    const cap = this.rules.block.html.exec(src);
    if (cap) {
      const token = {
        type: "html",
        block: true,
        raw: cap[0],
        pre: cap[1] === "pre" || cap[1] === "script" || cap[1] === "style",
        text: cap[0]
      };
      return token;
    }
  }
  def(src) {
    const cap = this.rules.block.def.exec(src);
    if (cap) {
      const tag = cap[1].toLowerCase().replace(/\s+/g, " ");
      const href = cap[2] ? cap[2].replace(/^<(.*)>$/, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "";
      const title = cap[3] ? cap[3].substring(1, cap[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : cap[3];
      return {
        type: "def",
        tag,
        raw: cap[0],
        href,
        title
      };
    }
  }
  table(src) {
    const cap = this.rules.block.table.exec(src);
    if (!cap) {
      return;
    }
    if (!/[:|]/.test(cap[2])) {
      return;
    }
    const headers = splitCells(cap[1]);
    const aligns = cap[2].replace(/^\||\| *$/g, "").split("|");
    const rows = cap[3] && cap[3].trim() ? cap[3].replace(/\n[ \t]*$/, "").split("\n") : [];
    const item = {
      type: "table",
      raw: cap[0],
      header: [],
      align: [],
      rows: []
    };
    if (headers.length !== aligns.length) {
      return;
    }
    for (const align of aligns) {
      if (/^ *-+: *$/.test(align)) {
        item.align.push("right");
      } else if (/^ *:-+: *$/.test(align)) {
        item.align.push("center");
      } else if (/^ *:-+ *$/.test(align)) {
        item.align.push("left");
      } else {
        item.align.push(null);
      }
    }
    for (let i = 0;i < headers.length; i++) {
      item.header.push({
        text: headers[i],
        tokens: this.lexer.inline(headers[i]),
        header: true,
        align: item.align[i]
      });
    }
    for (const row of rows) {
      item.rows.push(splitCells(row, item.header.length).map((cell, i) => {
        return {
          text: cell,
          tokens: this.lexer.inline(cell),
          header: false,
          align: item.align[i]
        };
      }));
    }
    return item;
  }
  lheading(src) {
    const cap = this.rules.block.lheading.exec(src);
    if (cap) {
      return {
        type: "heading",
        raw: cap[0],
        depth: cap[2].charAt(0) === "=" ? 1 : 2,
        text: cap[1],
        tokens: this.lexer.inline(cap[1])
      };
    }
  }
  paragraph(src) {
    const cap = this.rules.block.paragraph.exec(src);
    if (cap) {
      const text2 = cap[1].charAt(cap[1].length - 1) === "\n" ? cap[1].slice(0, -1) : cap[1];
      return {
        type: "paragraph",
        raw: cap[0],
        text: text2,
        tokens: this.lexer.inline(text2)
      };
    }
  }
  text(src) {
    const cap = this.rules.block.text.exec(src);
    if (cap) {
      return {
        type: "text",
        raw: cap[0],
        text: cap[0],
        tokens: this.lexer.inline(cap[0])
      };
    }
  }
  escape(src) {
    const cap = this.rules.inline.escape.exec(src);
    if (cap) {
      return {
        type: "escape",
        raw: cap[0],
        text: escape$1(cap[1])
      };
    }
  }
  tag(src) {
    const cap = this.rules.inline.tag.exec(src);
    if (cap) {
      if (!this.lexer.state.inLink && /^<a /i.test(cap[0])) {
        this.lexer.state.inLink = true;
      } else if (this.lexer.state.inLink && /^<\/a>/i.test(cap[0])) {
        this.lexer.state.inLink = false;
      }
      if (!this.lexer.state.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(cap[0])) {
        this.lexer.state.inRawBlock = true;
      } else if (this.lexer.state.inRawBlock && /^<\/(pre|code|kbd|script)(\s|>)/i.test(cap[0])) {
        this.lexer.state.inRawBlock = false;
      }
      return {
        type: "html",
        raw: cap[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: false,
        text: cap[0]
      };
    }
  }
  link(src) {
    const cap = this.rules.inline.link.exec(src);
    if (cap) {
      const trimmedUrl = cap[2].trim();
      if (!this.options.pedantic && /^</.test(trimmedUrl)) {
        if (!/>$/.test(trimmedUrl)) {
          return;
        }
        const rtrimSlash = rtrim(trimmedUrl.slice(0, -1), "\\");
        if ((trimmedUrl.length - rtrimSlash.length) % 2 === 0) {
          return;
        }
      } else {
        const lastParenIndex = findClosingBracket(cap[2], "()");
        if (lastParenIndex > -1) {
          const start = cap[0].indexOf("!") === 0 ? 5 : 4;
          const linkLen = start + cap[1].length + lastParenIndex;
          cap[2] = cap[2].substring(0, lastParenIndex);
          cap[0] = cap[0].substring(0, linkLen).trim();
          cap[3] = "";
        }
      }
      let href = cap[2];
      let title = "";
      if (this.options.pedantic) {
        const link = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(href);
        if (link) {
          href = link[1];
          title = link[3];
        }
      } else {
        title = cap[3] ? cap[3].slice(1, -1) : "";
      }
      href = href.trim();
      if (/^</.test(href)) {
        if (this.options.pedantic && !/>$/.test(trimmedUrl)) {
          href = href.slice(1);
        } else {
          href = href.slice(1, -1);
        }
      }
      return outputLink(cap, {
        href: href ? href.replace(this.rules.inline.anyPunctuation, "$1") : href,
        title: title ? title.replace(this.rules.inline.anyPunctuation, "$1") : title
      }, cap[0], this.lexer);
    }
  }
  reflink(src, links) {
    let cap;
    if ((cap = this.rules.inline.reflink.exec(src)) || (cap = this.rules.inline.nolink.exec(src))) {
      const linkString = (cap[2] || cap[1]).replace(/\s+/g, " ");
      const link = links[linkString.toLowerCase()];
      if (!link) {
        const text2 = cap[0].charAt(0);
        return {
          type: "text",
          raw: text2,
          text: text2
        };
      }
      return outputLink(cap, link, cap[0], this.lexer);
    }
  }
  emStrong(src, maskedSrc, prevChar = "") {
    let match = this.rules.inline.emStrongLDelim.exec(src);
    if (!match)
      return;
    if (match[3] && prevChar.match(/[\p{L}\p{N}]/u))
      return;
    const nextChar = match[1] || match[2] || "";
    if (!nextChar || !prevChar || this.rules.inline.punctuation.exec(prevChar)) {
      const lLength = [...match[0]].length - 1;
      let rDelim, rLength, delimTotal = lLength, midDelimTotal = 0;
      const endReg = match[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      endReg.lastIndex = 0;
      maskedSrc = maskedSrc.slice(-1 * src.length + lLength);
      while ((match = endReg.exec(maskedSrc)) != null) {
        rDelim = match[1] || match[2] || match[3] || match[4] || match[5] || match[6];
        if (!rDelim)
          continue;
        rLength = [...rDelim].length;
        if (match[3] || match[4]) {
          delimTotal += rLength;
          continue;
        } else if (match[5] || match[6]) {
          if (lLength % 3 && !((lLength + rLength) % 3)) {
            midDelimTotal += rLength;
            continue;
          }
        }
        delimTotal -= rLength;
        if (delimTotal > 0)
          continue;
        rLength = Math.min(rLength, rLength + delimTotal + midDelimTotal);
        const lastCharLength = [...match[0]][0].length;
        const raw2 = src.slice(0, lLength + match.index + lastCharLength + rLength);
        if (Math.min(lLength, rLength) % 2) {
          const text3 = raw2.slice(1, -1);
          return {
            type: "em",
            raw: raw2,
            text: text3,
            tokens: this.lexer.inlineTokens(text3)
          };
        }
        const text2 = raw2.slice(2, -2);
        return {
          type: "strong",
          raw: raw2,
          text: text2,
          tokens: this.lexer.inlineTokens(text2)
        };
      }
    }
  }
  codespan(src) {
    const cap = this.rules.inline.code.exec(src);
    if (cap) {
      let text2 = cap[2].replace(/\n/g, " ");
      const hasNonSpaceChars = /[^ ]/.test(text2);
      const hasSpaceCharsOnBothEnds = /^ /.test(text2) && / $/.test(text2);
      if (hasNonSpaceChars && hasSpaceCharsOnBothEnds) {
        text2 = text2.substring(1, text2.length - 1);
      }
      text2 = escape$1(text2, true);
      return {
        type: "codespan",
        raw: cap[0],
        text: text2
      };
    }
  }
  br(src) {
    const cap = this.rules.inline.br.exec(src);
    if (cap) {
      return {
        type: "br",
        raw: cap[0]
      };
    }
  }
  del(src) {
    const cap = this.rules.inline.del.exec(src);
    if (cap) {
      return {
        type: "del",
        raw: cap[0],
        text: cap[2],
        tokens: this.lexer.inlineTokens(cap[2])
      };
    }
  }
  autolink(src) {
    const cap = this.rules.inline.autolink.exec(src);
    if (cap) {
      let text2, href;
      if (cap[2] === "@") {
        text2 = escape$1(cap[1]);
        href = "mailto:" + text2;
      } else {
        text2 = escape$1(cap[1]);
        href = text2;
      }
      return {
        type: "link",
        raw: cap[0],
        text: text2,
        href,
        tokens: [
          {
            type: "text",
            raw: text2,
            text: text2
          }
        ]
      };
    }
  }
  url(src) {
    let cap;
    if (cap = this.rules.inline.url.exec(src)) {
      let text2, href;
      if (cap[2] === "@") {
        text2 = escape$1(cap[0]);
        href = "mailto:" + text2;
      } else {
        let prevCapZero;
        do {
          prevCapZero = cap[0];
          cap[0] = this.rules.inline._backpedal.exec(cap[0])?.[0] ?? "";
        } while (prevCapZero !== cap[0]);
        text2 = escape$1(cap[0]);
        if (cap[1] === "www.") {
          href = "http://" + cap[0];
        } else {
          href = cap[0];
        }
      }
      return {
        type: "link",
        raw: cap[0],
        text: text2,
        href,
        tokens: [
          {
            type: "text",
            raw: text2,
            text: text2
          }
        ]
      };
    }
  }
  inlineText(src) {
    const cap = this.rules.inline.text.exec(src);
    if (cap) {
      let text2;
      if (this.lexer.state.inRawBlock) {
        text2 = cap[0];
      } else {
        text2 = escape$1(cap[0]);
      }
      return {
        type: "text",
        raw: cap[0],
        text: text2
      };
    }
  }
}
var newline = /^(?: *(?:\n|$))+/;
var blockCode = /^( {4}[^\n]+(?:\n(?: *(?:\n|$))*)?)+/;
var fences = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/;
var hr = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/;
var heading = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/;
var bullet = /(?:[*+-]|\d{1,9}[.)])/;
var lheading = edit(/^(?!bull |blockCode|fences|blockquote|heading|html)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html))+?)\n {0,3}(=+|-+) *(?:\n+|$)/).replace(/bull/g, bullet).replace(/blockCode/g, / {4}/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).getRegex();
var _paragraph = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/;
var blockText = /^[^\n]+/;
var _blockLabel = /(?!\s*\])(?:\\.|[^\[\]\\])+/;
var def = edit(/^ {0,3}\[(label)\]: *(?:\n *)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n *)?| *\n *)(title))? *(?:\n+|$)/).replace("label", _blockLabel).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex();
var list = edit(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, bullet).getRegex();
var _tag = "address|article|aside|base|basefont|blockquote|body|caption" + "|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption" + "|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe" + "|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option" + "|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title" + "|tr|track|ul";
var _comment = /<!--(?:-?>|[\s\S]*?(?:-->|$))/;
var html = edit("^ {0,3}(?:" + "<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)" + "|comment[^\\n]*(\\n+|$)" + "|<\\?[\\s\\S]*?(?:\\?>\\n*|$)" + "|<![A-Z][\\s\\S]*?(?:>\\n*|$)" + "|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)" + "|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n *)+\\n|$)" + "|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)" + "|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n *)+\\n|$)" + ")", "i").replace("comment", _comment).replace("tag", _tag).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex();
var paragraph = edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
var blockquote = edit(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", paragraph).getRegex();
var blockNormal = {
  blockquote,
  code: blockCode,
  def,
  fences,
  heading,
  hr,
  html,
  lheading,
  list,
  newline,
  paragraph,
  table: noopTest,
  text: blockText
};
var gfmTable = edit("^ *([^\\n ].*)\\n" + " {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)" + "(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", " {4}[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex();
var blockGfm = {
  ...blockNormal,
  table: gfmTable,
  paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", gfmTable).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", _tag).getRegex()
};
var blockPedantic = {
  ...blockNormal,
  html: edit("^ *(?:comment *(?:\\n|\\s*$)" + "|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)" + '|<tag(?:"[^"]*"|\'[^\']*\'|\\s[^\'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))').replace("comment", _comment).replace(/tag/g, "(?!(?:" + "a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub" + "|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)" + "\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: noopTest,
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: edit(_paragraph).replace("hr", hr).replace("heading", " *#{1,6} *[^\n]").replace("lheading", lheading).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
};
var escape = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/;
var inlineCode = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/;
var br = /^( {2,}|\\)\n(?!\s*$)/;
var inlineText = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/;
var _punctuation = "\\p{P}\\p{S}";
var punctuation = edit(/^((?![*_])[\spunctuation])/, "u").replace(/punctuation/g, _punctuation).getRegex();
var blockSkip = /\[[^[\]]*?\]\([^\(\)]*?\)|`[^`]*?`|<[^<>]*?>/g;
var emStrongLDelim = edit(/^(?:\*+(?:((?!\*)[punct])|[^\s*]))|^_+(?:((?!_)[punct])|([^\s_]))/, "u").replace(/punct/g, _punctuation).getRegex();
var emStrongRDelimAst = edit("^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)" + "|[^*]+(?=[^*])" + "|(?!\\*)[punct](\\*+)(?=[\\s]|$)" + "|[^punct\\s](\\*+)(?!\\*)(?=[punct\\s]|$)" + "|(?!\\*)[punct\\s](\\*+)(?=[^punct\\s])" + "|[\\s](\\*+)(?!\\*)(?=[punct])" + "|(?!\\*)[punct](\\*+)(?!\\*)(?=[punct])" + "|[^punct\\s](\\*+)(?=[^punct\\s])", "gu").replace(/punct/g, _punctuation).getRegex();
var emStrongRDelimUnd = edit("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)" + "|[^_]+(?=[^_])" + "|(?!_)[punct](_+)(?=[\\s]|$)" + "|[^punct\\s](_+)(?!_)(?=[punct\\s]|$)" + "|(?!_)[punct\\s](_+)(?=[^punct\\s])" + "|[\\s](_+)(?!_)(?=[punct])" + "|(?!_)[punct](_+)(?!_)(?=[punct])", "gu").replace(/punct/g, _punctuation).getRegex();
var anyPunctuation = edit(/\\([punct])/, "gu").replace(/punct/g, _punctuation).getRegex();
var autolink = edit(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex();
var _inlineComment = edit(_comment).replace("(?:-->|$)", "-->").getRegex();
var tag = edit("^comment" + "|^</[a-zA-Z][\\w:-]*\\s*>" + "|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>" + "|^<\\?[\\s\\S]*?\\?>" + "|^<![a-zA-Z]+\\s[\\s\\S]*?>" + "|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", _inlineComment).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex();
var _inlineLabel = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/;
var link = edit(/^!?\[(label)\]\(\s*(href)(?:\s+(title))?\s*\)/).replace("label", _inlineLabel).replace("href", /<(?:\\.|[^\n<>\\])+>|[^\s\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex();
var reflink = edit(/^!?\[(label)\]\[(ref)\]/).replace("label", _inlineLabel).replace("ref", _blockLabel).getRegex();
var nolink = edit(/^!?\[(ref)\](?:\[\])?/).replace("ref", _blockLabel).getRegex();
var reflinkSearch = edit("reflink|nolink(?!\\()", "g").replace("reflink", reflink).replace("nolink", nolink).getRegex();
var inlineNormal = {
  _backpedal: noopTest,
  anyPunctuation,
  autolink,
  blockSkip,
  br,
  code: inlineCode,
  del: noopTest,
  emStrongLDelim,
  emStrongRDelimAst,
  emStrongRDelimUnd,
  escape,
  link,
  nolink,
  punctuation,
  reflink,
  reflinkSearch,
  tag,
  text: inlineText,
  url: noopTest
};
var inlinePedantic = {
  ...inlineNormal,
  link: edit(/^!?\[(label)\]\((.*?)\)/).replace("label", _inlineLabel).getRegex(),
  reflink: edit(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", _inlineLabel).getRegex()
};
var inlineGfm = {
  ...inlineNormal,
  escape: edit(escape).replace("])", "~|])").getRegex(),
  url: edit(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])([\s\S]*?[^\s~])\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
};
var inlineBreaks = {
  ...inlineGfm,
  br: edit(br).replace("{2,}", "*").getRegex(),
  text: edit(inlineGfm.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
};
var block = {
  normal: blockNormal,
  gfm: blockGfm,
  pedantic: blockPedantic
};
var inline = {
  normal: inlineNormal,
  gfm: inlineGfm,
  breaks: inlineBreaks,
  pedantic: inlinePedantic
};

class _Lexer {
  tokens;
  options;
  state;
  tokenizer;
  inlineQueue;
  constructor(options) {
    this.tokens = [];
    this.tokens.links = Object.create(null);
    this.options = options || _defaults;
    this.options.tokenizer = this.options.tokenizer || new _Tokenizer;
    this.tokenizer = this.options.tokenizer;
    this.tokenizer.options = this.options;
    this.tokenizer.lexer = this;
    this.inlineQueue = [];
    this.state = {
      inLink: false,
      inRawBlock: false,
      top: true
    };
    const rules = {
      block: block.normal,
      inline: inline.normal
    };
    if (this.options.pedantic) {
      rules.block = block.pedantic;
      rules.inline = inline.pedantic;
    } else if (this.options.gfm) {
      rules.block = block.gfm;
      if (this.options.breaks) {
        rules.inline = inline.breaks;
      } else {
        rules.inline = inline.gfm;
      }
    }
    this.tokenizer.rules = rules;
  }
  static get rules() {
    return {
      block,
      inline
    };
  }
  static lex(src, options) {
    const lexer = new _Lexer(options);
    return lexer.lex(src);
  }
  static lexInline(src, options) {
    const lexer = new _Lexer(options);
    return lexer.inlineTokens(src);
  }
  lex(src) {
    src = src.replace(/\r\n|\r/g, "\n");
    this.blockTokens(src, this.tokens);
    for (let i = 0;i < this.inlineQueue.length; i++) {
      const next = this.inlineQueue[i];
      this.inlineTokens(next.src, next.tokens);
    }
    this.inlineQueue = [];
    return this.tokens;
  }
  blockTokens(src, tokens = [], lastParagraphClipped = false) {
    if (this.options.pedantic) {
      src = src.replace(/\t/g, "    ").replace(/^ +$/gm, "");
    } else {
      src = src.replace(/^( *)(\t+)/gm, (_, leading, tabs) => {
        return leading + "    ".repeat(tabs.length);
      });
    }
    let token;
    let lastToken;
    let cutSrc;
    while (src) {
      if (this.options.extensions && this.options.extensions.block && this.options.extensions.block.some((extTokenizer) => {
        if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          return true;
        }
        return false;
      })) {
        continue;
      }
      if (token = this.tokenizer.space(src)) {
        src = src.substring(token.raw.length);
        if (token.raw.length === 1 && tokens.length > 0) {
          tokens[tokens.length - 1].raw += "\n";
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.code(src)) {
        src = src.substring(token.raw.length);
        lastToken = tokens[tokens.length - 1];
        if (lastToken && (lastToken.type === "paragraph" || lastToken.type === "text")) {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.fences(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.heading(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.hr(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.blockquote(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.list(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.html(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.def(src)) {
        src = src.substring(token.raw.length);
        lastToken = tokens[tokens.length - 1];
        if (lastToken && (lastToken.type === "paragraph" || lastToken.type === "text")) {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.raw;
          this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
        } else if (!this.tokens.links[token.tag]) {
          this.tokens.links[token.tag] = {
            href: token.href,
            title: token.title
          };
        }
        continue;
      }
      if (token = this.tokenizer.table(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.lheading(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      cutSrc = src;
      if (this.options.extensions && this.options.extensions.startBlock) {
        let startIndex = Infinity;
        const tempSrc = src.slice(1);
        let tempStart;
        this.options.extensions.startBlock.forEach((getStartIndex) => {
          tempStart = getStartIndex.call({ lexer: this }, tempSrc);
          if (typeof tempStart === "number" && tempStart >= 0) {
            startIndex = Math.min(startIndex, tempStart);
          }
        });
        if (startIndex < Infinity && startIndex >= 0) {
          cutSrc = src.substring(0, startIndex + 1);
        }
      }
      if (this.state.top && (token = this.tokenizer.paragraph(cutSrc))) {
        lastToken = tokens[tokens.length - 1];
        if (lastParagraphClipped && lastToken?.type === "paragraph") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.pop();
          this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
        } else {
          tokens.push(token);
        }
        lastParagraphClipped = cutSrc.length !== src.length;
        src = src.substring(token.raw.length);
        continue;
      }
      if (token = this.tokenizer.text(src)) {
        src = src.substring(token.raw.length);
        lastToken = tokens[tokens.length - 1];
        if (lastToken && lastToken.type === "text") {
          lastToken.raw += "\n" + token.raw;
          lastToken.text += "\n" + token.text;
          this.inlineQueue.pop();
          this.inlineQueue[this.inlineQueue.length - 1].src = lastToken.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (src) {
        const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
        if (this.options.silent) {
          console.error(errMsg);
          break;
        } else {
          throw new Error(errMsg);
        }
      }
    }
    this.state.top = true;
    return tokens;
  }
  inline(src, tokens = []) {
    this.inlineQueue.push({ src, tokens });
    return tokens;
  }
  inlineTokens(src, tokens = []) {
    let token, lastToken, cutSrc;
    let maskedSrc = src;
    let match;
    let keepPrevChar, prevChar;
    if (this.tokens.links) {
      const links = Object.keys(this.tokens.links);
      if (links.length > 0) {
        while ((match = this.tokenizer.rules.inline.reflinkSearch.exec(maskedSrc)) != null) {
          if (links.includes(match[0].slice(match[0].lastIndexOf("[") + 1, -1))) {
            maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex);
          }
        }
      }
    }
    while ((match = this.tokenizer.rules.inline.blockSkip.exec(maskedSrc)) != null) {
      maskedSrc = maskedSrc.slice(0, match.index) + "[" + "a".repeat(match[0].length - 2) + "]" + maskedSrc.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    }
    while ((match = this.tokenizer.rules.inline.anyPunctuation.exec(maskedSrc)) != null) {
      maskedSrc = maskedSrc.slice(0, match.index) + "++" + maskedSrc.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    }
    while (src) {
      if (!keepPrevChar) {
        prevChar = "";
      }
      keepPrevChar = false;
      if (this.options.extensions && this.options.extensions.inline && this.options.extensions.inline.some((extTokenizer) => {
        if (token = extTokenizer.call({ lexer: this }, src, tokens)) {
          src = src.substring(token.raw.length);
          tokens.push(token);
          return true;
        }
        return false;
      })) {
        continue;
      }
      if (token = this.tokenizer.escape(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.tag(src)) {
        src = src.substring(token.raw.length);
        lastToken = tokens[tokens.length - 1];
        if (lastToken && token.type === "text" && lastToken.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.link(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.reflink(src, this.tokens.links)) {
        src = src.substring(token.raw.length);
        lastToken = tokens[tokens.length - 1];
        if (lastToken && token.type === "text" && lastToken.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (token = this.tokenizer.emStrong(src, maskedSrc, prevChar)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.codespan(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.br(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.del(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (token = this.tokenizer.autolink(src)) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      if (!this.state.inLink && (token = this.tokenizer.url(src))) {
        src = src.substring(token.raw.length);
        tokens.push(token);
        continue;
      }
      cutSrc = src;
      if (this.options.extensions && this.options.extensions.startInline) {
        let startIndex = Infinity;
        const tempSrc = src.slice(1);
        let tempStart;
        this.options.extensions.startInline.forEach((getStartIndex) => {
          tempStart = getStartIndex.call({ lexer: this }, tempSrc);
          if (typeof tempStart === "number" && tempStart >= 0) {
            startIndex = Math.min(startIndex, tempStart);
          }
        });
        if (startIndex < Infinity && startIndex >= 0) {
          cutSrc = src.substring(0, startIndex + 1);
        }
      }
      if (token = this.tokenizer.inlineText(cutSrc)) {
        src = src.substring(token.raw.length);
        if (token.raw.slice(-1) !== "_") {
          prevChar = token.raw.slice(-1);
        }
        keepPrevChar = true;
        lastToken = tokens[tokens.length - 1];
        if (lastToken && lastToken.type === "text") {
          lastToken.raw += token.raw;
          lastToken.text += token.text;
        } else {
          tokens.push(token);
        }
        continue;
      }
      if (src) {
        const errMsg = "Infinite loop on byte: " + src.charCodeAt(0);
        if (this.options.silent) {
          console.error(errMsg);
          break;
        } else {
          throw new Error(errMsg);
        }
      }
    }
    return tokens;
  }
}

class _Renderer {
  options;
  parser;
  constructor(options) {
    this.options = options || _defaults;
  }
  space(token) {
    return "";
  }
  code({ text: text2, lang, escaped }) {
    const langString = (lang || "").match(/^\S*/)?.[0];
    const code = text2.replace(/\n$/, "") + "\n";
    if (!langString) {
      return "<pre><code>" + (escaped ? code : escape$1(code, true)) + "</code></pre>\n";
    }
    return '<pre><code class="language-' + escape$1(langString) + '">' + (escaped ? code : escape$1(code, true)) + "</code></pre>\n";
  }
  blockquote({ tokens }) {
    const body = this.parser.parse(tokens);
    return `<blockquote>\n${body}</blockquote>\n`;
  }
  html({ text: text2 }) {
    return text2;
  }
  heading({ tokens, depth }) {
    return `<h${depth}>${this.parser.parseInline(tokens)}</h${depth}>\n`;
  }
  hr(token) {
    return "<hr>\n";
  }
  list(token) {
    const ordered = token.ordered;
    const start = token.start;
    let body = "";
    for (let j = 0;j < token.items.length; j++) {
      const item = token.items[j];
      body += this.listitem(item);
    }
    const type = ordered ? "ol" : "ul";
    const startAttr = ordered && start !== 1 ? ' start="' + start + '"' : "";
    return "<" + type + startAttr + ">\n" + body + "</" + type + ">\n";
  }
  listitem(item) {
    let itemBody = "";
    if (item.task) {
      const checkbox = this.checkbox({ checked: !!item.checked });
      if (item.loose) {
        if (item.tokens.length > 0 && item.tokens[0].type === "paragraph") {
          item.tokens[0].text = checkbox + " " + item.tokens[0].text;
          if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === "text") {
            item.tokens[0].tokens[0].text = checkbox + " " + item.tokens[0].tokens[0].text;
          }
        } else {
          item.tokens.unshift({
            type: "text",
            raw: checkbox + " ",
            text: checkbox + " "
          });
        }
      } else {
        itemBody += checkbox + " ";
      }
    }
    itemBody += this.parser.parse(item.tokens, !!item.loose);
    return `<li>${itemBody}</li>\n`;
  }
  checkbox({ checked }) {
    return "<input " + (checked ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens }) {
    return `<p>${this.parser.parseInline(tokens)}</p>\n`;
  }
  table(token) {
    let header = "";
    let cell = "";
    for (let j = 0;j < token.header.length; j++) {
      cell += this.tablecell(token.header[j]);
    }
    header += this.tablerow({ text: cell });
    let body = "";
    for (let j = 0;j < token.rows.length; j++) {
      const row = token.rows[j];
      cell = "";
      for (let k = 0;k < row.length; k++) {
        cell += this.tablecell(row[k]);
      }
      body += this.tablerow({ text: cell });
    }
    if (body)
      body = `<tbody>${body}</tbody>`;
    return "<table>\n" + "<thead>\n" + header + "</thead>\n" + body + "</table>\n";
  }
  tablerow({ text: text2 }) {
    return `<tr>\n${text2}</tr>\n`;
  }
  tablecell(token) {
    const content = this.parser.parseInline(token.tokens);
    const type = token.header ? "th" : "td";
    const tag2 = token.align ? `<${type} align="${token.align}">` : `<${type}>`;
    return tag2 + content + `</${type}>\n`;
  }
  strong({ tokens }) {
    return `<strong>${this.parser.parseInline(tokens)}</strong>`;
  }
  em({ tokens }) {
    return `<em>${this.parser.parseInline(tokens)}</em>`;
  }
  codespan({ text: text2 }) {
    return `<code>${text2}</code>`;
  }
  br(token) {
    return "<br>";
  }
  del({ tokens }) {
    return `<del>${this.parser.parseInline(tokens)}</del>`;
  }
  link({ href, title, tokens }) {
    const text2 = this.parser.parseInline(tokens);
    const cleanHref = cleanUrl(href);
    if (cleanHref === null) {
      return text2;
    }
    href = cleanHref;
    let out = '<a href="' + href + '"';
    if (title) {
      out += ' title="' + title + '"';
    }
    out += ">" + text2 + "</a>";
    return out;
  }
  image({ href, title, text: text2 }) {
    const cleanHref = cleanUrl(href);
    if (cleanHref === null) {
      return text2;
    }
    href = cleanHref;
    let out = `<img src="${href}" alt="${text2}"`;
    if (title) {
      out += ` title="${title}"`;
    }
    out += ">";
    return out;
  }
  text(token) {
    return "tokens" in token && token.tokens ? this.parser.parseInline(token.tokens) : token.text;
  }
}

class _TextRenderer {
  strong({ text: text2 }) {
    return text2;
  }
  em({ text: text2 }) {
    return text2;
  }
  codespan({ text: text2 }) {
    return text2;
  }
  del({ text: text2 }) {
    return text2;
  }
  html({ text: text2 }) {
    return text2;
  }
  text({ text: text2 }) {
    return text2;
  }
  link({ text: text2 }) {
    return "" + text2;
  }
  image({ text: text2 }) {
    return "" + text2;
  }
  br() {
    return "";
  }
}

class _Parser {
  options;
  renderer;
  textRenderer;
  constructor(options) {
    this.options = options || _defaults;
    this.options.renderer = this.options.renderer || new _Renderer;
    this.renderer = this.options.renderer;
    this.renderer.options = this.options;
    this.renderer.parser = this;
    this.textRenderer = new _TextRenderer;
  }
  static parse(tokens, options) {
    const parser = new _Parser(options);
    return parser.parse(tokens);
  }
  static parseInline(tokens, options) {
    const parser = new _Parser(options);
    return parser.parseInline(tokens);
  }
  parse(tokens, top = true) {
    let out = "";
    for (let i = 0;i < tokens.length; i++) {
      const anyToken = tokens[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[anyToken.type]) {
        const genericToken = anyToken;
        const ret = this.options.extensions.renderers[genericToken.type].call({ parser: this }, genericToken);
        if (ret !== false || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(genericToken.type)) {
          out += ret || "";
          continue;
        }
      }
      const token = anyToken;
      switch (token.type) {
        case "space": {
          out += this.renderer.space(token);
          continue;
        }
        case "hr": {
          out += this.renderer.hr(token);
          continue;
        }
        case "heading": {
          out += this.renderer.heading(token);
          continue;
        }
        case "code": {
          out += this.renderer.code(token);
          continue;
        }
        case "table": {
          out += this.renderer.table(token);
          continue;
        }
        case "blockquote": {
          out += this.renderer.blockquote(token);
          continue;
        }
        case "list": {
          out += this.renderer.list(token);
          continue;
        }
        case "html": {
          out += this.renderer.html(token);
          continue;
        }
        case "paragraph": {
          out += this.renderer.paragraph(token);
          continue;
        }
        case "text": {
          let textToken = token;
          let body = this.renderer.text(textToken);
          while (i + 1 < tokens.length && tokens[i + 1].type === "text") {
            textToken = tokens[++i];
            body += "\n" + this.renderer.text(textToken);
          }
          if (top) {
            out += this.renderer.paragraph({
              type: "paragraph",
              raw: body,
              text: body,
              tokens: [{ type: "text", raw: body, text: body }]
            });
          } else {
            out += body;
          }
          continue;
        }
        default: {
          const errMsg = 'Token with "' + token.type + '" type was not found.';
          if (this.options.silent) {
            console.error(errMsg);
            return "";
          } else {
            throw new Error(errMsg);
          }
        }
      }
    }
    return out;
  }
  parseInline(tokens, renderer) {
    renderer = renderer || this.renderer;
    let out = "";
    for (let i = 0;i < tokens.length; i++) {
      const anyToken = tokens[i];
      if (this.options.extensions && this.options.extensions.renderers && this.options.extensions.renderers[anyToken.type]) {
        const ret = this.options.extensions.renderers[anyToken.type].call({ parser: this }, anyToken);
        if (ret !== false || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(anyToken.type)) {
          out += ret || "";
          continue;
        }
      }
      const token = anyToken;
      switch (token.type) {
        case "escape": {
          out += renderer.text(token);
          break;
        }
        case "html": {
          out += renderer.html(token);
          break;
        }
        case "link": {
          out += renderer.link(token);
          break;
        }
        case "image": {
          out += renderer.image(token);
          break;
        }
        case "strong": {
          out += renderer.strong(token);
          break;
        }
        case "em": {
          out += renderer.em(token);
          break;
        }
        case "codespan": {
          out += renderer.codespan(token);
          break;
        }
        case "br": {
          out += renderer.br(token);
          break;
        }
        case "del": {
          out += renderer.del(token);
          break;
        }
        case "text": {
          out += renderer.text(token);
          break;
        }
        default: {
          const errMsg = 'Token with "' + token.type + '" type was not found.';
          if (this.options.silent) {
            console.error(errMsg);
            return "";
          } else {
            throw new Error(errMsg);
          }
        }
      }
    }
    return out;
  }
}

class _Hooks {
  options;
  constructor(options) {
    this.options = options || _defaults;
  }
  static passThroughHooks = new Set([
    "preprocess",
    "postprocess",
    "processAllTokens"
  ]);
  preprocess(markdown) {
    return markdown;
  }
  postprocess(html2) {
    return html2;
  }
  processAllTokens(tokens) {
    return tokens;
  }
}

class Marked {
  defaults = _getDefaults();
  options = this.setOptions;
  parse = this.#parseMarkdown(_Lexer.lex, _Parser.parse);
  parseInline = this.#parseMarkdown(_Lexer.lexInline, _Parser.parseInline);
  Parser = _Parser;
  Renderer = _Renderer;
  TextRenderer = _TextRenderer;
  Lexer = _Lexer;
  Tokenizer = _Tokenizer;
  Hooks = _Hooks;
  constructor(...args) {
    this.use(...args);
  }
  walkTokens(tokens, callback) {
    let values = [];
    for (const token of tokens) {
      values = values.concat(callback.call(this, token));
      switch (token.type) {
        case "table": {
          const tableToken = token;
          for (const cell of tableToken.header) {
            values = values.concat(this.walkTokens(cell.tokens, callback));
          }
          for (const row of tableToken.rows) {
            for (const cell of row) {
              values = values.concat(this.walkTokens(cell.tokens, callback));
            }
          }
          break;
        }
        case "list": {
          const listToken = token;
          values = values.concat(this.walkTokens(listToken.items, callback));
          break;
        }
        default: {
          const genericToken = token;
          if (this.defaults.extensions?.childTokens?.[genericToken.type]) {
            this.defaults.extensions.childTokens[genericToken.type].forEach((childTokens) => {
              const tokens2 = genericToken[childTokens].flat(Infinity);
              values = values.concat(this.walkTokens(tokens2, callback));
            });
          } else if (genericToken.tokens) {
            values = values.concat(this.walkTokens(genericToken.tokens, callback));
          }
        }
      }
    }
    return values;
  }
  use(...args) {
    const extensions = this.defaults.extensions || { renderers: {}, childTokens: {} };
    args.forEach((pack) => {
      const opts = { ...pack };
      opts.async = this.defaults.async || opts.async || false;
      if (pack.extensions) {
        pack.extensions.forEach((ext) => {
          if (!ext.name) {
            throw new Error("extension name required");
          }
          if ("renderer" in ext) {
            const prevRenderer = extensions.renderers[ext.name];
            if (prevRenderer) {
              extensions.renderers[ext.name] = function(...args2) {
                let ret = ext.renderer.apply(this, args2);
                if (ret === false) {
                  ret = prevRenderer.apply(this, args2);
                }
                return ret;
              };
            } else {
              extensions.renderers[ext.name] = ext.renderer;
            }
          }
          if ("tokenizer" in ext) {
            if (!ext.level || ext.level !== "block" && ext.level !== "inline") {
              throw new Error("extension level must be 'block' or 'inline'");
            }
            const extLevel = extensions[ext.level];
            if (extLevel) {
              extLevel.unshift(ext.tokenizer);
            } else {
              extensions[ext.level] = [ext.tokenizer];
            }
            if (ext.start) {
              if (ext.level === "block") {
                if (extensions.startBlock) {
                  extensions.startBlock.push(ext.start);
                } else {
                  extensions.startBlock = [ext.start];
                }
              } else if (ext.level === "inline") {
                if (extensions.startInline) {
                  extensions.startInline.push(ext.start);
                } else {
                  extensions.startInline = [ext.start];
                }
              }
            }
          }
          if ("childTokens" in ext && ext.childTokens) {
            extensions.childTokens[ext.name] = ext.childTokens;
          }
        });
        opts.extensions = extensions;
      }
      if (pack.renderer) {
        const renderer = this.defaults.renderer || new _Renderer(this.defaults);
        for (const prop in pack.renderer) {
          if (!(prop in renderer)) {
            throw new Error(`renderer '${prop}' does not exist`);
          }
          if (["options", "parser"].includes(prop)) {
            continue;
          }
          const rendererProp = prop;
          let rendererFunc = pack.renderer[rendererProp];
          const prevRenderer = renderer[rendererProp];
          renderer[rendererProp] = (...args2) => {
            if (!pack.useNewRenderer) {
              rendererFunc = this.#convertRendererFunction(rendererFunc, rendererProp, renderer);
            }
            let ret = rendererFunc.apply(renderer, args2);
            if (ret === false) {
              ret = prevRenderer.apply(renderer, args2);
            }
            return ret || "";
          };
        }
        opts.renderer = renderer;
      }
      if (pack.tokenizer) {
        const tokenizer = this.defaults.tokenizer || new _Tokenizer(this.defaults);
        for (const prop in pack.tokenizer) {
          if (!(prop in tokenizer)) {
            throw new Error(`tokenizer '${prop}' does not exist`);
          }
          if (["options", "rules", "lexer"].includes(prop)) {
            continue;
          }
          const tokenizerProp = prop;
          const tokenizerFunc = pack.tokenizer[tokenizerProp];
          const prevTokenizer = tokenizer[tokenizerProp];
          tokenizer[tokenizerProp] = (...args2) => {
            let ret = tokenizerFunc.apply(tokenizer, args2);
            if (ret === false) {
              ret = prevTokenizer.apply(tokenizer, args2);
            }
            return ret;
          };
        }
        opts.tokenizer = tokenizer;
      }
      if (pack.hooks) {
        const hooks = this.defaults.hooks || new _Hooks;
        for (const prop in pack.hooks) {
          if (!(prop in hooks)) {
            throw new Error(`hook '${prop}' does not exist`);
          }
          if (prop === "options") {
            continue;
          }
          const hooksProp = prop;
          const hooksFunc = pack.hooks[hooksProp];
          const prevHook = hooks[hooksProp];
          if (_Hooks.passThroughHooks.has(prop)) {
            hooks[hooksProp] = (arg) => {
              if (this.defaults.async) {
                return Promise.resolve(hooksFunc.call(hooks, arg)).then((ret2) => {
                  return prevHook.call(hooks, ret2);
                });
              }
              const ret = hooksFunc.call(hooks, arg);
              return prevHook.call(hooks, ret);
            };
          } else {
            hooks[hooksProp] = (...args2) => {
              let ret = hooksFunc.apply(hooks, args2);
              if (ret === false) {
                ret = prevHook.apply(hooks, args2);
              }
              return ret;
            };
          }
        }
        opts.hooks = hooks;
      }
      if (pack.walkTokens) {
        const walkTokens = this.defaults.walkTokens;
        const packWalktokens = pack.walkTokens;
        opts.walkTokens = function(token) {
          let values = [];
          values.push(packWalktokens.call(this, token));
          if (walkTokens) {
            values = values.concat(walkTokens.call(this, token));
          }
          return values;
        };
      }
      this.defaults = { ...this.defaults, ...opts };
    });
    return this;
  }
  #convertRendererFunction(func, prop, renderer) {
    switch (prop) {
      case "heading":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, renderer.parser.parseInline(token.tokens), token.depth, unescape2(renderer.parser.parseInline(token.tokens, renderer.parser.textRenderer)));
        };
      case "code":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.text, token.lang, !!token.escaped);
        };
      case "table":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          let header = "";
          let cell = "";
          for (let j = 0;j < token.header.length; j++) {
            cell += this.tablecell({
              text: token.header[j].text,
              tokens: token.header[j].tokens,
              header: true,
              align: token.align[j]
            });
          }
          header += this.tablerow({ text: cell });
          let body = "";
          for (let j = 0;j < token.rows.length; j++) {
            const row = token.rows[j];
            cell = "";
            for (let k = 0;k < row.length; k++) {
              cell += this.tablecell({
                text: row[k].text,
                tokens: row[k].tokens,
                header: false,
                align: token.align[k]
              });
            }
            body += this.tablerow({ text: cell });
          }
          return func.call(this, header, body);
        };
      case "blockquote":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          const body = this.parser.parse(token.tokens);
          return func.call(this, body);
        };
      case "list":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          const ordered = token.ordered;
          const start = token.start;
          const loose = token.loose;
          let body = "";
          for (let j = 0;j < token.items.length; j++) {
            const item = token.items[j];
            const checked = item.checked;
            const task = item.task;
            let itemBody = "";
            if (item.task) {
              const checkbox = this.checkbox({ checked: !!checked });
              if (loose) {
                if (item.tokens.length > 0 && item.tokens[0].type === "paragraph") {
                  item.tokens[0].text = checkbox + " " + item.tokens[0].text;
                  if (item.tokens[0].tokens && item.tokens[0].tokens.length > 0 && item.tokens[0].tokens[0].type === "text") {
                    item.tokens[0].tokens[0].text = checkbox + " " + item.tokens[0].tokens[0].text;
                  }
                } else {
                  item.tokens.unshift({
                    type: "text",
                    text: checkbox + " "
                  });
                }
              } else {
                itemBody += checkbox + " ";
              }
            }
            itemBody += this.parser.parse(item.tokens, loose);
            body += this.listitem({
              type: "list_item",
              raw: itemBody,
              text: itemBody,
              task,
              checked: !!checked,
              loose,
              tokens: item.tokens
            });
          }
          return func.call(this, body, ordered, start);
        };
      case "html":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.text, token.block);
        };
      case "paragraph":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, this.parser.parseInline(token.tokens));
        };
      case "escape":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.text);
        };
      case "link":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.href, token.title, this.parser.parseInline(token.tokens));
        };
      case "image":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.href, token.title, token.text);
        };
      case "strong":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, this.parser.parseInline(token.tokens));
        };
      case "em":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, this.parser.parseInline(token.tokens));
        };
      case "codespan":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.text);
        };
      case "del":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, this.parser.parseInline(token.tokens));
        };
      case "text":
        return function(token) {
          if (!token.type || token.type !== prop) {
            return func.apply(this, arguments);
          }
          return func.call(this, token.text);
        };
    }
    return func;
  }
  setOptions(opt) {
    this.defaults = { ...this.defaults, ...opt };
    return this;
  }
  lexer(src, options) {
    return _Lexer.lex(src, options ?? this.defaults);
  }
  parser(tokens, options) {
    return _Parser.parse(tokens, options ?? this.defaults);
  }
  #parseMarkdown(lexer, parser) {
    return (src, options) => {
      const origOpt = { ...options };
      const opt = { ...this.defaults, ...origOpt };
      if (this.defaults.async === true && origOpt.async === false) {
        if (!opt.silent) {
          console.warn("marked(): The async option was set to true by an extension. The async: false option sent to parse will be ignored.");
        }
        opt.async = true;
      }
      const throwError = this.#onError(!!opt.silent, !!opt.async);
      if (typeof src === "undefined" || src === null) {
        return throwError(new Error("marked(): input parameter is undefined or null"));
      }
      if (typeof src !== "string") {
        return throwError(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(src) + ", string expected"));
      }
      if (opt.hooks) {
        opt.hooks.options = opt;
      }
      if (opt.async) {
        return Promise.resolve(opt.hooks ? opt.hooks.preprocess(src) : src).then((src2) => lexer(src2, opt)).then((tokens) => opt.hooks ? opt.hooks.processAllTokens(tokens) : tokens).then((tokens) => opt.walkTokens ? Promise.all(this.walkTokens(tokens, opt.walkTokens)).then(() => tokens) : tokens).then((tokens) => parser(tokens, opt)).then((html2) => opt.hooks ? opt.hooks.postprocess(html2) : html2).catch(throwError);
      }
      try {
        if (opt.hooks) {
          src = opt.hooks.preprocess(src);
        }
        let tokens = lexer(src, opt);
        if (opt.hooks) {
          tokens = opt.hooks.processAllTokens(tokens);
        }
        if (opt.walkTokens) {
          this.walkTokens(tokens, opt.walkTokens);
        }
        let html2 = parser(tokens, opt);
        if (opt.hooks) {
          html2 = opt.hooks.postprocess(html2);
        }
        return html2;
      } catch (e) {
        return throwError(e);
      }
    };
  }
  #onError(silent, async) {
    return (e) => {
      e.message += "\nPlease report this to https://github.com/markedjs/marked.";
      if (silent) {
        const msg = "<p>An error occurred:</p><pre>" + escape$1(e.message + "", true) + "</pre>";
        if (async) {
          return Promise.resolve(msg);
        }
        return msg;
      }
      if (async) {
        return Promise.reject(e);
      }
      throw e;
    };
  }
}
var markedInstance = new Marked;
marked.options = marked.setOptions = function(options) {
  markedInstance.setOptions(options);
  marked.defaults = markedInstance.defaults;
  changeDefaults(marked.defaults);
  return marked;
};
marked.getDefaults = _getDefaults;
marked.defaults = _defaults;
marked.use = function(...args) {
  markedInstance.use(...args);
  marked.defaults = markedInstance.defaults;
  changeDefaults(marked.defaults);
  return marked;
};
marked.walkTokens = function(tokens, callback) {
  return markedInstance.walkTokens(tokens, callback);
};
marked.parseInline = markedInstance.parseInline;
marked.Parser = _Parser;
marked.parser = _Parser.parse;
marked.Renderer = _Renderer;
marked.TextRenderer = _TextRenderer;
marked.Lexer = _Lexer;
marked.lexer = _Lexer.lex;
marked.Tokenizer = _Tokenizer;
marked.Hooks = _Hooks;
marked.parse = marked;
var options = marked.options;
var setOptions = marked.setOptions;
var use = marked.use;
var walkTokens = marked.walkTokens;
var parseInline = marked.parseInline;
var parser = _Parser.parse;
var lexer = _Lexer.lex;

// node_modules/liquidjs/dist/liquid.node.esm.js
import {PassThrough} from "stream";
import {sep, extname, resolve as resolve$1, dirname as dirname$1} from "path";
import {statSync, readFileSync as readFileSync$1, stat, readFile as readFile$1} from "fs";
var isString = function(value) {
  return typeof value === "string";
};
var isFunction = function(value) {
  return typeof value === "function";
};
var isPromise = function(val) {
  return val && isFunction(val.then);
};
var isIterator = function(val) {
  return val && isFunction(val.next) && isFunction(val.throw) && isFunction(val.return);
};
var escapeRegex = function(str) {
  return str.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
};
var promisify = function(fn) {
  return function(...args) {
    return new Promise((resolve, reject) => {
      fn(...args, (err, result) => {
        err ? reject(err) : resolve(result);
      });
    });
  };
};
var stringify2 = function(value) {
  value = toValue(value);
  if (isString(value))
    return value;
  if (isNil(value))
    return "";
  if (isArray(value))
    return value.map((x) => stringify2(x)).join("");
  return String(value);
};
var toEnumerable = function(val) {
  val = toValue(val);
  if (isArray(val))
    return val;
  if (isString(val) && val.length > 0)
    return [val];
  if (isIterable(val))
    return Array.from(val);
  if (isObject(val))
    return Object.keys(val).map((key) => [key, val[key]]);
  return [];
};
var toArray = function(val) {
  val = toValue(val);
  if (isNil(val))
    return [];
  if (isArray(val))
    return val;
  return [val];
};
var toValue = function(value) {
  return value instanceof Drop && isFunction(value.valueOf) ? value.valueOf() : value;
};
var isNumber = function(value) {
  return typeof value === "number";
};
var toLiquid = function(value) {
  if (value && isFunction(value.toLiquid))
    return toLiquid(value.toLiquid());
  return value;
};
var isNil = function(value) {
  return value == null;
};
var isUndefined = function(value) {
  return value === undefined;
};
var isArray = function(value) {
  return toString$1.call(value) === "[object Array]";
};
var isIterable = function(value) {
  return isObject(value) && Symbol.iterator in value;
};
var forOwn = function(obj, iteratee) {
  obj = obj || {};
  for (const k in obj) {
    if (hasOwnProperty.call(obj, k)) {
      if (iteratee(obj[k], k, obj) === false)
        break;
    }
  }
  return obj;
};
var last = function(arr) {
  return arr[arr.length - 1];
};
var isObject = function(value) {
  const type = typeof value;
  return value !== null && (type === "object" || type === "function");
};
var range = function(start, stop, step = 1) {
  const arr = [];
  for (let i = start;i < stop; i += step) {
    arr.push(i);
  }
  return arr;
};
var padStart = function(str, length, ch = " ") {
  return pad(str, length, ch, (str2, ch2) => ch2 + str2);
};
var padEnd = function(str, length, ch = " ") {
  return pad(str, length, ch, (str2, ch2) => str2 + ch2);
};
var pad = function(str, length, ch, add) {
  str = String(str);
  let n = length - str.length;
  while (n-- > 0)
    str = add(str, ch);
  return str;
};
var identify = function(val) {
  return val;
};
var changeCase = function(str) {
  const hasLowerCase = [...str].some((ch) => ch >= "a" && ch <= "z");
  return hasLowerCase ? str.toUpperCase() : str.toLowerCase();
};
var ellipsis = function(str, N) {
  return str.length > N ? str.slice(0, N - 3) + "..." : str;
};
var caseInsensitiveCompare = function(a, b) {
  if (a == null && b == null)
    return 0;
  if (a == null)
    return 1;
  if (b == null)
    return -1;
  a = toLowerCase.call(a);
  b = toLowerCase.call(b);
  if (a < b)
    return -1;
  if (a > b)
    return 1;
  return 0;
};
var argumentsToValue = function(fn) {
  return function(...args) {
    return fn.call(this, ...args.map(toValue));
  };
};
var escapeRegExp = function(text2) {
  return text2.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
};
var mkContext = function(token) {
  const [line, col] = token.getPosition();
  const lines = token.input.split("\n");
  const begin = Math.max(line - 2, 1);
  const end = Math.min(line + 3, lines.length);
  const context = range(begin, end + 1).map((lineNumber) => {
    const rowIndicator = lineNumber === line ? ">> " : "   ";
    const num = padStart(String(lineNumber), String(end).length);
    let text2 = `${rowIndicator}${num}| `;
    const colIndicator = lineNumber === line ? "\n" + padStart("^", col + text2.length) : "";
    text2 += lines[lineNumber - 1];
    text2 += colIndicator;
    return text2;
  }).join("\n");
  return context;
};
var mkMessage = function(msg, token) {
  if (token.file)
    msg += `, file:${token.file}`;
  const [line, col] = token.getPosition();
  msg += `, line:${line}, col:${col}`;
  return msg;
};
var isWord = function(char) {
  const code = char.charCodeAt(0);
  return code >= 128 ? !TYPES[code] : !!(TYPES[code] & WORD);
};
var assert = function(predicate, message) {
  if (!predicate) {
    const msg = typeof message === "function" ? message() : message || `expect ${predicate} to be true`;
    throw new AssertionError(msg);
  }
};
var assertEmpty = function(predicate, message = `unexpected ${JSON.stringify(predicate)}`) {
  assert(!predicate, message);
};
var isComparable = function(arg) {
  return arg && isFunction(arg.equals) && isFunction(arg.gt) && isFunction(arg.geq) && isFunction(arg.lt) && isFunction(arg.leq);
};
var createTrie = function(input) {
  const trie = {};
  for (const [name, data] of Object.entries(input)) {
    let node = trie;
    for (let i = 0;i < name.length; i++) {
      const c = name[i];
      node[c] = node[c] || {};
      if (i === name.length - 1 && isWord(name[i])) {
        node[c].needBoundary = true;
      }
      node = node[c];
    }
    node.data = data;
    node.end = true;
  }
  return trie;
};
var __awaiter = function(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
var toPromise = function(val) {
  return __awaiter(this, undefined, undefined, function* () {
    if (!isIterator(val))
      return val;
    let value;
    let done = false;
    let next = "next";
    do {
      const state = val[next](value);
      done = state.done;
      value = state.value;
      next = "next";
      try {
        if (isIterator(value))
          value = toPromise(value);
        if (isPromise(value))
          value = yield value;
      } catch (err) {
        next = "throw";
        value = err;
      }
    } while (!done);
    return value;
  });
};
var toValueSync = function(val) {
  if (!isIterator(val))
    return val;
  let value;
  let done = false;
  let next = "next";
  do {
    const state = val[next](value);
    done = state.done;
    value = state.value;
    next = "next";
    if (isIterator(value)) {
      try {
        value = toValueSync(value);
      } catch (err) {
        next = "throw";
        value = err;
      }
    }
  } while (!done);
  return value;
};
var abbr = function(str) {
  return str.slice(0, 3);
};
var daysInMonth = function(d) {
  const feb = isLeapYear(d) ? 29 : 28;
  return [31, feb, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
};
var getDayOfYear = function(d) {
  let num = 0;
  for (let i = 0;i < d.getMonth(); ++i) {
    num += daysInMonth(d)[i];
  }
  return num + d.getDate();
};
var getWeekOfYear = function(d, startDay) {
  const now = getDayOfYear(d) + (startDay - d.getDay());
  const jan1 = new Date(d.getFullYear(), 0, 1);
  const then = 7 - jan1.getDay() + startDay;
  return String(Math.floor((now - then) / 7) + 1);
};
var isLeapYear = function(d) {
  const year = d.getFullYear();
  return !!((year & 3) === 0 && (year % 100 || year % 400 === 0 && year));
};
var ordinal = function(d) {
  const date = d.getDate();
  if ([11, 12, 13].includes(date))
    return "th";
  switch (date % 10) {
    case 1:
      return "st";
    case 2:
      return "nd";
    case 3:
      return "rd";
    default:
      return "th";
  }
};
var century = function(d) {
  return parseInt(d.getFullYear().toString().substring(0, 2), 10);
};
var getTimezoneOffset = function(d, opts) {
  const nOffset = Math.abs(d.getTimezoneOffset());
  const h = Math.floor(nOffset / 60);
  const m = nOffset % 60;
  return (d.getTimezoneOffset() > 0 ? "-" : "+") + padStart(h, 2, "0") + (opts.flags[":"] ? ":" : "") + padStart(m, 2, "0");
};
var strftime = function(d, formatStr) {
  let output = "";
  let remaining = formatStr;
  let match;
  while (match = rFormat.exec(remaining)) {
    output += remaining.slice(0, match.index);
    remaining = remaining.slice(match.index + match[0].length);
    output += format(d, match);
  }
  return output + remaining;
};
var format = function(d, match) {
  const [input, flagStr = "", width, modifier, conversion] = match;
  const convert = formatCodes[conversion];
  if (!convert)
    return input;
  const flags = {};
  for (const flag of flagStr)
    flags[flag] = true;
  let ret = String(convert(d, { flags, width, modifier }));
  let padChar = padChars[conversion] || "0";
  let padWidth = width || padWidths[conversion] || 0;
  if (flags["^"])
    ret = ret.toUpperCase();
  else if (flags["#"])
    ret = changeCase(ret);
  if (flags["_"])
    padChar = " ";
  else if (flags["0"])
    padChar = "0";
  if (flags["-"])
    padWidth = 0;
  return padStart(ret, padWidth, padChar);
};
var hexVal = function(c) {
  const code = c.charCodeAt(0);
  if (code >= 97)
    return code - 87;
  if (code >= 65)
    return code - 55;
  return code - 48;
};
var parseStringLiteral = function(str) {
  let ret = "";
  for (let i = 1;i < str.length - 1; i++) {
    if (str[i] !== "\\") {
      ret += str[i];
      continue;
    }
    if (escapeChar[str[i + 1]] !== undefined) {
      ret += escapeChar[str[++i]];
    } else if (str[i + 1] === "u") {
      let val = 0;
      let j = i + 2;
      while (j <= i + 5 && rHex.test(str[j])) {
        val = val * 16 + hexVal(str[j++]);
      }
      i = j - 1;
      ret += String.fromCharCode(val);
    } else if (!rOct.test(str[i + 1])) {
      ret += str[++i];
    } else {
      let j = i + 1;
      let val = 0;
      while (j <= i + 3 && rOct.test(str[j])) {
        val = val * 8 + hexVal(str[j++]);
      }
      i = j - 1;
      ret += String.fromCharCode(val);
    }
  }
  return ret;
};
function* evalToken(token, ctx, lenient = false) {
  if (!token)
    return;
  if ("content" in token)
    return token.content;
  if (isPropertyAccessToken(token))
    return yield evalPropertyAccessToken(token, ctx, lenient);
  if (isRangeToken(token))
    return yield evalRangeToken(token, ctx);
}
function* evalPropertyAccessToken(token, ctx, lenient) {
  const props = [];
  for (const prop of token.props) {
    props.push(yield evalToken(prop, ctx, false));
  }
  try {
    if (token.variable) {
      const variable = yield evalToken(token.variable, ctx, lenient);
      return yield ctx._getFromScope(variable, props);
    } else {
      return yield ctx._get(props);
    }
  } catch (e) {
    if (lenient && e.name === "InternalUndefinedVariableError")
      return null;
    throw new UndefinedVariableError(e, token);
  }
}
var evalQuotedToken = function(token) {
  return token.content;
};
function* evalRangeToken(token, ctx) {
  const low = yield evalToken(token.lhs, ctx);
  const high = yield evalToken(token.rhs, ctx);
  return range(+low, +high + 1);
}
function* toPostfix(tokens) {
  const ops = [];
  for (const token of tokens) {
    if (isOperatorToken(token)) {
      while (ops.length && ops[ops.length - 1].getPrecedence() > token.getPrecedence()) {
        yield ops.pop();
      }
      ops.push(token);
    } else
      yield token;
  }
  while (ops.length) {
    yield ops.pop();
  }
}
var isTruthy = function(val, ctx) {
  return !isFalsy(val, ctx);
};
var isFalsy = function(val, ctx) {
  val = toValue(val);
  if (ctx.opts.jsTruthy) {
    return !val;
  } else {
    return val === false || val === undefined || val === null;
  }
};
var equals = function(lhs, rhs) {
  if (isComparable(lhs))
    return lhs.equals(rhs);
  if (isComparable(rhs))
    return rhs.equals(lhs);
  lhs = toValue(lhs);
  rhs = toValue(rhs);
  if (isArray(lhs)) {
    return isArray(rhs) && arrayEquals(lhs, rhs);
  }
  return lhs === rhs;
};
var arrayEquals = function(lhs, rhs) {
  if (lhs.length !== rhs.length)
    return false;
  return !lhs.some((value, i) => !equals(value, rhs[i]));
};
var exists2 = function(filepath) {
  return __awaiter(this, undefined, undefined, function* () {
    try {
      yield statAsync(filepath);
      return true;
    } catch (err) {
      return false;
    }
  });
};
var readFile = function(filepath) {
  return readFileAsync(filepath, "utf8");
};
var existsSync = function(filepath) {
  try {
    statSync(filepath);
    return true;
  } catch (err) {
    return false;
  }
};
var readFileSync = function(filepath) {
  return readFileSync$1(filepath, "utf8");
};
var resolve = function(root, file, ext) {
  if (!extname(file))
    file += ext;
  return resolve$1(root, file);
};
var fallback = function(file) {
  try {
    return requireResolve(file);
  } catch (e) {
  }
};
var dirname = function(filepath) {
  return dirname$1(filepath);
};
var contains = function(root, file) {
  root = resolve$1(root);
  root = root.endsWith(sep) ? root : root + sep;
  return file.startsWith(root);
};
var defaultFilter = function(value, defaultValue, ...args) {
  value = toValue(value);
  if (isArray(value) || isString(value))
    return value.length ? value : defaultValue;
  if (value === false && new Map(args).get("allow_false"))
    return false;
  return isFalsy(value, this.context) ? defaultValue : value;
};
var json = function(value, space = 0) {
  return JSON.stringify(value, null, space);
};
var inspect = function(value, space = 0) {
  const ancestors = [];
  return JSON.stringify(value, function(_key, value2) {
    if (typeof value2 !== "object" || value2 === null)
      return value2;
    while (ancestors.length > 0 && ancestors[ancestors.length - 1] !== this)
      ancestors.pop();
    if (ancestors.includes(value2))
      return "[Circular]";
    ancestors.push(value2);
    return value2;
  }, space);
};
var to_integer = function(value) {
  return Number(value);
};
var escape2 = function(str) {
  str = stringify2(str);
  this.context.memoryLimit.use(str.length);
  return str.replace(/&|<|>|"|'/g, (m) => escapeMap[m]);
};
var xml_escape = function(str) {
  return escape2.call(this, str);
};
var unescape3 = function(str) {
  str = stringify2(str);
  this.context.memoryLimit.use(str.length);
  return str.replace(/&(amp|lt|gt|#34|#39);/g, (m) => unescapeMap[m]);
};
var escape_once = function(str) {
  return escape2.call(this, unescape3.call(this, str));
};
var newline_to_br = function(v) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.replace(/\r?\n/gm, "<br />\n");
};
var strip_html = function(v) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<.*?>|<!--[\s\S]*?-->/g, "");
};
var normalize = function(options2) {
  if (options2.hasOwnProperty("root")) {
    if (!options2.hasOwnProperty("partials"))
      options2.partials = options2.root;
    if (!options2.hasOwnProperty("layouts"))
      options2.layouts = options2.root;
  }
  if (options2.hasOwnProperty("cache")) {
    let cache;
    if (typeof options2.cache === "number")
      cache = options2.cache > 0 ? new LRU(options2.cache) : undefined;
    else if (typeof options2.cache === "object")
      cache = options2.cache;
    else
      cache = options2.cache ? new LRU(1024) : undefined;
    options2.cache = cache;
  }
  options2 = Object.assign(Object.assign(Object.assign({}, defaultOptions), options2.jekyllInclude ? { dynamicPartials: false } : {}), options2);
  if ((!options2.fs.dirname || !options2.fs.sep) && options2.relativeReference) {
    console.warn("[LiquidJS] `fs.dirname` and `fs.sep` are required for relativeReference, set relativeReference to `false` to suppress this warning");
    options2.relativeReference = false;
  }
  options2.root = normalizeDirectoryList(options2.root);
  options2.partials = normalizeDirectoryList(options2.partials);
  options2.layouts = normalizeDirectoryList(options2.layouts);
  options2.outputEscape = options2.outputEscape && getOutputEscapeFunction(options2.outputEscape);
  options2.parseLimit = options2.parseLimit || Infinity;
  options2.renderLimit = options2.renderLimit || Infinity;
  options2.memoryLimit = options2.memoryLimit || Infinity;
  if (options2.templates) {
    options2.fs = new MapFS(options2.templates);
    options2.relativeReference = true;
    options2.root = options2.partials = options2.layouts = ".";
  }
  return options2;
};
var getOutputEscapeFunction = function(nameOrFunction) {
  if (nameOrFunction === "escape")
    return escape2;
  if (nameOrFunction === "json")
    return misc.json;
  assert(isFunction(nameOrFunction), "`outputEscape` need to be of type string or function");
  return nameOrFunction;
};
var normalizeDirectoryList = function(value) {
  let list2 = [];
  if (isArray(value))
    list2 = value;
  if (isString(value))
    list2 = [value];
  return list2;
};
var whiteSpaceCtrl = function(tokens, options2) {
  let inRaw = false;
  for (let i = 0;i < tokens.length; i++) {
    const token = tokens[i];
    if (!isDelimitedToken(token))
      continue;
    if (!inRaw && token.trimLeft) {
      trimLeft(tokens[i - 1], options2.greedy);
    }
    if (isTagToken(token)) {
      if (token.name === "raw")
        inRaw = true;
      else if (token.name === "endraw")
        inRaw = false;
    }
    if (!inRaw && token.trimRight) {
      trimRight(tokens[i + 1], options2.greedy);
    }
  }
};
var trimLeft = function(token, greedy) {
  if (!token || !isHTMLToken(token))
    return;
  const mask = greedy ? BLANK : INLINE_BLANK;
  while (TYPES[token.input.charCodeAt(token.end - 1 - token.trimRight)] & mask)
    token.trimRight++;
};
var trimRight = function(token, greedy) {
  if (!token || !isHTMLToken(token))
    return;
  const mask = greedy ? BLANK : INLINE_BLANK;
  while (TYPES[token.input.charCodeAt(token.begin + token.trimLeft)] & mask)
    token.trimLeft++;
  if (token.input.charAt(token.begin + token.trimLeft) === "\n")
    token.trimLeft++;
};
var createTagClass = function(options2) {
  return class extends Tag {
    constructor(token, tokens, liquid) {
      super(token, tokens, liquid);
      if (isFunction(options2.parse)) {
        options2.parse.call(this, token, tokens);
      }
    }
    *render(ctx, emitter) {
      const hash = yield new Hash(this.token.args).render(ctx);
      return yield options2.render.call(this, ctx, emitter, hash);
    }
  };
};
var isKeyValuePair = function(arr) {
  return isArray(arr);
};
var isDelimitedToken = function(val) {
  return !!(getKind(val) & TokenKind.Delimited);
};
var isOperatorToken = function(val) {
  return getKind(val) === TokenKind.Operator;
};
var isHTMLToken = function(val) {
  return getKind(val) === TokenKind.HTML;
};
var isOutputToken = function(val) {
  return getKind(val) === TokenKind.Output;
};
var isTagToken = function(val) {
  return getKind(val) === TokenKind.Tag;
};
var isQuotedToken = function(val) {
  return getKind(val) === TokenKind.Quoted;
};
var isPropertyAccessToken = function(val) {
  return getKind(val) === TokenKind.PropertyAccess;
};
var isRangeToken = function(val) {
  return getKind(val) === TokenKind.Range;
};
var getKind = function(val) {
  return val ? val.kind : -1;
};
var readProperty = function(obj, key, ownPropertyOnly) {
  obj = toLiquid(obj);
  if (isNil(obj))
    return obj;
  if (isArray(obj) && key < 0)
    return obj[obj.length + +key];
  const value = readJSProperty(obj, key, ownPropertyOnly);
  if (value === undefined && obj instanceof Drop)
    return obj.liquidMethodMissing(key);
  if (isFunction(value))
    return value.call(obj);
  if (key === "size")
    return readSize(obj);
  else if (key === "first")
    return readFirst(obj);
  else if (key === "last")
    return readLast(obj);
  return value;
};
var readJSProperty = function(obj, key, ownPropertyOnly) {
  if (ownPropertyOnly && !Object.hasOwnProperty.call(obj, key) && !(obj instanceof Drop))
    return;
  return obj[key];
};
var readFirst = function(obj) {
  if (isArray(obj))
    return obj[0];
  return obj["first"];
};
var readLast = function(obj) {
  if (isArray(obj))
    return obj[obj.length - 1];
  return obj["last"];
};
var readSize = function(obj) {
  if (obj.hasOwnProperty("size") || obj["size"] !== undefined)
    return obj["size"];
  if (isArray(obj) || isString(obj))
    return obj.length;
  if (typeof obj === "object")
    return Object.keys(obj).length;
};
var round = function(v, arg = 0) {
  v = toValue(v);
  arg = toValue(arg);
  const amp = Math.pow(10, arg);
  return Math.round(v * amp) / amp;
};
var plus = function(v, arg) {
  v = toValue(v);
  arg = toValue(arg);
  return Number(v) + Number(arg);
};
var slugify = function(str, mode = "default", cased = false) {
  str = stringify2(str);
  const replacer = rSlugifyReplacers[mode];
  if (replacer) {
    if (mode === "latin")
      str = removeAccents(str);
    str = str.replace(replacer, "-").replace(/^-|-$/g, "");
  }
  return cased ? str : str.toLowerCase();
};
var removeAccents = function(str) {
  return str.replace(/[\u00E0\u00E1\u00E2\u00E3\u00E4\u00E5]/g, "a").replace(/[\u00E6]/g, "ae").replace(/[\u00E7]/g, "c").replace(/[\u00E8\u00E9\u00EA\u00EB]/g, "e").replace(/[\u00EC\u00ED\u00EE\u00EF]/g, "i").replace(/[\u00F0]/g, "d").replace(/[\u00F1]/g, "n").replace(/[\u00F2\u00F3\u00F4\u00F5\u00F6\u00F8]/g, "o").replace(/[\u00F9\u00FA\u00FB\u00FC]/g, "u").replace(/[\u00FD\u00FF]/g, "y").replace(/[\u00DF]/g, "ss").replace(/[\u0153]/g, "oe").replace(/[\u00FE]/g, "th").replace(/[\u1E9E]/g, "SS").replace(/[\u0152]/g, "OE").replace(/[\u00DE]/g, "TH");
};
function* sort(arr, property) {
  const values = [];
  const array = toArray(arr);
  this.context.memoryLimit.use(array.length);
  for (const item of array) {
    values.push([
      item,
      property ? yield this.context._getFromScope(item, stringify2(property).split("."), false) : item
    ]);
  }
  return values.sort((lhs, rhs) => {
    const lvalue = lhs[1];
    const rvalue = rhs[1];
    return lvalue < rvalue ? -1 : lvalue > rvalue ? 1 : 0;
  }).map((tuple) => tuple[0]);
}
var sort_natural = function(input, property) {
  const propertyString = stringify2(property);
  const compare = property === undefined ? caseInsensitiveCompare : (lhs, rhs) => caseInsensitiveCompare(lhs[propertyString], rhs[propertyString]);
  const array = toArray(input);
  this.context.memoryLimit.use(array.length);
  return [...array].sort(compare);
};
function* map(arr, property) {
  const results = [];
  const array = toArray(arr);
  this.context.memoryLimit.use(array.length);
  for (const item of array) {
    results.push(yield this.context._getFromScope(item, stringify2(property), false));
  }
  return results;
}
function* sum(arr, property) {
  let sum2 = 0;
  const array = toArray(arr);
  for (const item of array) {
    const data = Number(property ? yield this.context._getFromScope(item, stringify2(property), false) : item);
    sum2 += Number.isNaN(data) ? 0 : data;
  }
  return sum2;
}
var compact = function(arr) {
  const array = toArray(arr);
  this.context.memoryLimit.use(array.length);
  return array.filter((x) => !isNil(toValue(x)));
};
var concat = function(v, arg = []) {
  const lhs = toArray(v);
  const rhs = toArray(arg);
  this.context.memoryLimit.use(lhs.length + rhs.length);
  return lhs.concat(rhs);
};
var push = function(v, arg) {
  return concat.call(this, v, [arg]);
};
var unshift = function(v, arg) {
  const array = toArray(v);
  this.context.memoryLimit.use(array.length);
  const clone = [...array];
  clone.unshift(arg);
  return clone;
};
var pop = function(v) {
  const clone = [...toArray(v)];
  clone.pop();
  return clone;
};
var shift = function(v) {
  const array = toArray(v);
  this.context.memoryLimit.use(array.length);
  const clone = [...array];
  clone.shift();
  return clone;
};
var slice = function(v, begin, length = 1) {
  v = toValue(v);
  if (isNil(v))
    return [];
  if (!isArray(v))
    v = stringify2(v);
  begin = begin < 0 ? v.length + begin : begin;
  this.context.memoryLimit.use(length);
  return v.slice(begin, begin + length);
};
function* where(arr, property, expected) {
  const values = [];
  arr = toArray(arr);
  this.context.memoryLimit.use(arr.length);
  const token = new Tokenizer(stringify2(property)).readScopeValue();
  for (const item of arr) {
    values.push(yield evalToken(token, this.context.spawn(item)));
  }
  return arr.filter((_, i) => {
    if (expected === undefined)
      return isTruthy(values[i], this.context);
    return equals(values[i], expected);
  });
}
function* where_exp(arr, itemName, exp) {
  const filtered = [];
  const keyTemplate = new Value(stringify2(exp), this.liquid);
  const array = toArray(arr);
  this.context.memoryLimit.use(array.length);
  for (const item of array) {
    const value = yield keyTemplate.value(this.context.spawn({ [itemName]: item }));
    if (value)
      filtered.push(item);
  }
  return filtered;
}
function* group_by(arr, property) {
  const map2 = new Map;
  arr = toArray(arr);
  const token = new Tokenizer(stringify2(property)).readScopeValue();
  this.context.memoryLimit.use(arr.length);
  for (const item of arr) {
    const key = yield evalToken(token, this.context.spawn(item));
    if (!map2.has(key))
      map2.set(key, []);
    map2.get(key).push(item);
  }
  return [...map2.entries()].map(([name, items]) => ({ name, items }));
}
function* group_by_exp(arr, itemName, exp) {
  const map2 = new Map;
  const keyTemplate = new Value(stringify2(exp), this.liquid);
  arr = toArray(arr);
  this.context.memoryLimit.use(arr.length);
  for (const item of arr) {
    const key = yield keyTemplate.value(this.context.spawn({ [itemName]: item }));
    if (!map2.has(key))
      map2.set(key, []);
    map2.get(key).push(item);
  }
  return [...map2.entries()].map(([name, items]) => ({ name, items }));
}
function* find(arr, property, expected) {
  const token = new Tokenizer(stringify2(property)).readScopeValue();
  const array = toArray(arr);
  for (const item of array) {
    const value = yield evalToken(token, this.context.spawn(item));
    if (equals(value, expected))
      return item;
  }
  return null;
}
function* find_exp(arr, itemName, exp) {
  const predicate = new Value(stringify2(exp), this.liquid);
  const array = toArray(arr);
  for (const item of array) {
    const value = yield predicate.value(this.context.spawn({ [itemName]: item }));
    if (value)
      return item;
  }
  return null;
}
var uniq = function(arr) {
  arr = toValue(arr);
  this.context.memoryLimit.use(arr.length);
  const u = {};
  return (arr || []).filter((val) => {
    if (hasOwnProperty.call(u, String(val)))
      return false;
    u[String(val)] = true;
    return true;
  });
};
var sample = function(v, count = 1) {
  v = toValue(v);
  if (isNil(v))
    return [];
  if (!isArray(v))
    v = stringify2(v);
  this.context.memoryLimit.use(count);
  const shuffled = [...v].sort(() => Math.random() - 0.5);
  if (count === 1)
    return shuffled[0];
  return shuffled.slice(0, count);
};
var date = function(v, format2, timezoneOffset) {
  var _a, _b, _c;
  const size = ((_a = v === null || v === undefined ? undefined : v.length) !== null && _a !== undefined ? _a : 0) + ((_b = format2 === null || format2 === undefined ? undefined : format2.length) !== null && _b !== undefined ? _b : 0) + ((_c = timezoneOffset === null || timezoneOffset === undefined ? undefined : timezoneOffset.length) !== null && _c !== undefined ? _c : 0);
  this.context.memoryLimit.use(size);
  const date2 = parseDate(v, this.context.opts, timezoneOffset);
  if (!date2)
    return v;
  format2 = toValue(format2);
  format2 = isNil(format2) ? this.context.opts.dateFormat : stringify2(format2);
  return strftime(date2, format2);
};
var date_to_xmlschema = function(v) {
  return date.call(this, v, "%Y-%m-%dT%H:%M:%S%:z");
};
var date_to_rfc822 = function(v) {
  return date.call(this, v, "%a, %d %b %Y %H:%M:%S %z");
};
var date_to_string = function(v, type, style) {
  return stringify_date.call(this, v, "%b", type, style);
};
var date_to_long_string = function(v, type, style) {
  return stringify_date.call(this, v, "%B", type, style);
};
var stringify_date = function(v, month_type, type, style) {
  const date2 = parseDate(v, this.context.opts);
  if (!date2)
    return v;
  if (type === "ordinal") {
    const d = date2.getDate();
    return style === "US" ? strftime(date2, `${month_type} ${d}%q, %Y`) : strftime(date2, `${d}%q ${month_type} %Y`);
  }
  return strftime(date2, `%d ${month_type} %Y`);
};
var parseDate = function(v, opts, timezoneOffset) {
  let date2;
  v = toValue(v);
  if (v === "now" || v === "today") {
    date2 = new Date;
  } else if (isNumber(v)) {
    date2 = new Date(v * 1000);
  } else if (isString(v)) {
    if (/^\d+$/.test(v)) {
      date2 = new Date(+v * 1000);
    } else if (opts.preserveTimezones) {
      date2 = TimezoneDate.createDateFixedToTimezone(v);
    } else {
      date2 = new Date(v);
    }
  } else {
    date2 = v;
  }
  if (!isValidDate(date2))
    return;
  if (timezoneOffset !== undefined) {
    date2 = new TimezoneDate(date2, timezoneOffset);
  } else if (!(date2 instanceof TimezoneDate) && opts.timezoneOffset !== undefined) {
    date2 = new TimezoneDate(date2, opts.timezoneOffset);
  }
  return date2;
};
var isValidDate = function(date2) {
  return (date2 instanceof Date || date2 instanceof TimezoneDate) && !isNaN(date2.getTime());
};
var append = function(v, arg) {
  assert(arguments.length === 2, "append expect 2 arguments");
  const lhs = stringify2(v);
  const rhs = stringify2(arg);
  this.context.memoryLimit.use(lhs.length + rhs.length);
  return lhs + rhs;
};
var prepend = function(v, arg) {
  assert(arguments.length === 2, "prepend expect 2 arguments");
  const lhs = stringify2(v);
  const rhs = stringify2(arg);
  this.context.memoryLimit.use(lhs.length + rhs.length);
  return rhs + lhs;
};
var lstrip = function(v, chars) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  if (chars) {
    chars = escapeRegExp(stringify2(chars));
    return str.replace(new RegExp(`^[${chars}]+`, "g"), "");
  }
  return str.replace(/^\s+/, "");
};
var downcase = function(v) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.toLowerCase();
};
var upcase = function(v) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return stringify2(str).toUpperCase();
};
var remove = function(v, arg) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.split(stringify2(arg)).join("");
};
var remove_first = function(v, l) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.replace(stringify2(l), "");
};
var remove_last = function(v, l) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  const pattern = stringify2(l);
  const index = str.lastIndexOf(pattern);
  if (index === -1)
    return str;
  return str.substring(0, index) + str.substring(index + pattern.length);
};
var rstrip = function(str, chars) {
  str = stringify2(str);
  this.context.memoryLimit.use(str.length);
  if (chars) {
    chars = escapeRegExp(stringify2(chars));
    return str.replace(new RegExp(`[${chars}]+\$`, "g"), "");
  }
  return str.replace(/\s+$/, "");
};
var split = function(v, arg) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  const arr = str.split(stringify2(arg));
  while (arr.length && arr[arr.length - 1] === "")
    arr.pop();
  return arr;
};
var strip = function(v, chars) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  if (chars) {
    chars = escapeRegExp(stringify2(chars));
    return str.replace(new RegExp(`^[${chars}]+`, "g"), "").replace(new RegExp(`[${chars}]+\$`, "g"), "");
  }
  return str.trim();
};
var strip_newlines = function(v) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.replace(/\r?\n/gm, "");
};
var capitalize = function(str) {
  str = stringify2(str);
  this.context.memoryLimit.use(str.length);
  return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
};
var replace = function(v, pattern, replacement) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.split(stringify2(pattern)).join(replacement);
};
var replace_first = function(v, arg1, arg2) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.replace(stringify2(arg1), arg2);
};
var replace_last = function(v, arg1, arg2) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  const pattern = stringify2(arg1);
  const index = str.lastIndexOf(pattern);
  if (index === -1)
    return str;
  const replacement = stringify2(arg2);
  return str.substring(0, index) + replacement + str.substring(index + pattern.length);
};
var truncate = function(v, l = 50, o = "...") {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  if (str.length <= l)
    return v;
  return str.substring(0, l - o.length) + o;
};
var truncatewords = function(v, words = 15, o = "...") {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  const arr = str.split(/\s+/);
  if (words <= 0)
    words = 1;
  let ret = arr.slice(0, words).join(" ");
  if (arr.length >= words)
    ret += o;
  return ret;
};
var normalize_whitespace = function(v) {
  const str = stringify2(v);
  this.context.memoryLimit.use(str.length);
  return str.replace(/\s+/g, " ");
};
var number_of_words = function(input, mode) {
  const str = stringify2(input);
  this.context.memoryLimit.use(str.length);
  input = str.trim();
  if (!input)
    return 0;
  switch (mode) {
    case "cjk":
      return (input.match(rCJKWord) || []).length + (input.match(rNonCJKWord) || []).length;
    case "auto":
      return rCJKWord.test(input) ? input.match(rCJKWord).length + (input.match(rNonCJKWord) || []).length : input.split(/\s+/).length;
    default:
      return input.split(/\s+/).length;
  }
};
var array_to_sentence_string = function(array, connector = "and") {
  this.context.memoryLimit.use(array.length);
  switch (array.length) {
    case 0:
      return "";
    case 1:
      return array[0];
    case 2:
      return `${array[0]} ${connector} ${array[1]}`;
    default:
      return `${array.slice(0, -1).join(", ")}, ${connector} ${array[array.length - 1]}`;
  }
};
var reversed = function(arr) {
  return [...arr].reverse();
};
var offset = function(arr, count) {
  return arr.slice(count);
};
var limit = function(arr, count) {
  return arr.slice(0, count);
};
var parseFilePath = function(tokenizer, liquid, parser2) {
  if (liquid.options.dynamicPartials) {
    const file = tokenizer.readValue();
    tokenizer.assert(file, "illegal file path");
    if (file.getText() === "none")
      return;
    if (isQuotedToken(file)) {
      const templates2 = parser2.parse(evalQuotedToken(file));
      return optimize(templates2);
    }
    return file;
  }
  const tokens = [...tokenizer.readFileNameTemplate(liquid.options)];
  const templates = optimize(parser2.parseTokens(tokens));
  return templates === "none" ? undefined : templates;
};
var optimize = function(templates) {
  if (templates.length === 1 && isHTMLToken(templates[0].token))
    return templates[0].token.getContent();
  return templates;
};
function* renderFilePath(file, ctx, liquid) {
  if (typeof file === "string")
    return file;
  if (Array.isArray(file))
    return liquid.renderer.renderTemplates(file, ctx);
  return yield evalToken(file, ctx);
}

class Token {
  constructor(kind, input, begin, end, file) {
    this.kind = kind;
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
  }
  getText() {
    return this.input.slice(this.begin, this.end);
  }
  getPosition() {
    let [row, col] = [1, 1];
    for (let i = 0;i < this.begin; i++) {
      if (this.input[i] === "\n") {
        row++;
        col = 1;
      } else
        col++;
    }
    return [row, col];
  }
  size() {
    return this.end - this.begin;
  }
}

class Drop {
  liquidMethodMissing(key) {
    return;
  }
}
var toString$1 = Object.prototype.toString;
var toLowerCase = String.prototype.toLowerCase;
var hasOwnProperty = Object.hasOwnProperty;
var TRAIT = "__liquidClass__";

class LiquidError extends Error {
  constructor(err, token) {
    super(typeof err === "string" ? err : err.message);
    this.context = "";
    if (typeof err !== "string")
      Object.defineProperty(this, "originalError", { value: err, enumerable: false });
    Object.defineProperty(this, "token", { value: token, enumerable: false });
    Object.defineProperty(this, TRAIT, { value: "LiquidError", enumerable: false });
  }
  update() {
    Object.defineProperty(this, "context", { value: mkContext(this.token), enumerable: false });
    this.message = mkMessage(this.message, this.token);
    this.stack = this.message + "\n" + this.context + "\n" + this.stack;
    if (this.originalError)
      this.stack += "\nFrom " + this.originalError.stack;
  }
  static is(obj) {
    return (obj === null || obj === undefined ? undefined : obj[TRAIT]) === "LiquidError";
  }
}

class TokenizationError extends LiquidError {
  constructor(message, token) {
    super(message, token);
    this.name = "TokenizationError";
    super.update();
  }
}

class ParseError extends LiquidError {
  constructor(err, token) {
    super(err, token);
    this.name = "ParseError";
    this.message = err.message;
    super.update();
  }
}

class RenderError extends LiquidError {
  constructor(err, tpl) {
    super(err, tpl.token);
    this.name = "RenderError";
    this.message = err.message;
    super.update();
  }
  static is(obj) {
    return obj.name === "RenderError";
  }
}

class LiquidErrors extends LiquidError {
  constructor(errors3) {
    super(errors3[0], errors3[0].token);
    this.errors = errors3;
    this.name = "LiquidErrors";
    const s = errors3.length > 1 ? "s" : "";
    this.message = `${errors3.length} error${s} found`;
    super.update();
  }
  static is(obj) {
    return obj.name === "LiquidErrors";
  }
}

class UndefinedVariableError extends LiquidError {
  constructor(err, token) {
    super(err, token);
    this.name = "UndefinedVariableError";
    this.message = err.message;
    super.update();
  }
}

class InternalUndefinedVariableError extends Error {
  constructor(variableName) {
    super(`undefined variable: ${variableName}`);
    this.name = "InternalUndefinedVariableError";
    this.variableName = variableName;
  }
}

class AssertionError extends Error {
  constructor(message) {
    super(message);
    this.name = "AssertionError";
    this.message = message + "";
  }
}
var TYPES = [0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 4, 4, 4, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 2, 8, 0, 0, 0, 0, 8, 0, 0, 0, 64, 0, 65, 0, 0, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 0, 0, 2, 2, 2, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0];
var WORD = 1;
var BLANK = 4;
var QUOTE = 8;
var INLINE_BLANK = 16;
var NUMBER = 32;
var SIGN = 64;
var PUNCTUATION = 128;
TYPES[160] = TYPES[5760] = TYPES[6158] = TYPES[8192] = TYPES[8193] = TYPES[8194] = TYPES[8195] = TYPES[8196] = TYPES[8197] = TYPES[8198] = TYPES[8199] = TYPES[8200] = TYPES[8201] = TYPES[8202] = TYPES[8232] = TYPES[8233] = TYPES[8239] = TYPES[8287] = TYPES[12288] = BLANK;
TYPES[8220] = TYPES[8221] = PUNCTUATION;

class NullDrop extends Drop {
  equals(value) {
    return isNil(toValue(value));
  }
  gt() {
    return false;
  }
  geq() {
    return false;
  }
  lt() {
    return false;
  }
  leq() {
    return false;
  }
  valueOf() {
    return null;
  }
}

class EmptyDrop extends Drop {
  equals(value) {
    if (value instanceof EmptyDrop)
      return false;
    value = toValue(value);
    if (isString(value) || isArray(value))
      return value.length === 0;
    if (isObject(value))
      return Object.keys(value).length === 0;
    return false;
  }
  gt() {
    return false;
  }
  geq() {
    return false;
  }
  lt() {
    return false;
  }
  leq() {
    return false;
  }
  valueOf() {
    return "";
  }
}

class BlankDrop extends EmptyDrop {
  equals(value) {
    if (value === false)
      return true;
    if (isNil(toValue(value)))
      return true;
    if (isString(value))
      return /^\s*$/.test(value);
    return super.equals(value);
  }
}

class ForloopDrop extends Drop {
  constructor(length, collection, variable) {
    super();
    this.i = 0;
    this.length = length;
    this.name = `${variable}-${collection}`;
  }
  next() {
    this.i++;
  }
  index0() {
    return this.i;
  }
  index() {
    return this.i + 1;
  }
  first() {
    return this.i === 0;
  }
  last() {
    return this.i === this.length - 1;
  }
  rindex() {
    return this.length - this.i;
  }
  rindex0() {
    return this.length - this.i - 1;
  }
  valueOf() {
    return JSON.stringify(this);
  }
}

class BlockDrop extends Drop {
  constructor(superBlockRender = () => "") {
    super();
    this.superBlockRender = superBlockRender;
  }
  super() {
    return this.superBlockRender();
  }
}
var nil = new NullDrop;
var literalValues = {
  true: true,
  false: false,
  nil,
  null: nil,
  empty: new EmptyDrop,
  blank: new BlankDrop
};
var __assign = function() {
  __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length;i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var rFormat = /%([-_0^#:]+)?(\d+)?([EO])?(.)/;
var monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
];
var dayNames = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday"
];
var monthNamesShort = monthNames.map(abbr);
var dayNamesShort = dayNames.map(abbr);
var padWidths = {
  d: 2,
  e: 2,
  H: 2,
  I: 2,
  j: 3,
  k: 2,
  l: 2,
  L: 3,
  m: 2,
  M: 2,
  S: 2,
  U: 2,
  W: 2
};
var padChars = {
  a: " ",
  A: " ",
  b: " ",
  B: " ",
  c: " ",
  e: " ",
  k: " ",
  l: " ",
  p: " ",
  P: " "
};
var formatCodes = {
  a: (d) => dayNamesShort[d.getDay()],
  A: (d) => dayNames[d.getDay()],
  b: (d) => monthNamesShort[d.getMonth()],
  B: (d) => monthNames[d.getMonth()],
  c: (d) => d.toLocaleString(),
  C: (d) => century(d),
  d: (d) => d.getDate(),
  e: (d) => d.getDate(),
  H: (d) => d.getHours(),
  I: (d) => String(d.getHours() % 12 || 12),
  j: (d) => getDayOfYear(d),
  k: (d) => d.getHours(),
  l: (d) => String(d.getHours() % 12 || 12),
  L: (d) => d.getMilliseconds(),
  m: (d) => d.getMonth() + 1,
  M: (d) => d.getMinutes(),
  N: (d, opts) => {
    const width = Number(opts.width) || 9;
    const str = String(d.getMilliseconds()).slice(0, width);
    return padEnd(str, width, "0");
  },
  p: (d) => d.getHours() < 12 ? "AM" : "PM",
  P: (d) => d.getHours() < 12 ? "am" : "pm",
  q: (d) => ordinal(d),
  s: (d) => Math.round(d.getTime() / 1000),
  S: (d) => d.getSeconds(),
  u: (d) => d.getDay() || 7,
  U: (d) => getWeekOfYear(d, 0),
  w: (d) => d.getDay(),
  W: (d) => getWeekOfYear(d, 1),
  x: (d) => d.toLocaleDateString(),
  X: (d) => d.toLocaleTimeString(),
  y: (d) => d.getFullYear().toString().slice(2, 4),
  Y: (d) => d.getFullYear(),
  z: getTimezoneOffset,
  Z: (d, opts) => {
    if (d.getTimezoneName) {
      return d.getTimezoneName() || getTimezoneOffset(d, opts);
    }
    return typeof Intl !== "undefined" ? Intl.DateTimeFormat().resolvedOptions().timeZone : "";
  },
  t: () => "\t",
  n: () => "\n",
  "%": () => "%"
};
formatCodes.h = formatCodes.b;
var OneMinute = 60000;
var ISO8601_TIMEZONE_PATTERN = /([zZ]|([+-])(\d{2}):(\d{2}))$/;

class TimezoneDate {
  constructor(init, timezone) {
    this.date = init instanceof TimezoneDate ? init.date : new Date(init);
    this.timezoneOffset = isString(timezone) ? TimezoneDate.getTimezoneOffset(timezone, this.date) : timezone;
    this.timezoneName = isString(timezone) ? timezone : "";
    const diff = (this.date.getTimezoneOffset() - this.timezoneOffset) * OneMinute;
    const time = this.date.getTime() + diff;
    this.displayDate = new Date(time);
  }
  getTime() {
    return this.displayDate.getTime();
  }
  getMilliseconds() {
    return this.displayDate.getMilliseconds();
  }
  getSeconds() {
    return this.displayDate.getSeconds();
  }
  getMinutes() {
    return this.displayDate.getMinutes();
  }
  getHours() {
    return this.displayDate.getHours();
  }
  getDay() {
    return this.displayDate.getDay();
  }
  getDate() {
    return this.displayDate.getDate();
  }
  getMonth() {
    return this.displayDate.getMonth();
  }
  getFullYear() {
    return this.displayDate.getFullYear();
  }
  toLocaleString(locale, init) {
    if (init === null || init === undefined ? undefined : init.timeZone) {
      return this.date.toLocaleString(locale, init);
    }
    return this.displayDate.toLocaleString(locale, init);
  }
  toLocaleTimeString(locale) {
    return this.displayDate.toLocaleTimeString(locale);
  }
  toLocaleDateString(locale) {
    return this.displayDate.toLocaleDateString(locale);
  }
  getTimezoneOffset() {
    return this.timezoneOffset;
  }
  getTimezoneName() {
    return this.timezoneName;
  }
  static createDateFixedToTimezone(dateString) {
    const m = dateString.match(ISO8601_TIMEZONE_PATTERN);
    if (m && m[1] === "Z") {
      return new TimezoneDate(+new Date(dateString), 0);
    }
    if (m && m[2] && m[3] && m[4]) {
      const [, , sign, hours, minutes] = m;
      const offset2 = (sign === "+" ? -1 : 1) * (parseInt(hours, 10) * 60 + parseInt(minutes, 10));
      return new TimezoneDate(+new Date(dateString), offset2);
    }
    return new Date(dateString);
  }
  static getTimezoneOffset(timezoneName, date2 = new Date) {
    const localDateString = date2.toLocaleString("en-US", { timeZone: timezoneName });
    const utcDateString = date2.toLocaleString("en-US", { timeZone: "UTC" });
    const localDate = new Date(localDateString);
    const utcDate = new Date(utcDateString);
    return (+utcDate - +localDate) / (60 * 1000);
  }
}

class Limiter {
  constructor(resource, limit2) {
    this.base = 0;
    this.message = `${resource} limit exceeded`;
    this.limit = limit2;
  }
  use(count) {
    assert(this.base + count <= this.limit, this.message);
    this.base += count;
  }
  check(count) {
    assert(count <= this.limit, this.message);
  }
}

class DelimitedToken extends Token {
  constructor(kind, [contentBegin, contentEnd], input, begin, end, trimLeft2, trimRight2, file) {
    super(kind, input, begin, end, file);
    this.trimLeft = false;
    this.trimRight = false;
    const tl = input[contentBegin] === "-";
    const tr = input[contentEnd - 1] === "-";
    let l = tl ? contentBegin + 1 : contentBegin;
    let r = tr ? contentEnd - 1 : contentEnd;
    while (l < r && TYPES[input.charCodeAt(l)] & BLANK)
      l++;
    while (r > l && TYPES[input.charCodeAt(r - 1)] & BLANK)
      r--;
    this.contentRange = [l, r];
    this.trimLeft = tl || trimLeft2;
    this.trimRight = tr || trimRight2;
  }
  get content() {
    return this.input.slice(this.contentRange[0], this.contentRange[1]);
  }
}

class TagToken extends DelimitedToken {
  constructor(input, begin, end, options2, file) {
    const { trimTagLeft, trimTagRight, tagDelimiterLeft, tagDelimiterRight } = options2;
    const [valueBegin, valueEnd] = [begin + tagDelimiterLeft.length, end - tagDelimiterRight.length];
    super(TokenKind.Tag, [valueBegin, valueEnd], input, begin, end, trimTagLeft, trimTagRight, file);
    this.tokenizer = new Tokenizer(input, options2.operators, file, this.contentRange);
    this.name = this.tokenizer.readTagName();
    this.tokenizer.assert(this.name, `illegal tag syntax, tag name expected`);
    this.tokenizer.skipBlank();
  }
  get args() {
    return this.tokenizer.input.slice(this.tokenizer.p, this.contentRange[1]);
  }
}

class OutputToken extends DelimitedToken {
  constructor(input, begin, end, options2, file) {
    const { trimOutputLeft, trimOutputRight, outputDelimiterLeft, outputDelimiterRight } = options2;
    const valueRange = [begin + outputDelimiterLeft.length, end - outputDelimiterRight.length];
    super(TokenKind.Output, valueRange, input, begin, end, trimOutputLeft, trimOutputRight, file);
  }
}

class HTMLToken extends Token {
  constructor(input, begin, end, file) {
    super(TokenKind.HTML, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
    this.trimLeft = 0;
    this.trimRight = 0;
  }
  getContent() {
    return this.input.slice(this.begin + this.trimLeft, this.end - this.trimRight);
  }
}

class NumberToken extends Token {
  constructor(input, begin, end, file) {
    super(TokenKind.Number, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
    this.content = Number(this.getText());
  }
}

class IdentifierToken extends Token {
  constructor(input, begin, end, file) {
    super(TokenKind.Word, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
    this.content = this.getText();
  }
  isNumber(allowSign = false) {
    const begin = allowSign && TYPES[this.input.charCodeAt(this.begin)] & SIGN ? this.begin + 1 : this.begin;
    for (let i = begin;i < this.end; i++) {
      if (!(TYPES[this.input.charCodeAt(i)] & NUMBER))
        return false;
    }
    return true;
  }
}

class LiteralToken extends Token {
  constructor(input, begin, end, file) {
    super(TokenKind.Literal, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
    this.literal = this.getText();
    this.content = literalValues[this.literal];
  }
}
var operatorPrecedences = {
  "==": 2,
  "!=": 2,
  ">": 2,
  "<": 2,
  ">=": 2,
  "<=": 2,
  contains: 2,
  not: 1,
  and: 0,
  or: 0
};
var operatorTypes = {
  "==": 0,
  "!=": 0,
  ">": 0,
  "<": 0,
  ">=": 0,
  "<=": 0,
  contains: 0,
  not: 1,
  and: 0,
  or: 0
};

class OperatorToken extends Token {
  constructor(input, begin, end, file) {
    super(TokenKind.Operator, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
    this.operator = this.getText();
  }
  getPrecedence() {
    const key = this.getText();
    return key in operatorPrecedences ? operatorPrecedences[key] : 1;
  }
}

class PropertyAccessToken extends Token {
  constructor(variable, props, input, begin, end, file) {
    super(TokenKind.PropertyAccess, input, begin, end, file);
    this.variable = variable;
    this.props = props;
  }
}

class FilterToken extends Token {
  constructor(name, args, input, begin, end, file) {
    super(TokenKind.Filter, input, begin, end, file);
    this.name = name;
    this.args = args;
  }
}

class HashToken extends Token {
  constructor(input, begin, end, name, value, file) {
    super(TokenKind.Hash, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.name = name;
    this.value = value;
    this.file = file;
  }
}
var rHex = /[\da-fA-F]/;
var rOct = /[0-7]/;
var escapeChar = {
  b: "\b",
  f: "\f",
  n: "\n",
  r: "\r",
  t: "\t",
  v: "\v"
};

class QuotedToken extends Token {
  constructor(input, begin, end, file) {
    super(TokenKind.Quoted, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
    this.content = parseStringLiteral(this.getText());
  }
}

class RangeToken extends Token {
  constructor(input, begin, end, lhs, rhs, file) {
    super(TokenKind.Range, input, begin, end, file);
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.lhs = lhs;
    this.rhs = rhs;
    this.file = file;
  }
}

class LiquidTagToken extends DelimitedToken {
  constructor(input, begin, end, options2, file) {
    super(TokenKind.Tag, [begin, end], input, begin, end, false, false, file);
    this.tokenizer = new Tokenizer(input, options2.operators, file, this.contentRange);
    this.name = this.tokenizer.readTagName();
    this.tokenizer.assert(this.name, "illegal liquid tag syntax");
    this.tokenizer.skipBlank();
    this.args = this.tokenizer.remaining();
  }
}

class FilteredValueToken extends Token {
  constructor(initial, filters, input, begin, end, file) {
    super(TokenKind.FilteredValue, input, begin, end, file);
    this.initial = initial;
    this.filters = filters;
    this.input = input;
    this.begin = begin;
    this.end = end;
    this.file = file;
  }
}

class SimpleEmitter {
  constructor() {
    this.buffer = "";
  }
  write(html2) {
    this.buffer += stringify2(html2);
  }
}

class StreamedEmitter {
  constructor() {
    this.buffer = "";
    this.stream = new PassThrough;
  }
  write(html2) {
    this.stream.write(stringify2(html2));
  }
  error(err) {
    this.stream.emit("error", err);
  }
  end() {
    this.stream.end();
  }
}

class KeepingTypeEmitter {
  constructor() {
    this.buffer = "";
  }
  write(html2) {
    html2 = toValue(html2);
    if (typeof html2 !== "string" && this.buffer === "") {
      this.buffer = html2;
    } else {
      this.buffer = stringify2(this.buffer) + stringify2(html2);
    }
  }
}

class Render {
  renderTemplatesToNodeStream(templates, ctx) {
    const emitter = new StreamedEmitter;
    Promise.resolve().then(() => toPromise(this.renderTemplates(templates, ctx, emitter))).then(() => emitter.end(), (err) => emitter.error(err));
    return emitter.stream;
  }
  *renderTemplates(templates, ctx, emitter) {
    if (!emitter) {
      emitter = ctx.opts.keepOutputType ? new KeepingTypeEmitter : new SimpleEmitter;
    }
    const errors3 = [];
    for (const tpl of templates) {
      ctx.renderLimit.check(performance.now());
      try {
        const html2 = yield tpl.render(ctx, emitter);
        html2 && emitter.write(html2);
        if (emitter["break"] || emitter["continue"])
          break;
      } catch (e) {
        const err = LiquidError.is(e) ? e : new RenderError(e, tpl);
        if (ctx.opts.catchAllErrors)
          errors3.push(err);
        else
          throw err;
      }
    }
    if (errors3.length) {
      throw new LiquidErrors(errors3);
    }
    return emitter.buffer;
  }
}

class Expression {
  constructor(tokens) {
    this.postfix = [...toPostfix(tokens)];
  }
  *evaluate(ctx, lenient) {
    assert(ctx, "unable to evaluate: context not defined");
    const operands = [];
    for (const token of this.postfix) {
      if (isOperatorToken(token)) {
        const r = operands.pop();
        let result;
        if (operatorTypes[token.operator] === 1) {
          result = yield ctx.opts.operators[token.operator](r, ctx);
        } else {
          const l = operands.pop();
          result = yield ctx.opts.operators[token.operator](l, r, ctx);
        }
        operands.push(result);
      } else {
        operands.push(yield evalToken(token, ctx, lenient));
      }
    }
    return operands[0];
  }
  valid() {
    return !!this.postfix.length;
  }
}
var defaultOperators = {
  "==": equals,
  "!=": (l, r) => !equals(l, r),
  ">": (l, r) => {
    if (isComparable(l))
      return l.gt(r);
    if (isComparable(r))
      return r.lt(l);
    return toValue(l) > toValue(r);
  },
  "<": (l, r) => {
    if (isComparable(l))
      return l.lt(r);
    if (isComparable(r))
      return r.gt(l);
    return toValue(l) < toValue(r);
  },
  ">=": (l, r) => {
    if (isComparable(l))
      return l.geq(r);
    if (isComparable(r))
      return r.leq(l);
    return toValue(l) >= toValue(r);
  },
  "<=": (l, r) => {
    if (isComparable(l))
      return l.leq(r);
    if (isComparable(r))
      return r.geq(l);
    return toValue(l) <= toValue(r);
  },
  contains: (l, r) => {
    l = toValue(l);
    if (isArray(l))
      return l.some((i) => equals(i, r));
    if (isFunction(l === null || l === undefined ? undefined : l.indexOf))
      return l.indexOf(toValue(r)) > -1;
    return false;
  },
  not: (v, ctx) => isFalsy(toValue(v), ctx),
  and: (l, r, ctx) => isTruthy(toValue(l), ctx) && isTruthy(toValue(r), ctx),
  or: (l, r, ctx) => isTruthy(toValue(l), ctx) || isTruthy(toValue(r), ctx)
};

class Node {
  constructor(key, value, next, prev) {
    this.key = key;
    this.value = value;
    this.next = next;
    this.prev = prev;
  }
}

class LRU {
  constructor(limit2, size = 0) {
    this.limit = limit2;
    this.size = size;
    this.cache = {};
    this.head = new Node("HEAD", null, null, null);
    this.tail = new Node("TAIL", null, null, null);
    this.head.next = this.tail;
    this.tail.prev = this.head;
  }
  write(key, value) {
    if (this.cache[key]) {
      this.cache[key].value = value;
    } else {
      const node = new Node(key, value, this.head.next, this.head);
      this.head.next.prev = node;
      this.head.next = node;
      this.cache[key] = node;
      this.size++;
      this.ensureLimit();
    }
  }
  read(key) {
    if (!this.cache[key])
      return;
    const { value } = this.cache[key];
    this.remove(key);
    this.write(key, value);
    return value;
  }
  remove(key) {
    const node = this.cache[key];
    node.prev.next = node.next;
    node.next.prev = node.prev;
    delete this.cache[key];
    this.size--;
  }
  clear() {
    this.head.next = this.tail;
    this.tail.prev = this.head;
    this.size = 0;
    this.cache = {};
  }
  ensureLimit() {
    if (this.size > this.limit)
      this.remove(this.tail.prev.key);
  }
}
var requireResolve = import.meta.require.resolve;
var statAsync = promisify(stat);
var readFileAsync = promisify(readFile$1);
var fs2 = Object.freeze({
  __proto__: null,
  exists: exists2,
  readFile,
  existsSync,
  readFileSync,
  resolve,
  fallback,
  dirname,
  contains,
  sep
});
var raw2 = {
  raw: true,
  handler: identify
};
var misc = {
  default: defaultFilter,
  raw: raw2,
  jsonify: json,
  to_integer,
  json,
  inspect
};
var escapeMap = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&#34;",
  "'": "&#39;"
};
var unescapeMap = {
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&#34;": '"',
  "&#39;": "'"
};
var htmlFilters = Object.freeze({
  __proto__: null,
  escape: escape2,
  xml_escape,
  escape_once,
  newline_to_br,
  strip_html
});

class MapFS {
  constructor(mapping) {
    this.mapping = mapping;
    this.sep = "/";
  }
  exists(filepath) {
    return __awaiter(this, undefined, undefined, function* () {
      return this.existsSync(filepath);
    });
  }
  existsSync(filepath) {
    return !isNil(this.mapping[filepath]);
  }
  readFile(filepath) {
    return __awaiter(this, undefined, undefined, function* () {
      return this.readFileSync(filepath);
    });
  }
  readFileSync(filepath) {
    const content = this.mapping[filepath];
    if (isNil(content))
      throw new Error(`ENOENT: ${filepath}`);
    return content;
  }
  dirname(filepath) {
    const segments = filepath.split(this.sep);
    segments.pop();
    return segments.join(this.sep);
  }
  resolve(dir, file, ext) {
    file += ext;
    if (dir === ".")
      return file;
    const segments = dir.split(/\/+/);
    for (const segment of file.split(this.sep)) {
      if (segment === "." || segment === "")
        continue;
      else if (segment === "..") {
        if (segments.length > 1 || segments[0] !== "")
          segments.pop();
      } else
        segments.push(segment);
    }
    return segments.join(this.sep);
  }
}
var defaultOptions = {
  root: ["."],
  layouts: ["."],
  partials: ["."],
  relativeReference: true,
  jekyllInclude: false,
  cache: undefined,
  extname: "",
  fs: fs2,
  dynamicPartials: true,
  jsTruthy: false,
  dateFormat: "%A, %B %-e, %Y at %-l:%M %P %z",
  trimTagRight: false,
  trimTagLeft: false,
  trimOutputRight: false,
  trimOutputLeft: false,
  greedy: true,
  tagDelimiterLeft: "{%",
  tagDelimiterRight: "%}",
  outputDelimiterLeft: "{{",
  outputDelimiterRight: "}}",
  preserveTimezones: false,
  strictFilters: false,
  strictVariables: false,
  ownPropertyOnly: true,
  lenientIf: false,
  globals: {},
  keepOutputType: false,
  operators: defaultOperators,
  memoryLimit: Infinity,
  parseLimit: Infinity,
  renderLimit: Infinity
};

class Tokenizer {
  constructor(input, operators = defaultOptions.operators, file, range2) {
    this.input = input;
    this.file = file;
    this.rawBeginAt = -1;
    this.p = range2 ? range2[0] : 0;
    this.N = range2 ? range2[1] : input.length;
    this.opTrie = createTrie(operators);
    this.literalTrie = createTrie(literalValues);
  }
  readExpression() {
    return new Expression(this.readExpressionTokens());
  }
  *readExpressionTokens() {
    while (this.p < this.N) {
      const operator = this.readOperator();
      if (operator) {
        yield operator;
        continue;
      }
      const operand = this.readValue();
      if (operand) {
        yield operand;
        continue;
      }
      return;
    }
  }
  readOperator() {
    this.skipBlank();
    const end = this.matchTrie(this.opTrie);
    if (end === -1)
      return;
    return new OperatorToken(this.input, this.p, this.p = end, this.file);
  }
  matchTrie(trie) {
    let node = trie;
    let i = this.p;
    let info;
    while (node[this.input[i]] && i < this.N) {
      node = node[this.input[i++]];
      if (node["end"])
        info = node;
    }
    if (!info)
      return -1;
    if (info["needBoundary"] && isWord(this.peek(i - this.p)))
      return -1;
    return i;
  }
  readFilteredValue() {
    const begin = this.p;
    const initial = this.readExpression();
    this.assert(initial.valid(), `invalid value expression: ${this.snapshot()}`);
    const filters = this.readFilters();
    return new FilteredValueToken(initial, filters, this.input, begin, this.p, this.file);
  }
  readFilters() {
    const filters = [];
    while (true) {
      const filter = this.readFilter();
      if (!filter)
        return filters;
      filters.push(filter);
    }
  }
  readFilter() {
    this.skipBlank();
    if (this.end())
      return null;
    this.assert(this.peek() === "|", `expected "|" before filter`);
    this.p++;
    const begin = this.p;
    const name = this.readIdentifier();
    if (!name.size()) {
      this.assert(this.end(), `expected filter name`);
      return null;
    }
    const args = [];
    this.skipBlank();
    if (this.peek() === ":") {
      do {
        ++this.p;
        const arg = this.readFilterArg();
        arg && args.push(arg);
        this.skipBlank();
        this.assert(this.end() || this.peek() === "," || this.peek() === "|", () => `unexpected character ${this.snapshot()}`);
      } while (this.peek() === ",");
    } else if (this.peek() === "|" || this.end())
      ;
    else {
      throw this.error('expected ":" after filter name');
    }
    return new FilterToken(name.getText(), args, this.input, begin, this.p, this.file);
  }
  readFilterArg() {
    const key = this.readValue();
    if (!key)
      return;
    this.skipBlank();
    if (this.peek() !== ":")
      return key;
    ++this.p;
    const value = this.readValue();
    return [key.getText(), value];
  }
  readTopLevelTokens(options2 = defaultOptions) {
    const tokens = [];
    while (this.p < this.N) {
      const token = this.readTopLevelToken(options2);
      tokens.push(token);
    }
    whiteSpaceCtrl(tokens, options2);
    return tokens;
  }
  readTopLevelToken(options2) {
    const { tagDelimiterLeft, outputDelimiterLeft } = options2;
    if (this.rawBeginAt > -1)
      return this.readEndrawOrRawContent(options2);
    if (this.match(tagDelimiterLeft))
      return this.readTagToken(options2);
    if (this.match(outputDelimiterLeft))
      return this.readOutputToken(options2);
    return this.readHTMLToken([tagDelimiterLeft, outputDelimiterLeft]);
  }
  readHTMLToken(stopStrings) {
    const begin = this.p;
    while (this.p < this.N) {
      if (stopStrings.some((str) => this.match(str)))
        break;
      ++this.p;
    }
    return new HTMLToken(this.input, begin, this.p, this.file);
  }
  readTagToken(options2 = defaultOptions) {
    const { file, input } = this;
    const begin = this.p;
    if (this.readToDelimiter(options2.tagDelimiterRight) === -1) {
      throw this.error(`tag ${this.snapshot(begin)} not closed`, begin);
    }
    const token = new TagToken(input, begin, this.p, options2, file);
    if (token.name === "raw")
      this.rawBeginAt = begin;
    return token;
  }
  readToDelimiter(delimiter, respectQuoted = false) {
    this.skipBlank();
    while (this.p < this.N) {
      if (respectQuoted && this.peekType() & QUOTE) {
        this.readQuoted();
        continue;
      }
      ++this.p;
      if (this.rmatch(delimiter))
        return this.p;
    }
    return -1;
  }
  readOutputToken(options2 = defaultOptions) {
    const { file, input } = this;
    const { outputDelimiterRight } = options2;
    const begin = this.p;
    if (this.readToDelimiter(outputDelimiterRight, true) === -1) {
      throw this.error(`output ${this.snapshot(begin)} not closed`, begin);
    }
    return new OutputToken(input, begin, this.p, options2, file);
  }
  readEndrawOrRawContent(options2) {
    const { tagDelimiterLeft, tagDelimiterRight } = options2;
    const begin = this.p;
    let leftPos = this.readTo(tagDelimiterLeft) - tagDelimiterLeft.length;
    while (this.p < this.N) {
      if (this.readIdentifier().getText() !== "endraw") {
        leftPos = this.readTo(tagDelimiterLeft) - tagDelimiterLeft.length;
        continue;
      }
      while (this.p <= this.N) {
        if (this.rmatch(tagDelimiterRight)) {
          const end = this.p;
          if (begin === leftPos) {
            this.rawBeginAt = -1;
            return new TagToken(this.input, begin, end, options2, this.file);
          } else {
            this.p = leftPos;
            return new HTMLToken(this.input, begin, leftPos, this.file);
          }
        }
        if (this.rmatch(tagDelimiterLeft))
          break;
        this.p++;
      }
    }
    throw this.error(`raw ${this.snapshot(this.rawBeginAt)} not closed`, begin);
  }
  readLiquidTagTokens(options2 = defaultOptions) {
    const tokens = [];
    while (this.p < this.N) {
      const token = this.readLiquidTagToken(options2);
      token && tokens.push(token);
    }
    return tokens;
  }
  readLiquidTagToken(options2) {
    this.skipBlank();
    if (this.end())
      return;
    const begin = this.p;
    this.readToDelimiter("\n");
    const end = this.p;
    return new LiquidTagToken(this.input, begin, end, options2, this.file);
  }
  error(msg, pos = this.p) {
    return new TokenizationError(msg, new IdentifierToken(this.input, pos, this.N, this.file));
  }
  assert(pred, msg, pos) {
    if (!pred)
      throw this.error(typeof msg === "function" ? msg() : msg, pos);
  }
  snapshot(begin = this.p) {
    return JSON.stringify(ellipsis(this.input.slice(begin, this.N), 32));
  }
  readWord() {
    return this.readIdentifier();
  }
  readIdentifier() {
    this.skipBlank();
    const begin = this.p;
    while (!this.end() && isWord(this.peek()))
      ++this.p;
    return new IdentifierToken(this.input, begin, this.p, this.file);
  }
  readNonEmptyIdentifier() {
    const id = this.readIdentifier();
    return id.size() ? id : undefined;
  }
  readTagName() {
    this.skipBlank();
    if (this.input[this.p] === "#")
      return this.input.slice(this.p, ++this.p);
    return this.readIdentifier().getText();
  }
  readHashes(jekyllStyle) {
    const hashes = [];
    while (true) {
      const hash = this.readHash(jekyllStyle);
      if (!hash)
        return hashes;
      hashes.push(hash);
    }
  }
  readHash(jekyllStyle) {
    this.skipBlank();
    if (this.peek() === ",")
      ++this.p;
    const begin = this.p;
    const name = this.readNonEmptyIdentifier();
    if (!name)
      return;
    let value;
    this.skipBlank();
    const sep2 = jekyllStyle ? "=" : ":";
    if (this.peek() === sep2) {
      ++this.p;
      value = this.readValue();
    }
    return new HashToken(this.input, begin, this.p, name, value, this.file);
  }
  remaining() {
    return this.input.slice(this.p, this.N);
  }
  advance(step = 1) {
    this.p += step;
  }
  end() {
    return this.p >= this.N;
  }
  readTo(end) {
    while (this.p < this.N) {
      ++this.p;
      if (this.rmatch(end))
        return this.p;
    }
    return -1;
  }
  readValue() {
    this.skipBlank();
    const begin = this.p;
    const variable = this.readLiteral() || this.readQuoted() || this.readRange() || this.readNumber();
    const props = this.readProperties(!variable);
    if (!props.length)
      return variable;
    return new PropertyAccessToken(variable, props, this.input, begin, this.p);
  }
  readScopeValue() {
    this.skipBlank();
    const begin = this.p;
    const props = this.readProperties();
    if (!props.length)
      return;
    return new PropertyAccessToken(undefined, props, this.input, begin, this.p);
  }
  readProperties(isBegin = true) {
    const props = [];
    while (true) {
      if (this.peek() === "[") {
        this.p++;
        const prop = this.readValue() || new IdentifierToken(this.input, this.p, this.p, this.file);
        this.assert(this.readTo("]") !== -1, "[ not closed");
        props.push(prop);
        continue;
      }
      if (isBegin && !props.length) {
        const prop = this.readNonEmptyIdentifier();
        if (prop) {
          props.push(prop);
          continue;
        }
      }
      if (this.peek() === "." && this.peek(1) !== ".") {
        this.p++;
        const prop = this.readNonEmptyIdentifier();
        if (!prop)
          break;
        props.push(prop);
        continue;
      }
      break;
    }
    return props;
  }
  readNumber() {
    this.skipBlank();
    let decimalFound = false;
    let digitFound = false;
    let n = 0;
    if (this.peekType() & SIGN)
      n++;
    while (this.p + n <= this.N) {
      if (this.peekType(n) & NUMBER) {
        digitFound = true;
        n++;
      } else if (this.peek(n) === "." && this.peek(n + 1) !== ".") {
        if (decimalFound || !digitFound)
          return;
        decimalFound = true;
        n++;
      } else
        break;
    }
    if (digitFound && !isWord(this.peek(n))) {
      const num = new NumberToken(this.input, this.p, this.p + n, this.file);
      this.advance(n);
      return num;
    }
  }
  readLiteral() {
    this.skipBlank();
    const end = this.matchTrie(this.literalTrie);
    if (end === -1)
      return;
    const literal = new LiteralToken(this.input, this.p, end, this.file);
    this.p = end;
    return literal;
  }
  readRange() {
    this.skipBlank();
    const begin = this.p;
    if (this.peek() !== "(")
      return;
    ++this.p;
    const lhs = this.readValueOrThrow();
    this.p += 2;
    const rhs = this.readValueOrThrow();
    ++this.p;
    return new RangeToken(this.input, begin, this.p, lhs, rhs, this.file);
  }
  readValueOrThrow() {
    const value = this.readValue();
    this.assert(value, () => `unexpected token ${this.snapshot()}, value expected`);
    return value;
  }
  readQuoted() {
    this.skipBlank();
    const begin = this.p;
    if (!(this.peekType() & QUOTE))
      return;
    ++this.p;
    let escaped = false;
    while (this.p < this.N) {
      ++this.p;
      if (this.input[this.p - 1] === this.input[begin] && !escaped)
        break;
      if (escaped)
        escaped = false;
      else if (this.input[this.p - 1] === "\\")
        escaped = true;
    }
    return new QuotedToken(this.input, begin, this.p, this.file);
  }
  *readFileNameTemplate(options2) {
    const { outputDelimiterLeft } = options2;
    const htmlStopStrings = [",", " ", outputDelimiterLeft];
    const htmlStopStringSet = new Set(htmlStopStrings);
    while (this.p < this.N && !htmlStopStringSet.has(this.peek())) {
      yield this.match(outputDelimiterLeft) ? this.readOutputToken(options2) : this.readHTMLToken(htmlStopStrings);
    }
  }
  match(word) {
    for (let i = 0;i < word.length; i++) {
      if (word[i] !== this.input[this.p + i])
        return false;
    }
    return true;
  }
  rmatch(pattern) {
    for (let i = 0;i < pattern.length; i++) {
      if (pattern[pattern.length - 1 - i] !== this.input[this.p - 1 - i])
        return false;
    }
    return true;
  }
  peekType(n = 0) {
    return this.p + n >= this.N ? 0 : TYPES[this.input.charCodeAt(this.p + n)];
  }
  peek(n = 0) {
    return this.p + n >= this.N ? "" : this.input[this.p + n];
  }
  skipBlank() {
    while (this.peekType() & BLANK)
      ++this.p;
  }
}

class ParseStream {
  constructor(tokens, parseToken) {
    this.handlers = {};
    this.stopRequested = false;
    this.tokens = tokens;
    this.parseToken = parseToken;
  }
  on(name, cb) {
    this.handlers[name] = cb;
    return this;
  }
  trigger(event, arg) {
    const h = this.handlers[event];
    return h ? (h.call(this, arg), true) : false;
  }
  start() {
    this.trigger("start");
    let token;
    while (!this.stopRequested && (token = this.tokens.shift())) {
      if (this.trigger("token", token))
        continue;
      if (isTagToken(token) && this.trigger(`tag:${token.name}`, token)) {
        continue;
      }
      const template = this.parseToken(token, this.tokens);
      this.trigger("template", template);
    }
    if (!this.stopRequested)
      this.trigger("end");
    return this;
  }
  stop() {
    this.stopRequested = true;
    return this;
  }
}

class TemplateImpl {
  constructor(token) {
    this.token = token;
  }
}

class Tag extends TemplateImpl {
  constructor(token, remainTokens, liquid) {
    super(token);
    this.name = token.name;
    this.liquid = liquid;
    this.tokenizer = token.tokenizer;
  }
}

class Hash {
  constructor(markup, jekyllStyle) {
    this.hash = {};
    const tokenizer = new Tokenizer(markup, {});
    for (const hash of tokenizer.readHashes(jekyllStyle)) {
      this.hash[hash.name.content] = hash.value;
    }
  }
  *render(ctx) {
    const hash = {};
    for (const key of Object.keys(this.hash)) {
      hash[key] = this.hash[key] === undefined ? true : yield evalToken(this.hash[key], ctx);
    }
    return hash;
  }
}

class Filter {
  constructor(name, options2, args, liquid) {
    this.name = name;
    this.handler = isFunction(options2) ? options2 : isFunction(options2 === null || options2 === undefined ? undefined : options2.handler) ? options2.handler : identify;
    this.raw = !isFunction(options2) && !!(options2 === null || options2 === undefined ? undefined : options2.raw);
    this.args = args;
    this.liquid = liquid;
  }
  *render(value, context) {
    const argv = [];
    for (const arg of this.args) {
      if (isKeyValuePair(arg))
        argv.push([arg[0], yield evalToken(arg[1], context)]);
      else
        argv.push(yield evalToken(arg, context));
    }
    return yield this.handler.apply({ context, liquid: this.liquid }, [value, ...argv]);
  }
}

class Value {
  constructor(input, liquid) {
    this.filters = [];
    const token = typeof input === "string" ? new Tokenizer(input, liquid.options.operators).readFilteredValue() : input;
    this.initial = token.initial;
    this.filters = token.filters.map(({ name, args }) => new Filter(name, this.getFilter(liquid, name), args, liquid));
  }
  *value(ctx, lenient) {
    lenient = lenient || ctx.opts.lenientIf && this.filters.length > 0 && this.filters[0].name === "default";
    let val = yield this.initial.evaluate(ctx, lenient);
    for (const filter of this.filters) {
      val = yield filter.render(val, ctx);
    }
    return val;
  }
  getFilter(liquid, name) {
    const impl = liquid.filters[name];
    assert(impl || !liquid.options.strictFilters, () => `undefined filter: ${name}`);
    return impl;
  }
}

class Output extends TemplateImpl {
  constructor(token, liquid) {
    var _a;
    super(token);
    const tokenizer = new Tokenizer(token.input, liquid.options.operators, token.file, token.contentRange);
    this.value = new Value(tokenizer.readFilteredValue(), liquid);
    const filters = this.value.filters;
    const outputEscape = liquid.options.outputEscape;
    if (!((_a = filters[filters.length - 1]) === null || _a === undefined ? undefined : _a.raw) && outputEscape) {
      filters.push(new Filter(toString.call(outputEscape), outputEscape, [], liquid));
    }
  }
  *render(ctx, emitter) {
    const val = yield this.value.value(ctx, false);
    emitter.write(val);
  }
}

class HTML extends TemplateImpl {
  constructor(token) {
    super(token);
    this.str = token.getContent();
  }
  *render(ctx, emitter) {
    emitter.write(this.str);
  }
}
var LookupType;
(function(LookupType2) {
  LookupType2["Partials"] = "partials";
  LookupType2["Layouts"] = "layouts";
  LookupType2["Root"] = "root";
})(LookupType || (LookupType = {}));

class Loader {
  constructor(options2) {
    this.options = options2;
    if (options2.relativeReference) {
      const sep2 = options2.fs.sep;
      assert(sep2, "`fs.sep` is required for relative reference");
      const rRelativePath = new RegExp(["." + sep2, ".." + sep2, "./", "../"].map((prefix) => escapeRegex(prefix)).join("|"));
      this.shouldLoadRelative = (referencedFile) => rRelativePath.test(referencedFile);
    } else {
      this.shouldLoadRelative = (referencedFile) => false;
    }
    this.contains = this.options.fs.contains || (() => true);
  }
  *lookup(file, type, sync, currentFile) {
    const { fs: fs3 } = this.options;
    const dirs = this.options[type];
    for (const filepath of this.candidates(file, dirs, currentFile, type !== LookupType.Root)) {
      if (sync ? fs3.existsSync(filepath) : yield fs3.exists(filepath))
        return filepath;
    }
    throw this.lookupError(file, dirs);
  }
  *candidates(file, dirs, currentFile, enforceRoot) {
    const { fs: fs3, extname: extname2 } = this.options;
    if (this.shouldLoadRelative(file) && currentFile) {
      const referenced = fs3.resolve(this.dirname(currentFile), file, extname2);
      for (const dir of dirs) {
        if (!enforceRoot || this.contains(dir, referenced)) {
          yield referenced;
          break;
        }
      }
    }
    for (const dir of dirs) {
      const referenced = fs3.resolve(dir, file, extname2);
      if (!enforceRoot || this.contains(dir, referenced)) {
        yield referenced;
      }
    }
    if (fs3.fallback !== undefined) {
      const filepath = fs3.fallback(file);
      if (filepath !== undefined)
        yield filepath;
    }
  }
  dirname(path2) {
    const fs3 = this.options.fs;
    assert(fs3.dirname, "`fs.dirname` is required for relative reference");
    return fs3.dirname(path2);
  }
  lookupError(file, roots) {
    const err = new Error("ENOENT");
    err.message = `ENOENT: Failed to lookup "${file}" in "${roots}"`;
    err.code = "ENOENT";
    return err;
  }
}

class Parser {
  constructor(liquid) {
    this.liquid = liquid;
    this.cache = this.liquid.options.cache;
    this.fs = this.liquid.options.fs;
    this.parseFile = this.cache ? this._parseFileCached : this._parseFile;
    this.loader = new Loader(this.liquid.options);
    this.parseLimit = new Limiter("parse length", liquid.options.parseLimit);
  }
  parse(html2, filepath) {
    this.parseLimit.use(html2.length);
    const tokenizer = new Tokenizer(html2, this.liquid.options.operators, filepath);
    const tokens = tokenizer.readTopLevelTokens(this.liquid.options);
    return this.parseTokens(tokens);
  }
  parseTokens(tokens) {
    let token;
    const templates = [];
    const errors3 = [];
    while (token = tokens.shift()) {
      try {
        templates.push(this.parseToken(token, tokens));
      } catch (err) {
        if (this.liquid.options.catchAllErrors)
          errors3.push(err);
        else
          throw err;
      }
    }
    if (errors3.length)
      throw new LiquidErrors(errors3);
    return templates;
  }
  parseToken(token, remainTokens) {
    try {
      if (isTagToken(token)) {
        const TagClass = this.liquid.tags[token.name];
        assert(TagClass, `tag "${token.name}" not found`);
        return new TagClass(token, remainTokens, this.liquid, this);
      }
      if (isOutputToken(token)) {
        return new Output(token, this.liquid);
      }
      return new HTML(token);
    } catch (e) {
      if (LiquidError.is(e))
        throw e;
      throw new ParseError(e, token);
    }
  }
  parseStream(tokens) {
    return new ParseStream(tokens, (token, tokens2) => this.parseToken(token, tokens2));
  }
  *_parseFileCached(file, sync, type = LookupType.Root, currentFile) {
    const cache = this.cache;
    const key = this.loader.shouldLoadRelative(file) ? currentFile + "," + file : type + ":" + file;
    const tpls = yield cache.read(key);
    if (tpls)
      return tpls;
    const task = this._parseFile(file, sync, type, currentFile);
    const taskOrTpl = sync ? yield task : toPromise(task);
    cache.write(key, taskOrTpl);
    try {
      return yield taskOrTpl;
    } catch (err) {
      cache.remove(key);
      throw err;
    }
  }
  *_parseFile(file, sync, type = LookupType.Root, currentFile) {
    const filepath = yield this.loader.lookup(file, type, sync, currentFile);
    return this.parse(sync ? this.fs.readFileSync(filepath) : yield this.fs.readFile(filepath), filepath);
  }
}
var TokenKind;
(function(TokenKind2) {
  TokenKind2[TokenKind2["Number"] = 1] = "Number";
  TokenKind2[TokenKind2["Literal"] = 2] = "Literal";
  TokenKind2[TokenKind2["Tag"] = 4] = "Tag";
  TokenKind2[TokenKind2["Output"] = 8] = "Output";
  TokenKind2[TokenKind2["HTML"] = 16] = "HTML";
  TokenKind2[TokenKind2["Filter"] = 32] = "Filter";
  TokenKind2[TokenKind2["Hash"] = 64] = "Hash";
  TokenKind2[TokenKind2["PropertyAccess"] = 128] = "PropertyAccess";
  TokenKind2[TokenKind2["Word"] = 256] = "Word";
  TokenKind2[TokenKind2["Range"] = 512] = "Range";
  TokenKind2[TokenKind2["Quoted"] = 1024] = "Quoted";
  TokenKind2[TokenKind2["Operator"] = 2048] = "Operator";
  TokenKind2[TokenKind2["FilteredValue"] = 4096] = "FilteredValue";
  TokenKind2[TokenKind2["Delimited"] = 12] = "Delimited";
})(TokenKind || (TokenKind = {}));
class Context {
  constructor(env = {}, opts = defaultOptions, renderOptions = {}, { memoryLimit, renderLimit } = {}) {
    var _a, _b, _c, _d, _e;
    this.scopes = [{}];
    this.registers = {};
    this.sync = !!renderOptions.sync;
    this.opts = opts;
    this.globals = (_a = renderOptions.globals) !== null && _a !== undefined ? _a : opts.globals;
    this.environments = isObject(env) ? env : Object(env);
    this.strictVariables = (_b = renderOptions.strictVariables) !== null && _b !== undefined ? _b : this.opts.strictVariables;
    this.ownPropertyOnly = (_c = renderOptions.ownPropertyOnly) !== null && _c !== undefined ? _c : opts.ownPropertyOnly;
    this.memoryLimit = memoryLimit !== null && memoryLimit !== undefined ? memoryLimit : new Limiter("memory alloc", (_d = renderOptions.memoryLimit) !== null && _d !== undefined ? _d : opts.memoryLimit);
    this.renderLimit = renderLimit !== null && renderLimit !== undefined ? renderLimit : new Limiter("template render", performance.now() + ((_e = renderOptions.templateLimit) !== null && _e !== undefined ? _e : opts.renderLimit));
  }
  getRegister(key) {
    return this.registers[key] = this.registers[key] || {};
  }
  setRegister(key, value) {
    return this.registers[key] = value;
  }
  saveRegister(...keys) {
    return keys.map((key) => [key, this.getRegister(key)]);
  }
  restoreRegister(keyValues) {
    return keyValues.forEach(([key, value]) => this.setRegister(key, value));
  }
  getAll() {
    return [this.globals, this.environments, ...this.scopes].reduce((ctx, val) => __assign(ctx, val), {});
  }
  get(paths) {
    return this.getSync(paths);
  }
  getSync(paths) {
    return toValueSync(this._get(paths));
  }
  *_get(paths) {
    const scope = this.findScope(paths[0]);
    return yield this._getFromScope(scope, paths);
  }
  getFromScope(scope, paths) {
    return toValueSync(this._getFromScope(scope, paths));
  }
  *_getFromScope(scope, paths, strictVariables = this.strictVariables) {
    if (isString(paths))
      paths = paths.split(".");
    for (let i = 0;i < paths.length; i++) {
      scope = yield readProperty(scope, paths[i], this.ownPropertyOnly);
      if (strictVariables && isUndefined(scope)) {
        throw new InternalUndefinedVariableError(paths.slice(0, i + 1).join("."));
      }
    }
    return scope;
  }
  push(ctx) {
    return this.scopes.push(ctx);
  }
  pop() {
    return this.scopes.pop();
  }
  bottom() {
    return this.scopes[0];
  }
  spawn(scope = {}) {
    return new Context(scope, this.opts, {
      sync: this.sync,
      globals: this.globals,
      strictVariables: this.strictVariables
    }, {
      renderLimit: this.renderLimit,
      memoryLimit: this.memoryLimit
    });
  }
  findScope(key) {
    for (let i = this.scopes.length - 1;i >= 0; i--) {
      const candidate = this.scopes[i];
      if (key in candidate)
        return candidate;
    }
    if (key in this.environments)
      return this.environments;
    return this.globals;
  }
}
var BlockMode;
(function(BlockMode2) {
  BlockMode2[BlockMode2["OUTPUT"] = 0] = "OUTPUT";
  BlockMode2[BlockMode2["STORE"] = 1] = "STORE";
})(BlockMode || (BlockMode = {}));
var abs = argumentsToValue(Math.abs);
var at_least = argumentsToValue(Math.max);
var at_most = argumentsToValue(Math.min);
var ceil = argumentsToValue(Math.ceil);
var divided_by = argumentsToValue((dividend, divisor, integerArithmetic = false) => integerArithmetic ? Math.floor(dividend / divisor) : dividend / divisor);
var floor = argumentsToValue(Math.floor);
var minus = argumentsToValue((v, arg) => v - arg);
var modulo = argumentsToValue((v, arg) => v % arg);
var times = argumentsToValue((v, arg) => v * arg);
var mathFilters = Object.freeze({
  __proto__: null,
  abs,
  at_least,
  at_most,
  ceil,
  divided_by,
  floor,
  minus,
  modulo,
  times,
  round,
  plus
});
var url_decode = (x) => decodeURIComponent(stringify2(x)).replace(/\+/g, " ");
var url_encode = (x) => encodeURIComponent(stringify2(x)).replace(/%20/g, "+");
var cgi_escape = (x) => encodeURIComponent(stringify2(x)).replace(/%20/g, "+").replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());
var uri_escape = (x) => encodeURI(stringify2(x)).replace(/%5B/g, "[").replace(/%5D/g, "]");
var rSlugifyDefault = /[^\p{M}\p{L}\p{Nd}]+/ug;
var rSlugifyReplacers = {
  raw: /\s+/g,
  default: rSlugifyDefault,
  pretty: /[^\p{M}\p{L}\p{Nd}._~!$&'()+,;=@]+/ug,
  ascii: /[^A-Za-z0-9]+/g,
  latin: rSlugifyDefault,
  none: null
};
var urlFilters = Object.freeze({
  __proto__: null,
  url_decode,
  url_encode,
  cgi_escape,
  uri_escape,
  slugify
});
var join = argumentsToValue(function(v, arg) {
  const array = toArray(v);
  const sep2 = arg === undefined ? " " : arg;
  const complexity = array.length * (1 + sep2.length);
  this.context.memoryLimit.use(complexity);
  return array.join(sep2);
});
var last$1 = argumentsToValue((v) => isArray(v) ? last(v) : "");
var first = argumentsToValue((v) => isArray(v) ? v[0] : "");
var reverse = argumentsToValue(function(v) {
  const array = toArray(v);
  this.context.memoryLimit.use(array.length);
  return [...array].reverse();
});
var size = (v) => v && v.length || 0;
var arrayFilters = Object.freeze({
  __proto__: null,
  join,
  last: last$1,
  first,
  reverse,
  sort,
  sort_natural,
  size,
  map,
  sum,
  compact,
  concat,
  push,
  unshift,
  pop,
  shift,
  slice,
  where,
  where_exp,
  group_by,
  group_by_exp,
  find,
  find_exp,
  uniq,
  sample
});
var dateFilters = Object.freeze({
  __proto__: null,
  date,
  date_to_xmlschema,
  date_to_rfc822,
  date_to_string,
  date_to_long_string
});
var rCJKWord = /[\u4E00-\u9FFF\uF900-\uFAFF\u3400-\u4DBF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF]/gu;
var rNonCJKWord = /[^\u4E00-\u9FFF\uF900-\uFAFF\u3400-\u4DBF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF\s]+/gu;
var stringFilters = Object.freeze({
  __proto__: null,
  append,
  prepend,
  lstrip,
  downcase,
  upcase,
  remove,
  remove_first,
  remove_last,
  rstrip,
  split,
  strip,
  strip_newlines,
  capitalize,
  replace,
  replace_first,
  replace_last,
  truncate,
  truncatewords,
  normalize_whitespace,
  number_of_words,
  array_to_sentence_string
});
var filters = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, htmlFilters), mathFilters), urlFilters), arrayFilters), dateFilters), stringFilters), misc);

class AssignTag extends Tag {
  constructor(token, remainTokens, liquid) {
    super(token, remainTokens, liquid);
    this.key = this.tokenizer.readIdentifier().content;
    this.tokenizer.assert(this.key, "expected variable name");
    this.tokenizer.skipBlank();
    this.tokenizer.assert(this.tokenizer.peek() === "=", 'expected "="');
    this.tokenizer.advance();
    this.value = new Value(this.tokenizer.readFilteredValue(), this.liquid);
  }
  *render(ctx) {
    ctx.bottom()[this.key] = yield this.value.value(ctx, this.liquid.options.lenientIf);
  }
}
var MODIFIERS = ["offset", "limit", "reversed"];

class ForTag extends Tag {
  constructor(token, remainTokens, liquid, parser2) {
    super(token, remainTokens, liquid);
    const variable = this.tokenizer.readIdentifier();
    const inStr = this.tokenizer.readIdentifier();
    const collection = this.tokenizer.readValue();
    if (!variable.size() || inStr.content !== "in" || !collection) {
      throw new Error(`illegal tag: ${token.getText()}`);
    }
    this.variable = variable.content;
    this.collection = collection;
    this.hash = new Hash(this.tokenizer.remaining());
    this.templates = [];
    this.elseTemplates = [];
    let p;
    const stream = parser2.parseStream(remainTokens).on("start", () => p = this.templates).on("tag:else", (tag2) => {
      assertEmpty(tag2.args);
      p = this.elseTemplates;
    }).on("tag:endfor", (tag2) => {
      assertEmpty(tag2.args);
      stream.stop();
    }).on("template", (tpl) => p.push(tpl)).on("end", () => {
      throw new Error(`tag ${token.getText()} not closed`);
    });
    stream.start();
  }
  *render(ctx, emitter) {
    const r = this.liquid.renderer;
    let collection = toEnumerable(yield evalToken(this.collection, ctx));
    if (!collection.length) {
      yield r.renderTemplates(this.elseTemplates, ctx, emitter);
      return;
    }
    const continueKey = "continue-" + this.variable + "-" + this.collection.getText();
    ctx.push({ continue: ctx.getRegister(continueKey) });
    const hash = yield this.hash.render(ctx);
    ctx.pop();
    const modifiers = this.liquid.options.orderedFilterParameters ? Object.keys(hash).filter((x) => MODIFIERS.includes(x)) : MODIFIERS.filter((x) => hash[x] !== undefined);
    collection = modifiers.reduce((collection2, modifier) => {
      if (modifier === "offset")
        return offset(collection2, hash["offset"]);
      if (modifier === "limit")
        return limit(collection2, hash["limit"]);
      return reversed(collection2);
    }, collection);
    ctx.setRegister(continueKey, (hash["offset"] || 0) + collection.length);
    const scope = { forloop: new ForloopDrop(collection.length, this.collection.getText(), this.variable) };
    ctx.push(scope);
    for (const item of collection) {
      scope[this.variable] = item;
      yield r.renderTemplates(this.templates, ctx, emitter);
      if (emitter["break"]) {
        emitter["break"] = false;
        break;
      }
      emitter["continue"] = false;
      scope.forloop.next();
    }
    ctx.pop();
  }
}

class CaptureTag extends Tag {
  constructor(tagToken, remainTokens, liquid, parser2) {
    super(tagToken, remainTokens, liquid);
    this.templates = [];
    this.variable = this.readVariableName();
    while (remainTokens.length) {
      const token = remainTokens.shift();
      if (isTagToken(token) && token.name === "endcapture")
        return;
      this.templates.push(parser2.parseToken(token, remainTokens));
    }
    throw new Error(`tag ${tagToken.getText()} not closed`);
  }
  *render(ctx) {
    const r = this.liquid.renderer;
    const html2 = yield r.renderTemplates(this.templates, ctx);
    ctx.bottom()[this.variable] = html2;
  }
  readVariableName() {
    const word = this.tokenizer.readIdentifier().content;
    if (word)
      return word;
    const quoted = this.tokenizer.readQuoted();
    if (quoted)
      return evalQuotedToken(quoted);
    throw this.tokenizer.error("invalid capture name");
  }
}

class CaseTag extends Tag {
  constructor(tagToken, remainTokens, liquid, parser2) {
    super(tagToken, remainTokens, liquid);
    this.branches = [];
    this.elseTemplates = [];
    this.value = new Value(this.tokenizer.readFilteredValue(), this.liquid);
    this.elseTemplates = [];
    let p = [];
    let elseCount = 0;
    const stream = parser2.parseStream(remainTokens).on("tag:when", (token) => {
      if (elseCount > 0) {
        return;
      }
      p = [];
      const values = [];
      while (!token.tokenizer.end()) {
        values.push(token.tokenizer.readValueOrThrow());
        token.tokenizer.skipBlank();
        if (token.tokenizer.peek() === ",") {
          token.tokenizer.readTo(",");
        } else {
          token.tokenizer.readTo("or");
        }
      }
      this.branches.push({
        values,
        templates: p
      });
    }).on("tag:else", () => {
      elseCount++;
      p = this.elseTemplates;
    }).on("tag:endcase", () => stream.stop()).on("template", (tpl) => {
      if (p !== this.elseTemplates || elseCount === 1) {
        p.push(tpl);
      }
    }).on("end", () => {
      throw new Error(`tag ${tagToken.getText()} not closed`);
    });
    stream.start();
  }
  *render(ctx, emitter) {
    const r = this.liquid.renderer;
    const target = toValue(yield this.value.value(ctx, ctx.opts.lenientIf));
    let branchHit = false;
    for (const branch of this.branches) {
      for (const valueToken of branch.values) {
        const value = yield evalToken(valueToken, ctx, ctx.opts.lenientIf);
        if (equals(target, value)) {
          yield r.renderTemplates(branch.templates, ctx, emitter);
          branchHit = true;
          break;
        }
      }
    }
    if (!branchHit) {
      yield r.renderTemplates(this.elseTemplates, ctx, emitter);
    }
  }
}

class CommentTag extends Tag {
  constructor(tagToken, remainTokens, liquid) {
    super(tagToken, remainTokens, liquid);
    while (remainTokens.length) {
      const token = remainTokens.shift();
      if (isTagToken(token) && token.name === "endcomment")
        return;
    }
    throw new Error(`tag ${tagToken.getText()} not closed`);
  }
  render() {
  }
}

class RenderTag extends Tag {
  constructor(token, remainTokens, liquid, parser2) {
    super(token, remainTokens, liquid);
    const tokenizer = this.tokenizer;
    this.file = parseFilePath(tokenizer, this.liquid, parser2);
    this.currentFile = token.file;
    while (!tokenizer.end()) {
      tokenizer.skipBlank();
      const begin = tokenizer.p;
      const keyword = tokenizer.readIdentifier();
      if (keyword.content === "with" || keyword.content === "for") {
        tokenizer.skipBlank();
        if (tokenizer.peek() !== ":") {
          const value = tokenizer.readValue();
          if (value) {
            const beforeAs = tokenizer.p;
            const asStr = tokenizer.readIdentifier();
            let alias3;
            if (asStr.content === "as")
              alias3 = tokenizer.readIdentifier();
            else
              tokenizer.p = beforeAs;
            this[keyword.content] = { value, alias: alias3 && alias3.content };
            tokenizer.skipBlank();
            if (tokenizer.peek() === ",")
              tokenizer.advance();
            continue;
          }
        }
      }
      tokenizer.p = begin;
      break;
    }
    this.hash = new Hash(tokenizer.remaining());
  }
  *render(ctx, emitter) {
    const { liquid, hash } = this;
    const filepath = yield renderFilePath(this["file"], ctx, liquid);
    assert(filepath, () => `illegal file path "${filepath}"`);
    const childCtx = ctx.spawn();
    const scope = childCtx.bottom();
    __assign(scope, yield hash.render(ctx));
    if (this["with"]) {
      const { value, alias: alias3 } = this["with"];
      scope[alias3 || filepath] = yield evalToken(value, ctx);
    }
    if (this["for"]) {
      const { value, alias: alias3 } = this["for"];
      const collection = toEnumerable(yield evalToken(value, ctx));
      scope["forloop"] = new ForloopDrop(collection.length, value.getText(), alias3);
      for (const item of collection) {
        scope[alias3] = item;
        const templates = yield liquid._parsePartialFile(filepath, childCtx.sync, this["currentFile"]);
        yield liquid.renderer.renderTemplates(templates, childCtx, emitter);
        scope["forloop"].next();
      }
    } else {
      const templates = yield liquid._parsePartialFile(filepath, childCtx.sync, this["currentFile"]);
      yield liquid.renderer.renderTemplates(templates, childCtx, emitter);
    }
  }
}

class IncludeTag extends Tag {
  constructor(token, remainTokens, liquid, parser2) {
    super(token, remainTokens, liquid);
    const { tokenizer } = token;
    this["file"] = parseFilePath(tokenizer, this.liquid, parser2);
    this["currentFile"] = token.file;
    const begin = tokenizer.p;
    const withStr = tokenizer.readIdentifier();
    if (withStr.content === "with") {
      tokenizer.skipBlank();
      if (tokenizer.peek() !== ":") {
        this.withVar = tokenizer.readValue();
      } else
        tokenizer.p = begin;
    } else
      tokenizer.p = begin;
    this.hash = new Hash(tokenizer.remaining(), this.liquid.options.jekyllInclude);
  }
  *render(ctx, emitter) {
    const { liquid, hash, withVar } = this;
    const { renderer } = liquid;
    const filepath = yield renderFilePath(this["file"], ctx, liquid);
    assert(filepath, () => `illegal file path "${filepath}"`);
    const saved = ctx.saveRegister("blocks", "blockMode");
    ctx.setRegister("blocks", {});
    ctx.setRegister("blockMode", BlockMode.OUTPUT);
    const scope = yield hash.render(ctx);
    if (withVar)
      scope[filepath] = yield evalToken(withVar, ctx);
    const templates = yield liquid._parsePartialFile(filepath, ctx.sync, this["currentFile"]);
    ctx.push(ctx.opts.jekyllInclude ? { include: scope } : scope);
    yield renderer.renderTemplates(templates, ctx, emitter);
    ctx.pop();
    ctx.restoreRegister(saved);
  }
}

class DecrementTag extends Tag {
  constructor(token, remainTokens, liquid) {
    super(token, remainTokens, liquid);
    this.variable = this.tokenizer.readIdentifier().content;
  }
  render(context, emitter) {
    const scope = context.environments;
    if (!isNumber(scope[this.variable])) {
      scope[this.variable] = 0;
    }
    emitter.write(stringify2(--scope[this.variable]));
  }
}

class CycleTag extends Tag {
  constructor(token, remainTokens, liquid) {
    super(token, remainTokens, liquid);
    this.candidates = [];
    const group = this.tokenizer.readValue();
    this.tokenizer.skipBlank();
    if (group) {
      if (this.tokenizer.peek() === ":") {
        this.group = group;
        this.tokenizer.advance();
      } else
        this.candidates.push(group);
    }
    while (!this.tokenizer.end()) {
      const value = this.tokenizer.readValue();
      if (value)
        this.candidates.push(value);
      this.tokenizer.readTo(",");
    }
    this.tokenizer.assert(this.candidates.length, () => `empty candidates: "${token.getText()}"`);
  }
  *render(ctx, emitter) {
    const group = yield evalToken(this.group, ctx);
    const fingerprint = `cycle:${group}:` + this.candidates.join(",");
    const groups = ctx.getRegister("cycle");
    let idx = groups[fingerprint];
    if (idx === undefined) {
      idx = groups[fingerprint] = 0;
    }
    const candidate = this.candidates[idx];
    idx = (idx + 1) % this.candidates.length;
    groups[fingerprint] = idx;
    return yield evalToken(candidate, ctx);
  }
}

class IfTag extends Tag {
  constructor(tagToken, remainTokens, liquid, parser2) {
    super(tagToken, remainTokens, liquid);
    this.branches = [];
    let p = [];
    parser2.parseStream(remainTokens).on("start", () => this.branches.push({
      value: new Value(tagToken.args, this.liquid),
      templates: p = []
    })).on("tag:elsif", (token) => {
      assert(!this.elseTemplates, "unexpected elsif after else");
      this.branches.push({
        value: new Value(token.args, this.liquid),
        templates: p = []
      });
    }).on("tag:else", (tag2) => {
      assertEmpty(tag2.args);
      assert(!this.elseTemplates, "duplicated else");
      p = this.elseTemplates = [];
    }).on("tag:endif", function(tag2) {
      assertEmpty(tag2.args);
      this.stop();
    }).on("template", (tpl) => p.push(tpl)).on("end", () => {
      throw new Error(`tag ${tagToken.getText()} not closed`);
    }).start();
  }
  *render(ctx, emitter) {
    const r = this.liquid.renderer;
    for (const { value, templates } of this.branches) {
      const v = yield value.value(ctx, ctx.opts.lenientIf);
      if (isTruthy(v, ctx)) {
        yield r.renderTemplates(templates, ctx, emitter);
        return;
      }
    }
    yield r.renderTemplates(this.elseTemplates || [], ctx, emitter);
  }
}

class IncrementTag extends Tag {
  constructor(token, remainTokens, liquid) {
    super(token, remainTokens, liquid);
    this.variable = this.tokenizer.readIdentifier().content;
  }
  render(context, emitter) {
    const scope = context.environments;
    if (!isNumber(scope[this.variable])) {
      scope[this.variable] = 0;
    }
    const val = scope[this.variable];
    scope[this.variable]++;
    emitter.write(stringify2(val));
  }
}

class LayoutTag extends Tag {
  constructor(token, remainTokens, liquid, parser2) {
    super(token, remainTokens, liquid);
    this.file = parseFilePath(this.tokenizer, this.liquid, parser2);
    this["currentFile"] = token.file;
    this.args = new Hash(this.tokenizer.remaining());
    this.templates = parser2.parseTokens(remainTokens);
  }
  *render(ctx, emitter) {
    const { liquid, args, file } = this;
    const { renderer } = liquid;
    if (file === undefined) {
      ctx.setRegister("blockMode", BlockMode.OUTPUT);
      yield renderer.renderTemplates(this.templates, ctx, emitter);
      return;
    }
    const filepath = yield renderFilePath(this.file, ctx, liquid);
    assert(filepath, () => `illegal file path "${filepath}"`);
    const templates = yield liquid._parseLayoutFile(filepath, ctx.sync, this["currentFile"]);
    ctx.setRegister("blockMode", BlockMode.STORE);
    const html2 = yield renderer.renderTemplates(this.templates, ctx);
    const blocks = ctx.getRegister("blocks");
    if (blocks[""] === undefined)
      blocks[""] = (parent, emitter2) => emitter2.write(html2);
    ctx.setRegister("blockMode", BlockMode.OUTPUT);
    ctx.push(yield args.render(ctx));
    yield renderer.renderTemplates(templates, ctx, emitter);
    ctx.pop();
  }
}

class BlockTag extends Tag {
  constructor(token, remainTokens, liquid, parser2) {
    super(token, remainTokens, liquid);
    this.templates = [];
    const match = /\w+/.exec(token.args);
    this.block = match ? match[0] : "";
    while (remainTokens.length) {
      const token2 = remainTokens.shift();
      if (isTagToken(token2) && token2.name === "endblock")
        return;
      const template = parser2.parseToken(token2, remainTokens);
      this.templates.push(template);
    }
    throw new Error(`tag ${token.getText()} not closed`);
  }
  *render(ctx, emitter) {
    const blockRender = this.getBlockRender(ctx);
    if (ctx.getRegister("blockMode") === BlockMode.STORE) {
      ctx.getRegister("blocks")[this.block] = blockRender;
    } else {
      yield blockRender(new BlockDrop, emitter);
    }
  }
  getBlockRender(ctx) {
    const { liquid, templates } = this;
    const renderChild = ctx.getRegister("blocks")[this.block];
    const renderCurrent = function* (superBlock, emitter) {
      ctx.push({ block: superBlock });
      yield liquid.renderer.renderTemplates(templates, ctx, emitter);
      ctx.pop();
    };
    return renderChild ? (superBlock, emitter) => renderChild(new BlockDrop(() => renderCurrent(superBlock, emitter)), emitter) : renderCurrent;
  }
}

class RawTag extends Tag {
  constructor(tagToken, remainTokens, liquid) {
    super(tagToken, remainTokens, liquid);
    this.tokens = [];
    while (remainTokens.length) {
      const token = remainTokens.shift();
      if (isTagToken(token) && token.name === "endraw")
        return;
      this.tokens.push(token);
    }
    throw new Error(`tag ${tagToken.getText()} not closed`);
  }
  render() {
    return this.tokens.map((token) => token.getText()).join("");
  }
}

class TablerowloopDrop extends ForloopDrop {
  constructor(length, cols, collection, variable) {
    super(length, collection, variable);
    this.length = length;
    this.cols = cols;
  }
  row() {
    return Math.floor(this.i / this.cols) + 1;
  }
  col0() {
    return this.i % this.cols;
  }
  col() {
    return this.col0() + 1;
  }
  col_first() {
    return this.col0() === 0;
  }
  col_last() {
    return this.col() === this.cols;
  }
}

class TablerowTag extends Tag {
  constructor(tagToken, remainTokens, liquid, parser2) {
    super(tagToken, remainTokens, liquid);
    const variable = this.tokenizer.readIdentifier();
    this.tokenizer.skipBlank();
    const predicate = this.tokenizer.readIdentifier();
    const collectionToken = this.tokenizer.readValue();
    if (predicate.content !== "in" || !collectionToken) {
      throw new Error(`illegal tag: ${tagToken.getText()}`);
    }
    this.variable = variable.content;
    this.collection = collectionToken;
    this.args = new Hash(this.tokenizer.remaining());
    this.templates = [];
    let p;
    const stream = parser2.parseStream(remainTokens).on("start", () => p = this.templates).on("tag:endtablerow", () => stream.stop()).on("template", (tpl) => p.push(tpl)).on("end", () => {
      throw new Error(`tag ${tagToken.getText()} not closed`);
    });
    stream.start();
  }
  *render(ctx, emitter) {
    let collection = toEnumerable(yield evalToken(this.collection, ctx));
    const args = yield this.args.render(ctx);
    const offset2 = args.offset || 0;
    const limit2 = args.limit === undefined ? collection.length : args.limit;
    collection = collection.slice(offset2, offset2 + limit2);
    const cols = args.cols || collection.length;
    const r = this.liquid.renderer;
    const tablerowloop = new TablerowloopDrop(collection.length, cols, this.collection.getText(), this.variable);
    const scope = { tablerowloop };
    ctx.push(scope);
    for (let idx = 0;idx < collection.length; idx++, tablerowloop.next()) {
      scope[this.variable] = collection[idx];
      if (tablerowloop.col0() === 0) {
        if (tablerowloop.row() !== 1)
          emitter.write("</tr>");
        emitter.write(`<tr class="row${tablerowloop.row()}">`);
      }
      emitter.write(`<td class="col${tablerowloop.col()}">`);
      yield r.renderTemplates(this.templates, ctx, emitter);
      emitter.write("</td>");
    }
    if (collection.length)
      emitter.write("</tr>");
    ctx.pop();
  }
}

class UnlessTag extends Tag {
  constructor(tagToken, remainTokens, liquid, parser2) {
    super(tagToken, remainTokens, liquid);
    this.branches = [];
    this.elseTemplates = [];
    let p = [];
    let elseCount = 0;
    parser2.parseStream(remainTokens).on("start", () => this.branches.push({
      value: new Value(tagToken.args, this.liquid),
      test: isFalsy,
      templates: p = []
    })).on("tag:elsif", (token) => {
      if (elseCount > 0) {
        p = [];
        return;
      }
      this.branches.push({
        value: new Value(token.args, this.liquid),
        test: isTruthy,
        templates: p = []
      });
    }).on("tag:else", () => {
      elseCount++;
      p = this.elseTemplates;
    }).on("tag:endunless", function() {
      this.stop();
    }).on("template", (tpl) => {
      if (p !== this.elseTemplates || elseCount === 1) {
        p.push(tpl);
      }
    }).on("end", () => {
      throw new Error(`tag ${tagToken.getText()} not closed`);
    }).start();
  }
  *render(ctx, emitter) {
    const r = this.liquid.renderer;
    for (const { value, test, templates } of this.branches) {
      const v = yield value.value(ctx, ctx.opts.lenientIf);
      if (test(v, ctx)) {
        yield r.renderTemplates(templates, ctx, emitter);
        return;
      }
    }
    yield r.renderTemplates(this.elseTemplates, ctx, emitter);
  }
}

class BreakTag extends Tag {
  render(ctx, emitter) {
    emitter["break"] = true;
  }
}

class ContinueTag extends Tag {
  render(ctx, emitter) {
    emitter["continue"] = true;
  }
}

class EchoTag extends Tag {
  constructor(token, remainTokens, liquid) {
    super(token, remainTokens, liquid);
    this.tokenizer.skipBlank();
    if (!this.tokenizer.end()) {
      this.value = new Value(this.tokenizer.readFilteredValue(), this.liquid);
    }
  }
  *render(ctx, emitter) {
    if (!this.value)
      return;
    const val = yield this.value.value(ctx, false);
    emitter.write(val);
  }
}

class LiquidTag extends Tag {
  constructor(token, remainTokens, liquid, parser2) {
    super(token, remainTokens, liquid);
    const tokens = this.tokenizer.readLiquidTagTokens(this.liquid.options);
    this.templates = parser2.parseTokens(tokens);
  }
  *render(ctx, emitter) {
    yield this.liquid.renderer.renderTemplates(this.templates, ctx, emitter);
  }
}

class InlineCommentTag extends Tag {
  constructor(tagToken, remainTokens, liquid) {
    super(tagToken, remainTokens, liquid);
    if (tagToken.args.search(/\n\s*[^#\s]/g) !== -1) {
      throw new Error("every line of an inline comment must start with a \'#\' character");
    }
  }
  render() {
  }
}
var tags = {
  assign: AssignTag,
  for: ForTag,
  capture: CaptureTag,
  case: CaseTag,
  comment: CommentTag,
  include: IncludeTag,
  render: RenderTag,
  decrement: DecrementTag,
  increment: IncrementTag,
  cycle: CycleTag,
  if: IfTag,
  layout: LayoutTag,
  block: BlockTag,
  raw: RawTag,
  tablerow: TablerowTag,
  unless: UnlessTag,
  break: BreakTag,
  continue: ContinueTag,
  echo: EchoTag,
  liquid: LiquidTag,
  "#": InlineCommentTag
};

class Liquid {
  constructor(opts = {}) {
    this.renderer = new Render;
    this.filters = {};
    this.tags = {};
    this.options = normalize(opts);
    this.parser = new Parser(this);
    forOwn(tags, (conf, name) => this.registerTag(name, conf));
    forOwn(filters, (handler, name) => this.registerFilter(name, handler));
  }
  parse(html2, filepath) {
    const parser2 = new Parser(this);
    return parser2.parse(html2, filepath);
  }
  _render(tpl, scope, renderOptions) {
    const ctx = scope instanceof Context ? scope : new Context(scope, this.options, renderOptions);
    return this.renderer.renderTemplates(tpl, ctx);
  }
  render(tpl, scope, renderOptions) {
    return __awaiter(this, undefined, undefined, function* () {
      return toPromise(this._render(tpl, scope, Object.assign(Object.assign({}, renderOptions), { sync: false })));
    });
  }
  renderSync(tpl, scope, renderOptions) {
    return toValueSync(this._render(tpl, scope, Object.assign(Object.assign({}, renderOptions), { sync: true })));
  }
  renderToNodeStream(tpl, scope, renderOptions = {}) {
    const ctx = new Context(scope, this.options, renderOptions);
    return this.renderer.renderTemplatesToNodeStream(tpl, ctx);
  }
  _parseAndRender(html2, scope, renderOptions) {
    const tpl = this.parse(html2);
    return this._render(tpl, scope, renderOptions);
  }
  parseAndRender(html2, scope, renderOptions) {
    return __awaiter(this, undefined, undefined, function* () {
      return toPromise(this._parseAndRender(html2, scope, Object.assign(Object.assign({}, renderOptions), { sync: false })));
    });
  }
  parseAndRenderSync(html2, scope, renderOptions) {
    return toValueSync(this._parseAndRender(html2, scope, Object.assign(Object.assign({}, renderOptions), { sync: true })));
  }
  _parsePartialFile(file, sync, currentFile) {
    return new Parser(this).parseFile(file, sync, LookupType.Partials, currentFile);
  }
  _parseLayoutFile(file, sync, currentFile) {
    return new Parser(this).parseFile(file, sync, LookupType.Layouts, currentFile);
  }
  _parseFile(file, sync, lookupType, currentFile) {
    return new Parser(this).parseFile(file, sync, lookupType, currentFile);
  }
  parseFile(file, lookupType) {
    return __awaiter(this, undefined, undefined, function* () {
      return toPromise(new Parser(this).parseFile(file, false, lookupType));
    });
  }
  parseFileSync(file, lookupType) {
    return toValueSync(new Parser(this).parseFile(file, true, lookupType));
  }
  *_renderFile(file, ctx, renderFileOptions) {
    const templates = yield this._parseFile(file, renderFileOptions.sync, renderFileOptions.lookupType);
    return yield this._render(templates, ctx, renderFileOptions);
  }
  renderFile(file, ctx, renderFileOptions) {
    return __awaiter(this, undefined, undefined, function* () {
      return toPromise(this._renderFile(file, ctx, Object.assign(Object.assign({}, renderFileOptions), { sync: false })));
    });
  }
  renderFileSync(file, ctx, renderFileOptions) {
    return toValueSync(this._renderFile(file, ctx, Object.assign(Object.assign({}, renderFileOptions), { sync: true })));
  }
  renderFileToNodeStream(file, scope, renderOptions) {
    return __awaiter(this, undefined, undefined, function* () {
      const templates = yield this.parseFile(file);
      return this.renderToNodeStream(templates, scope, renderOptions);
    });
  }
  _evalValue(str, scope) {
    const value = new Value(str, this);
    const ctx = scope instanceof Context ? scope : new Context(scope, this.options);
    return value.value(ctx);
  }
  evalValue(str, scope) {
    return __awaiter(this, undefined, undefined, function* () {
      return toPromise(this._evalValue(str, scope));
    });
  }
  evalValueSync(str, scope) {
    return toValueSync(this._evalValue(str, scope));
  }
  registerFilter(name, filter) {
    this.filters[name] = filter;
  }
  registerTag(name, tag2) {
    this.tags[name] = isFunction(tag2) ? tag2 : createTagClass(tag2);
  }
  plugin(plugin) {
    return plugin.call(this, Liquid);
  }
  express() {
    const self = this;
    let firstCall = true;
    return function(filePath, ctx, callback) {
      if (firstCall) {
        firstCall = false;
        const dirs = normalizeDirectoryList(this.root);
        self.options.root.unshift(...dirs);
        self.options.layouts.unshift(...dirs);
        self.options.partials.unshift(...dirs);
      }
      self.renderFile(filePath, ctx).then((html2) => callback(null, html2), callback);
    };
  }
}

// src/sender.ts
async function getTransporter(smtpServerId) {
  if (transporters[smtpServerId])
    return transporters[smtpServerId];
  const smtpServer = await database_default.query.smtpServers.findFirst({
    where: sql`id = ${smtpServerId}`
  });
  if (!smtpServer) {
  }
  const smtpConfig = smtpServer?.smtpConfig || {};
  return transporters[smtpServerId] = $createTransport({
    host: smtpConfig.host,
    port: parseInt(smtpConfig.port),
    secure: parseInt(smtpConfig.port) === 465,
    auth: {
      user: smtpConfig.username,
      pass: smtpConfig.password
    }
  });
}
var transporters = {};
var engine = new Liquid;
var queueEmail = async (event, sender, email, sub) => {
  const { smtpServer, from } = (await database_default.select({ smtpServer: senders.smtpServer, from: senders.from }).from(senders).where(sql`id = ${sender}`))[0];
  const emailObj = (await database_default.select().from(emails).where(sql`id = ${email}`))[0];
  const subObj = (await database_default.select().from(subscribers).where(sql`id = ${sub}`))[0];
  const context = {
    name: subObj.name,
    email: subObj.email,
    sub: subObj.attributes || {}
  };
  const subject = await engine.render(engine.parse(emailObj.subject || ""), context);
  const body = await engine.render(engine.parse(emailObj.body || ""), context);
  const html2 = emailObj.type === "plaintext" ? body : marked.parse(body);
  await database_default.insert(sendingQueue).values({
    event,
    sender,
    email,
    payload: {
      smtpServer,
      from,
      to: subObj.email,
      email: {
        subject,
        html: html2,
        text: ""
      }
    }
  });
};
var sendEmail = async (smtpServer, from, to, email) => {
  const transporter = await getTransporter(smtpServer);
  return await transporter.sendMail({
    from,
    to,
    subject: email.subject,
    html: email.html,
    text: email.text
  });
};
var sendPendingEmails = async () => {
  const pendingEmails = await database_default.select({
    id: sendingQueue.id,
    payload: sendingQueue.payload,
    retries: sendingQueue.retries
  }).from(sendingQueue).where(sql`status = "pending"`);
  for (const email of pendingEmails) {
    console.log("pending", email);
    if (email?.payload) {
      try {
        await sendEmail(email.payload.smtpServer, email.payload.from, email.payload.to, email.payload.email);
        await database_default.update(sendingQueue).set({ status: "sent", sentAt: sql`(CURRENT_TIMESTAMP)` }).where(sql`id = ${email.id}`);
      } catch (error) {
        console.log("err", error);
        await database_default.update(sendingQueue).set({
          ...email.retries > 3 ? { status: "failed" } : {},
          retries: email.retries + 1
        }).where(sql`id = ${email.id}`);
      }
    }
  }
};
var SENDER_INTERVAL = 5 * 1000;
var sending = false;
var senderTimeout = null;
var startSender = async () => {
  if (sending)
    return;
  sending = true;
  await sendPendingEmails();
  sending = false;
  if (senderTimeout)
    clearTimeout(senderTimeout);
  senderTimeout = setTimeout(startSender, SENDER_INTERVAL);
};

// node_modules/filtrex/dist/esm/filtrex.mjs
var _createForOfIteratorHelper = function(o, allowArrayLike) {
  var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
  if (!it) {
    if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it)
        o = it;
      var i = 0;
      var F = function F() {
      };
      return { s: F, n: function n() {
        if (i >= o.length)
          return { done: true };
        return { done: false, value: o[i++] };
      }, e: function e(_e) {
        throw _e;
      }, f: F };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  var normalCompletion = true, didErr = false, err;
  return { s: function s() {
    it = it.call(o);
  }, n: function n() {
    var step = it.next();
    normalCompletion = step.done;
    return step;
  }, e: function e(_e2) {
    didErr = true;
    err = _e2;
  }, f: function f() {
    try {
      if (!normalCompletion && it.return != null)
        it.return();
    } finally {
      if (didErr)
        throw err;
    }
  } };
};
var _typeof = function(obj) {
  "@babel/helpers - typeof";
  return _typeof = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(obj2) {
    return typeof obj2;
  } : function(obj2) {
    return obj2 && typeof Symbol == "function" && obj2.constructor === Symbol && obj2 !== Symbol.prototype ? "symbol" : typeof obj2;
  }, _typeof(obj);
};
var _defineProperties = function(target, props) {
  for (var i = 0;i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor)
      descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
};
var _createClass = function(Constructor, protoProps, staticProps) {
  if (protoProps)
    _defineProperties(Constructor.prototype, protoProps);
  if (staticProps)
    _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", { writable: false });
  return Constructor;
};
var _classCallCheck = function(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};
var _inherits = function(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function");
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } });
  Object.defineProperty(subClass, "prototype", { writable: false });
  if (superClass)
    _setPrototypeOf(subClass, superClass);
};
var _createSuper = function(Derived) {
  var hasNativeReflectConstruct = _isNativeReflectConstruct();
  return function _createSuperInternal() {
    var Super = _getPrototypeOf(Derived), result;
    if (hasNativeReflectConstruct) {
      var NewTarget = _getPrototypeOf(this).constructor;
      result = Reflect.construct(Super, arguments, NewTarget);
    } else {
      result = Super.apply(this, arguments);
    }
    return _possibleConstructorReturn(this, result);
  };
};
var _possibleConstructorReturn = function(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  } else if (call !== undefined) {
    throw new TypeError("Derived constructors may only return object or undefined");
  }
  return _assertThisInitialized(self);
};
var _assertThisInitialized = function(self) {
  if (self === undefined) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return self;
};
var _wrapNativeSuper = function(Class) {
  var _cache = typeof Map === "function" ? new Map : undefined;
  _wrapNativeSuper = function _wrapNativeSuper(Class2) {
    if (Class2 === null || !_isNativeFunction(Class2))
      return Class2;
    if (typeof Class2 !== "function") {
      throw new TypeError("Super expression must either be null or a function");
    }
    if (typeof _cache !== "undefined") {
      if (_cache.has(Class2))
        return _cache.get(Class2);
      _cache.set(Class2, Wrapper);
    }
    function Wrapper() {
      return _construct(Class2, arguments, _getPrototypeOf(this).constructor);
    }
    Wrapper.prototype = Object.create(Class2.prototype, { constructor: { value: Wrapper, enumerable: false, writable: true, configurable: true } });
    return _setPrototypeOf(Wrapper, Class2);
  };
  return _wrapNativeSuper(Class);
};
var _construct = function(Parent, args, Class) {
  if (_isNativeReflectConstruct()) {
    _construct = Reflect.construct;
  } else {
    _construct = function _construct(Parent2, args2, Class2) {
      var a = [null];
      a.push.apply(a, args2);
      var Constructor = Function.bind.apply(Parent2, a);
      var instance = new Constructor;
      if (Class2)
        _setPrototypeOf(instance, Class2.prototype);
      return instance;
    };
  }
  return _construct.apply(null, arguments);
};
var _isNativeReflectConstruct = function() {
  if (typeof Reflect === "undefined" || !Reflect.construct)
    return false;
  if (Reflect.construct.sham)
    return false;
  if (typeof Proxy === "function")
    return true;
  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
    return true;
  } catch (e) {
    return false;
  }
};
var _isNativeFunction = function(fn) {
  return Function.toString.call(fn).indexOf("[native code]") !== -1;
};
var _setPrototypeOf = function(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o2, p2) {
    o2.__proto__ = p2;
    return o2;
  };
  return _setPrototypeOf(o, p);
};
var _getPrototypeOf = function(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o2) {
    return o2.__proto__ || Object.getPrototypeOf(o2);
  };
  return _getPrototypeOf(o);
};
var _defineProperty = function(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, { value, enumerable: true, configurable: true, writable: true });
  } else {
    obj[key] = value;
  }
  return obj;
};
var _toConsumableArray = function(arr) {
  return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
};
var _nonIterableSpread = function() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
};
var _unsupportedIterableToArray = function(o, minLen) {
  if (!o)
    return;
  if (typeof o === "string")
    return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor)
    n = o.constructor.name;
  if (n === "Map" || n === "Set")
    return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n))
    return _arrayLikeToArray(o, minLen);
};
var _iterableToArray = function(iter) {
  if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null)
    return Array.from(iter);
};
var _arrayWithoutHoles = function(arr) {
  if (Array.isArray(arr))
    return _arrayLikeToArray(arr);
};
var _arrayLikeToArray = function(arr, len) {
  if (len == null || len > arr.length)
    len = arr.length;
  for (var i = 0, arr2 = new Array(len);i < len; i++) {
    arr2[i] = arr[i];
  }
  return arr2;
};
var hasOwnProperty2 = function(obj, prop) {
  if (_typeof(obj) === "object" || typeof obj === "function") {
    return Object.prototype.hasOwnProperty.call(obj, prop);
  }
  return false;
};
var _mod = function(a, b) {
  return (a % b + b) % b;
};
var unbox = function(value) {
  if (_typeof(value) !== "object")
    return value;
  if (value instanceof Number || value instanceof String || value instanceof Boolean)
    return value.valueOf();
};
var unwrap = function(value) {
  if (Array.isArray(value) && value.length === 1)
    value = value[0];
  return unbox(value);
};
var prettyType = function(value) {
  value = unwrap(value);
  if (value === undefined)
    return "undefined";
  if (value === null)
    return "null";
  if (value === true)
    return "true";
  if (value === false)
    return "false";
  if (typeof value === "number")
    return "number";
  if (typeof value === "string")
    return "text";
  if (_typeof(value) !== "object" && typeof value !== "function")
    return "unknown type";
  if (Array.isArray(value))
    return "list";
  return "object";
};
var num = function(value) {
  value = unwrap(value);
  if (typeof value === "number")
    return value;
  throw new UnexpectedTypeError("number", prettyType(value));
};
var str = function(value) {
  value = unwrap(value);
  if (typeof value === "string")
    return value;
  throw new UnexpectedTypeError("text", prettyType(value));
};
var numstr = function(value) {
  value = unwrap(value);
  if (typeof value === "string" || typeof value === "number")
    return value;
  throw new UnexpectedTypeError("text or number", prettyType(value));
};
var bool = function(value) {
  value = unwrap(value);
  if (typeof value === "boolean")
    return value;
  throw new UnexpectedTypeError("logical value (\u201Ctrue\u201D or \u201Cfalse\u201D)", prettyType(value));
};
var arr = function(value) {
  if (value === undefined || value === null) {
    throw new UnexpectedTypeError("list", prettyType(value));
  }
  if (Array.isArray(value)) {
    return value;
  } else {
    return [value];
  }
};
var flatten = function(input) {
  var stack = _toConsumableArray(input);
  var res = [];
  while (stack.length) {
    var next = stack.pop();
    if (Array.isArray(next)) {
      stack.push.apply(stack, _toConsumableArray(next));
    } else {
      res.push(next);
    }
  }
  return res.reverse();
};
var useDotAccessOperatorAndOptionalChaining = function(name, get, obj, type) {
  if (obj === null || obj === undefined)
    return obj;
  if (type === "single-quoted")
    return get(name);
  var parts = name.split(".");
  var _iterator2 = _createForOfIteratorHelper(parts), _step2;
  try {
    for (_iterator2.s();!(_step2 = _iterator2.n()).done; ) {
      var propertyName = _step2.value;
      if (obj === null || obj === undefined) {
        return obj;
      } else {
        obj = obj[propertyName];
      }
    }
  } catch (err) {
    _iterator2.e(err);
  } finally {
    _iterator2.f();
  }
  return obj;
};
var compileExpression = function(expression, options2) {
  var _constants;
  if (arguments.length > 2)
    throw new TypeError("Too many arguments.");
  options2 = _typeof(options2) === "object" ? options2 : {};
  var knownOptions = ["extraFunctions", "constants", "customProp", "operators"];
  var _options = options2, extraFunctions = _options.extraFunctions, constants = _options.constants, customProp = _options.customProp, operators = _options.operators;
  for (var _i = 0, _Object$keys = Object.keys(options2);_i < _Object$keys.length; _i++) {
    var key = _Object$keys[_i];
    if (!knownOptions.includes(key))
      throw new UnknownOptionError(key);
  }
  var functions = {
    abs: Math.abs,
    ceil: Math.ceil,
    floor: Math.floor,
    log: Math.log,
    log2: Math.log2,
    log10: Math.log10,
    max: Math.max,
    min: Math.min,
    round: Math.round,
    sqrt: Math.sqrt,
    exists: function exists(v) {
      return v !== undefined && v !== null;
    },
    empty: function empty(v) {
      return v === undefined || v === null || v === "" || Array.isArray(v) && v.length === 0;
    }
  };
  if (extraFunctions) {
    for (var _i2 = 0, _Object$keys2 = Object.keys(extraFunctions);_i2 < _Object$keys2.length; _i2++) {
      var name = _Object$keys2[_i2];
      functions[name] = extraFunctions[name];
    }
  }
  var defaultOperators2 = {
    "+": function _(a, b) {
      return numstr(a) + numstr(b);
    },
    "-": function _(a, b) {
      return b === undefined ? -num(a) : num(a) - num(b);
    },
    "*": function _(a, b) {
      return num(a) * num(b);
    },
    "/": function _(a, b) {
      return num(a) / num(b);
    },
    "^": function _(a, b) {
      return Math.pow(num(a), num(b));
    },
    mod: function mod(a, b) {
      return _mod(num(a), num(b));
    },
    "==": function _(a, b) {
      return a === b;
    },
    "!=": function _(a, b) {
      return a !== b;
    },
    "<": function _(a, b) {
      return num(a) < num(b);
    },
    "<=": function _(a, b) {
      return num(a) <= num(b);
    },
    ">=": function _(a, b) {
      return num(a) >= num(b);
    },
    ">": function _(a, b) {
      return num(a) > num(b);
    },
    "~=": function _(a, b) {
      return RegExp(str(b)).test(str(a));
    }
  };
  if (operators) {
    for (var _i3 = 0, _Object$keys3 = Object.keys(operators);_i3 < _Object$keys3.length; _i3++) {
      var _name = _Object$keys3[_i3];
      defaultOperators2[_name] = operators[_name];
    }
  }
  operators = defaultOperators2;
  constants = (_constants = constants) !== null && _constants !== undefined ? _constants : {};
  var js = flatten(parser2.parse(expression));
  js.unshift("return ");
  js.push(";");
  function nakedProp(name2, obj, type) {
    if (hasOwnProperty2(obj !== null && obj !== undefined ? obj : {}, name2))
      return obj[name2];
    throw new UnknownPropertyError(name2);
  }
  function safeGetter(obj) {
    return function get(name2) {
      if (hasOwnProperty2(obj !== null && obj !== undefined ? obj : {}, name2))
        return obj[name2];
      throw new UnknownPropertyError(name2);
    };
  }
  if (typeof customProp === "function") {
    nakedProp = function nakedProp(name2, obj, type) {
      return customProp(name2, safeGetter(obj), obj, type);
    };
  }
  function createCall(fns) {
    return function call(_ref) {
      var name2 = _ref.name;
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1;_key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      if (hasOwnProperty2(fns, name2) && typeof fns[name2] === "function")
        return fns[name2].apply(fns, args);
      throw new UnknownFunctionError(name2);
    };
  }
  function prop(_ref2, obj) {
    var { name: name2, type } = _ref2;
    if (type === "unescaped" && hasOwnProperty2(constants, name2))
      return constants[name2];
    return nakedProp(name2, obj, type);
  }
  var func = new Function("call", "ops", "std", "prop", "data", js.join(""));
  return function(data) {
    try {
      return func(createCall(functions), operators, std, prop, data);
    } catch (e) {
      return e;
    }
  };
};
var _parser = function() {
  var parser2 = {
    trace: function trace() {
    },
    yy: {},
    symbols_: {
      error: 2,
      expressions: 3,
      e: 4,
      EndOfExpression: 5,
      "-": 6,
      "+": 7,
      "*": 8,
      "/": 9,
      "^": 10,
      mod: 11,
      and: 12,
      or: 13,
      not: 14,
      if: 15,
      then: 16,
      else: 17,
      in: 18,
      notIn: 19,
      "(": 20,
      ")": 21,
      Arguments: 22,
      ",": 23,
      Number: 24,
      Symbol: 25,
      String: 26,
      of: 27,
      Relation: 28,
      "%": 29,
      "?": 30,
      ":": 31,
      RelationalOperator: 32,
      "==": 33,
      "!=": 34,
      "~=": 35,
      "<": 36,
      "<=": 37,
      ">=": 38,
      ">": 39,
      $accept: 0,
      $end: 1
    },
    terminals_: {
      2: "error",
      5: "EndOfExpression",
      6: "-",
      7: "+",
      8: "*",
      9: "/",
      10: "^",
      11: "mod",
      12: "and",
      13: "or",
      14: "not",
      15: "if",
      16: "then",
      17: "else",
      18: "in",
      19: "notIn",
      20: "(",
      21: ")",
      23: ",",
      24: "Number",
      25: "Symbol",
      26: "String",
      27: "of",
      29: "%",
      30: "?",
      31: ":",
      33: "==",
      34: "!=",
      35: "~=",
      36: "<",
      37: "<=",
      38: ">=",
      39: ">"
    },
    productions_: [0, [3, 2], [4, 2], [4, 3], [4, 3], [4, 3], [4, 3], [4, 3], [4, 3], [4, 3], [4, 3], [4, 2], [4, 6], [4, 3], [4, 3], [4, 3], [4, 5], [4, 1], [4, 1], [4, 1], [4, 3], [4, 3], [4, 4], [4, 1], [4, 3], [4, 5], [32, 1], [32, 1], [32, 1], [32, 1], [32, 1], [32, 1], [32, 1], [28, 3], [28, 3], [22, 1], [22, 3]],
    performAction: function anonymous(yytext, yyleng, yylineno, yy, yystate, $$, _$) {
      var $0 = $$.length - 1;
      switch (yystate) {
        case 1:
          return $$[$0 - 1];
        case 2:
          this.$ = ["(", "ops['-'](", $$[$0], ")", ")"];
          break;
        case 3:
          this.$ = ["(", "ops['", $$[$0 - 1], "'](", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 4:
          this.$ = ["(", "ops['", $$[$0 - 1], "'](", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 5:
          this.$ = ["(", "ops['", $$[$0 - 1], "'](", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 6:
          this.$ = ["(", "ops['", $$[$0 - 1], "'](", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 7:
          this.$ = ["(", "ops['", $$[$0 - 1], "'](", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 8:
          this.$ = ["(", "ops.mod(", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 9:
          this.$ = ["(", "", "std.coerceBoolean", "(", $$[$0 - 2], ") && ", "std.coerceBoolean", "(", $$[$0], ")", ")"];
          break;
        case 10:
          this.$ = ["(", "", "std.coerceBoolean", "(", $$[$0 - 2], ") || ", "std.coerceBoolean", "(", $$[$0], ")", ")"];
          break;
        case 11:
          this.$ = ["(", "! ", "std.coerceBoolean", "(", $$[$0], ")", ")"];
          break;
        case 12:
          this.$ = ["(", "", "std.coerceBoolean", "(", $$[$0 - 4], ") ? ", $$[$0 - 2], " : ", $$[$0], "", ")"];
          break;
        case 13:
          this.$ = ["(", "std.isSubset(", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 14:
          this.$ = ["(", "!std.isSubset(", $$[$0 - 2], ", ", $$[$0], ")", ")"];
          break;
        case 15:
          this.$ = ["(", "", $$[$0 - 1], "", ")"];
          break;
        case 16:
          this.$ = ["(", "[ ", $$[$0 - 3], ", ", $$[$0 - 1], " ]", ")"];
          break;
        case 17:
          this.$ = ["", $$[$0], ""];
          break;
        case 18:
          this.$ = ["prop(", $$[$0], ", data)"];
          break;
        case 19:
          this.$ = ["", $$[$0], ""];
          break;
        case 20:
          this.$ = ["prop(", $$[$0 - 2], ", ", $$[$0], ")"];
          break;
        case 21:
          this.$ = ["call(", $$[$0 - 2], ")"];
          break;
        case 22:
          this.$ = ["call(", $$[$0 - 3], ", ", $$[$0 - 1], ")"];
          break;
        case 23:
          this.$ = yy.reduceRelation($$[$0]);
          break;
        case 24:
          this.$ = ["std.warnDeprecated('modulo', ops['mod'](", $$[$0 - 2], ", ", $$[$0], "))"];
          break;
        case 25:
          this.$ = ["std.warnDeprecated('ternary', ", "std.coerceBoolean", "(", $$[$0 - 4], ") ? ", $$[$0 - 2], " : ", $$[$0], ")"];
          break;
        case 26:
          this.$ = ["=="];
          break;
        case 27:
          this.$ = ["!="];
          break;
        case 28:
          this.$ = ["~="];
          break;
        case 29:
          this.$ = ["<"];
          break;
        case 30:
          this.$ = ["<="];
          break;
        case 31:
          this.$ = [">="];
          break;
        case 32:
          this.$ = [">"];
          break;
        case 33:
          this.$ = [$$[$0 - 2], $$[$0 - 1]].concat(_toConsumableArray($$[$0]));
          break;
        case 34:
          this.$ = [$$[$0 - 2], $$[$0 - 1], $$[$0]];
          break;
        case 35:
          this.$ = ["", $$[$0], ""];
          break;
        case 36:
          this.$ = ["", $$[$0 - 2], ", ", $$[$0], ""];
          break;
      }
    },
    table: [{
      3: 1,
      4: 2,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      1: [3]
    }, {
      5: [1, 11],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      18: [1, 20],
      19: [1, 21],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      4: 32,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 33,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 34,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 35,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      22: 36,
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      5: [2, 17],
      6: [2, 17],
      7: [2, 17],
      8: [2, 17],
      9: [2, 17],
      10: [2, 17],
      11: [2, 17],
      12: [2, 17],
      13: [2, 17],
      16: [2, 17],
      17: [2, 17],
      18: [2, 17],
      19: [2, 17],
      21: [2, 17],
      23: [2, 17],
      29: [2, 17],
      30: [2, 17],
      31: [2, 17],
      33: [2, 17],
      34: [2, 17],
      35: [2, 17],
      36: [2, 17],
      37: [2, 17],
      38: [2, 17],
      39: [2, 17]
    }, {
      5: [2, 18],
      6: [2, 18],
      7: [2, 18],
      8: [2, 18],
      9: [2, 18],
      10: [2, 18],
      11: [2, 18],
      12: [2, 18],
      13: [2, 18],
      16: [2, 18],
      17: [2, 18],
      18: [2, 18],
      19: [2, 18],
      20: [1, 38],
      21: [2, 18],
      23: [2, 18],
      27: [1, 37],
      29: [2, 18],
      30: [2, 18],
      31: [2, 18],
      33: [2, 18],
      34: [2, 18],
      35: [2, 18],
      36: [2, 18],
      37: [2, 18],
      38: [2, 18],
      39: [2, 18]
    }, {
      5: [2, 19],
      6: [2, 19],
      7: [2, 19],
      8: [2, 19],
      9: [2, 19],
      10: [2, 19],
      11: [2, 19],
      12: [2, 19],
      13: [2, 19],
      16: [2, 19],
      17: [2, 19],
      18: [2, 19],
      19: [2, 19],
      21: [2, 19],
      23: [2, 19],
      29: [2, 19],
      30: [2, 19],
      31: [2, 19],
      33: [2, 19],
      34: [2, 19],
      35: [2, 19],
      36: [2, 19],
      37: [2, 19],
      38: [2, 19],
      39: [2, 19]
    }, {
      5: [2, 23],
      6: [2, 23],
      7: [2, 23],
      8: [2, 23],
      9: [2, 23],
      10: [2, 23],
      11: [2, 23],
      12: [2, 23],
      13: [2, 23],
      16: [2, 23],
      17: [2, 23],
      18: [2, 23],
      19: [2, 23],
      21: [2, 23],
      23: [2, 23],
      29: [2, 23],
      30: [2, 23],
      31: [2, 23],
      33: [2, 23],
      34: [2, 23],
      35: [2, 23],
      36: [2, 23],
      37: [2, 23],
      38: [2, 23],
      39: [2, 23]
    }, {
      1: [2, 1]
    }, {
      4: 39,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 40,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 41,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 42,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 43,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 44,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 45,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 46,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 47,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 48,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 49,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 50,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 52,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 51
    }, {
      6: [2, 26],
      14: [2, 26],
      15: [2, 26],
      20: [2, 26],
      24: [2, 26],
      25: [2, 26],
      26: [2, 26]
    }, {
      6: [2, 27],
      14: [2, 27],
      15: [2, 27],
      20: [2, 27],
      24: [2, 27],
      25: [2, 27],
      26: [2, 27]
    }, {
      6: [2, 28],
      14: [2, 28],
      15: [2, 28],
      20: [2, 28],
      24: [2, 28],
      25: [2, 28],
      26: [2, 28]
    }, {
      6: [2, 29],
      14: [2, 29],
      15: [2, 29],
      20: [2, 29],
      24: [2, 29],
      25: [2, 29],
      26: [2, 29]
    }, {
      6: [2, 30],
      14: [2, 30],
      15: [2, 30],
      20: [2, 30],
      24: [2, 30],
      25: [2, 30],
      26: [2, 30]
    }, {
      6: [2, 31],
      14: [2, 31],
      15: [2, 31],
      20: [2, 31],
      24: [2, 31],
      25: [2, 31],
      26: [2, 31]
    }, {
      6: [2, 32],
      14: [2, 32],
      15: [2, 32],
      20: [2, 32],
      24: [2, 32],
      25: [2, 32],
      26: [2, 32]
    }, {
      5: [2, 2],
      6: [2, 2],
      7: [2, 2],
      8: [2, 2],
      9: [2, 2],
      10: [1, 16],
      11: [2, 2],
      12: [2, 2],
      13: [2, 2],
      16: [2, 2],
      17: [2, 2],
      18: [2, 2],
      19: [2, 2],
      21: [2, 2],
      23: [2, 2],
      29: [2, 2],
      30: [2, 2],
      31: [2, 2],
      32: 24,
      33: [2, 2],
      34: [2, 2],
      35: [2, 2],
      36: [2, 2],
      37: [2, 2],
      38: [2, 2],
      39: [2, 2]
    }, {
      5: [2, 11],
      6: [2, 11],
      7: [2, 11],
      8: [2, 11],
      9: [2, 11],
      10: [1, 16],
      11: [2, 11],
      12: [2, 11],
      13: [2, 11],
      16: [2, 11],
      17: [2, 11],
      18: [2, 11],
      19: [2, 11],
      21: [2, 11],
      23: [2, 11],
      29: [2, 11],
      30: [2, 11],
      31: [2, 11],
      32: 24,
      33: [2, 11],
      34: [2, 11],
      35: [2, 11],
      36: [2, 11],
      37: [2, 11],
      38: [2, 11],
      39: [2, 11]
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      16: [1, 53],
      18: [1, 20],
      19: [1, 21],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      18: [1, 20],
      19: [1, 21],
      21: [1, 54],
      23: [2, 35],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      23: [1, 55]
    }, {
      4: 56,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      4: 59,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      21: [1, 57],
      22: 58,
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      5: [2, 3],
      6: [2, 3],
      7: [2, 3],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [2, 3],
      13: [2, 3],
      16: [2, 3],
      17: [2, 3],
      18: [2, 3],
      19: [2, 3],
      21: [2, 3],
      23: [2, 3],
      29: [1, 22],
      30: [2, 3],
      31: [2, 3],
      32: 24,
      33: [2, 3],
      34: [2, 3],
      35: [2, 3],
      36: [2, 3],
      37: [2, 3],
      38: [2, 3],
      39: [2, 3]
    }, {
      5: [2, 4],
      6: [2, 4],
      7: [2, 4],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [2, 4],
      13: [2, 4],
      16: [2, 4],
      17: [2, 4],
      18: [2, 4],
      19: [2, 4],
      21: [2, 4],
      23: [2, 4],
      29: [1, 22],
      30: [2, 4],
      31: [2, 4],
      32: 24,
      33: [2, 4],
      34: [2, 4],
      35: [2, 4],
      36: [2, 4],
      37: [2, 4],
      38: [2, 4],
      39: [2, 4]
    }, {
      5: [2, 5],
      6: [2, 5],
      7: [2, 5],
      8: [2, 5],
      9: [2, 5],
      10: [1, 16],
      11: [2, 5],
      12: [2, 5],
      13: [2, 5],
      16: [2, 5],
      17: [2, 5],
      18: [2, 5],
      19: [2, 5],
      21: [2, 5],
      23: [2, 5],
      29: [2, 5],
      30: [2, 5],
      31: [2, 5],
      32: 24,
      33: [2, 5],
      34: [2, 5],
      35: [2, 5],
      36: [2, 5],
      37: [2, 5],
      38: [2, 5],
      39: [2, 5]
    }, {
      5: [2, 6],
      6: [2, 6],
      7: [2, 6],
      8: [2, 6],
      9: [2, 6],
      10: [1, 16],
      11: [2, 6],
      12: [2, 6],
      13: [2, 6],
      16: [2, 6],
      17: [2, 6],
      18: [2, 6],
      19: [2, 6],
      21: [2, 6],
      23: [2, 6],
      29: [2, 6],
      30: [2, 6],
      31: [2, 6],
      32: 24,
      33: [2, 6],
      34: [2, 6],
      35: [2, 6],
      36: [2, 6],
      37: [2, 6],
      38: [2, 6],
      39: [2, 6]
    }, {
      5: [2, 7],
      6: [2, 7],
      7: [2, 7],
      8: [2, 7],
      9: [2, 7],
      10: [1, 16],
      11: [2, 7],
      12: [2, 7],
      13: [2, 7],
      16: [2, 7],
      17: [2, 7],
      18: [2, 7],
      19: [2, 7],
      21: [2, 7],
      23: [2, 7],
      29: [2, 7],
      30: [2, 7],
      31: [2, 7],
      32: 24,
      33: [2, 7],
      34: [2, 7],
      35: [2, 7],
      36: [2, 7],
      37: [2, 7],
      38: [2, 7],
      39: [2, 7]
    }, {
      5: [2, 8],
      6: [2, 8],
      7: [2, 8],
      8: [2, 8],
      9: [2, 8],
      10: [1, 16],
      11: [2, 8],
      12: [2, 8],
      13: [2, 8],
      16: [2, 8],
      17: [2, 8],
      18: [2, 8],
      19: [2, 8],
      21: [2, 8],
      23: [2, 8],
      29: [2, 8],
      30: [2, 8],
      31: [2, 8],
      32: 24,
      33: [2, 8],
      34: [2, 8],
      35: [2, 8],
      36: [2, 8],
      37: [2, 8],
      38: [2, 8],
      39: [2, 8]
    }, {
      5: [2, 9],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [2, 9],
      13: [2, 9],
      16: [2, 9],
      17: [2, 9],
      18: [1, 20],
      19: [1, 21],
      21: [2, 9],
      23: [2, 9],
      29: [1, 22],
      30: [2, 9],
      31: [2, 9],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 10],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [2, 10],
      16: [2, 10],
      17: [2, 10],
      18: [1, 20],
      19: [1, 21],
      21: [2, 10],
      23: [2, 10],
      29: [1, 22],
      30: [2, 10],
      31: [2, 10],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 13],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [2, 13],
      13: [2, 13],
      16: [2, 13],
      17: [2, 13],
      18: [2, 13],
      19: [2, 13],
      21: [2, 13],
      23: [2, 13],
      29: [1, 22],
      30: [2, 13],
      31: [2, 13],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 14],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [2, 14],
      13: [2, 14],
      16: [2, 14],
      17: [2, 14],
      18: [2, 14],
      19: [2, 14],
      21: [2, 14],
      23: [2, 14],
      29: [1, 22],
      30: [2, 14],
      31: [2, 14],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 24],
      6: [2, 24],
      7: [2, 24],
      8: [2, 24],
      9: [2, 24],
      10: [1, 16],
      11: [2, 24],
      12: [2, 24],
      13: [2, 24],
      16: [2, 24],
      17: [2, 24],
      18: [2, 24],
      19: [2, 24],
      21: [2, 24],
      23: [2, 24],
      29: [2, 24],
      30: [2, 24],
      31: [2, 24],
      32: 24,
      33: [2, 24],
      34: [2, 24],
      35: [2, 24],
      36: [2, 24],
      37: [2, 24],
      38: [2, 24],
      39: [2, 24]
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      18: [1, 20],
      19: [1, 21],
      29: [1, 22],
      30: [1, 23],
      31: [1, 60],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 33],
      6: [2, 33],
      7: [2, 33],
      8: [2, 33],
      9: [2, 33],
      10: [2, 33],
      11: [2, 33],
      12: [2, 33],
      13: [2, 33],
      16: [2, 33],
      17: [2, 33],
      18: [2, 33],
      19: [2, 33],
      21: [2, 33],
      23: [2, 33],
      29: [2, 33],
      30: [2, 33],
      31: [2, 33],
      33: [2, 33],
      34: [2, 33],
      35: [2, 33],
      36: [2, 33],
      37: [2, 33],
      38: [2, 33],
      39: [2, 33]
    }, {
      5: [2, 34],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [2, 34],
      13: [2, 34],
      16: [2, 34],
      17: [2, 34],
      18: [2, 34],
      19: [2, 34],
      21: [2, 34],
      23: [2, 34],
      29: [1, 22],
      30: [2, 34],
      31: [2, 34],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      4: 61,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      5: [2, 15],
      6: [2, 15],
      7: [2, 15],
      8: [2, 15],
      9: [2, 15],
      10: [2, 15],
      11: [2, 15],
      12: [2, 15],
      13: [2, 15],
      16: [2, 15],
      17: [2, 15],
      18: [2, 15],
      19: [2, 15],
      21: [2, 15],
      23: [2, 15],
      29: [2, 15],
      30: [2, 15],
      31: [2, 15],
      33: [2, 15],
      34: [2, 15],
      35: [2, 15],
      36: [2, 15],
      37: [2, 15],
      38: [2, 15],
      39: [2, 15]
    }, {
      4: 62,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      5: [2, 20],
      6: [2, 20],
      7: [2, 20],
      8: [2, 20],
      9: [2, 20],
      10: [2, 20],
      11: [2, 20],
      12: [2, 20],
      13: [2, 20],
      16: [2, 20],
      17: [2, 20],
      18: [2, 20],
      19: [2, 20],
      21: [2, 20],
      23: [2, 20],
      29: [2, 20],
      30: [2, 20],
      31: [2, 20],
      32: 24,
      33: [2, 20],
      34: [2, 20],
      35: [2, 20],
      36: [2, 20],
      37: [2, 20],
      38: [2, 20],
      39: [2, 20]
    }, {
      5: [2, 21],
      6: [2, 21],
      7: [2, 21],
      8: [2, 21],
      9: [2, 21],
      10: [2, 21],
      11: [2, 21],
      12: [2, 21],
      13: [2, 21],
      16: [2, 21],
      17: [2, 21],
      18: [2, 21],
      19: [2, 21],
      21: [2, 21],
      23: [2, 21],
      29: [2, 21],
      30: [2, 21],
      31: [2, 21],
      33: [2, 21],
      34: [2, 21],
      35: [2, 21],
      36: [2, 21],
      37: [2, 21],
      38: [2, 21],
      39: [2, 21]
    }, {
      21: [1, 63],
      23: [1, 64]
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      18: [1, 20],
      19: [1, 21],
      21: [2, 35],
      23: [2, 35],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      4: 65,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      17: [1, 66],
      18: [1, 20],
      19: [1, 21],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      18: [1, 20],
      19: [1, 21],
      21: [1, 67],
      23: [2, 36],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 22],
      6: [2, 22],
      7: [2, 22],
      8: [2, 22],
      9: [2, 22],
      10: [2, 22],
      11: [2, 22],
      12: [2, 22],
      13: [2, 22],
      16: [2, 22],
      17: [2, 22],
      18: [2, 22],
      19: [2, 22],
      21: [2, 22],
      23: [2, 22],
      29: [2, 22],
      30: [2, 22],
      31: [2, 22],
      33: [2, 22],
      34: [2, 22],
      35: [2, 22],
      36: [2, 22],
      37: [2, 22],
      38: [2, 22],
      39: [2, 22]
    }, {
      4: 68,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      5: [2, 25],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      16: [2, 25],
      17: [2, 25],
      18: [1, 20],
      19: [1, 21],
      21: [2, 25],
      23: [2, 25],
      29: [1, 22],
      30: [1, 23],
      31: [2, 25],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      4: 69,
      6: [1, 3],
      14: [1, 4],
      15: [1, 5],
      20: [1, 6],
      24: [1, 7],
      25: [1, 8],
      26: [1, 9],
      28: 10
    }, {
      5: [2, 16],
      6: [2, 16],
      7: [2, 16],
      8: [2, 16],
      9: [2, 16],
      10: [2, 16],
      11: [2, 16],
      12: [2, 16],
      13: [2, 16],
      16: [2, 16],
      17: [2, 16],
      18: [2, 16],
      19: [2, 16],
      21: [2, 16],
      23: [2, 16],
      29: [2, 16],
      30: [2, 16],
      31: [2, 16],
      33: [2, 16],
      34: [2, 16],
      35: [2, 16],
      36: [2, 16],
      37: [2, 16],
      38: [2, 16],
      39: [2, 16]
    }, {
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      18: [1, 20],
      19: [1, 21],
      21: [2, 36],
      23: [2, 36],
      29: [1, 22],
      30: [1, 23],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }, {
      5: [2, 12],
      6: [1, 13],
      7: [1, 12],
      8: [1, 14],
      9: [1, 15],
      10: [1, 16],
      11: [1, 17],
      12: [1, 18],
      13: [1, 19],
      16: [2, 12],
      17: [2, 12],
      18: [1, 20],
      19: [1, 21],
      21: [2, 12],
      23: [2, 12],
      29: [1, 22],
      30: [1, 23],
      31: [2, 12],
      32: 24,
      33: [1, 25],
      34: [1, 26],
      35: [1, 27],
      36: [1, 28],
      37: [1, 29],
      38: [1, 30],
      39: [1, 31]
    }],
    defaultActions: {
      11: [2, 1]
    },
    parseError: function parseError(str2, hash) {
      throw new Error(str2);
    },
    parse: function parse(input) {
      var self = this, stack = [0], vstack = [null], lstack = [], table19 = this.table, yytext = "", yylineno = 0, yyleng = 0, recovering = 0, TERROR = 2, EOF = 1;
      this.lexer.setInput(input);
      this.lexer.yy = this.yy;
      this.yy.lexer = this.lexer;
      this.yy.parser = this;
      if (typeof this.lexer.yylloc == "undefined")
        this.lexer.yylloc = {};
      var yyloc = this.lexer.yylloc;
      lstack.push(yyloc);
      var ranges = this.lexer.options && this.lexer.options.ranges;
      if (typeof this.yy.parseError === "function")
        this.parseError = this.yy.parseError;
      function popStack(n) {
        stack.length = stack.length - 2 * n;
        vstack.length = vstack.length - n;
        lstack.length = lstack.length - n;
      }
      function lex() {
        var token;
        token = self.lexer.lex() || 1;
        if (typeof token !== "number") {
          token = self.symbols_[token] || token;
        }
        return token;
      }
      var symbol, preErrorSymbol, state, action, r, yyval = {}, p, len, newState, expected;
      while (true) {
        state = stack[stack.length - 1];
        if (this.defaultActions[state]) {
          action = this.defaultActions[state];
        } else {
          if (symbol === null || typeof symbol == "undefined") {
            symbol = lex();
          }
          action = table19[state] && table19[state][symbol];
        }
        if (typeof action === "undefined" || !action.length || !action[0]) {
          var errStr = "";
          if (!recovering) {
            expected = [];
            for (p in table19[state]) {
              if (this.terminals_[p] && p > 2) {
                expected.push("'" + this.terminals_[p] + "'");
              }
            }
            if (this.lexer.showPosition) {
              errStr = "Parse error on line " + (yylineno + 1) + ":\n" + this.lexer.showPosition() + "\nExpecting " + expected.join(", ") + ", got '" + (this.terminals_[symbol] || symbol) + "'";
            } else {
              errStr = "Parse error on line " + (yylineno + 1) + ": Unexpected " + (symbol == 1 ? "end of input" : "'" + (this.terminals_[symbol] || symbol) + "'");
            }
            this.parseError(errStr, {
              text: this.lexer.match,
              token: this.terminals_[symbol] || symbol,
              line: this.lexer.yylineno,
              loc: yyloc,
              expected
            });
          }
          if (recovering == 3) {
            if (symbol == EOF) {
              throw new Error(errStr || "Parsing halted.");
            }
            yyleng = this.lexer.yyleng;
            yytext = this.lexer.yytext;
            yylineno = this.lexer.yylineno;
            yyloc = this.lexer.yylloc;
            symbol = lex();
          }
          while (true) {
            if (TERROR.toString() in table19[state]) {
              break;
            }
            if (state === 0) {
              throw new Error(errStr || "Parsing halted.");
            }
            popStack(1);
            state = stack[stack.length - 1];
          }
          preErrorSymbol = symbol == 2 ? null : symbol;
          symbol = TERROR;
          state = stack[stack.length - 1];
          action = table19[state] && table19[state][TERROR];
          recovering = 3;
        }
        if (action[0] instanceof Array && action.length > 1) {
          throw new Error("Parse Error: multiple actions possible at state: " + state + ", token: " + symbol);
        }
        switch (action[0]) {
          case 1:
            stack.push(symbol);
            vstack.push(this.lexer.yytext);
            lstack.push(this.lexer.yylloc);
            stack.push(action[1]);
            symbol = null;
            if (!preErrorSymbol) {
              yyleng = this.lexer.yyleng;
              yytext = this.lexer.yytext;
              yylineno = this.lexer.yylineno;
              yyloc = this.lexer.yylloc;
              if (recovering > 0)
                recovering--;
            } else {
              symbol = preErrorSymbol;
              preErrorSymbol = null;
            }
            break;
          case 2:
            len = this.productions_[action[1]][1];
            yyval.$ = vstack[vstack.length - len];
            yyval._$ = {
              first_line: lstack[lstack.length - (len || 1)].first_line,
              last_line: lstack[lstack.length - 1].last_line,
              first_column: lstack[lstack.length - (len || 1)].first_column,
              last_column: lstack[lstack.length - 1].last_column
            };
            if (ranges) {
              yyval._$.range = [lstack[lstack.length - (len || 1)].range[0], lstack[lstack.length - 1].range[1]];
            }
            r = this.performAction.call(yyval, yytext, yyleng, yylineno, this.yy, action[1], vstack, lstack);
            if (typeof r !== "undefined") {
              return r;
            }
            if (len) {
              stack = stack.slice(0, -1 * len * 2);
              vstack = vstack.slice(0, -1 * len);
              lstack = lstack.slice(0, -1 * len);
            }
            stack.push(this.productions_[action[1]][0]);
            vstack.push(yyval.$);
            lstack.push(yyval._$);
            newState = table19[stack[stack.length - 2]][stack[stack.length - 1]];
            stack.push(newState);
            break;
          case 3:
            return true;
        }
      }
      return true;
    }
  };
  var lexer2 = function() {
    var lexer3 = {
      EOF: 1,
      parseError: function parseError(str2, hash) {
        if (this.yy.parser) {
          this.yy.parser.parseError(str2, hash);
        } else {
          throw new Error(str2);
        }
      },
      setInput: function setInput(input) {
        this._input = input;
        this._more = this._less = this.done = false;
        this.yylineno = this.yyleng = 0;
        this.yytext = this.matched = this.match = "";
        this.conditionStack = ["INITIAL"];
        this.yylloc = {
          first_line: 1,
          first_column: 0,
          last_line: 1,
          last_column: 0
        };
        if (this.options.ranges)
          this.yylloc.range = [0, 0];
        this.offset = 0;
        return this;
      },
      input: function input() {
        var ch = this._input[0];
        this.yytext += ch;
        this.yyleng++;
        this.offset++;
        this.match += ch;
        this.matched += ch;
        var lines = ch.match(/(?:\r\n?|\n).*/g);
        if (lines) {
          this.yylineno++;
          this.yylloc.last_line++;
        } else {
          this.yylloc.last_column++;
        }
        if (this.options.ranges)
          this.yylloc.range[1]++;
        this._input = this._input.slice(1);
        return ch;
      },
      unput: function unput(ch) {
        var len = ch.length;
        var lines = ch.split(/(?:\r\n?|\n)/g);
        this._input = ch + this._input;
        this.yytext = this.yytext.substr(0, this.yytext.length - len - 1);
        this.offset -= len;
        var oldLines = this.match.split(/(?:\r\n?|\n)/g);
        this.match = this.match.substr(0, this.match.length - 1);
        this.matched = this.matched.substr(0, this.matched.length - 1);
        if (lines.length - 1)
          this.yylineno -= lines.length - 1;
        var r = this.yylloc.range;
        this.yylloc = {
          first_line: this.yylloc.first_line,
          last_line: this.yylineno + 1,
          first_column: this.yylloc.first_column,
          last_column: lines ? (lines.length === oldLines.length ? this.yylloc.first_column : 0) + oldLines[oldLines.length - lines.length].length - lines[0].length : this.yylloc.first_column - len
        };
        if (this.options.ranges) {
          this.yylloc.range = [r[0], r[0] + this.yyleng - len];
        }
        return this;
      },
      more: function more() {
        this._more = true;
        return this;
      },
      less: function less(n) {
        this.unput(this.match.slice(n));
      },
      pastInput: function pastInput() {
        var past = this.matched.substr(0, this.matched.length - this.match.length);
        return (past.length > 20 ? "..." : "") + past.substr(-20).replace(/\n/g, "");
      },
      upcomingInput: function upcomingInput() {
        var next = this.match;
        if (next.length < 20) {
          next += this._input.substr(0, 20 - next.length);
        }
        return (next.substr(0, 20) + (next.length > 20 ? "..." : "")).replace(/\n/g, "");
      },
      showPosition: function showPosition() {
        var pre = this.pastInput();
        var c = new Array(pre.length + 1).join("-");
        return pre + this.upcomingInput() + "\n" + c + "^";
      },
      next: function next() {
        if (this.done) {
          return this.EOF;
        }
        if (!this._input)
          this.done = true;
        var token, match, tempMatch, index, lines;
        if (!this._more) {
          this.yytext = "";
          this.match = "";
        }
        var rules = this._currentRules();
        for (var i = 0;i < rules.length; i++) {
          tempMatch = this._input.match(this.rules[rules[i]]);
          if (tempMatch && (!match || tempMatch[0].length > match[0].length)) {
            match = tempMatch;
            index = i;
            if (!this.options.flex)
              break;
          }
        }
        if (match) {
          lines = match[0].match(/(?:\r\n?|\n).*/g);
          if (lines)
            this.yylineno += lines.length;
          this.yylloc = {
            first_line: this.yylloc.last_line,
            last_line: this.yylineno + 1,
            first_column: this.yylloc.last_column,
            last_column: lines ? lines[lines.length - 1].length - lines[lines.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + match[0].length
          };
          this.yytext += match[0];
          this.match += match[0];
          this.matches = match;
          this.yyleng = this.yytext.length;
          if (this.options.ranges) {
            this.yylloc.range = [this.offset, this.offset += this.yyleng];
          }
          this._more = false;
          this._input = this._input.slice(match[0].length);
          this.matched += match[0];
          token = this.performAction.call(this, this.yy, this, rules[index], this.conditionStack[this.conditionStack.length - 1]);
          if (this.done && this._input)
            this.done = false;
          if (token)
            return token;
          else
            return;
        }
        if (this._input === "") {
          return this.EOF;
        } else {
          return this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
            text: "",
            token: null,
            line: this.yylineno
          });
        }
      },
      lex: function lex() {
        var r = this.next();
        if (typeof r !== "undefined") {
          return r;
        } else {
          return this.lex();
        }
      },
      begin: function begin(condition) {
        this.conditionStack.push(condition);
      },
      popState: function popState() {
        return this.conditionStack.pop();
      },
      _currentRules: function _currentRules() {
        return this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules;
      },
      topState: function topState() {
        return this.conditionStack[this.conditionStack.length - 2];
      },
      pushState: function begin(condition) {
        this.begin(condition);
      }
    };
    lexer3.options = {};
    lexer3.performAction = function anonymous(yy, yy_, $avoiding_name_collisions, YY_START) {
      switch ($avoiding_name_collisions) {
        case 0:
          return "*";
        case 1:
          return "/";
        case 2:
          return "-";
        case 3:
          return "+";
        case 4:
          return "^";
        case 5:
          return "(";
        case 6:
          return ")";
        case 7:
          return ",";
        case 8:
          return "==";
        case 9:
          return "!=";
        case 10:
          return "~=";
        case 11:
          return ">=";
        case 12:
          return "<=";
        case 13:
          return "<";
        case 14:
          return ">";
        case 15:
          return "notIn";
        case 16:
          return "and";
        case 17:
          return "or";
        case 18:
          return "not";
        case 19:
          return "in";
        case 20:
          return "of";
        case 21:
          return "if";
        case 22:
          return "then";
        case 23:
          return "else";
        case 24:
          return "mod";
        case 25:
          break;
        case 26:
          return "Number";
        case 27:
          yy_.yytext = JSON.stringify({
            name: yy_.yytext,
            type: "unescaped"
          });
          return "Symbol";
        case 28:
          yy_.yytext = JSON.stringify({
            name: yy.buildString("'", yy_.yytext),
            type: "single-quoted"
          });
          return "Symbol";
        case 29:
          yy_.yytext = JSON.stringify(yy.buildString('"', yy_.yytext));
          return "String";
        case 30:
          return "%";
        case 31:
          return "?";
        case 32:
          return ":";
        case 33:
          return "EndOfExpression";
      }
    };
    lexer3.rules = [/^(?:\*)/, /^(?:\/)/, /^(?:-)/, /^(?:\+)/, /^(?:\^)/, /^(?:\()/, /^(?:\))/, /^(?:\,)/, /^(?:==)/, /^(?:\!=)/, /^(?:\~=)/, /^(?:>=)/, /^(?:<=)/, /^(?:<)/, /^(?:>)/, /^(?:not\s+in[^\w])/, /^(?:and[^\w])/, /^(?:or[^\w])/, /^(?:not[^\w])/, /^(?:in[^\w])/, /^(?:of[^\w])/, /^(?:if[^\w])/, /^(?:then[^\w])/, /^(?:else[^\w])/, /^(?:mod[^\w])/, /^(?:\s+)/, /^(?:[0-9]+(?:\.[0-9]+)?(?![0-9\.]))/, /^(?:[a-zA-Z$_][\.a-zA-Z0-9$_]*)/, /^(?:'(?:\\'|\\\\|[^'\\])*')/, /^(?:"(?:\\"|\\\\|[^"\\])*")/, /^(?:\%)/, /^(?:\?)/, /^(?::)/, /^(?:$)/];
    lexer3.conditions = {
      INITIAL: {
        rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33],
        inclusive: true
      }
    };
    return lexer3;
  }();
  parser2.lexer = lexer2;
  function Parser2() {
    this.yy = {};
  }
  Parser2.prototype = parser2;
  parser2.Parser = Parser2;
  return new Parser2;
}();
var parser2 = _parser;
_parser.Parser;
var UnknownFunctionError = function(_ReferenceError) {
  _inherits(UnknownFunctionError2, _ReferenceError);
  var _super = _createSuper(UnknownFunctionError2);
  function UnknownFunctionError2(funcName) {
    var _this;
    _classCallCheck(this, UnknownFunctionError2);
    _this = _super.call(this, "Unknown function: ".concat(funcName, "()"));
    _defineProperty(_assertThisInitialized(_this), "I18N_STRING", "UNKNOWN_FUNCTION");
    _this.functionName = funcName;
    return _this;
  }
  return _createClass(UnknownFunctionError2);
}(_wrapNativeSuper(ReferenceError));
var UnknownPropertyError = function(_ReferenceError2) {
  _inherits(UnknownPropertyError2, _ReferenceError2);
  var _super2 = _createSuper(UnknownPropertyError2);
  function UnknownPropertyError2(propName) {
    var _this2;
    _classCallCheck(this, UnknownPropertyError2);
    _this2 = _super2.call(this, "Property \u201C".concat(propName, "\u201D does not exist."));
    _defineProperty(_assertThisInitialized(_this2), "I18N_STRING", "UNKNOWN_PROPERTY");
    _this2.propertyName = propName;
    return _this2;
  }
  return _createClass(UnknownPropertyError2);
}(_wrapNativeSuper(ReferenceError));
var UnknownOptionError = function(_TypeError) {
  _inherits(UnknownOptionError2, _TypeError);
  var _super3 = _createSuper(UnknownOptionError2);
  function UnknownOptionError2(key) {
    var _this3;
    _classCallCheck(this, UnknownOptionError2);
    _this3 = _super3.call(this, "Unknown option: ".concat(key));
    _defineProperty(_assertThisInitialized(_this3), "I18N_STRING", "UNKNOWN_OPTION");
    _this3.keyName = key;
    return _this3;
  }
  return _createClass(UnknownOptionError2);
}(_wrapNativeSuper(TypeError));
var UnexpectedTypeError = function(_TypeError2) {
  _inherits(UnexpectedTypeError2, _TypeError2);
  var _super4 = _createSuper(UnexpectedTypeError2);
  function UnexpectedTypeError2(expected, got) {
    var _this4;
    _classCallCheck(this, UnexpectedTypeError2);
    _this4 = _super4.call(this, "Expected a ".concat(expected, ", but got a ").concat(got, " instead."));
    _defineProperty(_assertThisInitialized(_this4), "I18N_STRING", "UNEXPECTED_TYPE");
    _this4.expectedType = expected;
    _this4.recievedType = got;
    return _this4;
  }
  return _createClass(UnexpectedTypeError2);
}(_wrapNativeSuper(TypeError));
var InternalError = function(_Error) {
  _inherits(InternalError2, _Error);
  var _super5 = _createSuper(InternalError2);
  function InternalError2(message) {
    var _this5;
    _classCallCheck(this, InternalError2);
    _this5 = _super5.call(this, message);
    _defineProperty(_assertThisInitialized(_this5), "I18N_STRING", "INTERNAL");
    return _this5;
  }
  return _createClass(InternalError2);
}(_wrapNativeSuper(Error));
var std = {
  isfn: function isfn(fns, funcName) {
    return hasOwnProperty2(fns, funcName) && typeof fns[funcName] === "function";
  },
  unknown: function unknown(funcName) {
    throw new UnknownFunctionError(funcName);
  },
  coerceArray: arr,
  coerceNumber: num,
  coerceNumberOrString: numstr,
  coerceBoolean: bool,
  isSubset: function isSubset(a, b) {
    var A = arr(a);
    var B = arr(b);
    return A.every(function(val) {
      return B.includes(val);
    });
  },
  warnDeprecated: function() {
    var warnMax = 3;
    var warnedTimes = {
      ternary: 0,
      modulo: 0
    };
    return function(cause, value) {
      switch (cause) {
        case "ternary":
          if (warnedTimes.ternary++ >= warnMax)
            break;
          console.warn("The use of ? and : as conditional operators has been deprecated " + "in Filtrex v3 in favor of the if..then..else ternary operator. " + "See issue #34 for more information.");
          break;
        case "modulo":
          if (warnedTimes.modulo++ >= warnMax)
            break;
          console.warn("The use of '%' as a modulo operator has been deprecated in Filtrex v3 " + "in favor of the 'mod' operator. You can use it like this: '3 mod 2 == 1'. " + "See issue #48 for more information.");
          break;
      }
      return value;
    };
  }(),
  buildString: function buildString(quote, literal) {
    quote = String(quote)[0];
    literal = String(literal);
    var built = "";
    if (literal[0] !== quote || literal[literal.length - 1] !== quote)
      throw new InternalError("Unexpected internal error: String literal doesn't begin/end with the right quotation mark.");
    for (var i = 1;i < literal.length - 1; i++) {
      if (literal[i] === "\\") {
        i++;
        if (i >= literal.length - 1)
          throw new InternalError("Unexpected internal error: Unescaped backslash at the end of string literal.");
        if (literal[i] === "\\")
          built += "\\";
        else if (literal[i] === quote)
          built += quote;
        else
          throw new InternalError("Unexpected internal error: Invalid escaped character in string literal: ".concat(literal[i]));
      } else if (literal[i] === quote) {
        throw new InternalError("Unexpected internal error: String literal contains unescaped quotation mark.");
      } else {
        built += literal[i];
      }
    }
    return built;
  },
  reduceRelation: function reduceRelation(arr2) {
    var declarations = [];
    var comparisons = [];
    var previousExpression = flatten([arr2[0]]).join("");
    var j = 0;
    for (var i = 1;i < arr2.length - 1; i += 2) {
      var expr = flatten([arr2[i + 1]]).join("");
      var tempVar = "tmp".concat(j++);
      comparisons.push("ops[\"".concat(arr2[i], "\"](").concat(previousExpression, ", ").concat(tempVar, " = ").concat(expr, ")"));
      previousExpression = tempVar;
      declarations.push(tempVar);
    }
    return "(function(){ var ".concat(declarations.join(", "), "; return ").concat(comparisons.join(" && "), ";})()");
  }
};
parser2.yy = Object.create(std);

// src/filter.ts
function getFilter(exp) {
  return compileExpression(exp || "1", {
    customProp: useDotAccessOperatorAndOptionalChaining,
    extraFunctions: {
      strlen(s) {
        return s.length;
      },
      startswith(s, w) {
        return s.startsWith(w);
      },
      contains(a, b) {
        return a.includes(b);
      }
    }
  });
}

// src/events.ts
var pushEvent = async (event, time) => {
  await database_default.insert(events).values({
    type: event.type,
    payload: event,
    ...time ? { time } : {}
  });
};
var processEvents = async () => {
  const pendingEvents = await database_default.select({ id: events.id, payload: events.payload }).from(events).where(sql`status = "pending" AND time <= CURRENT_TIMESTAMP`);
  for (const event of pendingEvents) {
    if (event?.payload) {
      if (event.payload.type === "ConfirmationEmail") {
        const { defaultSender, confirmationEmail } = (await database_default.select().from(config))[0];
        if (defaultSender && confirmationEmail) {
          await queueEmail(event.id, defaultSender, confirmationEmail, event.payload.sub);
        }
      } else if (event.payload.type === "SendEmail") {
        const subs = await database_default.select().from(subscribers).where(sql`status = "subscribed"`);
        let filter2;
        try {
          filter2 = getFilter(event.payload.filter);
        } catch {
        }
        for (const sub of subs) {
          const subFilter = filter2({
            name: sub.name,
            email: sub.email,
            sub: sub.attributes
          });
          console.log("sub", subFilter);
          if (!subFilter)
            continue;
          await queueEmail(event.id, event.payload.sender, event.payload.email, sub.id);
        }
      }
      await database_default.update(events).set({ status: "processed" }).where(sql`id = ${event.id}`);
    }
  }
};
var EVENTS_INTERVAL = 5 * 1000;
var processing = false;
var eventsTimeout = null;
var startEventsQueue = async () => {
  if (processing)
    return;
  processing = true;
  await processEvents();
  processing = false;
  if (eventsTimeout)
    clearTimeout(eventsTimeout);
  eventsTimeout = setTimeout(startEventsQueue, EVENTS_INTERVAL);
};

// node_modules/hono/dist/utils/body.js
async function parseFormData(request2, options2) {
  const formData = await request2.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options2);
  }
  return {};
}
var convertFormDataToBodyData = function(formData, options2) {
  const form = Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options2.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options2.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
};
var parseBody = async (request2, options2 = Object.create(null)) => {
  const { all = false, dot = false } = options2;
  const headers = request2 instanceof HonoRequest ? request2.raw.headers : request2.headers;
  const contentType = headers.get("Content-Type");
  if (contentType !== null && contentType.startsWith("multipart/form-data") || contentType !== null && contentType.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request2, { all, dot });
  }
  return {};
};
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== undefined) {
    if (Array.isArray(form[key])) {
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    form[key] = value;
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// node_modules/hono/dist/utils/url.js
var splitPath = (path2) => {
  const paths = path2.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path: path2 } = extractGroupsFromPath(routePath);
  const paths = splitPath(path2);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path2) => {
  const groups = [];
  path2 = path2.replace(/\{[^}]+\}/g, (match, index) => {
    const mark = `@${index}`;
    groups.push([mark, match]);
    return mark;
  });
  return { groups, path: path2 };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1;i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1;j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label) => {
  if (label === "*") {
    return "*";
  }
  const match = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match) {
    if (!patternCache[label]) {
      if (match[2]) {
        patternCache[label] = [label, match[1], new RegExp("^" + match[2] + "$")];
      } else {
        patternCache[label] = [label, match[1], true];
      }
    }
    return patternCache[label];
  }
  return null;
};
var tryDecodeURI = (str2) => {
  try {
    return decodeURI(str2);
  } catch {
    return str2.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match) => {
      try {
        return decodeURI(match);
      } catch {
        return match;
      }
    });
  }
};
var getPath = (request2) => {
  const url = request2.url;
  const start = url.indexOf("/", 8);
  let i = start;
  for (;i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const path2 = url.slice(start, queryIndex === -1 ? undefined : queryIndex);
      return tryDecodeURI(path2.includes("%25") ? path2.replace(/%25/g, "%2525") : path2);
    } else if (charCode === 63) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request2) => {
  const result = getPath(request2);
  return result.length > 1 && result[result.length - 1] === "/" ? result.slice(0, -1) : result;
};
var mergePath = (...paths) => {
  let p = "";
  let endsWithSlash = false;
  for (let path2 of paths) {
    if (p[p.length - 1] === "/") {
      p = p.slice(0, -1);
      endsWithSlash = true;
    }
    if (path2[0] !== "/") {
      path2 = `/${path2}`;
    }
    if (path2 === "/" && endsWithSlash) {
      p = `${p}/`;
    } else if (path2 !== "/") {
      p = `${p}${path2}`;
    }
    if (path2 === "/" && p === "") {
      p = "/";
    }
  }
  return p;
};
var checkOptionalParameter = (path2) => {
  if (!path2.match(/\:.+\?$/)) {
    return null;
  }
  const segments = path2.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return /%/.test(value) ? decodeURIComponent_(value) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf(`?${key}`, 8);
    if (keyIndex2 === -1) {
      keyIndex2 = url.indexOf(`&${key}`, 8);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? undefined : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(keyIndex + 1, valueIndex === -1 ? nextKeyIndex === -1 ? undefined : nextKeyIndex : valueIndex);
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? undefined : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// node_modules/hono/dist/request.js
var HonoRequest = class {
  raw;
  #validatedData;
  #matchResult;
  routeIndex = 0;
  path;
  bodyCache = {};
  constructor(request2, path2 = "/", matchResult = [[]]) {
    this.raw = request2;
    this.path = path2;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.getDecodedParam(key) : this.getAllDecodedParams();
  }
  getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.getParamValue(paramKey);
    return param ? /\%/.test(param) ? decodeURIComponent_(param) : param : undefined;
  }
  getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value && typeof value === "string") {
        decoded[key] = /\%/.test(value) ? decodeURIComponent_(value) : value;
      }
    }
    return decoded;
  }
  getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name.toLowerCase()) ?? undefined;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options2) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options2);
  }
  cachedBody = (key) => {
    const { bodyCache, raw: raw3 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body2) => {
        if (anyCachedKey === "json") {
          body2 = JSON.stringify(body2);
        }
        return new Response(body2)[key]();
      });
    }
    return bodyCache[key] = raw3[key]();
  };
  json() {
    return this.cachedBody("json");
  }
  text() {
    return this.cachedBody("text");
  }
  arrayBuffer() {
    return this.cachedBody("arrayBuffer");
  }
  blob() {
    return this.cachedBody("blob");
  }
  formData() {
    return this.cachedBody("formData");
  }
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw3 = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str2, phase, preserveCallbacks, context, buffer) => {
  const callbacks = str2.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str2);
  }
  if (buffer) {
    buffer[0] += str2;
  } else {
    buffer = [str2];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then((res) => Promise.all(res.filter(Boolean).map((str22) => resolveCallback(str22, phase, false, context, buffer))).then(() => buffer[0]));
  if (preserveCallbacks) {
    return raw3(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setHeaders = (headers, map2 = {}) => {
  Object.entries(map2).forEach(([key, value]) => headers.set(key, value));
  return headers;
};
var Context2 = class {
  #rawRequest;
  #req;
  env = {};
  #var;
  finalized = false;
  error;
  #status = 200;
  #executionCtx;
  #headers;
  #preparedHeaders;
  #res;
  #isFresh = true;
  #layout;
  #renderer;
  #notFoundHandler;
  #matchResult;
  #path;
  constructor(req, options2) {
    this.#rawRequest = req;
    if (options2) {
      this.#executionCtx = options2.executionCtx;
      this.env = options2.env;
      this.#notFoundHandler = options2.notFoundHandler;
      this.#path = options2.path;
      this.#matchResult = options2.matchResult;
    }
  }
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  get res() {
    this.#isFresh = false;
    return this.#res ||= new Response("404 Not Found", { status: 404 });
  }
  set res(_res) {
    this.#isFresh = false;
    if (this.#res && _res) {
      this.#res.headers.delete("content-type");
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  setLayout = (layout) => this.#layout = layout;
  getLayout = () => this.#layout;
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  header = (name, value, options2) => {
    if (value === undefined) {
      if (this.#headers) {
        this.#headers.delete(name);
      } else if (this.#preparedHeaders) {
        delete this.#preparedHeaders[name.toLocaleLowerCase()];
      }
      if (this.finalized) {
        this.res.headers.delete(name);
      }
      return;
    }
    if (options2?.append) {
      if (!this.#headers) {
        this.#isFresh = false;
        this.#headers = new Headers(this.#preparedHeaders);
        this.#preparedHeaders = {};
      }
      this.#headers.append(name, value);
    } else {
      if (this.#headers) {
        this.#headers.set(name, value);
      } else {
        this.#preparedHeaders ??= {};
        this.#preparedHeaders[name.toLowerCase()] = value;
      }
    }
    if (this.finalized) {
      if (options2?.append) {
        this.res.headers.append(name, value);
      } else {
        this.res.headers.set(name, value);
      }
    }
  };
  status = (status) => {
    this.#isFresh = false;
    this.#status = status;
  };
  set = (key, value) => {
    this.#var ??= {};
    this.#var[key] = value;
  };
  get = (key) => {
    return this.#var ? this.#var[key] : undefined;
  };
  get var() {
    return { ...this.#var };
  }
  newResponse = (data, arg, headers) => {
    if (this.#isFresh && !headers && !arg && this.#status === 200) {
      return new Response(data, {
        headers: this.#preparedHeaders
      });
    }
    if (arg && typeof arg !== "number") {
      const header = new Headers(arg.headers);
      if (this.#headers) {
        this.#headers.forEach((v, k) => {
          if (k === "set-cookie") {
            header.append(k, v);
          } else {
            header.set(k, v);
          }
        });
      }
      const headers2 = setHeaders(header, this.#preparedHeaders);
      return new Response(data, {
        headers: headers2,
        status: arg.status ?? this.#status
      });
    }
    const status = typeof arg === "number" ? arg : this.#status;
    this.#preparedHeaders ??= {};
    this.#headers ??= new Headers;
    setHeaders(this.#headers, this.#preparedHeaders);
    if (this.#res) {
      this.#res.headers.forEach((v, k) => {
        if (k === "set-cookie") {
          this.#headers?.append(k, v);
        } else {
          this.#headers?.set(k, v);
        }
      });
      setHeaders(this.#headers, this.#preparedHeaders);
    }
    headers ??= {};
    for (const [k, v] of Object.entries(headers)) {
      if (typeof v === "string") {
        this.#headers.set(k, v);
      } else {
        this.#headers.delete(k);
        for (const v2 of v) {
          this.#headers.append(k, v2);
        }
      }
    }
    return new Response(data, {
      status,
      headers: this.#headers
    });
  };
  body = (data, arg, headers) => {
    return typeof arg === "number" ? this.newResponse(data, arg, headers) : this.newResponse(data, arg);
  };
  text = (text2, arg, headers) => {
    if (!this.#preparedHeaders) {
      if (this.#isFresh && !headers && !arg) {
        return new Response(text2);
      }
      this.#preparedHeaders = {};
    }
    this.#preparedHeaders["content-type"] = TEXT_PLAIN;
    return typeof arg === "number" ? this.newResponse(text2, arg, headers) : this.newResponse(text2, arg);
  };
  json = (object, arg, headers) => {
    const body2 = JSON.stringify(object);
    this.#preparedHeaders ??= {};
    this.#preparedHeaders["content-type"] = "application/json; charset=UTF-8";
    return typeof arg === "number" ? this.newResponse(body2, arg, headers) : this.newResponse(body2, arg);
  };
  html = (html3, arg, headers) => {
    this.#preparedHeaders ??= {};
    this.#preparedHeaders["content-type"] = "text/html; charset=UTF-8";
    if (typeof html3 === "object") {
      if (!(html3 instanceof Promise)) {
        html3 = html3.toString();
      }
      if (html3 instanceof Promise) {
        return html3.then((html22) => resolveCallback(html22, HtmlEscapedCallbackPhase.Stringify, false, {})).then((html22) => {
          return typeof arg === "number" ? this.newResponse(html22, arg, headers) : this.newResponse(html22, arg);
        });
      }
    }
    return typeof arg === "number" ? this.newResponse(html3, arg, headers) : this.newResponse(html3, arg);
  };
  redirect = (location, status) => {
    this.#headers ??= new Headers;
    this.#headers.set("Location", location);
    return this.newResponse(null, status ?? 302);
  };
  notFound = () => {
    this.#notFoundHandler ??= () => new Response;
    return this.#notFoundHandler(this);
  };
};

// node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context2, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        if (context2 instanceof Context2) {
          context2.req.routeIndex = i;
        }
      } else {
        handler = i === middleware.length && next || undefined;
      }
      if (!handler) {
        if (context2 instanceof Context2 && context2.finalized === false && onNotFound) {
          res = await onNotFound(context2);
        }
      } else {
        try {
          res = await handler(context2, () => {
            return dispatch(i + 1);
          });
        } catch (err) {
          if (err instanceof Error && context2 instanceof Context2 && onError) {
            context2.error = err;
            res = await onError(err, context2);
            isError = true;
          } else {
            throw err;
          }
        }
      }
      if (res && (context2.finalized === false || isError)) {
        context2.res = res;
      }
      return context2;
    }
  };
};

// node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// node_modules/hono/dist/hono-base.js
var COMPOSED_HANDLER = Symbol("composedHandler");
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    return err.getResponse();
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  router;
  getPath;
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options2 = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          if (typeof handler !== "string") {
            this.addRoute(method, this.#path, handler);
          }
        });
        return this;
      };
    });
    this.on = (method, path2, ...handlers) => {
      for (const p of [path2].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const strict = options2.strict ?? true;
    delete options2.strict;
    Object.assign(this, options2);
    this.getPath = strict ? options2.getPath ?? getPath : getPathNoStrict;
  }
  clone() {
    const clone = new Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.routes = this.routes;
    return clone;
  }
  notFoundHandler = notFoundHandler;
  errorHandler = errorHandler;
  route(path2, app) {
    const subApp = this.basePath(path2);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.addRoute(r.method, r.path, handler);
    });
    return this;
  }
  basePath(path2) {
    const subApp = this.clone();
    subApp._basePath = mergePath(this._basePath, path2);
    return subApp;
  }
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  notFound = (handler) => {
    this.notFoundHandler = handler;
    return this;
  };
  mount(path2, applicationHandler, options2) {
    let replaceRequest;
    let optionHandler;
    if (options2) {
      if (typeof options2 === "function") {
        optionHandler = options2;
      } else {
        optionHandler = options2.optionHandler;
        replaceRequest = options2.replaceRequest;
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options22 = optionHandler(c);
      return Array.isArray(options22) ? options22 : [options22];
    } : (c) => {
      let executionContext = undefined;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path2);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request3) => {
        const url3 = new URL(request3.url);
        url3.pathname = url3.pathname.slice(pathPrefixLength) || "/";
        return new Request(url3, request3);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.addRoute(METHOD_NAME_ALL, mergePath(path2, "*"), handler);
    return this;
  }
  addRoute(method, path2, handler) {
    method = method.toUpperCase();
    path2 = mergePath(this._basePath, path2);
    const r = { path: path2, method, handler };
    this.router.add(method, path2, [handler, r]);
    this.routes.push(r);
  }
  matchRoute(method, path2) {
    return this.router.match(method, path2);
  }
  handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  dispatch(request3, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.dispatch(request3, executionCtx, env, "GET")))();
    }
    const path2 = this.getPath(request3, { env });
    const matchResult = this.matchRoute(method, path2);
    const c = new Context2(request3, {
      path: path2,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.notFoundHandler(c);
        });
      } catch (err) {
        return this.handleError(err, c);
      }
      return res instanceof Promise ? res.then((resolved) => resolved || (c.finalized ? c.res : this.notFoundHandler(c))).catch((err) => this.handleError(err, c)) : res ?? this.notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.notFoundHandler);
    return (async () => {
      try {
        const context3 = await composed(c);
        if (!context3.finalized) {
          throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
        }
        return context3.res;
      } catch (err) {
        return this.handleError(err, c);
      }
    })();
  }
  fetch = (request3, ...rest) => {
    return this.dispatch(request3, rest[1], rest[0], request3.method);
  };
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      if (requestInit !== undefined) {
        input = new Request(input, requestInit);
      }
      return this.fetch(input, Env, executionCtx);
    }
    input = input.toString();
    const path2 = /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`;
    const req = new Request(path2, requestInit);
    return this.fetch(req, Env, executionCtx);
  };
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.dispatch(event.request, event, undefined, event.request.method));
    });
  };
};

// node_modules/hono/dist/router/reg-exp-router/node.js
var compareKey = function(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
};
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
var Node2 = class {
  index;
  varIndex;
  children = Object.create(null);
  insert(tokens, index, paramMap, context3, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.index !== undefined) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.children[regexpStr];
      if (!node) {
        if (Object.keys(this.children).some((k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR)) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.children[regexpStr] = new Node2;
        if (name !== "") {
          node.varIndex = context3.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.varIndex]);
      }
    } else {
      node = this.children[token];
      if (!node) {
        if (Object.keys(this.children).some((k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR)) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.children[token] = new Node2;
      }
    }
    node.insert(restTokens, index, paramMap, context3, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.children[k];
      return (typeof c.varIndex === "number" ? `(${k})@${c.varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.index === "number") {
      strList.unshift(`#${this.index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  context = { varIndex: 0 };
  root = new Node2;
  insert(path2, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0;; ) {
      let replaced = false;
      path2 = path2.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path2.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1;i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1;j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.root.insert(tokens, index, paramAssoc, this.context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (typeof handlerIndex !== "undefined") {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (typeof paramIndex !== "undefined") {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// node_modules/hono/dist/router/reg-exp-router/router.js
var buildWildcardRegExp = function(path2) {
  return wildcardRegExpCache[path2] ??= new RegExp(path2 === "*" ? "" : `^${path2.replace(/\/\*$|([.\\+*[^\]$()])/g, (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)")}\$`);
};
var clearWildcardRegExpCache = function() {
  wildcardRegExpCache = Object.create(null);
};
var buildMatcherFromPreprocessedRoutes = function(routes) {
  const trie2 = new Trie;
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map((route) => [!/\*|\/:/.test(route[0]), ...route]).sort(([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length);
  const staticMap = Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length;i < len; i++) {
    const [pathErrorCheckOnly, path2, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path2] = [handlers.map(([h]) => [h, Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie2.insert(path2, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path2) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = Object.create(null);
      paramCount -= 1;
      for (;paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie2.buildRegExp();
  for (let i = 0, len = handlerData.length;i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length;j < len2; j++) {
      const map2 = handlerData[i][j]?.[1];
      if (!map2) {
        continue;
      }
      const keys = Object.keys(map2);
      for (let k = 0, len3 = keys.length;k < len3; k++) {
        map2[keys[k]] = paramReplacementMap[map2[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
};
var findMiddleware = function(middleware, path2) {
  if (!middleware) {
    return;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path2)) {
      return [...middleware[k]];
    }
  }
  return;
};
var emptyParam = [];
var nullMatcher = [/^$/, [], Object.create(null)];
var wildcardRegExpCache = Object.create(null);
var RegExpRouter = class {
  name = "RegExpRouter";
  middleware;
  routes;
  constructor() {
    this.middleware = { [METHOD_NAME_ALL]: Object.create(null) };
    this.routes = { [METHOD_NAME_ALL]: Object.create(null) };
  }
  add(method, path2, handler) {
    const { middleware, routes } = this;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path2 === "/*") {
      path2 = "*";
    }
    const paramCount = (path2.match(/\/:/g) || []).length;
    if (/\*$/.test(path2)) {
      const re = buildWildcardRegExp(path2);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path2] ||= findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || [];
        });
      } else {
        middleware[method][path2] ||= findMiddleware(middleware[method], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach((p) => re.test(p) && routes[m][p].push([handler, paramCount]));
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path2) || [path2];
    for (let i = 0, len = paths.length;i < len; i++) {
      const path22 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path22] ||= [
            ...findMiddleware(middleware[m], path22) || findMiddleware(middleware[METHOD_NAME_ALL], path22) || []
          ];
          routes[m][path22].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match(method, path2) {
    clearWildcardRegExpCache();
    const matchers = this.buildAllMatchers();
    this.match = (method2, path22) => {
      const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
      const staticMatch = matcher[2][path22];
      if (staticMatch) {
        return staticMatch;
      }
      const match = path22.match(matcher[0]);
      if (!match) {
        return [[], emptyParam];
      }
      const index = match.indexOf("", 1);
      return [matcher[1][index], match];
    };
    return this.match(method, path2);
  }
  buildAllMatchers() {
    const matchers = Object.create(null);
    [...Object.keys(this.routes), ...Object.keys(this.middleware)].forEach((method) => {
      matchers[method] ||= this.buildMatcher(method);
    });
    this.middleware = this.routes = undefined;
    return matchers;
  }
  buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.middleware, this.routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path2) => [path2, r[method][path2]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(...Object.keys(r[METHOD_NAME_ALL]).map((path2) => [path2, r[METHOD_NAME_ALL][path2]]));
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  routers = [];
  routes = [];
  constructor(init) {
    Object.assign(this, init);
  }
  add(method, path2, handler) {
    if (!this.routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.routes.push([method, path2, handler]);
  }
  match(method, path2) {
    if (!this.routes) {
      throw new Error("Fatal error");
    }
    const { routers, routes } = this;
    const len = routers.length;
    let i = 0;
    let res;
    for (;i < len; i++) {
      const router5 = routers[i];
      try {
        routes.forEach((args) => {
          router5.add(...args);
        });
        res = router5.match(method, path2);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router5.match.bind(router5);
      this.routers = [router5];
      this.routes = undefined;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.routes || this.routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.routers[0];
  }
};

// node_modules/hono/dist/router/trie-router/node.js
var Node3 = class {
  methods;
  children;
  patterns;
  order = 0;
  name;
  params = Object.create(null);
  constructor(method, handler, children) {
    this.children = children || Object.create(null);
    this.methods = [];
    this.name = "";
    if (method && handler) {
      const m = Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0, name: this.name };
      this.methods = [m];
    }
    this.patterns = [];
  }
  insert(method, path2, handler) {
    this.name = `${method} ${path2}`;
    this.order = ++this.order;
    let curNode = this;
    const parts = splitRoutingPath(path2);
    const possibleKeys = [];
    for (let i = 0, len = parts.length;i < len; i++) {
      const p = parts[i];
      if (Object.keys(curNode.children).includes(p)) {
        curNode = curNode.children[p];
        const pattern2 = getPattern(p);
        if (pattern2) {
          possibleKeys.push(pattern2[1]);
        }
        continue;
      }
      curNode.children[p] = new Node3;
      const pattern = getPattern(p);
      if (pattern) {
        curNode.patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.children[p];
    }
    if (!curNode.methods.length) {
      curNode.methods = [];
    }
    const m = Object.create(null);
    const handlerSet = {
      handler,
      possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
      name: this.name,
      score: this.order
    };
    m[method] = handlerSet;
    curNode.methods.push(m);
    return curNode;
  }
  gHSets(node3, method, nodeParams, params) {
    const handlerSets = [];
    for (let i = 0, len = node3.methods.length;i < len; i++) {
      const m = node3.methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = Object.create(null);
      if (handlerSet !== undefined) {
        handlerSet.params = Object.create(null);
        handlerSet.possibleKeys.forEach((key) => {
          const processed = processedSet[handlerSet.name];
          handlerSet.params[key] = params[key] && !processed ? params[key] : nodeParams[key] ?? params[key];
          processedSet[handlerSet.name] = true;
        });
        handlerSets.push(handlerSet);
      }
    }
    return handlerSets;
  }
  search(method, path2) {
    const handlerSets = [];
    this.params = Object.create(null);
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path2);
    for (let i = 0, len = parts.length;i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length;j < len2; j++) {
        const node3 = curNodes[j];
        const nextNode = node3.children[part];
        if (nextNode) {
          nextNode.params = node3.params;
          if (isLast === true) {
            if (nextNode.children["*"]) {
              handlerSets.push(...this.gHSets(nextNode.children["*"], method, node3.params, Object.create(null)));
            }
            handlerSets.push(...this.gHSets(nextNode, method, node3.params, Object.create(null)));
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node3.patterns.length;k < len3; k++) {
          const pattern = node3.patterns[k];
          const params = { ...node3.params };
          if (pattern === "*") {
            const astNode = node3.children["*"];
            if (astNode) {
              handlerSets.push(...this.gHSets(astNode, method, node3.params, Object.create(null)));
              tempNodes.push(astNode);
            }
            continue;
          }
          if (part === "") {
            continue;
          }
          const [key, name, matcher] = pattern;
          const child = node3.children[key];
          const restPathString = parts.slice(i).join("/");
          if (matcher instanceof RegExp && matcher.test(restPathString)) {
            params[name] = restPathString;
            handlerSets.push(...this.gHSets(child, method, node3.params, params));
            continue;
          }
          if (matcher === true || matcher instanceof RegExp && matcher.test(part)) {
            if (typeof key === "string") {
              params[name] = part;
              if (isLast === true) {
                handlerSets.push(...this.gHSets(child, method, params, node3.params));
                if (child.children["*"]) {
                  handlerSets.push(...this.gHSets(child.children["*"], method, params, node3.params));
                }
              } else {
                child.params = params;
                tempNodes.push(child);
              }
            }
          }
        }
      }
      curNodes = tempNodes;
    }
    const results = handlerSets.sort((a, b) => {
      return a.score - b.score;
    });
    return [results.map(({ handler, params }) => [handler, params])];
  }
};

// node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  node;
  constructor() {
    this.node = new Node3;
  }
  add(method, path2, handler) {
    const results = checkOptionalParameter(path2);
    if (results) {
      for (const p of results) {
        this.node.insert(method, p, handler);
      }
      return;
    }
    this.node.insert(method, path2, handler);
  }
  match(method, path2) {
    return this.node.search(method, path2);
  }
};

// node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  constructor(options2 = {}) {
    super(options2);
    this.router = options2.router ?? new SmartRouter({
      routers: [new RegExpRouter, new TrieRouter]
    });
  }
};

// node_modules/hono/dist/middleware/cors/index.js
var cors = (options2) => {
  const defaults = {
    origin: "*",
    allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"],
    allowHeaders: [],
    exposeHeaders: []
  };
  const opts = {
    ...defaults,
    ...options2
  };
  const findAllowOrigin = ((optsOrigin) => {
    if (typeof optsOrigin === "string") {
      return () => optsOrigin;
    } else if (typeof optsOrigin === "function") {
      return optsOrigin;
    } else {
      return (origin) => optsOrigin.includes(origin) ? origin : optsOrigin[0];
    }
  })(opts.origin);
  return async function cors2(c, next) {
    function set(key, value) {
      c.res.headers.set(key, value);
    }
    const allowOrigin = findAllowOrigin(c.req.header("origin") || "", c);
    if (allowOrigin) {
      set("Access-Control-Allow-Origin", allowOrigin);
    }
    if (opts.origin !== "*") {
      const existingVary = c.req.header("Vary");
      if (existingVary) {
        set("Vary", existingVary);
      } else {
        set("Vary", "Origin");
      }
    }
    if (opts.credentials) {
      set("Access-Control-Allow-Credentials", "true");
    }
    if (opts.exposeHeaders?.length) {
      set("Access-Control-Expose-Headers", opts.exposeHeaders.join(","));
    }
    if (c.req.method === "OPTIONS") {
      if (opts.maxAge != null) {
        set("Access-Control-Max-Age", opts.maxAge.toString());
      }
      if (opts.allowMethods?.length) {
        set("Access-Control-Allow-Methods", opts.allowMethods.join(","));
      }
      let headers = opts.allowHeaders;
      if (!headers?.length) {
        const requestHeaders = c.req.header("Access-Control-Request-Headers");
        if (requestHeaders) {
          headers = requestHeaders.split(/\s*,\s*/);
        }
      }
      if (headers?.length) {
        set("Access-Control-Allow-Headers", headers.join(","));
        c.res.headers.append("Vary", "Access-Control-Request-Headers");
      }
      c.res.headers.delete("Content-Length");
      c.res.headers.delete("Content-Type");
      return new Response(null, {
        headers: c.res.headers,
        status: 204,
        statusText: c.res.statusText
      });
    }
    await next();
  };
};

// src/auth.ts
var import_jsonwebtoken = __toESM(require_jsonwebtoken(), 1);

// node_modules/hono/dist/helper/factory/index.js
var Factory = class {
  initApp;
  constructor(init) {
    this.initApp = init?.initApp;
  }
  createApp = () => {
    const app = new Hono2;
    if (this.initApp) {
      this.initApp(app);
    }
    return app;
  };
  createMiddleware = (middleware) => middleware;
  createHandlers = (...handlers) => {
    return handlers.filter((handler) => handler !== undefined);
  };
};
var createFactory = (init) => new Factory(init);
var createMiddleware = (middleware) => createFactory().createMiddleware(middleware);

// src/config.ts
import {randomBytes} from "crypto";
var generateRandomSecret = function() {
  return randomBytes(32).toString("hex");
};
async function getSecret() {
  const existingConfig = await database_default.query.config.findFirst({
    columns: { jwtSecret: true }
  });
  if (existingConfig && existingConfig.jwtSecret) {
    return existingConfig.jwtSecret;
  } else {
    const newSecret = generateRandomSecret();
    await database_default.insert(config).values({ id: 1, jwtSecret: newSecret }).onConflictDoUpdate({ target: config.id, set: { jwtSecret: newSecret } });
    return newSecret;
  }
}

// src/auth.ts
var validateToken = createMiddleware(async (c, next) => {
  const token = c.req.header("authorization")?.split(" ")[1];
  if (!token) {
    return c.json({ error: "Unauthorized" }, 401);
  }
  try {
    const user = import_jsonwebtoken.default.verify(token, await getSecret());
    c.set("user", user);
    await next();
  } catch (err) {
    return c.json({ error: "Unauthorized" }, 401);
  }
});
var hashPassword = async (password) => {
  return Bun.password.hash(password);
};
var comparePassword = async (password, hash) => {
  return Bun.password.verify(password, hash);
};
var generateToken = async (user) => {
  return import_jsonwebtoken.default.sign({ id: user.id, username: user.username }, await getSecret());
};
var createUser = async (username, password) => {
  const hashedPassword = await hashPassword(password);
  const user = await database_default.insert(users).values({ username, password: hashedPassword });
  return user;
};

// src/server.ts
var app = new Hono2;
app.use("/api/*", cors());
app.post("/api/token", async (c) => {
  try {
    const { username, password } = await c.req.json();
    const user = await database_default.select().from(users).where(sql`username = ${username}`);
    if (user[0] && await comparePassword(password, user[0].password)) {
      const token = await generateToken(user[0]);
      return c.json({ data: token });
    }
  } catch {
  }
  return c.json({ message: "Invalid credentials." }, 401);
});
app.get("/api/smtp", validateToken, async (c) => {
  const smtpList = await database_default.select().from(smtpServers);
  return c.json({ data: smtpList });
});
app.post("/api/smtp", validateToken, async (c) => {
  const { smtpConfig } = await c.req.json();
  await database_default.insert(smtpServers).values({ smtpConfig });
  return c.json({ data: null });
});
app.put("/api/smtp/:id", validateToken, async (c) => {
  const id = parseInt(c.req.param("id"));
  const { smtpConfig } = await c.req.json();
  await database_default.update(smtpServers).set({ smtpConfig }).where(sql`id = ${id}`);
  return c.json({ data: null });
});
app.delete("/api/senders/:id", validateToken, async (c) => {
  const id = parseInt(c.req.param("id"));
  await database_default.delete(senders).where(sql`id = ${id}`);
  return c.json({ data: null });
});
app.delete("/api/smtp/:id", validateToken, async (c) => {
  const id = parseInt(c.req.param("id"));
  await database_default.delete(smtpServers).where(sql`id = ${id}`);
  return c.json({ data: null });
});
app.get("/api/smtp/:id", validateToken, async (c) => {
  const id = c.req.param("id");
  const smtp = (await database_default.select().from(smtpServers).where(sql`id = ${id}`))[0];
  return c.json({ data: smtp });
});
app.get("/api/senders", validateToken, async (c) => {
  const senderList = await database_default.select().from(senders);
  return c.json({ data: senderList });
});
app.get("/api/senders/:id", validateToken, async (c) => {
  const id = c.req.param("id");
  const sender2 = (await database_default.select().from(senders).where(sql`id = ${id}`))[0];
  return c.json({ data: sender2 });
});
app.post("/api/senders", validateToken, async (c) => {
  const { from, smtpServer, setDefault } = await c.req.json();
  const sender2 = await database_default.insert(senders).values({ from, smtpServer }).returning({ id: senders.id });
  if (setDefault) {
    await database_default.update(config).set({ defaultSender: sender2[0].id });
  }
  return c.json({ data: null });
});
app.put("/api/senders/:id", validateToken, async (c) => {
  const id = c.req.param("id");
  const { from, smtpServer } = await c.req.json();
  await database_default.update(senders).set({ from, smtpServer }).where(sql`id = ${id}`);
  return c.json({ data: null });
});
app.get("/api/unsubscribe/:id", async (c) => {
  const id = parseInt(c.req.param("id"));
  await database_default.update(subscribers).set({ status: "unsubscribed" }).where(sql`id = ${id}`);
  return c.redirect("/unsubscribed");
});
app.get("/api/confirm/:id/:uuid", async (c) => {
  const id = parseInt(c.req.param("id"));
  const uuid2 = c.req.param("uuid");
  await database_default.update(subscribers).set({ status: "subscribed" }).where(sql`id = ${id} and uuid = ${uuid2}`);
  return c.redirect("/confirmed");
});
app.post("/api/subscribe", async (c) => {
  const {
    name,
    email,
    attributes = {},
    confirmed = false
  } = await c.req.json();
  const existingSubscriber = (await database_default.select().from(subscribers).where(sql`email = ${email}`))[0];
  if (existingSubscriber) {
    return c.json({
      data: null,
      message: "Email already subscribed",
      success: false
    });
  }
  const status = confirmed ? "subscribed" : "unconfirmed";
  const sub = (await database_default.insert(subscribers).values({ name, email, attributes, status }).returning({ id: subscribers.id }))[0];
  if (!confirmed) {
    pushEvent({
      type: "ConfirmationEmail",
      sub: sub.id
    });
  }
  return c.json({
    data: null,
    message: "Subscription successful",
    success: true
  });
});
app.post("/api/emails", validateToken, async (c) => {
  const { type, subject, body: body2 } = await c.req.json();
  const user = c.get("user");
  await database_default.insert(emails).values({ type, subject, body: body2, createdBy: user.id });
  return c.json({ data: null });
});
app.get("/api/emails", validateToken, async (c) => {
  const emailList = await database_default.select().from(emails).orderBy(desc(emails.createdAt));
  return c.json({ data: emailList });
});
app.get("/api/emails/:id", validateToken, async (c) => {
  const id = c.req.param("id");
  const email = (await database_default.select().from(emails).where(sql`id = ${id}`))[0];
  return c.json({ data: email });
});
app.delete("/api/emails/:id", validateToken, async (c) => {
  const id = c.req.param("id");
  await database_default.delete(emails).where(sql`id = ${id}`);
  return c.json({ data: null });
});
app.put("/api/emails/:id", validateToken, async (c) => {
  const id = parseInt(c.req.param("id"));
  const { type, subject, body: body2 } = await c.req.json();
  await database_default.update(emails).set({ type, subject, body: body2 }).where(sql`id = ${id}`);
  return c.json({ data: null });
});
app.post("/api/emails/:id/send", validateToken, async (c) => {
  const id = parseInt(c.req.param("id"));
  const { senderId, filter: filter2, time } = await c.req.json();
  await pushEvent({
    type: "SendEmail",
    sender: senderId,
    email: id,
    filter: filter2
  }, time);
  return c.json({ data: null });
});
app.get("/api/subscribers", validateToken, async (c) => {
  const subs = await database_default.select().from(subscribers);
  return c.json({ data: subs });
});
app.get("/api/config", validateToken, async (c) => {
  const configObject = await database_default.select({
    defaultSender: config.defaultSender,
    welcomeEmail: config.welcomeEmail,
    confirmationEmail: config.confirmationEmail,
    siteUrl: config.siteUrl
  }).from(config);
  return c.json({ data: configObject[0] });
});
app.put("/api/config", validateToken, async (c) => {
  const { defaultSender, welcomeEmail, confirmationEmail, siteUrl } = await c.req.json();
  await database_default.update(config).set({ defaultSender, welcomeEmail, confirmationEmail, siteUrl });
  return c.json({ data: null });
});
var server_default = app;

// src/index.ts
async function askQuestion(query2) {
  return new Promise((resolve2) => rl.question(query2, resolve2));
}
async function start() {
  startEventsQueue();
  startSender();
  await migrate(database_default, { migrationsFolder: "./drizzle" });
  Bun.serve(server_default);
}
async function init() {
  console.log("Let's create a user to access Kal.");
  const username = await askQuestion("Enter a username: ");
  let password;
  let confirmPassword;
  do {
    password = await askQuestion("Enter a password: ");
    confirmPassword = password;
  } while (password !== confirmPassword);
  try {
    await createUser(username, password);
    console.log(`User '${username}' created successfully.`);
  } catch (error) {
    console.error("Error creating user:", error);
  }
}
var rl = createInterface({
  input: process.stdin,
  output: process.stdout
});
var program2 = new Command;
program2.command("start").description("Start Kal.").action(start);
program2.command("init").description("Init Kal.").action(init);
program2.parse(process.argv);
